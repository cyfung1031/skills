# Network, Permissions, and Security

A userscript manager is a privilege broker. The source bundles expose permissions for tabs, storage, webRequest, cookies, notifications, downloads, all URLs, scripting/userScripts, offscreen documents, context menus, and extension UI. Agents should treat every network or permission change as security-sensitive.

## Permission decision model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## `@connect` and cross-origin requests

`@connect` is the script-level contract for cross-origin requests. The manager should normalize host rules, compare against the request target origin, apply user settings, and decide whether to allow, deny, or prompt. A browser host permission alone is not enough; the userscript metadata and user policy must also permit the request.

## Security-sensitive surfaces

| Surface | Risk | Review rule |
| --- | --- | --- |
| `GM_xmlhttpRequest` | Cross-origin data exfiltration, credentials misuse | Enforce @connect and sanitize headers. |
| Cookies | Session exposure | Limit by target URL and explicit permission. |
| Downloads | Drive-by files or path confusion | Require user-visible action/policy and safe filenames. |
| `unsafeWindow` | Page can tamper with bridged objects | Keep privileged APIs out of page object graph. |
| `GM_addElement`/`GM_addStyle` | DOM injection side effects | Sanitize where needed and scope cleanup. |
| Resources | Remote code execution through `@require` | Cache, validate update source, warn on new domains. |
| Sync/export | Leaking script values/secrets | Make sensitive value export explicit. |
| Incognito split | Cross-profile leakage | Separate stores and prompts. |

## CSP and injection

Page CSP can break script tag injection while content-script execution may still work. MV3 APIs such as `chrome.scripting` and `chrome.userScripts` have different compatibility and permission requirements. A fix should identify which world the script needs, not blindly switch injection strategy for every script.

## Least-privilege patch checklist

- Does the patch add or broaden manifest permissions?
- Does it expose a new background command reachable from page/content/UI?
- Does it validate script ID, tab ID, frame ID, and URL before acting?
- Does it serialize errors without exposing internal secrets?
- Does it keep user prompts understandable and reversible?
