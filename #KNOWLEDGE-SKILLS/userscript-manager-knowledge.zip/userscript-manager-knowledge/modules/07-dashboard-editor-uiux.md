# Dashboard, Editor, Popup, and Settings UI/UX

The inspected source bundles include action/popup pages, options/dashboard pages, editor bundles, CSS, localization catalogs, onboarding/help strings, import/export views, update UI, and permission prompts. A userscript manager UI must support both novice and expert workflows without hiding security impact.

## Primary UI surfaces

| Surface | User goal | Design requirements |
| --- | --- | --- |
| Popup/action | See current tab status, run scripts, toggle manager, access dashboard. | Fast load, current-tab context, compact explanation, keyboard command support. |
| Dashboard/options | List, search, tag, sort, enable/disable, update, delete, configure scripts. | Scalable list, bulk actions, status badges, undo/trash, clear filters. |
| Editor | Create/edit source, inspect metadata, lint/format, save/update. | Dirty-state visibility, autosave or explicit save, conflict handling, line/column diagnostics. |
| Install prompt | Review a new userscript before installation. | Show source URL, metadata, grants, match rules, connect hosts, update URL, warnings. |
| Permission prompt | Approve network/host/download/cookie actions. | Explain script, target, reason, remember choices, allow/deny options. |
| Import/export | Move scripts/settings across devices. | Dry run, conflict preview, progress, recovery, privacy filter. |


```ts
interface DashboardViewState {
  searchQuery: string;
  selectedTagNames: string[];
  visibleScripts: ScriptListItemViewModel[];
  selectedScriptId?: ScriptIdentifier;
  editorDirtyState: 'clean' | 'dirty' | 'saving' | 'conflict';
  permissionPrompts: PermissionPromptViewModel[];
  importExportProgress?: TransferProgressViewModel;
  activeToastMessages: ToastViewModel[];
}

function buildScriptListItemViewModel(scriptRecord: StoredUserscriptRecord): ScriptListItemViewModel {
  return {
    id: scriptRecord.id,
    title: scriptRecord.metadata.scriptName,
    subtitle: scriptRecord.metadata.description ?? scriptRecord.metadata.namespace,
    enabled: scriptRecord.enabled,
    version: scriptRecord.metadata.version,
    updateStatus: deriveUpdateBadge(scriptRecord),
    warningCount: countMetadataWarnings(scriptRecord.metadata),
    lastRunStatus: scriptRecord.lastRunStatus ?? 'not-run-yet',
  };
}
```


## UI state principles

- Keep long-running operations visible: update check, import, export, resource download, linting, sync.
- Never hide destructive operations behind icon-only controls.
- Show the script name and target URL in security decisions.
- Keep list filters, selected script, and editor dirty state separate.
- Localize technical terms consistently: script, userscript, match, grant, permission, connect, update, sync.

## Editor review checklist

- Does the editor parse metadata live without destroying the user's source formatting?
- Are lint warnings linked to source ranges and human-readable messages?
- Can a user recover unsaved edits after navigation or extension reload?
- Are keyboard shortcuts discoverable and non-conflicting with browser shortcuts?
- Are theme and high-contrast states usable in both dashboard and editor?
