# Storage, Sync, Import, and Export

Userscript managers store more than script source. They manage metadata, cached external resources, per-script values, UI preferences, update state, tags, trash state, enabled state, and sometimes cloud-sync state. Mixing these concerns creates migration bugs.

## Storage layers

| Layer | Stores | Requirements |
| --- | --- | --- |
| Script repository | source code, parsed metadata, enabled flag, install/update data | atomic replacement, versioned schema, rollback. |
| Value store | user script data written through GM_getValue/GM_setValue | namespace isolation, event listeners, type serialization. |
| Resource cache | `@require` and `@resource` fetched content | URL, integrity/mime metadata, cache invalidation. |
| UI preferences | filters, editor settings, themes, layout, sort mode | user-scoped, safe defaults, migration. |
| Sync/export | serialized records for backup or cloud | conflict resolution, schema version, privacy filter. |

## Readable repository pattern

```ts
interface ScriptRepository {
  listScripts(filter: ScriptListFilter): Promise<StoredUserscriptRecord[]>;
  getScript(scriptId: ScriptIdentifier): Promise<StoredUserscriptRecord | undefined>;
  saveNewScript(newScript: NewUserscriptInput): Promise<StoredUserscriptRecord>;
  replaceScriptSource(update: ReplaceScriptSourceInput): Promise<StoredUserscriptRecord>;
  setEnabled(scriptId: ScriptIdentifier, enabled: boolean): Promise<void>;
  moveToTrash(scriptId: ScriptIdentifier): Promise<void>;
  restoreFromTrash(scriptId: ScriptIdentifier): Promise<void>;
  permanentlyDelete(scriptId: ScriptIdentifier): Promise<void>;
}
```

## Sync conflict model

Resolve conflicts by comparing logical script identity, source hash, metadata version, local modification time, and user-edited state. Never assume a remote update should overwrite a locally dirty editor buffer. If conflict resolution is automatic, retain a recoverable copy.

## Import/export checklist

- Include schema version and manager name in the archive metadata.
- Preserve script IDs only when safe; otherwise map old IDs to new IDs.
- Keep per-script values namespaced and optional.
- Avoid exporting transient runtime ports, active requests, or page context.
- Warn before importing scripts with broader permissions, host access, or connect hosts.
- Support dry-run validation before mutating the current profile.
