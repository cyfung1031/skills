# Universal Coding Models

This module gives readable, universal code shapes for userscript-manager work. The examples are intentionally not copied from bundled source. They use meaningful names and stable domain concepts so agents and humans can reason about design and patches.

## Core type model


```ts
type ScriptIdentifier = string;
type FrameIdentifier = string;
type TabIdentifier = number;
type UrlString = string;

type UserscriptRunAt =
  | 'document-start'
  | 'document-body'
  | 'document-end'
  | 'document-idle'
  | 'context-menu';

type UserscriptSandboxMode =
  | 'isolatedWorld'
  | 'mainWorld'
  | 'userscriptWorld'
  | 'contentScriptBridge'
  | 'offscreenHelper';

interface UserscriptMetadata {
  scriptName: string;
  namespace: string;
  version: string;
  description?: string;
  author?: string;
  matchRules: MatchRule[];
  includeRules: MatchRule[];
  excludeRules: MatchRule[];
  grantedApis: GmApiGrant[];
  allowedConnectHosts: HostPermissionRule[];
  requiredResources: ExternalResourceReference[];
  requiredLibraries: ExternalLibraryReference[];
  runAt: UserscriptRunAt;
  noFrames: boolean;
  updateUrl?: UrlString;
  downloadUrl?: UrlString;
}

interface StoredUserscriptRecord {
  id: ScriptIdentifier;
  metadata: UserscriptMetadata;
  sourceCode: string;
  enabled: boolean;
  installSourceUrl?: UrlString;
  lastUpdatedAt: number;
  lastRunStatus?: ScriptRunStatus;
  userOptions: UserscriptUserOptions;
  resources: Record<string, CachedResourceRecord>;
  valueStoreNamespace: string;
}

interface ScriptExecutionContext {
  scriptId: ScriptIdentifier;
  tabId: TabIdentifier;
  frameId: FrameIdentifier;
  pageUrl: UrlString;
  topFrameUrl: UrlString;
  runAt: UserscriptRunAt;
  sandboxMode: UserscriptSandboxMode;
  grantedApis: Set<GmApiGrant>;
  allowedConnectHosts: HostPermissionRule[];
  incognitoMode: boolean;
  isTopFrame: boolean;
}

interface RuntimeMessageEnvelope<Payload> {
  messageId: string;
  senderContext: 'background' | 'content' | 'page' | 'offscreen' | 'dashboard' | 'editor';
  targetContext: 'background' | 'content' | 'page' | 'offscreen' | 'dashboard' | 'editor';
  commandName: string;
  scriptId?: ScriptIdentifier;
  tabId?: TabIdentifier;
  frameId?: FrameIdentifier;
  payload: Payload;
  expectsResponse: boolean;
  createdAt: number;
}

interface PermissionDecision {
  decision: 'allow' | 'deny' | 'askUser' | 'useCachedDecision';
  reason: string;
  requiredPermission: string;
  requestingScriptId?: ScriptIdentifier;
  requestingUrl?: UrlString;
  rememberDecision: boolean;
}
```


## Service container

```ts
interface UserscriptManagerServices {
  scriptRepository: ScriptRepository;
  metadataParser: UserscriptMetadataParser;
  matchEngine: UserscriptMatchEngine;
  injectionPlanner: ScriptInjectionPlanner;
  permissionService: PermissionDecisionService;
  networkGateway: UserscriptNetworkGateway;
  valueStore: UserscriptValueStore;
  resourceCache: UserscriptResourceCache;
  commandRegistry: RuntimeCommandRegistry;
  notificationService: UserNotificationService;
  auditLogger: UserscriptAuditLogger;
}
```

## Named function patterns


```ts
function parseUserscriptMetadataBlock(sourceCode: string): UserscriptMetadataParseResult {
  const headerBlock = extractDelimitedMetadataHeader(sourceCode);
  const parsedDirectives = parseMetadataDirectives(headerBlock.lines);
  const normalizedRules = normalizeMatchIncludeExcludeRules(parsedDirectives);
  const grantedApis = resolveGrantList(parsedDirectives.grantDirectives);
  const allowedConnectHosts = resolveConnectPermissionRules(parsedDirectives.connectDirectives);

  return {
    metadata: {
      scriptName: requireDirective(parsedDirectives, 'name'),
      namespace: optionalDirective(parsedDirectives, 'namespace') ?? 'user-script',
      version: optionalDirective(parsedDirectives, 'version') ?? '0.0.0',
      description: optionalDirective(parsedDirectives, 'description'),
      matchRules: normalizedRules.matchRules,
      includeRules: normalizedRules.includeRules,
      excludeRules: normalizedRules.excludeRules,
      grantedApis,
      allowedConnectHosts,
      requiredResources: collectResourceReferences(parsedDirectives),
      requiredLibraries: collectRequiredLibraries(parsedDirectives),
      runAt: resolveRunAt(parsedDirectives),
      noFrames: hasBooleanDirective(parsedDirectives, 'noframes'),
      updateUrl: optionalDirective(parsedDirectives, 'updateURL'),
      downloadUrl: optionalDirective(parsedDirectives, 'downloadURL'),
    },
    warnings: buildMetadataWarnings(parsedDirectives),
    errors: buildMetadataErrors(parsedDirectives),
  };
}
```



```ts
function selectRunnableScriptsForFrame(
  installedScripts: StoredUserscriptRecord[],
  frameContext: BrowserFrameContext,
): RunnableUserscript[] {
  return installedScripts
    .filter(scriptRecord => scriptRecord.enabled)
    .filter(scriptRecord => frameMatchesFramePolicy(scriptRecord.metadata, frameContext))
    .filter(scriptRecord => urlMatchesScriptRules(scriptRecord.metadata, frameContext.pageUrl))
    .filter(scriptRecord => !urlIsExcludedByScriptRules(scriptRecord.metadata, frameContext.pageUrl))
    .map(scriptRecord => buildRunnableUserscript(scriptRecord, frameContext))
    .sort(compareScriptsByPositionAndInstallOrder);
}
```



```ts
async function routeRuntimeMessage<Payload>(
  envelope: RuntimeMessageEnvelope<Payload>,
  services: UserscriptManagerServices,
): Promise<RuntimeMessageResponse> {
  assertKnownSender(envelope.senderContext);
  assertExpectedTarget(envelope.targetContext, 'background');
  assertCommandIsRegistered(envelope.commandName);

  const commandHandler = services.commandRegistry.get(envelope.commandName);
  const permissionDecision = await services.permissionService.authorizeCommand(envelope);
  if (permissionDecision.decision === 'deny') {
    return buildDeniedResponse(envelope, permissionDecision.reason);
  }

  const commandResult = await commandHandler.handle(envelope.payload, buildCommandContext(envelope));
  return buildSuccessfulResponse(envelope, commandResult);
}
```



```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```



```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```



```ts
async function updateInstalledUserscript(
  scriptRecord: StoredUserscriptRecord,
  services: UserscriptManagerServices,
): Promise<ScriptUpdateResult> {
  const candidateSource = await services.updateFetcher.fetchCandidateSource(scriptRecord.metadata);
  const candidateMetadata = parseUserscriptMetadataBlock(candidateSource).metadata;
  assertUpdateBelongsToSameScript(scriptRecord.metadata, candidateMetadata);
  assertUpdateVersionIsNewerOrAllowed(scriptRecord.metadata.version, candidateMetadata.version);

  const requiredResources = await services.resourceCache.fetchResources(candidateMetadata);
  const migratedValueStore = await services.valueStore.prepareMigration(scriptRecord, candidateMetadata);
  return services.scriptRepository.replaceScriptSource({
    existingScriptId: scriptRecord.id,
    sourceCode: candidateSource,
    metadata: candidateMetadata,
    resources: requiredResources,
    migratedValueStore,
  });
}
```


## Naming advice

Use nouns for durable records (`StoredUserscriptRecord`, `CachedResourceRecord`, `PermissionDecision`), verbs for commands (`parseUserscriptMetadataBlock`, `selectRunnableScriptsForFrame`, `requestThroughBackgroundNetworkGateway`), and explicit context names (`ScriptExecutionContext`, `BrowserFrameContext`, `RuntimeMessageEnvelope`). Avoid names like `data`, `info`, `obj`, `e`, `r`, and `handler` in new or explanatory code.
