# Metadata and Linting

Metadata is the highest-leverage part of userscript compatibility. Linting must understand both JavaScript syntax and userscript-specific directives. The inspected packages include lint workers and metadata validation logic, showing that agents should not rely on generic JavaScript linting alone.

## Important metadata directives

| Directive | Observed mentions | Role |
| --- | --- | --- |
| name | 182 | policy/display/lifecycle directive |
| namespace | 92 | policy/display/lifecycle directive |
| version | 23 | policy/display/lifecycle directive |
| description | 10 | policy/display/lifecycle directive |
| author | 12 | policy/display/lifecycle directive |
| match | 179 | policy/display/lifecycle directive |
| include | 191 | policy/display/lifecycle directive |
| exclude | 115 | policy/display/lifecycle directive |
| exclude-match | 30 | policy/display/lifecycle directive |
| require | 113 | policy/display/lifecycle directive |
| resource | 49 | policy/display/lifecycle directive |
| grant | 120 | policy/display/lifecycle directive |
| connect | 163 | policy/display/lifecycle directive |
| run-at | 50 | policy/display/lifecycle directive |
| run-in | 0 | policy/display/lifecycle directive |
| sandbox | 30 | policy/display/lifecycle directive |
| noframes | 1 | policy/display/lifecycle directive |
| unwrap | 1 | policy/display/lifecycle directive |
| icon | 6 | policy/display/lifecycle directive |
| iconURL | 0 | policy/display/lifecycle directive |
| icon64 | 0 | policy/display/lifecycle directive |
| icon64URL | 0 | policy/display/lifecycle directive |
| defaulticon | 0 | policy/display/lifecycle directive |
| downloadURL | 35 | policy/display/lifecycle directive |
| updateURL | 0 | policy/display/lifecycle directive |
| homepage | 0 | policy/display/lifecycle directive |
| homepageURL | 0 | policy/display/lifecycle directive |
| supportURL | 0 | policy/display/lifecycle directive |
| website | 0 | policy/display/lifecycle directive |
| license | 2 | policy/display/lifecycle directive |
| copyright | 2 | policy/display/lifecycle directive |
| antifeature | 0 | policy/display/lifecycle directive |
| tag | 47 | policy/display/lifecycle directive |
| compatible | 0 | policy/display/lifecycle directive |
| incompatible | 0 | policy/display/lifecycle directive |

## Validation areas

| Area | Examples | Agent action |
| --- | --- | --- |
| Required identity | `@name`, `@namespace`, `@version` | Warn or error according to install/update flow. |
| URL targeting | `@match`, `@include`, `@exclude` | Normalize, validate grammar, explain precedence. |
| Execution timing | `@run-at`, `@noframes` | Map to explicit `UserscriptRunAt` and frame policy. |
| Privileges | `@grant`, `@connect` | Build grant set and connect policy. |
| External dependencies | `@require`, `@resource` | Fetch/cache atomically and warn on domain changes. |
| Update metadata | `@updateURL`, `@downloadURL` | Validate ownership and update safety. |
| Display metadata | icon, description, author, support/homepage | Sanitize and localize UI display. |

## Readable linter model

```ts
interface MetadataDiagnostic {
  severity: 'info' | 'warning' | 'error';
  directiveName?: string;
  sourceRange?: SourceRange;
  message: string;
  suggestedFix?: string;
}

function lintUserscriptMetadata(metadata: UserscriptMetadata): MetadataDiagnostic[] {
  return [
    ...validateIdentityDirectives(metadata),
    ...validateUrlTargetingRules(metadata),
    ...validateGrantAndApiUsage(metadata),
    ...validateConnectRules(metadata),
    ...validateExternalResources(metadata),
    ...validateUpdateUrls(metadata),
  ];
}
```

## Compatibility guidance

Do not silently auto-add grants just because source code mentions a GM API. Prefer a diagnostic that says which API was detected and which `@grant` line is needed. Auto-fixes are useful only when they are reviewable in the editor.
