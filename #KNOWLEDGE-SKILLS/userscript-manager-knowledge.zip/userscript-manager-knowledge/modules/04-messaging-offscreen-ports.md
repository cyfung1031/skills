# Messaging, Offscreen Documents, and Ports

Userscript managers rely on multiple communication layers: page `postMessage`, content-script listeners, extension runtime messages, long-lived ports, worker messages, and offscreen-document messages. Bugs often appear as silent hangs because one layer returns before the next layer resolves.

## Message envelope model


```ts
async function routeRuntimeMessage<Payload>(
  envelope: RuntimeMessageEnvelope<Payload>,
  services: UserscriptManagerServices,
): Promise<RuntimeMessageResponse> {
  assertKnownSender(envelope.senderContext);
  assertExpectedTarget(envelope.targetContext, 'background');
  assertCommandIsRegistered(envelope.commandName);

  const commandHandler = services.commandRegistry.get(envelope.commandName);
  const permissionDecision = await services.permissionService.authorizeCommand(envelope);
  if (permissionDecision.decision === 'deny') {
    return buildDeniedResponse(envelope, permissionDecision.reason);
  }

  const commandResult = await commandHandler.handle(envelope.payload, buildCommandContext(envelope));
  return buildSuccessfulResponse(envelope, commandResult);
}
```


A message envelope should carry sender, target, command name, script ID, tab ID, frame ID, payload, response expectation, and a creation timestamp. This makes logs searchable and prevents ambiguous command handling.

## Common channels

| Channel | Good for | Avoid |
| --- | --- | --- |
| Page `window.postMessage` | page-world to content-world bridge | privileged payloads without origin/context checks. |
| `chrome.runtime.sendMessage` | one-shot requests to background | streaming progress, long downloads, many events. |
| `chrome.runtime.connect` ports | value-change listeners, XHR progress, editor sessions | durable state without reconnect handling. |
| Worker `postMessage` | linting, TypeScript/Monaco services, parsing | direct DOM or browser-extension APIs. |
| Offscreen document messages | DOMParser, Blob URL, download helper, long network fallback | duplicate offscreen creation, unbounded task maps. |

## Offscreen helper lifecycle

A robust offscreen service should create the document only when needed, keep a reference-counted task registry, reuse an existing document when possible, close it when idle, and retry idempotent requests if service-worker suspension interrupted the response. Store enough task metadata to explain the operation in logs without exposing script secrets.

## Debugging stuck messages

1. Confirm the page bridge emitted the command with a message ID.
2. Confirm the content script received it in the expected frame.
3. Confirm the background listener returned `true` or a promise where required by the browser API.
4. Confirm the command handler exists and passes permission checks.
5. Confirm offscreen work was created, completed, and responded.
6. Confirm the response was serialized into the callback/promise shape expected by the userscript API.

## Naming convention

Use command names like `scriptValue.get`, `networkRequest.start`, `networkRequest.abort`, `menuCommand.register`, `resource.getText`, `scriptUpdate.check`, and `dashboard.scriptToggle`. Avoid anonymous numeric command codes in new work.
