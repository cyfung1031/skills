# Complete Userscript Manager UI/UX Design

A complete userscript manager UI must help the user answer five questions: what scripts do I have, where do they run, what privileges do they use, what changed recently, and what can I safely do next?

## Information architecture

| Area | Screen/components | Required content |
| --- | --- | --- |
| Current tab | Popup, status badge, per-tab script list | Enabled/disabled manager state, scripts running on current URL, quick toggles, dashboard link. |
| Script library | Dashboard list, tags, search, filters, bulk actions | Name, version, enabled state, update status, warnings, match summary, last modified. |
| Script detail | Overview panel, metadata panel, permissions panel, resource panel | Exact match/include/exclude, grants, connect hosts, update/download URLs, resource URLs. |
| Editor | Code editor, metadata diagnostics, diff/update review, save controls | Source, lint findings, dirty state, formatting, version conflicts, rollback. |
| Install/update review | Permission diff, source origin, metadata diff, dependency diff | New grants, new connect hosts, new resources, changed match scope, downgrade warning. |
| Settings | General, security, sync, editor, appearance, backup | Defaults, warnings, sync status, import/export, keyboard shortcuts, localization. |
| Diagnostics | Logs, recent failures, support export | Script ID, tab/frame URL, stage, message ID, permission decision, error. |

## UX principles

- Security prompts must name the script and the target host.
- Install and update flows should show permission expansion as a diff.
- The dashboard should have a trash/recovery path for deletions.
- Expert features can be collapsible, but not invisible during risky changes.
- UI labels should use the same terms as metadata and diagnostics.
- Empty states should teach the next action: create, install, import, or enable.

## Accessible UI states

Every status should have at least two signals, for example text plus icon, not color alone. Keyboard users need focus order through list, detail, editor, dialogs, and permission prompts. Screen-reader labels should avoid jargon-only phrasing like "GM XHR" unless expanded nearby.

## Destructive actions

Deleting scripts, clearing values, overwriting local edits, importing conflicting backups, and accepting broader permissions should use confirmation or staged review. Bulk actions need a count and a visible scope summary.
