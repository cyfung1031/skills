# Extension Architecture

A userscript manager is a browser extension whose core purpose is to run user-owned JavaScript on selected pages while keeping privileged browser APIs behind an explicit policy boundary. The inspected source packages show both Manifest V2 and Manifest V3 designs, so agents must reason about runtime context before changing code.

## Runtime contexts

| Context | Responsibility | Typical files from inspected packages | Failure modes |
| --- | --- | --- | --- |
| Manifest | Declares permissions, entry points, commands, host scope, background model, options/popup pages, localization, and managed policy schema. | `manifest.json` | Missing permission, wrong MV version assumption, host scope too broad/narrow, command not wired. |
| Background service worker or event page | Durable coordinator for installation, storage, update checks, menu commands, network gateways, script matching, and privileged browser APIs. | `background.js`, `background/index.js`, `service_worker.js` | MV3 suspension loses transient state; listener not registered at top level; async response not kept alive. |
| Content script | Enters every eligible tab/frame and creates the communication bridge between page, isolated world, and background. | `content.js`, `injected.js` | Wrong run_at, iframe mismatch, page-navigation race, message origin leak. |
| Page-world runtime | Provides userscript globals in the same JavaScript realm as the page when required. | `page.js`, `injected-web.js`, sandbox scripts | unsafeWindow proxy bug, grant leakage, CSP/injection failure. |
| Offscreen document | Performs DOM-bound or long-running work unavailable to the service worker. | `offscreen.js`, `offscreen.html` | Not created before use, duplicate document, unclosed task, response lost on suspension. |
| Dashboard/options/popup | Lets users manage scripts, settings, permissions, updates, backups, and current-tab actions. | `extension.js`, `options/index.js`, `popup/index.js`, `action.html` | stale view state, destructive action without recovery, unreadable permission prompt. |
| Editor/lint workers | Edits source, validates metadata, provides syntax/lint/format features. | `editor.js`, `lint.js`, workers, CodeMirror/Monaco libs | worker path bug, linter version mismatch, dirty-state loss. |

## Architecture rule of thumb

Never let a userscript call browser APIs directly. The page runtime should call a local bridge, the content script should forward the request with frame context, and the background should verify grants, host permissions, and user policy before doing privileged work.

## Readable high-level flow

```text
Browser loads extension manifest
  -> Background registers top-level listeners and restores durable state
  -> Content script enters matching pages/frames at document_start or configured run_at
  -> Content script asks background which scripts apply to this frame URL
  -> Background returns runnable script descriptors with grants and cached resources
  -> Content script injects or evaluates the script in the selected sandbox/world
  -> Page runtime exposes grant-gated GM APIs
  -> GM calls travel page -> content -> background -> optional offscreen -> response
  -> Dashboard/options/editor mutate durable script records and notify active contexts
```

## MV3-specific concerns

Manifest V3 service workers can be suspended. Agents should avoid designs that require in-memory maps to survive navigation, downloads, XHR progress, update checks, or open editor sessions. Store durable state in a repository, correlate messages with explicit IDs, recreate offscreen helpers lazily, and make ports reconnectable.

## Code review invariant

Any patch touching context boundaries must answer five questions: who initiated the action, which script ID owns it, which tab/frame URL it came from, which grant/permission authorizes it, and how the response/error is serialized back to the caller.
