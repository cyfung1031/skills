# Userscript Lifecycle

The lifecycle spans source acquisition, metadata parsing, validation, installation, resource fetching, update checking, matching, execution, storage migration, UI management, and deletion. Treat it as a state machine rather than a collection of independent features.

## Lifecycle stages

| Stage | Agent mental model | Important persisted data | Common bugs |
| --- | --- | --- | --- |
| Discover | User opens a `.user.js` URL, imports a backup, creates a blank script, or receives a sync record. | candidate URL, candidate source, origin metadata | wrong content-type, duplicate detection missed, install prompt lacks origin. |
| Parse | Extract the metadata block and normalize directive values. | metadata, warnings, errors | header not detected, duplicated keys mishandled, @match grammar misread. |
| Validate | Lint source and metadata before persistence or update. | lint diagnostics, compatibility warnings | treating warnings as fatal, missing grant warning, bad URL pattern accepted. |
| Install | Persist source, metadata, resources, settings, and initial value namespace. | script record, resource cache, install timestamp | partial install leaves orphan resources, update URL not stored. |
| Match | Determine whether a script applies to a tab/frame URL. | match/include/exclude rules, noframes, enabled flag | include/exclude precedence wrong, iframe policy ignored, scheme mismatch. |
| Execute | Build execution context and run at the requested timing. | run-at, sandbox mode, grants, resources | document-start race, wrong world, resources unavailable. |
| Update | Fetch update metadata and/or full source, compare versions, replace safely. | previous metadata, candidate metadata, backup copy | downgrade, namespace/name mismatch, user edits overwritten silently. |
| Manage | Enable, disable, sort, tag, search, edit, delete, trash, restore. | user preferences, list order, tags, trash marker | destructive action without undo, UI stale after background update. |
| Export/import | Convert records to backup format and restore on another profile/device. | source, values, options, resources, version | incompatible schema, duplicated IDs, secrets leaked in plaintext. |

## Metadata is executable policy

A metadata header controls where the script runs, when it runs, what privileged APIs it may call, what external resources it can load, and what hosts cross-origin requests may contact. Never treat metadata as display-only comments.


```ts
function parseUserscriptMetadataBlock(sourceCode: string): UserscriptMetadataParseResult {
  const headerBlock = extractDelimitedMetadataHeader(sourceCode);
  const parsedDirectives = parseMetadataDirectives(headerBlock.lines);
  const normalizedRules = normalizeMatchIncludeExcludeRules(parsedDirectives);
  const grantedApis = resolveGrantList(parsedDirectives.grantDirectives);
  const allowedConnectHosts = resolveConnectPermissionRules(parsedDirectives.connectDirectives);

  return {
    metadata: {
      scriptName: requireDirective(parsedDirectives, 'name'),
      namespace: optionalDirective(parsedDirectives, 'namespace') ?? 'user-script',
      version: optionalDirective(parsedDirectives, 'version') ?? '0.0.0',
      description: optionalDirective(parsedDirectives, 'description'),
      matchRules: normalizedRules.matchRules,
      includeRules: normalizedRules.includeRules,
      excludeRules: normalizedRules.excludeRules,
      grantedApis,
      allowedConnectHosts,
      requiredResources: collectResourceReferences(parsedDirectives),
      requiredLibraries: collectRequiredLibraries(parsedDirectives),
      runAt: resolveRunAt(parsedDirectives),
      noFrames: hasBooleanDirective(parsedDirectives, 'noframes'),
      updateUrl: optionalDirective(parsedDirectives, 'updateURL'),
      downloadUrl: optionalDirective(parsedDirectives, 'downloadURL'),
    },
    warnings: buildMetadataWarnings(parsedDirectives),
    errors: buildMetadataErrors(parsedDirectives),
  };
}
```


## Matching and scheduling


```ts
function selectRunnableScriptsForFrame(
  installedScripts: StoredUserscriptRecord[],
  frameContext: BrowserFrameContext,
): RunnableUserscript[] {
  return installedScripts
    .filter(scriptRecord => scriptRecord.enabled)
    .filter(scriptRecord => frameMatchesFramePolicy(scriptRecord.metadata, frameContext))
    .filter(scriptRecord => urlMatchesScriptRules(scriptRecord.metadata, frameContext.pageUrl))
    .filter(scriptRecord => !urlIsExcludedByScriptRules(scriptRecord.metadata, frameContext.pageUrl))
    .map(scriptRecord => buildRunnableUserscript(scriptRecord, frameContext))
    .sort(compareScriptsByPositionAndInstallOrder);
}
```


The matching order should be easy to audit: disabled scripts are skipped first, frame policy next, positive URL rules next, exclude rules last, then scripts are ordered by user-defined position or install order. Any change to this ordering can break user expectations.

## Update safety checklist

- Keep the old source and metadata until the new version validates.
- Confirm that update metadata still belongs to the same logical script.
- Do not erase user-local values when source updates.
- Re-fetch `@require` and `@resource` entries atomically with the candidate script.
- Surface permission expansion, grant expansion, or new `@connect` hosts before applying the update.
- Preserve user-disabled state across updates.


```ts
async function updateInstalledUserscript(
  scriptRecord: StoredUserscriptRecord,
  services: UserscriptManagerServices,
): Promise<ScriptUpdateResult> {
  const candidateSource = await services.updateFetcher.fetchCandidateSource(scriptRecord.metadata);
  const candidateMetadata = parseUserscriptMetadataBlock(candidateSource).metadata;
  assertUpdateBelongsToSameScript(scriptRecord.metadata, candidateMetadata);
  assertUpdateVersionIsNewerOrAllowed(scriptRecord.metadata.version, candidateMetadata.version);

  const requiredResources = await services.resourceCache.fetchResources(candidateMetadata);
  const migratedValueStore = await services.valueStore.prepareMigration(scriptRecord, candidateMetadata);
  return services.scriptRepository.replaceScriptSource({
    existingScriptId: scriptRecord.id,
    sourceCode: candidateSource,
    metadata: candidateMetadata,
    resources: requiredResources,
    migratedValueStore,
  });
}
```
