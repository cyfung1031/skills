# Debugging and Issue Fixing

Userscript-manager issues are best debugged by walking the pipeline: install state, metadata parsing, matching, frame selection, timing, sandbox injection, GM bridge, background permission handling, offscreen work, and UI presentation. Do not start by editing the page runtime until matching and grants are proven correct.

## Symptom-first triage

| Symptom | First checks | Likely fix area |
| --- | --- | --- |
| Script does not run | enabled flag, match/include/exclude, iframe policy, run-at, tab URL scheme | lifecycle, matcher, content bridge. |
| GM API is undefined | metadata grants, grant aliases, sandbox bridge construction | GM API bridge, metadata linter. |
| XHR/fetch fails | @connect, host permissions, request headers, credentials, offscreen fallback | network gateway, permission prompt. |
| Menu command missing | grant, registration timing, frame cleanup, popup/context menu state | GM menu command registry. |
| Value change listener not firing | namespace, port lifetime, serialization, background listener map | value store and ports. |
| Update check fails | updateURL/downloadURL, redirects, version compare, metadata mismatch | update fetcher and parser. |
| Editor loses edits | dirty state, navigation guard, worker crash, save conflict | editor view model and repository. |
| Import duplicates scripts | identity mapping, namespace/name/version, existing IDs | import planner. |
| MV3 intermittently fails | service-worker suspension, missing top-level listener, offscreen lifecycle | MV3 architecture. |

## Minimal reproducible diagnosis template

```text
Script name:
Manager version/browser:
Page URL and frame URL:
Top frame or iframe:
Metadata @match/@include/@exclude:
Metadata @grant and @connect:
Expected run-at:
Observed console/log output:
Which pipeline stage is proven working:
Which stage first fails:
```

## Debugging invariant

Every issue should be reduced to one failing boundary: source-to-metadata, metadata-to-script-record, script-record-to-match, match-to-execution-context, execution-context-to-injection, userscript-to-GM-bridge, GM-bridge-to-background, background-to-browser/offscreen, or browser/offscreen-to-response.
