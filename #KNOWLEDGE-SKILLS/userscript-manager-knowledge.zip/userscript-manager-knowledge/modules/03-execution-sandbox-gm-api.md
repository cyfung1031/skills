# Execution, Sandbox, and GM API

Userscript execution is the highest-risk part of the system because it mixes user code, page code, browser-extension privileges, and asynchronous message passing. The inspected packages all separate policy from execution, although the exact MV2/MV3 mechanism differs.

## Execution worlds

| World | Meaning | Use when | Risk |
| --- | --- | --- | --- |
| Isolated extension/content world | Script runs with content-script isolation, not true page global identity. | safer default for many scripts | Page variables are not directly visible. |
| Main/page world | Script shares the page's JavaScript global object. | compatibility with scripts expecting page globals | Higher exposure to page tampering and CSP/injection issues. |
| Browser `userScripts` world | Browser-provided userScripts API world. | MV3-capable controlled injection | API availability and behavior differ by browser/version. |
| Sandbox page/iframe | Extension-owned sandboxed environment. | evaluating helper logic or isolating untrusted parsing | Bridge and resource access complexity. |
| Offscreen helper | Hidden document used by background. | DOMParser, download helpers, blob URLs, some network flows | Lifecycle and concurrency bugs. |

## Run timing

A script not running is often a timing bug, not a matching bug. Check `document-start`, `document-body`, `document-end`, `document-idle`, context-menu/manual execution, prerendered pages, SPA URL changes, and iframes. The run-at value should be normalized once and carried in `ScriptExecutionContext`.


```ts
type ScriptIdentifier = string;
type FrameIdentifier = string;
type TabIdentifier = number;
type UrlString = string;

type UserscriptRunAt =
  | 'document-start'
  | 'document-body'
  | 'document-end'
  | 'document-idle'
  | 'context-menu';

type UserscriptSandboxMode =
  | 'isolatedWorld'
  | 'mainWorld'
  | 'userscriptWorld'
  | 'contentScriptBridge'
  | 'offscreenHelper';

interface UserscriptMetadata {
  scriptName: string;
  namespace: string;
  version: string;
  description?: string;
  author?: string;
  matchRules: MatchRule[];
  includeRules: MatchRule[];
  excludeRules: MatchRule[];
  grantedApis: GmApiGrant[];
  allowedConnectHosts: HostPermissionRule[];
  requiredResources: ExternalResourceReference[];
  requiredLibraries: ExternalLibraryReference[];
  runAt: UserscriptRunAt;
  noFrames: boolean;
  updateUrl?: UrlString;
  downloadUrl?: UrlString;
}

interface StoredUserscriptRecord {
  id: ScriptIdentifier;
  metadata: UserscriptMetadata;
  sourceCode: string;
  enabled: boolean;
  installSourceUrl?: UrlString;
  lastUpdatedAt: number;
  lastRunStatus?: ScriptRunStatus;
  userOptions: UserscriptUserOptions;
  resources: Record<string, CachedResourceRecord>;
  valueStoreNamespace: string;
}

interface ScriptExecutionContext {
  scriptId: ScriptIdentifier;
  tabId: TabIdentifier;
  frameId: FrameIdentifier;
  pageUrl: UrlString;
  topFrameUrl: UrlString;
  runAt: UserscriptRunAt;
  sandboxMode: UserscriptSandboxMode;
  grantedApis: Set<GmApiGrant>;
  allowedConnectHosts: HostPermissionRule[];
  incognitoMode: boolean;
  isTopFrame: boolean;
}

interface RuntimeMessageEnvelope<Payload> {
  messageId: string;
  senderContext: 'background' | 'content' | 'page' | 'offscreen' | 'dashboard' | 'editor';
  targetContext: 'background' | 'content' | 'page' | 'offscreen' | 'dashboard' | 'editor';
  commandName: string;
  scriptId?: ScriptIdentifier;
  tabId?: TabIdentifier;
  frameId?: FrameIdentifier;
  payload: Payload;
  expectsResponse: boolean;
  createdAt: number;
}

interface PermissionDecision {
  decision: 'allow' | 'deny' | 'askUser' | 'useCachedDecision';
  reason: string;
  requiredPermission: string;
  requestingScriptId?: ScriptIdentifier;
  requestingUrl?: UrlString;
  rememberDecision: boolean;
}
```


## Grant-gated GM APIs

A good implementation generates the userscript global object from a grant set. If `@grant none` is used, privileged APIs should not appear. If explicit grants are used, expose only those APIs and their compatible aliases.


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## API categories

| Category | Examples | Review focus |
| --- | --- | --- |
| Value storage | get/set/delete/list values, listeners | namespace isolation, serialization, change notification order. |
| Network | `GM_xmlhttpRequest`, fetch/download helpers | @connect, credentials, headers, responseType, progress, abort. |
| Resources | get resource text/URL | cache lifetime, MIME type, blob URL revocation. |
| UI hooks | menu command, notification, set clipboard, addStyle/addElement | user visibility, callback lifetime, cleanup on navigation. |
| Tabs/window | openInTab, get/save tab, close/focus | activeTab/host permission, opener isolation. |
| Metadata/runtime | GM_info, sandbox mode, script handler info | no secret leakage, version compatibility. |

## unsafeWindow design

Use `unsafeWindow` as a compatibility feature, not as a privilege tunnel. A readable design should define which properties are proxied, which functions are rebound, how event handler properties behave, and how deletion/definition traps map to the page window. Regression tests should include getters, setters, functions using `this`, cross-frame references, and navigation cleanup.
