# Code Review and Maintenance

Review userscript-manager changes by responsibility boundary rather than by file size. Bundled extension source can be dense, but the product invariants are stable and readable.

## High-risk patch areas

| Area | Why risky | Required review questions |
| --- | --- | --- |
| Manifest permissions | Changes user trust and store review surface. | Is permission necessary? Is there an optional-permission path? |
| Background command router | Privileged action boundary. | Who can call it and what context is validated? |
| Injection/sandbox code | Can break every script or leak privileges. | Which worlds are affected? Are grants enforced? |
| Metadata parser | Affects install, update, matching, grants. | Are invalid scripts rejected safely? Are warnings useful? |
| Network gateway | Exfiltration and compatibility risk. | Are @connect, credentials, headers, abort, progress handled? |
| Storage migrations | Can erase user scripts or values. | Is migration atomic, reversible, and versioned? |
| Dashboard/editor UI | Can hide warnings or destructive actions. | Is state explicit? Is recovery possible? Is localization updated? |

## Regression tests to request or write

- Script with `@grant none` has no privileged APIs.
- Script with explicit GM grants exposes only those APIs and aliases.
- A script in an iframe respects `@noframes`.
- `@exclude` wins over positive include/match rules.
- Cross-origin XHR is denied without a matching `@connect` rule.
- A service-worker restart does not lose installed scripts or pending update state.
- Import dry-run reports conflicts before mutating storage.
- Editor dirty state survives route changes or warns before loss.

## Maintainability standards

Prefer meaningful type names and command names over raw object bags. A future agent should be able to inspect a handler named `handleNetworkRequestStart` and know that it validates a `UserscriptNetworkRequest`, checks a `PermissionDecision`, and returns a `UserscriptNetworkResponse`.
