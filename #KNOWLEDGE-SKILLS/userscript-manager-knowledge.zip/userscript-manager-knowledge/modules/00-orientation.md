# Orientation

This package is a wiki-style userscript-manager skill. It was built by inspecting all text files in three uploaded userscript-manager extension bundles: Tampermonkey 5.5.0, Violentmonkey 2.41.0, and ScriptCat 1.3.2. It uses the `appkit-textkit-layout` structure: `SKILL.md` is a compact routing index and the heavy material is split into modules, references, diagnostics, and recipes.

## What changed in this readable rebuild

The previous build included source chunks that looked like compiled/bundled code. This rebuild does not use raw minified source chunks as knowledge material. Each source reference is rewritten as a human-readable notebook with a role, extracted signals, named concepts, review checklist, and universal pseudocode pattern. Code examples use meaningful names such as `StoredUserscriptRecord`, `ScriptExecutionContext`, `PermissionDecision`, `routeRuntimeMessage`, and `requestThroughBackgroundNetworkGateway`.

## Source-derived domains

| Project | Manifest | Version | Permission sample |
| --- | --- | --- | --- |
| tampermonkey-5.5.0 | 3 | 5.5.0 | notifications, unlimitedStorage, tabs, idle, webNavigation, webRequest, webRequestBlocking, storage |
| violentmonkey-2.41.0 | 2 | 2.41.0 | tabs, <all_urls>, webRequest, webRequestBlocking, notifications, storage, unlimitedStorage, clipboardWrite |
| scriptcat-1.3.2 | 3 | 1.3.2 | tabs, alarms, storage, cookies, offscreen, scripting, downloads, activeTab |

The source teaches these domains:

1. **Browser extension topology**: background service worker or event page, popup/action UI, options/dashboard pages, content scripts, page-world injection, offscreen helper, sandbox pages, workers, localized messages, and vendored editor/lint libraries.
2. **Userscript lifecycle**: parse metadata, validate scripts, install from URL/file/import, cache resources, track update URLs, enable/disable, apply matching rules, execute in frames, migrate storage, and delete/trash/restore.
3. **Sandbox and GM APIs**: grant-gated globals, promise/callback compatibility, unsafeWindow proxying, addStyle/addElement, value storage, menu commands, notifications, downloads, resources, tab helpers, and cross-origin requests.
4. **Messaging and MV3 survival**: runtime messages, long-lived ports, page/content postMessage, offscreen delegation, service-worker suspension, reconnect logic, response correlation, and error serialization.
5. **Network and security policy**: `@connect`, host permissions, cookies, webRequest/DNR, downloads, CSP, page-vs-extension isolation, incognito split behavior, and user prompts.
6. **UI/UX**: dashboard list/detail, popup current-tab affordances, options/settings, editor workflows, import/export screens, update status, permission prompts, localization, keyboard shortcuts, and diagnostics.

## How agents should use this skill

Open only the module required by the task. For a script-not-running bug, start with `modules/09-debugging-issue-fix.md`; for a UI task, use `modules/07-dashboard-editor-uiux.md` and `modules/12-userscript-manager-uiux-design.md`; for coding new infrastructure, use `modules/11-universal-coding-models.md` and `reference/readable-implementation-patterns.generated.md`. For exact source orientation, use `reference/source-map.generated.md` then the matching `reference/source-notes/*.md` file.

## Universal design principles

| Principle | Operational meaning |
| --- | --- |
| Preserve privilege boundaries | Page-world code must not receive extension privileges directly. Route privileged work through explicit, grant-gated bridges. |
| Treat metadata as policy | Metadata is not just documentation. It controls matching, permissions, resources, network access, timing, and UI display. |
| Separate source from state | Store userscript source, parsed metadata, cached resources, script values, and UI preferences as distinct records with migration rules. |
| Use explicit message envelopes | Every async bridge message should name sender, target, command, context, and response expectations. |
| Design for MV3 suspension | Service workers can stop. Persist durable intent, reconnect ports, recreate offscreen documents, and avoid in-memory-only state for user-critical tasks. |
| Make UI decisions reversible | Enable/disable, delete, trash, update, and import flows need undo, confirmation, or visible recovery paths. |
| Debug by frame and timing | Most script-not-running issues are URL matching, iframe policy, run-at timing, sandbox selection, or grant mismatch. |
| Fail closed for network/security | If @connect, cookie, download, CSP, or host-permission checks are uncertain, deny or ask the user rather than silently granting. |
