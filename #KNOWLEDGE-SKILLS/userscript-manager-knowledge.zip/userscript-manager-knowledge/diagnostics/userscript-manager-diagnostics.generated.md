# Userscript Manager Diagnostics

| Symptom | Likely causes | Fix direction | Open |
| --- | --- | --- | --- |
| Script never runs | Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at | Normalize metadata and inspect ScriptExecutionContext before injection. | modules/09-debugging-issue-fix.md |
| Runs in top frame but not iframe | @noframes, all_frames, frame URL mismatch, sandbox blocked | Review frame policy and content-script all_frames behavior. | modules/09-debugging-issue-fix.md |
| GM_xmlhttpRequest denied | Missing @connect, denied prompt, host permission absent, forbidden header | Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. | modules/09-debugging-issue-fix.md |
| Update overwrites local edits | Dirty editor state ignored, update applied without diff | Gate updates behind source-hash and conflict review. | modules/09-debugging-issue-fix.md |
| Import creates duplicates | Identity mapping too weak, namespace/name ignored | Use import dry-run with logical identity mapping. | modules/09-debugging-issue-fix.md |
| Popup shows no scripts for current tab | Tab URL unavailable, match engine mismatch, stale background cache | Query current tab status with tab ID and URL, not UI filter state. | modules/09-debugging-issue-fix.md |
| Menu command fires wrong callback | Command ID not scoped by script/frame, cleanup missing | Scope registrations by script ID and frame ID. | modules/09-debugging-issue-fix.md |
| Service worker loses pending task | In-memory map used for durable task | Persist task intent or make request idempotent/retryable. | modules/09-debugging-issue-fix.md |
| Localization placeholder broken | Translated message missing placeholder | Validate placeholders against source locale. | modules/09-debugging-issue-fix.md |
| CSS makes warning invisible | Color-only state or dark-mode contrast | Use text/icon/state classes and accessibility checks. | modules/09-debugging-issue-fix.md |

## Diagnostic logging fields

```ts
interface UserscriptDiagnosticEvent {
  eventName: string;
  scriptId?: ScriptIdentifier;
  scriptName?: string;
  tabId?: TabIdentifier;
  frameId?: FrameIdentifier;
  pageUrl?: UrlString;
  runAt?: UserscriptRunAt;
  sandboxMode?: UserscriptSandboxMode;
  commandName?: string;
  permissionDecision?: PermissionDecision;
  humanReadableMessage: string;
  timestamp: number;
}
```
