# Scenario Playbooks

Detailed readable playbooks for issue fixing.


## Scenario 001: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 002: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 003: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 004: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 005: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 006: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 007: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 008: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 009: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 010: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 011: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 012: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 013: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 014: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 015: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 016: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 017: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 018: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 019: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 020: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 021: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 022: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 023: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 024: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 025: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 026: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 027: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 028: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 029: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 030: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 031: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 032: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 033: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 034: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 035: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 036: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 037: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 038: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 039: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 040: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 041: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 042: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 043: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 044: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 045: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 046: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 047: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 048: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 049: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 050: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 051: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 052: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 053: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 054: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 055: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 056: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 057: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 058: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 059: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 060: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 061: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 062: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 063: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 064: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 065: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 066: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 067: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 068: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 069: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 070: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 071: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 072: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 073: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 074: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 075: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 076: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 077: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 078: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 079: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 080: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 081: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 082: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 083: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 084: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 085: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 086: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 087: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 088: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 089: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 090: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 091: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 092: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 093: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 094: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 095: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 096: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 097: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 098: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 099: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 100: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 101: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 102: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 103: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 104: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 105: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 106: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 107: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 108: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 109: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 110: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 111: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 112: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 113: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 114: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 115: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 116: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 117: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 118: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 119: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 120: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 121: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 122: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 123: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 124: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 125: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 126: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 127: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 128: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 129: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 130: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 131: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 132: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 133: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 134: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 135: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 136: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 137: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 138: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 139: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 140: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 141: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 142: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 143: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 144: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 145: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 146: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 147: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 148: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 149: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 150: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 151: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 152: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 153: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 154: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 155: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 156: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 157: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 158: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 159: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 160: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 161: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 162: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 163: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 164: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 165: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 166: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 167: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 168: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 169: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 170: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 171: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 172: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 173: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 174: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 175: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 176: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 177: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 178: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 179: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 180: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 181: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 182: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 183: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 184: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 185: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 186: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 187: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 188: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 189: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 190: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 191: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 192: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 193: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 194: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 195: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 196: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 197: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 198: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 199: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 200: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 201: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 202: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 203: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 204: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 205: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 206: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 207: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 208: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 209: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 210: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 211: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 212: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 213: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 214: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 215: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 216: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 217: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 218: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 219: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 220: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 221: Script never runs while working on metadata

**Situation.** A user reports `Script never runs` after a change related to `metadata`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementMetadataFailure` or `buildMetadataDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 222: Runs in top frame but not iframe while working on matching

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `matching`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewMatchingFailure` or `buildMatchingDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 223: GM_xmlhttpRequest denied while working on sandbox

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `sandbox`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugSandboxFailure` or `buildSandboxDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 224: Update overwrites local edits while working on gm-api

**Situation.** A user reports `Update overwrites local edits` after a change related to `gm-api`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorGmApiFailure` or `buildGmApiDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 225: Import creates duplicates while working on network

**Situation.** A user reports `Import creates duplicates` after a change related to `network`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testNetworkFailure` or `buildNetworkDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 226: Popup shows no scripts for current tab while working on storage

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `storage`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentStorageFailure` or `buildStorageDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 227: Menu command fires wrong callback while working on sync

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `sync`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migrateSyncFailure` or `buildSyncDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 228: Service worker loses pending task while working on dashboard

**Situation.** A user reports `Service worker loses pending task` after a change related to `dashboard`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenDashboardFailure` or `buildDashboardDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 229: Localization placeholder broken while working on editor

**Situation.** A user reports `Localization placeholder broken` after a change related to `editor`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileEditorFailure` or `buildEditorDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 230: CSS makes warning invisible while working on permissions

**Situation.** A user reports `CSS makes warning invisible` after a change related to `permissions`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizePermissionsFailure` or `buildPermissionsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 231: Script never runs while working on offscreen

**Situation.** A user reports `Script never runs` after a change related to `offscreen`. The agent's job is to implement without guessing or editing unrelated bridge code.

**Primary hypothesis.** Disabled flag, manager paused, URL rules, excluded URL, iframe policy, wrong run-at.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Normalize metadata and inspect ScriptExecutionContext before injection. Keep the patch small and name new functions after the domain action, for example `implementOffscreenFailure` or `buildOffscreenDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 232: Runs in top frame but not iframe while working on i18n

**Situation.** A user reports `Runs in top frame but not iframe` after a change related to `i18n`. The agent's job is to review without guessing or editing unrelated bridge code.

**Primary hypothesis.** @noframes, all_frames, frame URL mismatch, sandbox blocked.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Review frame policy and content-script all_frames behavior. Keep the patch small and name new functions after the domain action, for example `reviewI18nFailure` or `buildI18nDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 233: GM_xmlhttpRequest denied while working on import-export

**Situation.** A user reports `GM_xmlhttpRequest denied` after a change related to `import-export`. The agent's job is to debug without guessing or editing unrelated bridge code.

**Primary hypothesis.** Missing @connect, denied prompt, host permission absent, forbidden header.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use NetworkPermissionGateway and emit a PermissionDecision diagnostic. Keep the patch small and name new functions after the domain action, for example `debugImportExportFailure` or `buildImportExportDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 234: Update overwrites local edits while working on updates

**Situation.** A user reports `Update overwrites local edits` after a change related to `updates`. The agent's job is to refactor without guessing or editing unrelated bridge code.

**Primary hypothesis.** Dirty editor state ignored, update applied without diff.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Gate updates behind source-hash and conflict review. Keep the patch small and name new functions after the domain action, for example `refactorUpdatesFailure` or `buildUpdatesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 235: Import creates duplicates while working on diagnostics

**Situation.** A user reports `Import creates duplicates` after a change related to `diagnostics`. The agent's job is to test without guessing or editing unrelated bridge code.

**Primary hypothesis.** Identity mapping too weak, namespace/name ignored.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use import dry-run with logical identity mapping. Keep the patch small and name new functions after the domain action, for example `testDiagnosticsFailure` or `buildDiagnosticsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 236: Popup shows no scripts for current tab while working on security

**Situation.** A user reports `Popup shows no scripts for current tab` after a change related to `security`. The agent's job is to document without guessing or editing unrelated bridge code.

**Primary hypothesis.** Tab URL unavailable, match engine mismatch, stale background cache.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Query current tab status with tab ID and URL, not UI filter state. Keep the patch small and name new functions after the domain action, for example `documentSecurityFailure` or `buildSecurityDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 237: Menu command fires wrong callback while working on popup

**Situation.** A user reports `Menu command fires wrong callback` after a change related to `popup`. The agent's job is to migrate without guessing or editing unrelated bridge code.

**Primary hypothesis.** Command ID not scoped by script/frame, cleanup missing.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Scope registrations by script ID and frame ID. Keep the patch small and name new functions after the domain action, for example `migratePopupFailure` or `buildPopupDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 238: Service worker loses pending task while working on cookies

**Situation.** A user reports `Service worker loses pending task` after a change related to `cookies`. The agent's job is to harden without guessing or editing unrelated bridge code.

**Primary hypothesis.** In-memory map used for durable task.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Persist task intent or make request idempotent/retryable. Keep the patch small and name new functions after the domain action, for example `hardenCookiesFailure` or `buildCookiesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 239: Localization placeholder broken while working on downloads

**Situation.** A user reports `Localization placeholder broken` after a change related to `downloads`. The agent's job is to profile without guessing or editing unrelated bridge code.

**Primary hypothesis.** Translated message missing placeholder.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Validate placeholders against source locale. Keep the patch small and name new functions after the domain action, for example `profileDownloadsFailure` or `buildDownloadsDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.


## Scenario 240: CSS makes warning invisible while working on resources

**Situation.** A user reports `CSS makes warning invisible` after a change related to `resources`. The agent's job is to localize without guessing or editing unrelated bridge code.

**Primary hypothesis.** Color-only state or dark-mode contrast.

**Readable investigation path.** First collect the `StoredUserscriptRecord`, then construct the expected `ScriptExecutionContext`. Compare the expected context with the runtime diagnostic event. If the failure crosses a message boundary, inspect the `RuntimeMessageEnvelope` fields before reading implementation details.

**Safe fix direction.** Use text/icon/state classes and accessibility checks. Keep the patch small and name new functions after the domain action, for example `localizeResourcesFailure` or `buildResourcesDiagnosticEvent`.

**Regression test.** Create one positive case, one denied/disabled case, and one navigation or reload case. The test should assert user-visible state and diagnostic output, not only internal return values.
