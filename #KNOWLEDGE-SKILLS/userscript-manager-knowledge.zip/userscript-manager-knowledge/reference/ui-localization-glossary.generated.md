# UI Localization Glossary

User-facing strings expose the product design. Keep terminology consistent across popup, dashboard, editor, settings, prompts, diagnostics, import/export, and sync.

## editor

| Project | Key | Readable text/message |
| --- | --- | --- |
| tampermonkey-5.5.0 | A_reload_is_required | A reload is required: <br>All unsaved changes will be lost! |
| tampermonkey-5.5.0 | Add_cursor_to_next_line | Add cursor to next line |
| tampermonkey-5.5.0 | Add_cursor_to_prev_line | Add cursor to previous line |
| tampermonkey-5.5.0 | All_modifications_are_only_kept_a_few_moments_Reconfigure_the_0name0_option_to_save_them_permanently_ | All modifications are only kept a few moments. Re-configure the '$name$' option to save them permanently. |
| tampermonkey-5.5.0 | Auto_Indent_all | Auto-Indent all |
| tampermonkey-5.5.0 | Auto_syntax_check_max_length | Automatic syntax check max size |
| tampermonkey-5.5.0 | Auto_syntax_check_on_typing | Automatic syntax check on typing |
| tampermonkey-5.5.0 | Autocomplete | Autocomplete |
| tampermonkey-5.5.0 | Center_Cursor | Center Cursor |
| tampermonkey-5.5.0 | Convert_CDATA_sections_into_a_chrome_compatible_format | Convert CDATA sections into a browser compatible format |
| tampermonkey-5.5.0 | Cursor | Cursor |
| tampermonkey-5.5.0 | Custom_Linter_Config | Custom Linter Config |
| tampermonkey-5.5.0 | Delete_Line | Delete Line |
| tampermonkey-5.5.0 | Delete_Line_Left | Delete Line Left |
| tampermonkey-5.5.0 | Delete_Line_Right | Delete Line Right |
| tampermonkey-5.5.0 | Duplicate_Lines | Duplicate Lines |
| tampermonkey-5.5.0 | Editor | Editor |
| tampermonkey-5.5.0 | Editor_reset | Discard changes |
| tampermonkey-5.5.0 | Enable_Editor | Enable enhanced editor |
| tampermonkey-5.5.0 | Enable_autoSave | Save content when editor loses focus |
| tampermonkey-5.5.0 | Enable_easySave | Don't show confirmation dialog on save |
| tampermonkey-5.5.0 | Indent | Indent |
| tampermonkey-5.5.0 | Indent_Less | Indent Less |
| tampermonkey-5.5.0 | Indent_More | Indent More |
| tampermonkey-5.5.0 | Indent_with | Indent with |
| tampermonkey-5.5.0 | Indentation_Width | Indentation Width |
| tampermonkey-5.5.0 | Insert_Line_After | Insert Line After |
| tampermonkey-5.5.0 | Insert_Line_Before | Insert Line Before |
| tampermonkey-5.5.0 | Join_Lines | Join Lines |
| tampermonkey-5.5.0 | Jump_to_line | Jump to line |
| tampermonkey-5.5.0 | Line_Case_Insensitive | Line Case Insensitive |
| tampermonkey-5.5.0 | Line_Down | Line Down |
| tampermonkey-5.5.0 | Line_Up | Line Up |
| tampermonkey-5.5.0 | Line_break | Word wrap |
| tampermonkey-5.5.0 | Lines | Lines |
| tampermonkey-5.5.0 | Lines_Menu | Lines |
| tampermonkey-5.5.0 | Move_Line_Down | Move Line Down |
| tampermonkey-5.5.0 | Move_Line_Up | Move Line Up |
| tampermonkey-5.5.0 | No_syntax_errors_were_found_ | No syntax errors were found. |
| tampermonkey-5.5.0 | Only_files_with_these_extensions_can_be_saved_to_the_harddisk_Be_careful_to_not_allow_file_extensions_that_represent_executables_at_your_operating_system_ | Only files with these extensions can be saved to harddisk.<br>Be careful to not allow file extensions that represent execut |
| tampermonkey-5.5.0 | Please_check_the_0editor0_documentation_for_more_details_ | Please check the $editor$ documentation for more details. |
| tampermonkey-5.5.0 | Reindent_on_typing | Re-indent on typing |
| tampermonkey-5.5.0 | Run_syntax_check | Run syntax check |
| tampermonkey-5.5.0 | Save | Save |
| tampermonkey-5.5.0 | Save_to_disk | Save to disk |
| tampermonkey-5.5.0 | Select_Line | Select Line |
| tampermonkey-5.5.0 | Split_into_Lines | Split into Lines |
| tampermonkey-5.5.0 | Split_selection_by_line | Split selection by line |
| tampermonkey-5.5.0 | There_are_unsaved_changed_ | There are unsaved changes.<br>Do you really want to close the editor? |
| tampermonkey-5.5.0 | This_editor_is_tracking_the_changes_of_0name0_ | This editor is tracking the changes of $name$. |
| tampermonkey-5.5.0 | Toggle_Comment_Indented | Toggle Comment Indented |
| tampermonkey-5.5.0 | Trim_trailing_whitespace_from_modified_lines | Trim trailing whitespace from modified lines |
| tampermonkey-5.5.0 | Wrap_lines | Wrap  lines |
| tampermonkey-5.5.0 | You_can_add_your_custom_linter_config_here_ | You can add your custom linter config here. |
| violentmonkey-2.41.0 | buttonSave | Save |
| violentmonkey-2.41.0 | buttonSaveClose | Save & Close |
| violentmonkey-2.41.0 | buttonSaved | Saved |
| violentmonkey-2.41.0 | buttonShowEditorState | Show editor state |
| violentmonkey-2.41.0 | confirmNotSaved | Modifications are not saved!<br>Click OK to discard them or cancel to stay. |
| violentmonkey-2.41.0 | descEditorOptions | Custom options for CodeMirror and addons in JSON object like <code>{"indentUnit":2, "smartIndent":true}</code> however n |
| violentmonkey-2.41.0 | descEditorOptionsGeneric | Boolean options may be toggled by double-clicking on the value: <code>true</code> = enabled, <code>false</code> = disabl |
| violentmonkey-2.41.0 | descEditorOptionsVM | Nonstandard options: <code>autocompleteOnTyping</code> is a delay in milliseconds to display autocomplete hints after ty |
| violentmonkey-2.41.0 | editHowToHint | Use another editor? |
| violentmonkey-2.41.0 | editLongLine | Line is too long |
| violentmonkey-2.41.0 | editLongLineTooltip | This line is too long so its text is collapsed to avoid delays when editing.<br>You can adjust the limit in advanced settin |
| violentmonkey-2.41.0 | labelEditor | Editor |
| violentmonkey-2.41.0 | labelLineNumber | Line no.:  |
| violentmonkey-2.41.0 | menuExcludeHint | The current tab will auto-reload if you enabled this option in general settings.<br>To apply changes to all other tabs plea |
| violentmonkey-2.41.0 | msgDateFormatInfo | Click to open MomentJS documentation. Allowed tokens: $1. Use [square brackets] to protect literal text. |
| violentmonkey-2.41.0 | msgSyntaxError | Syntax error? |
| violentmonkey-2.41.0 | optionEditorWindow | Open editor from popup in a new window |
| violentmonkey-2.41.0 | optionEditorWindowHint | Editor window position will be remembered only on resizing or saving |
| violentmonkey-2.41.0 | optionEditorWindowSimple | Hide omnibox |

## general

| Project | Key | Readable text/message |
| --- | --- | --- |
| tampermonkey-5.5.0 | 1 | 1 |
| tampermonkey-5.5.0 | 2 | 2 |
| tampermonkey-5.5.0 | 3 | 3 |
| tampermonkey-5.5.0 | 4 | 4 |
| tampermonkey-5.5.0 | 5 | 5 |
| tampermonkey-5.5.0 | 6 | 6 |
| tampermonkey-5.5.0 | 7 | 7 |
| tampermonkey-5.5.0 | 8 | 8 |
| tampermonkey-5.5.0 | 9 | 9 |
| tampermonkey-5.5.0 | 10 | 10 |
| tampermonkey-5.5.0 | 11 | 11 |
| tampermonkey-5.5.0 | extName | Tampermonkey |
| tampermonkey-5.5.0 | extNameBeta | Tampermonkey BETA |
| tampermonkey-5.5.0 | extNameLegacy | Tampermonkey Legacy |
| tampermonkey-5.5.0 | extNameClassic | Tampermonkey Classic |
| tampermonkey-5.5.0 | extShortName | Tampermonkey |
| tampermonkey-5.5.0 | extShortNameBeta | TM BETA |
| tampermonkey-5.5.0 | extShortNameLegacy | TM Legacy |
| tampermonkey-5.5.0 | extShortNameClassic | TM Classic |
| tampermonkey-5.5.0 | 0name0_Your_service_bot | $name$ - Your service bot |
| tampermonkey-5.5.0 | 0number0_Bytes | $number$ B |
| tampermonkey-5.5.0 | 0number0_GB | $number$ GB |
| tampermonkey-5.5.0 | 0number0_KB | $number$ KB |
| tampermonkey-5.5.0 | 0number0_MB | $number$ MB |
| tampermonkey-5.5.0 | 0number0_TB | $number$ TB |
| tampermonkey-5.5.0 | 0number0_days | $number$ d |
| tampermonkey-5.5.0 | 0number0_hours | $number$ h |
| tampermonkey-5.5.0 | 0number0_minutes | $number$ min |
| tampermonkey-5.5.0 | 15_Seconds | 15 Seconds |
| tampermonkey-5.5.0 | 1_Hour | 1 Hour |
| tampermonkey-5.5.0 | 1_Minute | 1 Minute |
| tampermonkey-5.5.0 | 30_Seconds | 30 Seconds |
| tampermonkey-5.5.0 | 5_Minutes | 5 Minutes |
| tampermonkey-5.5.0 | Aborted_by_user | Aborted by user |
| tampermonkey-5.5.0 | Add | Add |
| tampermonkey-5.5.0 | Add_GM_functions_to_this_or_window | Add GM functions to this or window |
| tampermonkey-5.5.0 | Add_Selection_Above | Add Selection Above |
| tampermonkey-5.5.0 | Add_Selection_Below | Add Selection Below |
| tampermonkey-5.5.0 | Add_Tampermonkey_to_the_site_s_content_csp | Add Tampermonkey to the HTML's CSP |
| tampermonkey-5.5.0 | Add_as_0clude0 | Add as $clude$ |
| tampermonkey-5.5.0 | Add_to_icon_badge_text | Add to icon badge text |
| tampermonkey-5.5.0 | Advanced | Advanced |
| tampermonkey-5.5.0 | All | All |
| tampermonkey-5.5.0 | All_local_files | All local files |
| tampermonkey-5.5.0 | Alltime_running_instances | All-time running instances |
| tampermonkey-5.5.0 | Always | Always |
| tampermonkey-5.5.0 | Always_ask | Always ask |
| tampermonkey-5.5.0 | Always_forbid | Always forbid |
| tampermonkey-5.5.0 | Always_forbid_domain | Always forbid domain |
| tampermonkey-5.5.0 | Anonymous_statistics | Anonymous statistics |
| tampermonkey-5.5.0 | Antifeature_ads | Ads |
| tampermonkey-5.5.0 | Antifeature_miner | Crypto Mining |
| tampermonkey-5.5.0 | Antifeature_no_details | No details given |
| tampermonkey-5.5.0 | Antifeature_other | a Antifeature |
| tampermonkey-5.5.0 | Antifeature_tracking | Tracking |
| tampermonkey-5.5.0 | Appearance | Appearance |
| tampermonkey-5.5.0 | Are_you_unsure_about_what__sandbox_value_to_use_ | Are you unsure about what @sandbox value to use? |
| tampermonkey-5.5.0 | Ask_if_unknown | Ask if unknown |
| tampermonkey-5.5.0 | At_least_one_of_the_include_match_or_exclude_statements_was_changed_ | At least one @include, @match or @exclude statement was changed. |
| tampermonkey-5.5.0 | Attention_Can_not_display_all_excludes_ | Attention: The exclude list was shortened.<br>Please check it manually! |
| tampermonkey-5.5.0 | Attention_Can_not_display_all_includes_ | Attention: The include list was shortened.<br>Please check it manually! |
| tampermonkey-5.5.0 | Author | Author |
| tampermonkey-5.5.0 | Auto | Auto |
| tampermonkey-5.5.0 | Automatic_installation | Automatic installation |
| tampermonkey-5.5.0 | Automatically_added_user_includes_for_compatibility_reasons_ | Some user includes were automatically added for compatibility reasons! |
| tampermonkey-5.5.0 | Back_or_close | Back or Close |
| tampermonkey-5.5.0 | Beginner | Beginner |
| tampermonkey-5.5.0 | BlackCheck | BlackCheck |
| tampermonkey-5.5.0 | Blacklist | Blacklist |
| tampermonkey-5.5.0 | Blacklist_0domain0 | Do not run on $domain$ |
| tampermonkey-5.5.0 | Blacklist_Severity | Block From Severity Level |
| tampermonkey-5.5.0 | Blacklisted_Pages | Blacklisted Pages |
| tampermonkey-5.5.0 | Bookmarks | Bookmarks |
| tampermonkey-5.5.0 | Both | Both |
| tampermonkey-5.5.0 | Browser_API | Browser API |
| tampermonkey-5.5.0 | Cancel | Cancel |
| tampermonkey-5.5.0 | Casual | Casual |
| tampermonkey-5.5.0 | Changelog | Changelog |
| tampermonkey-5.5.0 | Changes | Changes |
| tampermonkey-5.5.0 | Check_interval | Check Interval |
| tampermonkey-5.5.0 | Classic | Classic |
| tampermonkey-5.5.0 | Clean_after_session | Clean after session |
| tampermonkey-5.5.0 | Clear_All | Clear All |
| tampermonkey-5.5.0 | Click_here_to_install_it_ | Click here to install it. |
| tampermonkey-5.5.0 | Click_here_to_see_the_recent_changes | Click here to see the recent changes |
| tampermonkey-5.5.0 | Close | Close |
| tampermonkey-5.5.0 | Closing_Bracket | Closing Bracket |
| tampermonkey-5.5.0 | Columns | Columns |
| tampermonkey-5.5.0 | Comment | Comment |
| tampermonkey-5.5.0 | Config_Mode | Config mode |
| tampermonkey-5.5.0 | Configures_which_sandbox_values_are_valid | Configures which @sandbox values are valid |
| tampermonkey-5.5.0 | Copy | Copy |
| tampermonkey-5.5.0 | Current_Version | Current Version |
| tampermonkey-5.5.0 | Custom_CSS | Custom CSS |
| tampermonkey-5.5.0 | Cut | Cut |
| tampermonkey-5.5.0 | Debug | Debug |
| tampermonkey-5.5.0 | Decoding | Decoding... |
| tampermonkey-5.5.0 | Default | Default |
| tampermonkey-5.5.0 | Default_Dark | Default - Dark |
| tampermonkey-5.5.0 | Default_Darker | Default - Darker |
| tampermonkey-5.5.0 | Default_Light | Default - Light |
| tampermonkey-5.5.0 | Delete | Delete |
| tampermonkey-5.5.0 | Delete_all | Delete all |
| tampermonkey-5.5.0 | Delete_to_Next_Word_Boundary | Delete to Next Word Boundary |
| tampermonkey-5.5.0 | Delete_to_Previous_Word_Boundary | Delete to Previous Word Boundary |
| tampermonkey-5.5.0 | Delete_to_Sublime_Mark | Delete to Sublime Mark |
| tampermonkey-5.5.0 | Deleted_on | Deleted on |
| tampermonkey-5.5.0 | Destination_URL | Destination URL |
| tampermonkey-5.5.0 | Destination_domain | Destination domain |
| tampermonkey-5.5.0 | Details | Details |
| tampermonkey-5.5.0 | Developer | Developer |
| tampermonkey-5.5.0 | Developer_Mode | Developer Mode |
| tampermonkey-5.5.0 | Disable | Disable |
| tampermonkey-5.5.0 | Disabled | Disabled |
| tampermonkey-5.5.0 | Do_you_really_want_to_store_fixed_code_ | The Option '$option$' is enabled!<br><br>Do you really want to store the fixed source? |
| tampermonkey-5.5.0 | Document_End | Document End |
| tampermonkey-5.5.0 | Document_Start | Document Start |
| tampermonkey-5.5.0 | Dont_ask_again | Don't ask again |
| tampermonkey-5.5.0 | Downgrade | Downgrade |
| tampermonkey-5.5.0 | Dropbox | Dropbox |

## help-diagnostics

| Project | Key | Readable text/message |
| --- | --- | --- |
| tampermonkey-5.5.0 | 0count0_errors_or_hints_were_found_ | $count$ errors or hints were found. |
| tampermonkey-5.5.0 | An_internal_error_occured_Do_you_want_to_visit_the_forum_ | An internal error occurred. If this problem persists even after a restart of the browser, please press OK and report thi |
| tampermonkey-5.5.0 | Do_you_need_help_finding_Tampermonkey_s_console_output_ | Do you need help finding Tampermonkey's console output? |
| tampermonkey-5.5.0 | Do_you_need_help_working_with_Tampermonkey_ | Do you need help working with Tampermonkey? |
| tampermonkey-5.5.0 | Error | Error |
| tampermonkey-5.5.0 | Help | Help |
| tampermonkey-5.5.0 | One_error_or_hint_was_found_ | One error or hint was found. |
| tampermonkey-5.5.0 | Validate_if_supported | Validate if possible |
| tampermonkey-5.5.0 | Warning | Warning |
| tampermonkey-5.5.0 | Your_language_is_not_supported__Click_here_to_get_intructions_how_to_translate_TM_ | Your language is not supported?<br>Click here to get instructions how to translate Tampermonkey? |
| tampermonkey-5.5.0 | fatal_error | fatal error |
| violentmonkey-2.41.0 | buttonSupport | Support page |
| violentmonkey-2.41.0 | editHelpKeyboard | Keyboard shortcuts: |
| violentmonkey-2.41.0 | genericError | Error |
| violentmonkey-2.41.0 | labelHelpTranslate | Help with translation |
| violentmonkey-2.41.0 | msgErrorFetchingResource | Error fetching resource! |
| violentmonkey-2.41.0 | msgErrorLoadingDependency | Error loading dependencies. |

## navigation-ui

| Project | Key | Readable text/message |
| --- | --- | --- |
| tampermonkey-5.5.0 | Action | Action |
| tampermonkey-5.5.0 | Action_Menu | Action Menu |
| tampermonkey-5.5.0 | Action_failed | Action failed |
| tampermonkey-5.5.0 | Actions | Actions |
| tampermonkey-5.5.0 | All_tabs | All tabs |
| tampermonkey-5.5.0 | Changes_the_number_of_visible_config_options | Changes the number of visible config options |
| tampermonkey-5.5.0 | Context_Menu | Context Menu |
| tampermonkey-5.5.0 | Does_not_run_in_incognito_tabs | Does not run in incognito tabs |
| tampermonkey-5.5.0 | Does_not_run_in_normal_tabs | Does not run in normal tabs |
| tampermonkey-5.5.0 | Enable_context_menu | Enable context menu |
| tampermonkey-5.5.0 | Focus_tab | Focus source tab |
| tampermonkey-5.5.0 | GM_compat_options_ | GM/FF compatibility options |
| tampermonkey-5.5.0 | Global_Settings | Global Settings |
| tampermonkey-5.5.0 | Include_TM_settings | Include Tampermonkey settings |
| tampermonkey-5.5.0 | Incognito_tabs | Incognito tabs |
| tampermonkey-5.5.0 | Next_tab | Next Tab |
| tampermonkey-5.5.0 | Normal_tabs | Normal tabs |
| tampermonkey-5.5.0 | On_Action_Menu | On action menu |
| tampermonkey-5.5.0 | One_or_more_compatibility_options_are_set | One or more compatibility options are set. You might want/should review them. |
| tampermonkey-5.5.0 | Open | Open |
| tampermonkey-5.5.0 | Open_changelog | Open changelog |
| tampermonkey-5.5.0 | Partially_restricted_by_settings | Partially restricted by settings |
| tampermonkey-5.5.0 | Please_enable_anonymous_statistics_and_help_to_improve_this_extension_ | Please enable anonymous statistics and help optimize this extension. Only technical and extension interaction data is co |
| tampermonkey-5.5.0 | Previous_tab | Previous Tab |
| tampermonkey-5.5.0 | Scan_the_QR_code_to_use_Tampermonkey_on_your_phone_or_tablet_ | Scan the QR code to use Tampermonkey on your phone or tablet. |
| tampermonkey-5.5.0 | Settings | Settings |
| tampermonkey-5.5.0 | TabMode | TabMode |
| tampermonkey-5.5.0 | Tab_Size | Tab Size |
| tampermonkey-5.5.0 | Tab_URL | Tab URL |
| tampermonkey-5.5.0 | Tabs | Tabs |
| tampermonkey-5.5.0 | Tampermonkey_might_not_be_able_to_provide_access_to_the_unsafe_context_when_this_is_disabled | Tampermonkey might not be able to provide access to the unsafe context (unsafeWindow, page's functions and variables) wh |
| tampermonkey-5.5.0 | Tampermonkey_won_t_inject_into_other_tab_types_anymore_ | Tampermonkey won't inject into other tab types anymore! |
| tampermonkey-5.5.0 | This_will_overwrite_your_global_settings_ | This will overwrite your global settings! |
| tampermonkey-5.5.0 | You_can_add_your_custom_CSS_rules_here_ | You can add your own CSS rules for the Tampermonkey UI here. In case this breaks something you can get the default layou |
| violentmonkey-2.41.0 | buttonResetSettings | Reset settings |
| violentmonkey-2.41.0 | buttonVacuum | Vacuum database |
| violentmonkey-2.41.0 | editNavSettings | Settings |
| violentmonkey-2.41.0 | failureReasonBlacklisted | Blacklisted in Violentmonkey's settings |
| violentmonkey-2.41.0 | hashPatternWarning | "#" patterns work only when initially opening the site or reloading the tab: $1 |
| violentmonkey-2.41.0 | installOptionTrackTooltip | The source file tab should be kept open in Firefox 68 and newer. |
| violentmonkey-2.41.0 | labelSettings | Settings |
| violentmonkey-2.41.0 | labelViewTable | Table view |
| violentmonkey-2.41.0 | menuExclude | Exclude... |
| violentmonkey-2.41.0 | menuFeedback | Feedback |
| violentmonkey-2.41.0 | menuInjectionFailedFix | Retry in "auto" mode |
| violentmonkey-2.41.0 | optionPopup | Popup menu and icon |
| violentmonkey-2.41.0 | optionPopupEnabledFirst | Enabled first |
| violentmonkey-2.41.0 | popupSettings | Popup settings |
| violentmonkey-2.41.0 | popupSettingsHint | Right-click: popup settings |
| violentmonkey-2.41.0 | reloadTab | Reload tab |
| violentmonkey-2.41.0 | sideMenuAbout | About |
| violentmonkey-2.41.0 | sideMenuSettings | Settings |
| violentmonkey-2.41.0 | titleBadgeColorBlocked | Badge color when the site is non-injectable (blacklisted or unsupported) |
| violentmonkey-2.41.0 | trackEditsNote | Keep this page open to track your edits in local file |

## permissions-security

| Project | Key | Readable text/message |
| --- | --- | --- |
| tampermonkey-5.5.0 | Add_TM_to_CSP | Modify existing content security policy (CSP) headers |
| tampermonkey-5.5.0 | All_but_HttpOnly | All but protected cookies (HttpOnly) |
| tampermonkey-5.5.0 | Allow_Tampermonkey_to_collect_anonymous_statistics | Allow Tampermonkey to collect anonymous statistics via a self-hosted Matomo installation. This helps me to improve Tampe |
| tampermonkey-5.5.0 | Allow_communication_with_cooperate_pages | Allow communication with cooperate pages |
| tampermonkey-5.5.0 | Allow_once | Allow once |
| tampermonkey-5.5.0 | Always_allow | Always allow |
| tampermonkey-5.5.0 | Always_allow_all_domains | Always allow all domains |
| tampermonkey-5.5.0 | Always_allow_domain | Always allow domain |
| tampermonkey-5.5.0 | At_least_one_new_connect_statement_was_added_ | At least one new @connect statement was added. |
| tampermonkey-5.5.0 | Browser_API_Downloads | Browser API Downloads |
| tampermonkey-5.5.0 | Click_here_to_allow_TM_to_access_the_following_hosts_0hostlist0 | Please click OK in order to allow Tampermonkey to access the following hosts:<br><br>$hostlist$ |
| tampermonkey-5.5.0 | Click_here_to_allow_TM_to_make_use_of_a_proxy | Click OK to allow Tampermonkey to make use of a proxy. |
| tampermonkey-5.5.0 | Click_here_to_allow_TM_to_start_downloads | Click OK to allow Tampermonkey to start instant downloads. |
| tampermonkey-5.5.0 | Cross_Origin_Request_Permission | Cross Origin Request Permission |
| tampermonkey-5.5.0 | Do_you_want_to_know_how_to_allow_Tampermonkey_access_to_local_file_URIs_ | Do you want to know how to allow Tampermonkey access to local file URIs? |
| tampermonkey-5.5.0 | Download_Mode | Download Mode |
| tampermonkey-5.5.0 | Downloaded_from_0url0 | Downloaded from: $url$ |
| tampermonkey-5.5.0 | Downloads | Downloads |
| tampermonkey-5.5.0 | Host_permissions_denied_by_user_ | Host permissions denied by user: |
| tampermonkey-5.5.0 | No_previously_denied_runtime_host_permissions_found | No previously denied runtime host permissions found |
| tampermonkey-5.5.0 | Proxy_Permission | Proxy Permission |
| tampermonkey-5.5.0 | Requested_Host_Permissions | Requested Host Permissions |
| tampermonkey-5.5.0 | Runtime_Host_Permissions | Runtime Host Permissions |
| tampermonkey-5.5.0 | Security | Security |
| tampermonkey-5.5.0 | Tampermonkey_has_no_file_access_permission_ | Tampermonkey has no permission to access local files! |
| tampermonkey-5.5.0 | Temporarily_allow | Temporarily allow |
| tampermonkey-5.5.0 | The_Browser_API_mode_requires_a_special_permission_ | The Browser API mode requires a special permission. |
| tampermonkey-5.5.0 | XHR_Security | XHR Security |
| tampermonkey-5.5.0 | connect_mode | Check @connect |
| violentmonkey-2.41.0 | hintUseDownloadURL | Use @downloadURL |
| violentmonkey-2.41.0 | labelDownloadURL | Download URL: |
| violentmonkey-2.41.0 | labelHttpOnlyCookie | Allow GM_cookie to access HTTP-only cookies |
| violentmonkey-2.41.0 | labelPrivacyPolicy | Privacy Policy |
| violentmonkey-2.41.0 | labelXhrInject | Synchronous $1 mode |
| violentmonkey-2.41.0 | labelXhrInjectNote | (except incognito and sites with disabled cookies) |
| violentmonkey-2.41.0 | readonlyOpt | Allow edits |

## script-management

| Project | Key | Readable text/message |
| --- | --- | --- |
| tampermonkey-5.5.0 | extDescription | Change the web at will with userscripts |
| tampermonkey-5.5.0 | 0name0_0version0_is_available__Please_re_start_your_browser_to_update_ | $name$ $version$ is available.<br>Please re-start your browser to start the update! |
| tampermonkey-5.5.0 | A_recheck_of_the_GreaseMonkey_FF_compatibility_options_may_be_required_in_order_to_run_this_script_ | A recheck of the GreaseMonkey/FF compatibility options may be required in order to run this script. |
| tampermonkey-5.5.0 | A_request_to_a_cross_origin_resource_is_nothing_unusual__You_just_have_to_check_whether_this_script_has_a_good_reason_to_access_this_domain__For_example_there_are_only_a_very_few_reasons_for_a_userscript_to_contact_your_bank__Please_note_that_userscript_authors_can_avoid_this_dialog_by_adding_@connect_tags_to_their_scripts__You_can_change_your_opinion_at_any_time_at_the_scripts_settings_tab_ | A request to a cross origin resource is nothing unusual.<br>You just have to check whether this script has a good reason to |
| tampermonkey-5.5.0 | A_userscript_wants_to_access_a_cross_origin_resource_ | A userscript wants to access a cross-origin resource. |
| tampermonkey-5.5.0 | Add_Tag | Add Tag |
| tampermonkey-5.5.0 | Add_Tag_to_System | Add Tag to the system's list |
| tampermonkey-5.5.0 | Add_new_script___ | Create a new script... |
| tampermonkey-5.5.0 | All_script_settings_will_be_reset_ | All script settings will be reset! |
| tampermonkey-5.5.0 | Allow_headers_to_be_modified_by_scripts | Allow HTTP headers to be modified by scripts |
| tampermonkey-5.5.0 | Allow_scripts_to_run_scripts_in | Default tab types to run scripts in |
| tampermonkey-5.5.0 | Antifeature__0name0__0description0 | Contains $name$: $description$ |
| tampermonkey-5.5.0 | Apply_compatibility_options_to_required_script_too | Apply compatibility options to @require scripts too |
| tampermonkey-5.5.0 | Apply_this_action_to_the_selected_scripts | Apply this to all selected scripts |
| tampermonkey-5.5.0 | Apply_update | Apply update |
| tampermonkey-5.5.0 | Are_you_sure_that_you_don_t_want_to_be_notified_of_updates_ | When Tampermonkey is updated by your browser it is also re-started. Unfortunately this might break currently running scr |
| tampermonkey-5.5.0 | Auto_reload_on_script_enabled | Auto reload pages |
| tampermonkey-5.5.0 | Auto_reload_on_script_enabled_desc | Reload affected pages if a script was turned on or off |
| tampermonkey-5.5.0 | CONFLICT__This_script_was_modified_0t0_seconds_ago_ | CONFLICT:<br>This script was modified by another tab $t$ second(s) ago! |
| tampermonkey-5.5.0 | Check_disabled_scripts | Update disabled scripts |
| tampermonkey-5.5.0 | Check_for_Updates | Check for updates |
| tampermonkey-5.5.0 | Check_for_userscripts_updates | Check for userscript updates |
| tampermonkey-5.5.0 | Check_only_scripts_up_to_this_size_automatically_ | Check only scripts up to this size automatically. |
| tampermonkey-5.5.0 | Click_here_to_move_this_script | Click here to move this script |
| tampermonkey-5.5.0 | Content_Script | Content Script |
| tampermonkey-5.5.0 | Content_Script_API | Content Script API |
| tampermonkey-5.5.0 | Controls_how_deleted_scripts_are_handled__0enabled0_moves_scripts_to_a_virtual_trash__0disabled0_permanently_deletes_scripts__0cleanAfterSession0_automatically_deletes_all_on_session_end_ | Controls how deleted scripts are handled. '$enabled$' moves scripts to a virtual trash for potential recovery. '$disable |
| tampermonkey-5.5.0 | DOM_mode_is_unsecure__Scripts_can_install_new_scripts_ | "DOM" sandbox mode is unsecure. Running userscripts have almost full extension permissions and can even modify and insta |
| tampermonkey-5.5.0 | Dashboard | Dashboard |
| tampermonkey-5.5.0 | Debug_scripts | Debug scripts |
| tampermonkey-5.5.0 | Description | Description |
| tampermonkey-5.5.0 | Disable_Updates | Disable Updates |
| tampermonkey-5.5.0 | Disable_all_remaining_scripts_of_this_tag | Click to disable all remaining scripts of this tag |
| tampermonkey-5.5.0 | Disable_all_scripts_of_this_tag | Click to disable all scripts of this tag |
| tampermonkey-5.5.0 | Do_you_need_help_installing_new_scripts_to_Tampermonkey_ | Do you need help installing new scripts to Tampermonkey? |
| tampermonkey-5.5.0 | Do_you_need_help_syncing_all_your_installed_scripts_to_another_browser_ | Do you need help syncing all your installed scripts to another browser? |
| tampermonkey-5.5.0 | Do_you_need_help_viewing_and_editing_values_stored_by_a_userscript_ | Do you need help viewing and editing values stored by a userscript? |
| tampermonkey-5.5.0 | Do_you_want_to_use_an_external_editor_to_edit_your_scripts__nWould_you_like_to_know_how_to_set_this_up_ | Do you want to use an external editor to edit your scripts?<br>Would you like to know how to set this up? |
| tampermonkey-5.5.0 | Dont_ask_me_for_simple_script_updates | Don't ask me for simple script updates |
| tampermonkey-5.5.0 | Enable_Script_Sync | Enable Userscript Sync |
| tampermonkey-5.5.0 | Enable_Tags | Enable Tags |
| tampermonkey-5.5.0 | Enable_all_scripts_of_this_tag | Click to enable all scripts of this tag |
| tampermonkey-5.5.0 | Enabling_this_makes_it_easy_for_scripts_to_leak_it_s_granted_powers_to_the_page_Therefore__off__is_the_safest_option_ | Enabling this makes it very easy for userscripts to leak it's granted powers to the page. Therefore "$off$" is the safes |
| tampermonkey-5.5.0 | Export_script_0name0_0uuid0 | Export script "$name$" ($uuid$) |
| tampermonkey-5.5.0 | Export_script_meta_data_of_0name0 | Export script meta data of "$name$" ($uuid$) |
| tampermonkey-5.5.0 | Export_script_source_of_0name0 | Export script source of "$name$" ($uuid$) |
| tampermonkey-5.5.0 | Filter_by | Filter by |
| tampermonkey-5.5.0 | Force_JavaScript | Force JavaScript |
| tampermonkey-5.5.0 | Found_0count0_available_scripts | Found $count$ available scripts |
| tampermonkey-5.5.0 | Get_new_scripts___ | Find new scripts... |
| tampermonkey-5.5.0 | Get_some_scripts___ | Get some scripts... |
| tampermonkey-5.5.0 | Hide_disabled_scripts | Hide disabled scripts |
| tampermonkey-5.5.0 | Import_remote_script_0uuid0 | Import remote script ($uuid$) |
| tampermonkey-5.5.0 | In_order_to_search_for_userscripts__0on_action_menu0__and__0icon_badge_number0__automatically_transfer_the_tab_s_url_to_the_search_website__0on_click0_opens_the_search_page_on_click_Please_click_at_this_icon_to_open_the_privacy_policy_ | In mode "$icon_badge_number$" the tab's URL is automatically<br>transferred to the search website and used as search value. |
| tampermonkey-5.5.0 | Include_script_externals | Include external script resources |
| tampermonkey-5.5.0 | Include_script_storage | Include script storage |
| tampermonkey-5.5.0 | Install_this_script | Install this script |
| tampermonkey-5.5.0 | Installed_Version_ | Installed Version |
| tampermonkey-5.5.0 | Installed_userscripts | Installed Userscripts |
| tampermonkey-5.5.0 | Invalid_UserScript__Sry_ | Invalid Userscript! |
| tampermonkey-5.5.0 | Invalid_UserScript_name__Sry_ | Invalid Userscript name! |
| tampermonkey-5.5.0 | JavaScript_and_DOM | JavaScript+DOM |
| tampermonkey-5.5.0 | Just_another_service_provided_by_your_friendly_script_updater_ | Just another service provided by your friendly script updater |
| tampermonkey-5.5.0 | Last_updated | Last updated |
| tampermonkey-5.5.0 | Limited_runtime_host_permissions_might_break_some_Tampermonkey_features_ | Limited runtime host permissions might break some Tampermonkey features like script update, GM_xmlhttpRequest and others |
| tampermonkey-5.5.0 | Lookup_remote_script_0uuid0 | Lookup remote script ($uuid$) |
| tampermonkey-5.5.0 | Lookup_remote_script_list | Lookup remote script list |
| tampermonkey-5.5.0 | Malicious_scripts_can_violate_your_privacy_ | Malicious scripts can violate your privacy and act on your behalf!<br>You should only install scripts from sources that you |
| tampermonkey-5.5.0 | Manual_Script_Blacklist | Manual Userscript and @require Blacklist |
| tampermonkey-5.5.0 | Modifying_a_script_will_disable_automatic_script_updates_ | Modifying a script will disable automatic script updates! |
| tampermonkey-5.5.0 | New_Tag | New Tag |
| tampermonkey-5.5.0 | New_script_template_ | New userscript template |
| tampermonkey-5.5.0 | New_userscript | <New userscript> |
| tampermonkey-5.5.0 | No_available_scripts | No available scripts |
| tampermonkey-5.5.0 | No_script_is_installed | No script is installed |
| tampermonkey-5.5.0 | No_script_is_running | No script is running |
| tampermonkey-5.5.0 | No_update_found__sry_ | No update found, sry! |
| tampermonkey-5.5.0 | One_of_your_scripts_is_blacklisted__Would_you_like_to_know_why_ | One of your scripts is blacklisted. Would you like to know why? |
| tampermonkey-5.5.0 | Page_Filter_Mode | Page Filter Mode |
| tampermonkey-5.5.0 | Please_enable_the_allow_userscripts_extension_setting_ | Please enable the `Allow User Scripts` extension setting. Click here for more info how to do this. |
| tampermonkey-5.5.0 | Raw_and_JavaScript | Raw and JavaScript |
| tampermonkey-5.5.0 | Really_delete_all_userscripts_ | Do you really want to permanently delete all userscripts? |
| tampermonkey-5.5.0 | Really_factory_reset_this_script_ | Do you really want to factory reset this script? |
| tampermonkey-5.5.0 | Really_restore_all_userscripts_ | Do you really want to restore all userscripts? |
| tampermonkey-5.5.0 | Remove_Tag | Remove Tag |
| tampermonkey-5.5.0 | Remove_local_script_0name0_0uuid0 | Delete local script "$name$" ($uuid$) |
| tampermonkey-5.5.0 | Remove_remote_script_0name0_0uuid0 | Delete remote script "$name$" ($uuid$) |
| tampermonkey-5.5.0 | Report_an_issue_to_the_script_hoster_ | Report abuse.<br>(A user account may be required) |
| tampermonkey-5.5.0 | Running_scripts | Running scripts instances |
| tampermonkey-5.5.0 | Script_0name0_is_slowing_down_some_page_loads_ | Userscript '$name$' is slowing down your page loads |
| tampermonkey-5.5.0 | Script_Blacklist_Source | Userscript Blacklist Source |
| tampermonkey-5.5.0 | Script_Include_Mode | Userscript @include Mode |
| tampermonkey-5.5.0 | Script_Sync | Userscript Sync |
| tampermonkey-5.5.0 | Script_Tags | Script Tags |
| tampermonkey-5.5.0 | Script_URL_detection | Userscript URL detection |
| tampermonkey-5.5.0 | Script_Update | Userscript Update |
| tampermonkey-5.5.0 | Script_authors_can_secure_external_resources_by_adding_a_SRI_hash_to_the_URL_ | Script authors can secure external resources by adding a SRI hash to the source URL. |
| tampermonkey-5.5.0 | Script_cookies_access | Allow scripts to access cookies |
| tampermonkey-5.5.0 | Script_local_files_access | Allow scripts to access local files |
| tampermonkey-5.5.0 | Script_menu_commands | Userscript menu commands |
| tampermonkey-5.5.0 | Script_name_0name0 | Userscript name: $name$ |
| tampermonkey-5.5.0 | Script_order | Userscript order |
| tampermonkey-5.5.0 | Scripts_activated_by_context_menu | Userscripts using @run-at context-menu |
| tampermonkey-5.5.0 | Search_for_userscripts_for_this_tab | Search for userscripts for this page |
| tampermonkey-5.5.0 | Searching_for_userscripts_for_this_tab | Searching for userscripts... |
| tampermonkey-5.5.0 | Some_scripts_might_be_blocked_by_the_javascript_settings_for_this_page_or_a_script_blocker_ | Some scripts might be blocked by the JavaScript settings for this page or a script blocker! |
| tampermonkey-5.5.0 | Sort | Sort |
| tampermonkey-5.5.0 | Synchronize_your_scripts_across_browsers_and_operation_systems | Synchronize your scripts across browsers and operation systems |
| tampermonkey-5.5.0 | System_Tags | System Tags |
| tampermonkey-5.5.0 | Tag_Already_Exists | This tag already exists |
| tampermonkey-5.5.0 | Tags | Tags |
| tampermonkey-5.5.0 | Tampermonkey_and_script_version | Tampermonkey + script version |
| tampermonkey-5.5.0 | The_diff_for_this_script_is_too_large_to_render | The diff for this script is too large to render |
| tampermonkey-5.5.0 | The_downgraded_script_might_have_problems_to_read_its_stored_data_ | The downgraded script might have problems to read its stored data! |
| tampermonkey-5.5.0 | The_origin_of_this_script_cant_be_determined_ | Warning: The origin of this script can't be determined.<br>Either it was installed by a malicious third party to steal your |
| tampermonkey-5.5.0 | The_script_was_modified_locally_on_0date0__Updating_it_will_overwrite_your_changes_ | The script was modified locally on $date$. Updating it will overwrite your changes! |
| tampermonkey-5.5.0 | The_script_was_successfully_deleted_ | The script was successfully deleted. |
| tampermonkey-5.5.0 | The_script_was_successfully_moved_to_the_trash_ | The script was successfully moved to the trash. |
| tampermonkey-5.5.0 | The_update_url_has_changed_from_0oldurl0_to__0newurl0 | The update url has changed from:<br>    '$oldurl$'<br>    to:<br>    '$newurl$'<br> |
| tampermonkey-5.5.0 | There_are_no_active_scripts__Do_you_want_to_search_for_userscripts_ | There are no active scripts. Do you want to search for userscripts? |

## sync-import-export

| Project | Key | Readable text/message |
| --- | --- | --- |
| tampermonkey-5.5.0 | 0count0_changes_exported | $count$ change(s) exported |
| tampermonkey-5.5.0 | 0count0_changes_imported | $count$ change(s) imported |
| tampermonkey-5.5.0 | An_error_occured_during_import_ | An error occurred during import. |
| tampermonkey-5.5.0 | Browser_Sync | Browser Sync |
| tampermonkey-5.5.0 | Cloud | Cloud |
| tampermonkey-5.5.0 | Export | Export |
| tampermonkey-5.5.0 | Global_settings_import | Global settings import |
| tampermonkey-5.5.0 | Import | Import |
| tampermonkey-5.5.0 | Import_from_URL | Import from URL |
| tampermonkey-5.5.0 | Import_from_file | Import from file |
| tampermonkey-5.5.0 | Imported | Imported |
| tampermonkey-5.5.0 | No_backups_found | No backups found |
| tampermonkey-5.5.0 | Recent_Sync_Log | Recent Sync Log |
| tampermonkey-5.5.0 | Restore | Restore |
| tampermonkey-5.5.0 | Restore_all | Restore all |
| tampermonkey-5.5.0 | Show_backups | Show backups |
| tampermonkey-5.5.0 | Sync_Now | Run now |
| tampermonkey-5.5.0 | Sync_Reset | Reset |
| tampermonkey-5.5.0 | Sync_Type | Type |
| tampermonkey-5.5.0 | Sync_failed | Sync failed |
| tampermonkey-5.5.0 | Sync_finished | Sync finished |
| tampermonkey-5.5.0 | Sync_is_running | Sync is running |
| tampermonkey-5.5.0 | This_will_remove_all_remote_data_from_sync_Ok_ | Do you really want to delete all data from Sync? |
| tampermonkey-5.5.0 | Waiting_for_sync_to_finish | Waiting for sync to finish |
| tampermonkey-5.5.0 | WebDAV | WebDAV |
| violentmonkey-2.41.0 | buttonExportData | Export to zip |
| violentmonkey-2.41.0 | buttonImportData | Import from zip |
| violentmonkey-2.41.0 | buttonRestore | Restore |
| violentmonkey-2.41.0 | buttonSyncPullOnce | Pull once to local |
| violentmonkey-2.41.0 | buttonSyncPushOnce | Push once to remote |
| violentmonkey-2.41.0 | confirmUndoImport | Revert all changes made to the database (importing, updating, editing, customizing) |
| violentmonkey-2.41.0 | labelBackupMaintenance | Backup and maintenance |
| violentmonkey-2.41.0 | labelImportSettings | Import settings |
| violentmonkey-2.41.0 | labelSync | Sync |
| violentmonkey-2.41.0 | labelSyncAnonymous | Use anonymous account |
| violentmonkey-2.41.0 | labelSyncAuthorize | Authorize |
| violentmonkey-2.41.0 | labelSyncAuthorizing | Authorizing |
| violentmonkey-2.41.0 | labelSyncAutomatically | Sync automatically |
| violentmonkey-2.41.0 | labelSyncDisabled | None |
| violentmonkey-2.41.0 | labelSyncPassword | Password:  |
| violentmonkey-2.41.0 | labelSyncRevoke | Revoke |
| violentmonkey-2.41.0 | labelSyncS3AccessKeyId | Access Key ID:  |
| violentmonkey-2.41.0 | labelSyncS3Bucket | Bucket:  |
| violentmonkey-2.41.0 | labelSyncS3Endpoint | Custom Endpoint:  |
| violentmonkey-2.41.0 | labelSyncS3Prefix | Key Prefix:  |
| violentmonkey-2.41.0 | labelSyncS3Region | Region:  |
| violentmonkey-2.41.0 | labelSyncS3SecretAccessKey | Secret Access Key:  |
| violentmonkey-2.41.0 | labelSyncServerUrl | Server URL:  |
| violentmonkey-2.41.0 | labelSyncService | Sync to |
| violentmonkey-2.41.0 | labelSyncUsername | Username:  |
| violentmonkey-2.41.0 | lastSync | Last sync at $1 |
| violentmonkey-2.41.0 | msgImported | $1 item(s) are imported. |
| violentmonkey-2.41.0 | msgSyncError | Sync error! |
| violentmonkey-2.41.0 | msgSyncInit | Initializing... |
| violentmonkey-2.41.0 | msgSyncInitError | Initializing error! |
| violentmonkey-2.41.0 | msgSyncNoAuthYet | Not authorized yet. |
| violentmonkey-2.41.0 | msgSyncing | Sync in progress... |
