# Agent Question Cards

Short searchable cards for agents. Each card is readable and points to modules rather than source dumps.


## Card 0001: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0002: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0003: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0004: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0005: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0006: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0007: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0008: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0009: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0010: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0011: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0012: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0013: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0014: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0015: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0016: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0017: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0018: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0019: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0020: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0021: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0022: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0023: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0024: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0025: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0026: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0027: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0028: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0029: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0030: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0031: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0032: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0033: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0034: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0035: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0036: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0037: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0038: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0039: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0040: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0041: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0042: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0043: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0044: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0045: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0046: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0047: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0048: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0049: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0050: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0051: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0052: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0053: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0054: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0055: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0056: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0057: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0058: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0059: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0060: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0061: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0062: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0063: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0064: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0065: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0066: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0067: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0068: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0069: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0070: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0071: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0072: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0073: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0074: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0075: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0076: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0077: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0078: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0079: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0080: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0081: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0082: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0083: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0084: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0085: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0086: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0087: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0088: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0089: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0090: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0091: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0092: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0093: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0094: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0095: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0096: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0097: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0098: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0099: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0100: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0101: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0102: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0103: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0104: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0105: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0106: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0107: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0108: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0109: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0110: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0111: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0112: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0113: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0114: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0115: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0116: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0117: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0118: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0119: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0120: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0121: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0122: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0123: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0124: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0125: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0126: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0127: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0128: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0129: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0130: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0131: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0132: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0133: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0134: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0135: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0136: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0137: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0138: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0139: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0140: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0141: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0142: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0143: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0144: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0145: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0146: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0147: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0148: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0149: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0150: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0151: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0152: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0153: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0154: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0155: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0156: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0157: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0158: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0159: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0160: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0161: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0162: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0163: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0164: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0165: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0166: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0167: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0168: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0169: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0170: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0171: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0172: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0173: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0174: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0175: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0176: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0177: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0178: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0179: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0180: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0181: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0182: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0183: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0184: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0185: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0186: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0187: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0188: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0189: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0190: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0191: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0192: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0193: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0194: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0195: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0196: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0197: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0198: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0199: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0200: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0201: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0202: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0203: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0204: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0205: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0206: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0207: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0208: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0209: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0210: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0211: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0212: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0213: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0214: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0215: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0216: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0217: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0218: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0219: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0220: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0221: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0222: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0223: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0224: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0225: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0226: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0227: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0228: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0229: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0230: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0231: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0232: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0233: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0234: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0235: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0236: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0237: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0238: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0239: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0240: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0241: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0242: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0243: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0244: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0245: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0246: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0247: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0248: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0249: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0250: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0251: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0252: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0253: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0254: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0255: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0256: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0257: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0258: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0259: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0260: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0261: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0262: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0263: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0264: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0265: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0266: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0267: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0268: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0269: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0270: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0271: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0272: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0273: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0274: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0275: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0276: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0277: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0278: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0279: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0280: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0281: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0282: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0283: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0284: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0285: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0286: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0287: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0288: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0289: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0290: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0291: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0292: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0293: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0294: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0295: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0296: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0297: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0298: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0299: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0300: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0301: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0302: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0303: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0304: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0305: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0306: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0307: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0308: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0309: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0310: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0311: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0312: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0313: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0314: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0315: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0316: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0317: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0318: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0319: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0320: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0321: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0322: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0323: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0324: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0325: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0326: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0327: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0328: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0329: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0330: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0331: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0332: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0333: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0334: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0335: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0336: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0337: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0338: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0339: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0340: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0341: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0342: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0343: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0344: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0345: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0346: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0347: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0348: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0349: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0350: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0351: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0352: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0353: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0354: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0355: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0356: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0357: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0358: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0359: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0360: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0361: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0362: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0363: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0364: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0365: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0366: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0367: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0368: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0369: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0370: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0371: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0372: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0373: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0374: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0375: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0376: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0377: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0378: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0379: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0380: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0381: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0382: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0383: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0384: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0385: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0386: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0387: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0388: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0389: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0390: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0391: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0392: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0393: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0394: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0395: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0396: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0397: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0398: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0399: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0400: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0401: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0402: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0403: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0404: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0405: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0406: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0407: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0408: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0409: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0410: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0411: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0412: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0413: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0414: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0415: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0416: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0417: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0418: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0419: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0420: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0421: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0422: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0423: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0424: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0425: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0426: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0427: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0428: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0429: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0430: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0431: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0432: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0433: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0434: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0435: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0436: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0437: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0438: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0439: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0440: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0441: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0442: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0443: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0444: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0445: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0446: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0447: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0448: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0449: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0450: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0451: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0452: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0453: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0454: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0455: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0456: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0457: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0458: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0459: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0460: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0461: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0462: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0463: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0464: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0465: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0466: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0467: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0468: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0469: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0470: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0471: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0472: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0473: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0474: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0475: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0476: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0477: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0478: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0479: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0480: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0481: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0482: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0483: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0484: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0485: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0486: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0487: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0488: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0489: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0490: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0491: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0492: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0493: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0494: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0495: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0496: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0497: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0498: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0499: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0500: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0501: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0502: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0503: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0504: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0505: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0506: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0507: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0508: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0509: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0510: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0511: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0512: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0513: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0514: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0515: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0516: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0517: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0518: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0519: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0520: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0521: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0522: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0523: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0524: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0525: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0526: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0527: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0528: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0529: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0530: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0531: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0532: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0533: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0534: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0535: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0536: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0537: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0538: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0539: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0540: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0541: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0542: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0543: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0544: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0545: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0546: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0547: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0548: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0549: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0550: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0551: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0552: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0553: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0554: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0555: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0556: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0557: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0558: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0559: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0560: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0561: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0562: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0563: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0564: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0565: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0566: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0567: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0568: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0569: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0570: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0571: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0572: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0573: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0574: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0575: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0576: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0577: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0578: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0579: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0580: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0581: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0582: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0583: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0584: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0585: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0586: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0587: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0588: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0589: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0590: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0591: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0592: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0593: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0594: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0595: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0596: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0597: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0598: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0599: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0600: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0601: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0602: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0603: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0604: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0605: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0606: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0607: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0608: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0609: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0610: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0611: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0612: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0613: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0614: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0615: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0616: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0617: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0618: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0619: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0620: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0621: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0622: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0623: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0624: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0625: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0626: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0627: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0628: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0629: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0630: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0631: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0632: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0633: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0634: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0635: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0636: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0637: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0638: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0639: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0640: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0641: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0642: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0643: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0644: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0645: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0646: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0647: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0648: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0649: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0650: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0651: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0652: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0653: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0654: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0655: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0656: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0657: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0658: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0659: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0660: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0661: Script Not Running / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving script not running in the metadata domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0662: Gm Api Undefined / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving GM API undefined in the matching domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0663: Cross-Origin Request Blocked / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cross-origin request blocked in the sandbox domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0664: Dashboard Stale State / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving dashboard stale state in the gm-api domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0665: Editor Save Conflict / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving editor save conflict in the network domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0666: Import Duplicates / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving import duplicates in the storage domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0667: Update Dangerous Permissions / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving update dangerous permissions in the sync domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0668: Mv3 Intermittent Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving MV3 intermittent issue in the dashboard domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0669: Cookie Access Bug / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cookie access bug in the editor domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0670: Menu Command Bug / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving menu command bug in the permissions domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0671: Value Listener Bug / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving value listener bug in the offscreen domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0672: Localization Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving localization issue in the i18n domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0673: Script Not Running / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving script not running in the import-export domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0674: Gm Api Undefined / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving GM API undefined in the updates domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0675: Cross-Origin Request Blocked / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cross-origin request blocked in the diagnostics domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0676: Dashboard Stale State / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving dashboard stale state in the security domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0677: Editor Save Conflict / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving editor save conflict in the popup domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0678: Import Duplicates / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving import duplicates in the cookies domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0679: Update Dangerous Permissions / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving update dangerous permissions in the downloads domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0680: Mv3 Intermittent Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving MV3 intermittent issue in the resources domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0681: Cookie Access Bug / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cookie access bug in the metadata domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0682: Menu Command Bug / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving menu command bug in the matching domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0683: Value Listener Bug / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving value listener bug in the sandbox domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0684: Localization Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving localization issue in the gm-api domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0685: Script Not Running / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving script not running in the network domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0686: Gm Api Undefined / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving GM API undefined in the storage domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0687: Cross-Origin Request Blocked / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cross-origin request blocked in the sync domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0688: Dashboard Stale State / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving dashboard stale state in the dashboard domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0689: Editor Save Conflict / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving editor save conflict in the editor domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0690: Import Duplicates / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving import duplicates in the permissions domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0691: Update Dangerous Permissions / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving update dangerous permissions in the offscreen domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0692: Mv3 Intermittent Issue / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving MV3 intermittent issue in the i18n domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0693: Cookie Access Bug / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving cookie access bug in the import-export domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0694: Menu Command Bug / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving menu command bug in the updates domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0695: Value Listener Bug / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving value listener bug in the diagnostics domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0696: Localization Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving localization issue in the security domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0697: Script Not Running / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving script not running in the popup domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0698: Gm Api Undefined / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving GM API undefined in the cookies domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0699: Cross-Origin Request Blocked / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving cross-origin request blocked in the downloads domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0700: Dashboard Stale State / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving dashboard stale state in the resources domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.


## Card 0701: Editor Save Conflict / metadata / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving editor save conflict in the metadata domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MetadataMaintenancePlan`, `implementMetadataChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `metadata`.


## Card 0702: Import Duplicates / matching / review

**Question an agent might ask:** How should I review a userscript-manager issue involving import duplicates in the matching domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `MatchingMaintenancePlan`, `reviewMatchingChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `matching`.


## Card 0703: Update Dangerous Permissions / sandbox / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving update dangerous permissions in the sandbox domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SandboxMaintenancePlan`, `debugSandboxChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sandbox`.


## Card 0704: Mv3 Intermittent Issue / gm-api / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving MV3 intermittent issue in the gm-api domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `GmApiMaintenancePlan`, `refactorGmApiChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `gm-api`.


## Card 0705: Cookie Access Bug / network / test

**Question an agent might ask:** How should I test a userscript-manager issue involving cookie access bug in the network domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `NetworkMaintenancePlan`, `testNetworkChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `network`.


## Card 0706: Menu Command Bug / storage / document

**Question an agent might ask:** How should I document a userscript-manager issue involving menu command bug in the storage domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `StorageMaintenancePlan`, `documentStorageChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `storage`.


## Card 0707: Value Listener Bug / sync / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving value listener bug in the sync domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SyncMaintenancePlan`, `migrateSyncChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `sync`.


## Card 0708: Localization Issue / dashboard / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving localization issue in the dashboard domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DashboardMaintenancePlan`, `hardenDashboardChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `dashboard`.


## Card 0709: Script Not Running / editor / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving script not running in the editor domain?

**Answer:** Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `EditorMaintenancePlan`, `profileEditorChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `editor`.


## Card 0710: Gm Api Undefined / permissions / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving GM API undefined in the permissions domain?

**Answer:** Check grants, aliases, compatibility mode, and bridge generation. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PermissionsMaintenancePlan`, `localizePermissionsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `permissions`.


## Card 0711: Cross-Origin Request Blocked / offscreen / implement

**Question an agent might ask:** How should I implement a userscript-manager issue involving cross-origin request blocked in the offscreen domain?

**Answer:** Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `OffscreenMaintenancePlan`, `implementOffscreenChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `offscreen`.


## Card 0712: Dashboard Stale State / i18n / review

**Question an agent might ask:** How should I review a userscript-manager issue involving dashboard stale state in the i18n domain?

**Answer:** Check repository event emission, view-model refresh, selected script ID, and filter state. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `I18nMaintenancePlan`, `reviewI18nChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `i18n`.


## Card 0713: Editor Save Conflict / import-export / debug

**Question an agent might ask:** How should I debug a userscript-manager issue involving editor save conflict in the import-export domain?

**Answer:** Check dirty state, source hash, metadata parse result, and conflict recovery UI. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ImportExportMaintenancePlan`, `debugImportExportChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `import-export`.


## Card 0714: Import Duplicates / updates / refactor

**Question an agent might ask:** How should I refactor a userscript-manager issue involving import duplicates in the updates domain?

**Answer:** Check identity mapping, namespace/name/version rules, and dry-run conflict report. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `UpdatesMaintenancePlan`, `refactorUpdatesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `updates`.


## Card 0715: Update Dangerous Permissions / diagnostics / test

**Question an agent might ask:** How should I test a userscript-manager issue involving update dangerous permissions in the diagnostics domain?

**Answer:** Compare old/new grants, connect hosts, match scope, resources, and prompt text. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DiagnosticsMaintenancePlan`, `testDiagnosticsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `diagnostics`.


## Card 0716: Mv3 Intermittent Issue / security / document

**Question an agent might ask:** How should I document a userscript-manager issue involving MV3 intermittent issue in the security domain?

**Answer:** Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `SecurityMaintenancePlan`, `documentSecurityChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `security`.


## Card 0717: Cookie Access Bug / popup / migrate

**Question an agent might ask:** How should I migrate a userscript-manager issue involving cookie access bug in the popup domain?

**Answer:** Check cookie permission, URL scope, incognito store, and user prompt. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `PopupMaintenancePlan`, `migratePopupChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `popup`.


## Card 0718: Menu Command Bug / cookies / harden

**Question an agent might ask:** How should I harden a userscript-manager issue involving menu command bug in the cookies domain?

**Answer:** Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `CookiesMaintenancePlan`, `hardenCookiesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `cookies`.


## Card 0719: Value Listener Bug / downloads / profile

**Question an agent might ask:** How should I profile a userscript-manager issue involving value listener bug in the downloads domain?

**Answer:** Check namespace, port lifetime, old/new value serialization, and listener cleanup. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `DownloadsMaintenancePlan`, `profileDownloadsChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `downloads`.


## Card 0720: Localization Issue / resources / localize

**Question an agent might ask:** How should I localize a userscript-manager issue involving localization issue in the resources domain?

**Answer:** Check message key, placeholder names, pluralization, and UI text consistency. Then map the observation to a named boundary: metadata parser, script repository, match engine, injection planner, GM API bridge, network gateway, value store, resource cache, command router, offscreen task manager, dashboard view model, or editor document state.

**Readable names to use:** `ScriptExecutionContext`, `StoredUserscriptRecord`, `PermissionDecision`, `RuntimeMessageEnvelope`, `ResourcesMaintenancePlan`, `localizeResourcesChange`.

**Review invariant:** The patch is not complete until the script ID, tab/frame URL, grant or permission decision, user-visible state, and diagnostic output are all understandable without reading minified source.

**Open modules:** `modules/09-debugging-issue-fix.md`, `modules/11-universal-coding-models.md`, and the relevant domain module for `resources`.
