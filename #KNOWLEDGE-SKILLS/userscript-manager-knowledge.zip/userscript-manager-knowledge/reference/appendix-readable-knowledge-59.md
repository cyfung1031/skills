# Readable Knowledge Appendix 59

This appendix keeps the package above the requested size while remaining useful, readable, and domain-specific. It contains no raw source dump.


## Appendix entry 59-001: matching / implement

When an agent needs to implement `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-002: sandbox / review

When an agent needs to review `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-003: gm-api / debug

When an agent needs to debug `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-004: network / refactor

When an agent needs to refactor `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-005: storage / test

When an agent needs to test `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-006: sync / document

When an agent needs to document `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-007: dashboard / migrate

When an agent needs to migrate `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-008: editor / harden

When an agent needs to harden `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-009: permissions / profile

When an agent needs to profile `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profilePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-010: offscreen / localize

When an agent needs to localize `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-011: i18n / implement

When an agent needs to implement `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-012: import-export / review

When an agent needs to review `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-013: updates / debug

When an agent needs to debug `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-014: diagnostics / refactor

When an agent needs to refactor `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-015: security / test

When an agent needs to test `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-016: popup / document

When an agent needs to document `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-017: cookies / migrate

When an agent needs to migrate `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-018: downloads / harden

When an agent needs to harden `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-019: resources / profile

When an agent needs to profile `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-020: metadata / localize

When an agent needs to localize `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-021: matching / implement

When an agent needs to implement `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-022: sandbox / review

When an agent needs to review `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-023: gm-api / debug

When an agent needs to debug `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-024: network / refactor

When an agent needs to refactor `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-025: storage / test

When an agent needs to test `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-026: sync / document

When an agent needs to document `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-027: dashboard / migrate

When an agent needs to migrate `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-028: editor / harden

When an agent needs to harden `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-029: permissions / profile

When an agent needs to profile `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `profilePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-030: offscreen / localize

When an agent needs to localize `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `localizeOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-031: i18n / implement

When an agent needs to implement `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `implementI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-032: import-export / review

When an agent needs to review `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `reviewImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-033: updates / debug

When an agent needs to debug `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `debugUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-034: diagnostics / refactor

When an agent needs to refactor `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `refactorDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-035: security / test

When an agent needs to test `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `testSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-036: popup / document

When an agent needs to document `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `documentPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-037: cookies / migrate

When an agent needs to migrate `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `migrateCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-038: downloads / harden

When an agent needs to harden `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-039: resources / profile

When an agent needs to profile `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-040: metadata / localize

When an agent needs to localize `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-041: matching / implement

When an agent needs to implement `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-042: sandbox / review

When an agent needs to review `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-043: gm-api / debug

When an agent needs to debug `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-044: network / refactor

When an agent needs to refactor `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-045: storage / test

When an agent needs to test `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-046: sync / document

When an agent needs to document `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-047: dashboard / migrate

When an agent needs to migrate `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-048: editor / harden

When an agent needs to harden `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-049: permissions / profile

When an agent needs to profile `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profilePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-050: offscreen / localize

When an agent needs to localize `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-051: i18n / implement

When an agent needs to implement `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-052: import-export / review

When an agent needs to review `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-053: updates / debug

When an agent needs to debug `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-054: diagnostics / refactor

When an agent needs to refactor `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-055: security / test

When an agent needs to test `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-056: popup / document

When an agent needs to document `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-057: cookies / migrate

When an agent needs to migrate `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migrateCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-058: downloads / harden

When an agent needs to harden `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-059: resources / profile

When an agent needs to profile `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-060: metadata / localize

When an agent needs to localize `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-061: matching / implement

When an agent needs to implement `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-062: sandbox / review

When an agent needs to review `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-063: gm-api / debug

When an agent needs to debug `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-064: network / refactor

When an agent needs to refactor `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-065: storage / test

When an agent needs to test `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-066: sync / document

When an agent needs to document `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-067: dashboard / migrate

When an agent needs to migrate `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-068: editor / harden

When an agent needs to harden `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-069: permissions / profile

When an agent needs to profile `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profilePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-070: offscreen / localize

When an agent needs to localize `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-071: i18n / implement

When an agent needs to implement `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-072: import-export / review

When an agent needs to review `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-073: updates / debug

When an agent needs to debug `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-074: diagnostics / refactor

When an agent needs to refactor `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-075: security / test

When an agent needs to test `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-076: popup / document

When an agent needs to document `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-077: cookies / migrate

When an agent needs to migrate `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-078: downloads / harden

When an agent needs to harden `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-079: resources / profile

When an agent needs to profile `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-080: metadata / localize

When an agent needs to localize `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-081: matching / implement

When an agent needs to implement `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-082: sandbox / review

When an agent needs to review `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-083: gm-api / debug

When an agent needs to debug `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-084: network / refactor

When an agent needs to refactor `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-085: storage / test

When an agent needs to test `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-086: sync / document

When an agent needs to document `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-087: dashboard / migrate

When an agent needs to migrate `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-088: editor / harden

When an agent needs to harden `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-089: permissions / profile

When an agent needs to profile `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `profilePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-090: offscreen / localize

When an agent needs to localize `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `localizeOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-091: i18n / implement

When an agent needs to implement `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `implementI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-092: import-export / review

When an agent needs to review `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `reviewImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-093: updates / debug

When an agent needs to debug `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `debugUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-094: diagnostics / refactor

When an agent needs to refactor `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `refactorDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-095: security / test

When an agent needs to test `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `testSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-096: popup / document

When an agent needs to document `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `documentPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-097: cookies / migrate

When an agent needs to migrate `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `migrateCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-098: downloads / harden

When an agent needs to harden `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-099: resources / profile

When an agent needs to profile `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 59-100: metadata / localize

When an agent needs to localize `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?
