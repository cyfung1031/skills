# Reference Directory

All reference files are readable markdown. They summarize inspected source files, APIs, messages, UI concepts, selectors, diagnostics, and universal coding patterns. Raw bundled/minified source chunks are intentionally not included.

For exact implementation work, use the file atlas and source notes to find the right original source file in the uploaded archive, then inspect the source only as needed.


## Appendix files

| File | Purpose |
| --- | --- |
| reference/appendix-readable-knowledge-01.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-02.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-03.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-04.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-05.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-06.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-07.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-08.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-09.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-10.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-11.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-12.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-13.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-14.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-15.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-16.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-17.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-18.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-19.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-20.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-21.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-22.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-23.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-24.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-25.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-26.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-27.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-28.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-29.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-30.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-31.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-32.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-33.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-34.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-35.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-36.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-37.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-38.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-39.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-40.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-41.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-42.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-43.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-44.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-45.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-46.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-47.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-48.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-49.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-50.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-51.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-52.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-53.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-54.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-55.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-56.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-57.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-58.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-59.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-60.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
| reference/appendix-readable-knowledge-61.md | Readable domain-specific appendix, generated to keep the package size target without unreadable code chunks. |
