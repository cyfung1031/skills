# Readable Knowledge Appendix 14

This appendix keeps the package above the requested size while remaining useful, readable, and domain-specific. It contains no raw source dump.


## Appendix entry 14-001: matching / document

When an agent needs to document `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-002: sandbox / migrate

When an agent needs to migrate `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-003: gm-api / harden

When an agent needs to harden `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-004: network / profile

When an agent needs to profile `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-005: storage / localize

When an agent needs to localize `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-006: sync / implement

When an agent needs to implement `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-007: dashboard / review

When an agent needs to review `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-008: editor / debug

When an agent needs to debug `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-009: permissions / refactor

When an agent needs to refactor `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-010: offscreen / test

When an agent needs to test `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-011: i18n / document

When an agent needs to document `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-012: import-export / migrate

When an agent needs to migrate `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-013: updates / harden

When an agent needs to harden `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-014: diagnostics / profile

When an agent needs to profile `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `profileDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-015: security / localize

When an agent needs to localize `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `localizeSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-016: popup / implement

When an agent needs to implement `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `implementPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-017: cookies / review

When an agent needs to review `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `reviewCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-018: downloads / debug

When an agent needs to debug `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `debugDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-019: resources / refactor

When an agent needs to refactor `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `refactorResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-020: metadata / test

When an agent needs to test `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `testMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-021: matching / document

When an agent needs to document `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `documentMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-022: sandbox / migrate

When an agent needs to migrate `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `migrateSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-023: gm-api / harden

When an agent needs to harden `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-024: network / profile

When an agent needs to profile `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-025: storage / localize

When an agent needs to localize `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-026: sync / implement

When an agent needs to implement `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-027: dashboard / review

When an agent needs to review `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-028: editor / debug

When an agent needs to debug `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-029: permissions / refactor

When an agent needs to refactor `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-030: offscreen / test

When an agent needs to test `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-031: i18n / document

When an agent needs to document `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-032: import-export / migrate

When an agent needs to migrate `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-033: updates / harden

When an agent needs to harden `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-034: diagnostics / profile

When an agent needs to profile `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-035: security / localize

When an agent needs to localize `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-036: popup / implement

When an agent needs to implement `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-037: cookies / review

When an agent needs to review `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-038: downloads / debug

When an agent needs to debug `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-039: resources / refactor

When an agent needs to refactor `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-040: metadata / test

When an agent needs to test `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-041: matching / document

When an agent needs to document `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-042: sandbox / migrate

When an agent needs to migrate `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migrateSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-043: gm-api / harden

When an agent needs to harden `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-044: network / profile

When an agent needs to profile `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-045: storage / localize

When an agent needs to localize `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-046: sync / implement

When an agent needs to implement `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-047: dashboard / review

When an agent needs to review `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-048: editor / debug

When an agent needs to debug `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-049: permissions / refactor

When an agent needs to refactor `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-050: offscreen / test

When an agent needs to test `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-051: i18n / document

When an agent needs to document `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-052: import-export / migrate

When an agent needs to migrate `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-053: updates / harden

When an agent needs to harden `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-054: diagnostics / profile

When an agent needs to profile `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profileDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-055: security / localize

When an agent needs to localize `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-056: popup / implement

When an agent needs to implement `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-057: cookies / review

When an agent needs to review `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-058: downloads / debug

When an agent needs to debug `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-059: resources / refactor

When an agent needs to refactor `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-060: metadata / test

When an agent needs to test `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-061: matching / document

When an agent needs to document `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-062: sandbox / migrate

When an agent needs to migrate `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-063: gm-api / harden

When an agent needs to harden `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-064: network / profile

When an agent needs to profile `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-065: storage / localize

When an agent needs to localize `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-066: sync / implement

When an agent needs to implement `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-067: dashboard / review

When an agent needs to review `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-068: editor / debug

When an agent needs to debug `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-069: permissions / refactor

When an agent needs to refactor `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-070: offscreen / test

When an agent needs to test `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-071: i18n / document

When an agent needs to document `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-072: import-export / migrate

When an agent needs to migrate `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-073: updates / harden

When an agent needs to harden `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-074: diagnostics / profile

When an agent needs to profile `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `profileDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-075: security / localize

When an agent needs to localize `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `localizeSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-076: popup / implement

When an agent needs to implement `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `implementPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-077: cookies / review

When an agent needs to review `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `reviewCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-078: downloads / debug

When an agent needs to debug `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `debugDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-079: resources / refactor

When an agent needs to refactor `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `refactorResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-080: metadata / test

When an agent needs to test `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `testMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-081: matching / document

When an agent needs to document `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `documentMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-082: sandbox / migrate

When an agent needs to migrate `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `migrateSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-083: gm-api / harden

When an agent needs to harden `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-084: network / profile

When an agent needs to profile `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-085: storage / localize

When an agent needs to localize `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-086: sync / implement

When an agent needs to implement `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-087: dashboard / review

When an agent needs to review `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-088: editor / debug

When an agent needs to debug `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-089: permissions / refactor

When an agent needs to refactor `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-090: offscreen / test

When an agent needs to test `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-091: i18n / document

When an agent needs to document `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-092: import-export / migrate

When an agent needs to migrate `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-093: updates / harden

When an agent needs to harden `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-094: diagnostics / profile

When an agent needs to profile `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-095: security / localize

When an agent needs to localize `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-096: popup / implement

When an agent needs to implement `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-097: cookies / review

When an agent needs to review `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-098: downloads / debug

When an agent needs to debug `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-099: resources / refactor

When an agent needs to refactor `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 14-100: metadata / test

When an agent needs to test `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?
