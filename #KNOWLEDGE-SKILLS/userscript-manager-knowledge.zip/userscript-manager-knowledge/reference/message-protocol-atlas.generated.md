# Message Protocol Atlas

The inspected source bundles contain many command names and message-like strings. This file does not reproduce handlers; it maps vocabulary into a readable protocol model.

## Envelope contract


```ts
async function routeRuntimeMessage<Payload>(
  envelope: RuntimeMessageEnvelope<Payload>,
  services: UserscriptManagerServices,
): Promise<RuntimeMessageResponse> {
  assertKnownSender(envelope.senderContext);
  assertExpectedTarget(envelope.targetContext, 'background');
  assertCommandIsRegistered(envelope.commandName);

  const commandHandler = services.commandRegistry.get(envelope.commandName);
  const permissionDecision = await services.permissionService.authorizeCommand(envelope);
  if (permissionDecision.decision === 'deny') {
    return buildDeniedResponse(envelope, permissionDecision.reason);
  }

  const commandResult = await commandHandler.handle(envelope.payload, buildCommandContext(envelope));
  return buildSuccessfulResponse(envelope, commandResult);
}
```


## Vocabulary hints

| String | Mentions | Kind | Readable guidance |
| --- | --- | --- | --- |
| message | 26573 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| description | 295 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| connect | 103 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| import | 102 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| export | 100 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| async | 94 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| javascript | 90 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| script | 83 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| editor | 78 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| install | 71 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| update | 68 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| table | 67 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| extDescription | 64 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| options | 60 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ImportSpecifier | 59 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Editor | 54 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| onUpdate:modelValue | 54 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ExportNamedDeclaration | 51 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Update | 50 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Import | 47 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| UpdateExpression | 45 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Export | 44 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| typescript | 42 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Install | 42 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| run-at | 41 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Reinstall | 41 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ImportExpression | 40 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| sync | 38 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ExportSpecifier | 38 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| text/javascript | 37 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelRunAtDefault | 37 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Description | 36 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Apply_update | 36 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Storage | 36 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Userscripts | 36 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSync | 36 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgInvalidScript | 36 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ExportAllDeclaration | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ExportDefaultDeclaration | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| update_success | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Downloads | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Last_updated | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| You_are_about_to_install_a_UserScript_ | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| buttonImportData | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionUpdate | 35 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Check_for_Updates | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Check_for_userscripts_updates | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Report_an_issue_to_the_script_hoster_ | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| descEditorOptions | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| installFrom | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelHttpOnlyCookie | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelHttpOnlyCookieHint | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelInstall | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuScriptDisabled | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgSyncInitError | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgUpdated | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| reloadTab | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| skipScripts | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| updateScriptsInTab | 34 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Tabs | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ImportDeclaration | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Add_new_script___ | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Invalid_UserScript_name__Sry_ | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| No_update_found__sry_ | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_Update | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_does_not_provide_any__include_information_ | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| buttonExportData | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| buttonInstallFromURL | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| buttonShowEditorState | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| buttonSyncPullOnce | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| buttonSyncPushOnce | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| buttonUpdate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| confirmManualUpdate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| confirmUndoImport | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| descEditorOptionsGeneric | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| descEditorOptionsVM | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| descScriptTemplate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| disabledScriptsGroup | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| disabledScriptsHide | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| disabledScriptsSelector | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| disabledScriptsShow | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| failureReasonNoninjectable | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| fileInstallBlocked | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| filterLastUpdateOrder | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| hintUseDownloadURL | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| installOptionTrackTooltip | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelAllowUpdate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelAutoReloadCurrentTab | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelAutoUpdate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelDownloadURL | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelEditor | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelEnabledScriptsOnly | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelExportScriptData | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelImportScriptData | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelImportSettings | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelLastUpdatedAt | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelNoSearchScripts | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelNotifyThisUpdated | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelNotifyUpdates | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelNotifyUpdatesGlobal | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelPageMenuCommands | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelReinstall | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelRunAt | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelScriptOptionRequired | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelScriptOptionRequiredGlobal | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelScriptTemplate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSearchScript | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncAnonymous | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncAuthorize | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncAuthorizing | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncAutomatically | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncDisabled | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncPassword | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncRevoke | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncS3AccessKeyId | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncS3Bucket | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncS3Endpoint | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncS3Prefix | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncS3Region | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncS3SecretAccessKey | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncScriptStatus | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncServerUrl | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncService | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelSyncUsername | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelUpdateURL | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelViewTable | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelXhrInject | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelXhrInjectHint | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| labelXhrInjectNote | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| lastSync | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuDashboard | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuExclude | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuExcludeHint | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuFeedback | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuFindScripts | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuInjectionFailed | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuInjectionFailedFix | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuMatchedDisabledScripts | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuMatchedFrameScripts | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuMatchedScripts | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuNewScript | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| menuScriptEnabled | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgCheckingForUpdate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgErrorFetchingScript | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgErrorFetchingUpdateInfo | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgImported | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgInstalled | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgNoUpdate | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgOpenUpdateErrors | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgReinstallScripts | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgScriptUpdated | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgSyncError | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgSyncInit | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgSyncNoAuthYet | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| msgSyncing | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionEditorWindow | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionEditorWindowHint | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionEditorWindowSimple | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionPopup | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionPopupEnabledFirst | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionPopupGroupRunAt | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| optionShowEnabledFirst | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| popupSettings | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| popupSettingsHint | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| reinstall | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| reloadTabTrackHint | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| sideMenuAbout | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| sideMenuInstalled | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| sideMenuSettings | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| skipScriptsMsg | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| updateListedCmd | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| updateScript | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| updateScriptForced | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| updateScriptsAll | 33 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| exports | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| tabIndex | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| All_script_settings_will_be_reset_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| An_error_occured_during_import_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Apply_compatibility_options_to_required_script_too | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Apply_this_action_to_the_selected_scripts | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Are_you_sure_that_you_don_t_want_to_be_notified_of_updates_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| CONFLICT__This_script_was_modified_0t0_seconds_ago_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Changes_the_number_of_visible_config_options | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Check_disabled_scripts | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Click_here_to_allow_TM_to_start_downloads | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Debug_scripts | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Disable_Updates | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Disable_all_remaining_scripts_of_this_tag | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Disable_all_scripts_of_this_tag | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Does_not_run_in_incognito_tabs | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Download_Mode | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Downloaded_from_0url0 | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Editor_reset | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Enable_all_scripts_of_this_tag | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| GM_compat_options_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Get_new_scripts___ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Get_some_scripts___ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Global_settings_import | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Import_from_file | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Imported | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Include_script_storage | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Installed_Version_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Installed_userscripts | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Invalid_UserScript__Sry_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Malicious_scripts_can_violate_your_privacy_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| No_script_is_installed | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| No_script_is_running | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| One_or_more_compatibility_options_are_set | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Please_check_the_0editor0_documentation_for_more_details_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Run_at | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Run_in | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Scan_the_QR_code_to_use_Tampermonkey_on_your_phone_or_tablet_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_Blacklist_Source | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_Tags | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_cookies_access | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_name_0name0 | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| TabMode | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Tampermonkey_won_t_inject_into_other_tab_types_anymore_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| The_Browser_API_mode_requires_a_special_permission_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| The_update_url_has_changed_from_0oldurl0_to__0newurl0 | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_editor_is_tracking_the_changes_of_0name0_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_is_a_system_script | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_is_a_userscript | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_has_access_to_https_pages | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_has_full_web_access | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_stores_data | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_will_remove_all_remote_data_from_sync_Ok_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_will_remove_all_scripts_and_reset_all_settings_Ok_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Trigger_Update | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Unable_to_load_script_from_url_0url0 | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Update_Notification | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Updated_to__0version0 | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Waiting_for_sync_to_finish | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| You_are_about_to_downgrade_a_UserScript | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| You_are_about_to_modify_a_UserScript_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| You_are_about_to_reinstall_a_UserScript_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| You_are_about_to_update_a_UserScript_ | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| connect_mode | 32 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| download | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ImportDefaultSpecifier | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ImportNamespaceSpecifier | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| permission | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| A_userscript_wants_to_access_a_cross_origin_resource_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Action_Menu | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Allow_headers_to_be_modified_by_scripts | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Alltime_running_instances | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Auto_reload_on_script_enabled | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Auto_reload_on_script_enabled_desc | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Browser_API_Downloads | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Click_here_to_install_it_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Click_here_to_move_this_script | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Does_not_run_in_normal_tabs | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Dont_ask_me_for_simple_script_updates | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Enable_Editor | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Enable_Script_Sync | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Focus_tab | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Hide_disabled_scripts | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Hide_notification_after | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Install_this_script | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Manual_Script_Blacklist | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| New_script_template_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| New_userscript | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Please_enable_the_allow_userscripts_extension_setting_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Proxy_Permission | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Run_syntax_check | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Running_scripts | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_URL_detection | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_order | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Show_notification | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Sync_Reset | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Sync_Type | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Tampermonkey_has_no_file_access_permission_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| There_is_an_update_for_0name0_avaiable_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_is_blacklisted_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Unique_running_scripts | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Update_URL_ | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Update_interval | 31 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Check_only_scripts_up_to_this_size_automatically_ | 30 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Really_factory_reset_this_script_ | 30 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| XHR_Security | 30 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| run-in | 29 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| exported | 29 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Tab_URL | 29 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Updates | 29 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| scripts | 28 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| check_update | 28 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| contextmenu | 28 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| notification | 28 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| confirm_update | 28 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Tampermonkey_and_script_version | 28 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Update_check_is_disabled | 28 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| ScriptCat | 27 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| enable_script | 27 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| At_least_one_new_connect_statement_was_added_ | 26 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_Sync | 26 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| cookie | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| GM_registerMenuCommand | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| writable | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| xmlhttprequest | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Automatic_installation | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Browser_Sync | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_local_files_access | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| The_diff_for_this_script_is_too_large_to_render | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_was_deleted | 25 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| sendMessage | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| running | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_0name0_is_slowing_down_some_page_loads_ | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Sync_finished | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Sync_is_running | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_was_executed_0count0_times | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_was_not_executed | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_was_not_executed_yet | 24 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| editor_config | 23 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Lines_Menu | 23 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| scriptcat | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| GM_cookie | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| GM.cookie | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| normal-tabs | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| incognito-tabs | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Cross_Origin_Request_Permission | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Include_script_externals | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Try_to_install_as_script | 22 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| editor_type_definition | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| last_updated | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Import_from_URL | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Tab_Size | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| The_origin_of_this_script_cant_be_determined_ | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Incognito_tabs | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Normal_tabs | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| On_Action_Menu | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Search_for_userscripts_for_this_tab | 21 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| GM_openInTab | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| tabSize | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| popup | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| script_name | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| All_tabs | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Allow_scripts_to_run_scripts_in | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Antifeature__0name0__0description0 | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Context_Menu | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Enable_context_menu | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Found_0count0_available_scripts | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| No_available_scripts | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Really_delete_all_userscripts_ | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Really_restore_all_userscripts_ | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Script_menu_commands | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Searching_for_userscripts_for_this_tab | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_does_not_require_any_special_powers_ | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| This_script_was_deleted_by_the_hoster_ | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Userscript_Search | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |
| Userscript_search_integration_mode | 20 | message/command vocabulary | Use as search hint; prefer explicit RuntimeMessageEnvelope in new code. |

## Recommended command families

| Family | Example commands | Required context |
| --- | --- | --- |
| Script value store | `scriptValue.get`, `scriptValue.set`, `scriptValue.delete`, `scriptValue.observe` | script ID, value namespace, caller frame. |
| Network gateway | `networkRequest.start`, `networkRequest.abort`, `networkRequest.progress` | script ID, target URL, @connect decision. |
| Resource access | `resource.getText`, `resource.getUrl`, `resource.revokeUrl` | script ID, resource name, cache record. |
| Menu commands | `menuCommand.register`, `menuCommand.unregister`, `menuCommand.invoke` | script ID, tab/frame, title, callback ID. |
| Script lifecycle | `script.install`, `script.update`, `script.enable`, `script.disable`, `script.delete` | script record and user action source. |
| UI/editor | `editor.save`, `editor.lint`, `dashboard.refresh`, `popup.currentTabStatus` | UI route, selected script, dirty state. |
