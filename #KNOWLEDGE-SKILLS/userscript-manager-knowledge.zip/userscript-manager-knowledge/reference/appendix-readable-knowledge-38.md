# Readable Knowledge Appendix 38

This appendix keeps the package above the requested size while remaining useful, readable, and domain-specific. It contains no raw source dump.


## Appendix entry 38-001: matching / localize

When an agent needs to localize `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-002: sandbox / implement

When an agent needs to implement `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-003: gm-api / review

When an agent needs to review `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-004: network / debug

When an agent needs to debug `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-005: storage / refactor

When an agent needs to refactor `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-006: sync / test

When an agent needs to test `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-007: dashboard / document

When an agent needs to document `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-008: editor / migrate

When an agent needs to migrate `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-009: permissions / harden

When an agent needs to harden `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-010: offscreen / profile

When an agent needs to profile `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-011: i18n / localize

When an agent needs to localize `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-012: import-export / implement

When an agent needs to implement `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-013: updates / review

When an agent needs to review `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-014: diagnostics / debug

When an agent needs to debug `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-015: security / refactor

When an agent needs to refactor `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-016: popup / test

When an agent needs to test `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-017: cookies / document

When an agent needs to document `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-018: downloads / migrate

When an agent needs to migrate `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migrateDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-019: resources / harden

When an agent needs to harden `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-020: metadata / profile

When an agent needs to profile `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-021: matching / localize

When an agent needs to localize `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-022: sandbox / implement

When an agent needs to implement `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-023: gm-api / review

When an agent needs to review `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-024: network / debug

When an agent needs to debug `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-025: storage / refactor

When an agent needs to refactor `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-026: sync / test

When an agent needs to test `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-027: dashboard / document

When an agent needs to document `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-028: editor / migrate

When an agent needs to migrate `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-029: permissions / harden

When an agent needs to harden `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-030: offscreen / profile

When an agent needs to profile `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profileOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-031: i18n / localize

When an agent needs to localize `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-032: import-export / implement

When an agent needs to implement `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-033: updates / review

When an agent needs to review `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-034: diagnostics / debug

When an agent needs to debug `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-035: security / refactor

When an agent needs to refactor `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-036: popup / test

When an agent needs to test `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-037: cookies / document

When an agent needs to document `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-038: downloads / migrate

When an agent needs to migrate `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-039: resources / harden

When an agent needs to harden `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-040: metadata / profile

When an agent needs to profile `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-041: matching / localize

When an agent needs to localize `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-042: sandbox / implement

When an agent needs to implement `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-043: gm-api / review

When an agent needs to review `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-044: network / debug

When an agent needs to debug `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-045: storage / refactor

When an agent needs to refactor `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-046: sync / test

When an agent needs to test `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-047: dashboard / document

When an agent needs to document `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-048: editor / migrate

When an agent needs to migrate `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-049: permissions / harden

When an agent needs to harden `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-050: offscreen / profile

When an agent needs to profile `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `profileOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-051: i18n / localize

When an agent needs to localize `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `localizeI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-052: import-export / implement

When an agent needs to implement `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `implementImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-053: updates / review

When an agent needs to review `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `reviewUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-054: diagnostics / debug

When an agent needs to debug `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `debugDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-055: security / refactor

When an agent needs to refactor `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `refactorSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-056: popup / test

When an agent needs to test `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `testPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-057: cookies / document

When an agent needs to document `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `documentCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-058: downloads / migrate

When an agent needs to migrate `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `migrateDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-059: resources / harden

When an agent needs to harden `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-060: metadata / profile

When an agent needs to profile `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-061: matching / localize

When an agent needs to localize `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-062: sandbox / implement

When an agent needs to implement `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-063: gm-api / review

When an agent needs to review `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-064: network / debug

When an agent needs to debug `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-065: storage / refactor

When an agent needs to refactor `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-066: sync / test

When an agent needs to test `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-067: dashboard / document

When an agent needs to document `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-068: editor / migrate

When an agent needs to migrate `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-069: permissions / harden

When an agent needs to harden `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-070: offscreen / profile

When an agent needs to profile `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-071: i18n / localize

When an agent needs to localize `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-072: import-export / implement

When an agent needs to implement `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-073: updates / review

When an agent needs to review `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-074: diagnostics / debug

When an agent needs to debug `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-075: security / refactor

When an agent needs to refactor `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-076: popup / test

When an agent needs to test `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-077: cookies / document

When an agent needs to document `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-078: downloads / migrate

When an agent needs to migrate `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migrateDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-079: resources / harden

When an agent needs to harden `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-080: metadata / profile

When an agent needs to profile `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-081: matching / localize

When an agent needs to localize `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-082: sandbox / implement

When an agent needs to implement `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-083: gm-api / review

When an agent needs to review `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-084: network / debug

When an agent needs to debug `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-085: storage / refactor

When an agent needs to refactor `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-086: sync / test

When an agent needs to test `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-087: dashboard / document

When an agent needs to document `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-088: editor / migrate

When an agent needs to migrate `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-089: permissions / harden

When an agent needs to harden `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-090: offscreen / profile

When an agent needs to profile `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profileOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-091: i18n / localize

When an agent needs to localize `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-092: import-export / implement

When an agent needs to implement `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-093: updates / review

When an agent needs to review `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-094: diagnostics / debug

When an agent needs to debug `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-095: security / refactor

When an agent needs to refactor `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-096: popup / test

When an agent needs to test `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-097: cookies / document

When an agent needs to document `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-098: downloads / migrate

When an agent needs to migrate `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-099: resources / harden

When an agent needs to harden `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 38-100: metadata / profile

When an agent needs to profile `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?
