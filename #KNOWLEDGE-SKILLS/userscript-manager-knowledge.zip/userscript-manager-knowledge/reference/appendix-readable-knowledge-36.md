# Readable Knowledge Appendix 36

This appendix keeps the package above the requested size while remaining useful, readable, and domain-specific. It contains no raw source dump.


## Appendix entry 36-001: matching / harden

When an agent needs to harden `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-002: sandbox / profile

When an agent needs to profile `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-003: gm-api / localize

When an agent needs to localize `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-004: network / implement

When an agent needs to implement `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-005: storage / review

When an agent needs to review `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-006: sync / debug

When an agent needs to debug `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-007: dashboard / refactor

When an agent needs to refactor `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-008: editor / test

When an agent needs to test `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-009: permissions / document

When an agent needs to document `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-010: offscreen / migrate

When an agent needs to migrate `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-011: i18n / harden

When an agent needs to harden `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-012: import-export / profile

When an agent needs to profile `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-013: updates / localize

When an agent needs to localize `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-014: diagnostics / implement

When an agent needs to implement `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-015: security / review

When an agent needs to review `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-016: popup / debug

When an agent needs to debug `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-017: cookies / refactor

When an agent needs to refactor `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-018: downloads / test

When an agent needs to test `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-019: resources / document

When an agent needs to document `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-020: metadata / migrate

When an agent needs to migrate `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migrateMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-021: matching / harden

When an agent needs to harden `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-022: sandbox / profile

When an agent needs to profile `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-023: gm-api / localize

When an agent needs to localize `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-024: network / implement

When an agent needs to implement `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-025: storage / review

When an agent needs to review `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-026: sync / debug

When an agent needs to debug `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-027: dashboard / refactor

When an agent needs to refactor `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-028: editor / test

When an agent needs to test `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-029: permissions / document

When an agent needs to document `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-030: offscreen / migrate

When an agent needs to migrate `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-031: i18n / harden

When an agent needs to harden `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-032: import-export / profile

When an agent needs to profile `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profileImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-033: updates / localize

When an agent needs to localize `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-034: diagnostics / implement

When an agent needs to implement `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-035: security / review

When an agent needs to review `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-036: popup / debug

When an agent needs to debug `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-037: cookies / refactor

When an agent needs to refactor `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-038: downloads / test

When an agent needs to test `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-039: resources / document

When an agent needs to document `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-040: metadata / migrate

When an agent needs to migrate `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-041: matching / harden

When an agent needs to harden `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-042: sandbox / profile

When an agent needs to profile `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-043: gm-api / localize

When an agent needs to localize `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-044: network / implement

When an agent needs to implement `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-045: storage / review

When an agent needs to review `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-046: sync / debug

When an agent needs to debug `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-047: dashboard / refactor

When an agent needs to refactor `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-048: editor / test

When an agent needs to test `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-049: permissions / document

When an agent needs to document `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-050: offscreen / migrate

When an agent needs to migrate `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-051: i18n / harden

When an agent needs to harden `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-052: import-export / profile

When an agent needs to profile `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `profileImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-053: updates / localize

When an agent needs to localize `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `localizeUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-054: diagnostics / implement

When an agent needs to implement `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `implementDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-055: security / review

When an agent needs to review `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `reviewSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-056: popup / debug

When an agent needs to debug `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `debugPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-057: cookies / refactor

When an agent needs to refactor `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `refactorCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-058: downloads / test

When an agent needs to test `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `testDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-059: resources / document

When an agent needs to document `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `documentResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-060: metadata / migrate

When an agent needs to migrate `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `migrateMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-061: matching / harden

When an agent needs to harden `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-062: sandbox / profile

When an agent needs to profile `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-063: gm-api / localize

When an agent needs to localize `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-064: network / implement

When an agent needs to implement `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-065: storage / review

When an agent needs to review `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-066: sync / debug

When an agent needs to debug `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-067: dashboard / refactor

When an agent needs to refactor `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-068: editor / test

When an agent needs to test `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-069: permissions / document

When an agent needs to document `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-070: offscreen / migrate

When an agent needs to migrate `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-071: i18n / harden

When an agent needs to harden `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-072: import-export / profile

When an agent needs to profile `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-073: updates / localize

When an agent needs to localize `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-074: diagnostics / implement

When an agent needs to implement `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-075: security / review

When an agent needs to review `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-076: popup / debug

When an agent needs to debug `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-077: cookies / refactor

When an agent needs to refactor `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-078: downloads / test

When an agent needs to test `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-079: resources / document

When an agent needs to document `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-080: metadata / migrate

When an agent needs to migrate `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migrateMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-081: matching / harden

When an agent needs to harden `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-082: sandbox / profile

When an agent needs to profile `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-083: gm-api / localize

When an agent needs to localize `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-084: network / implement

When an agent needs to implement `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-085: storage / review

When an agent needs to review `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-086: sync / debug

When an agent needs to debug `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-087: dashboard / refactor

When an agent needs to refactor `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-088: editor / test

When an agent needs to test `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-089: permissions / document

When an agent needs to document `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentPermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-090: offscreen / migrate

When an agent needs to migrate `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-091: i18n / harden

When an agent needs to harden `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-092: import-export / profile

When an agent needs to profile `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profileImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-093: updates / localize

When an agent needs to localize `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-094: diagnostics / implement

When an agent needs to implement `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-095: security / review

When an agent needs to review `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-096: popup / debug

When an agent needs to debug `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-097: cookies / refactor

When an agent needs to refactor `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-098: downloads / test

When an agent needs to test `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-099: resources / document

When an agent needs to document `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 36-100: metadata / migrate

When an agent needs to migrate `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migrateMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?
