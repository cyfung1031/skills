# Review Card Batch 11

Readable issue/review cards for userscript manager agents.


## Review card 0601

Scenario: script not running. Domain: metadata. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MetadataContext`, `ScriptNotRunningDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0602

Scenario: GM API undefined. Domain: matching. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MatchingContext`, `GmApiUndefinedDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0603

Scenario: cross-origin request blocked. Domain: sandbox. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SandboxContext`, `Cross-originRequestBlockedDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0604

Scenario: dashboard stale state. Domain: gm-api. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `GmApiContext`, `DashboardStaleStateDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0605

Scenario: editor save conflict. Domain: network. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `NetworkContext`, `EditorSaveConflictDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0606

Scenario: import duplicates. Domain: storage. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `StorageContext`, `ImportDuplicatesDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0607

Scenario: update dangerous permissions. Domain: sync. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SyncContext`, `UpdateDangerousPermissionsDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0608

Scenario: MV3 intermittent issue. Domain: dashboard. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DashboardContext`, `Mv3IntermittentIssueDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0609

Scenario: cookie access bug. Domain: editor. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `EditorContext`, `CookieAccessBugDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0610

Scenario: menu command bug. Domain: permissions. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PermissionsContext`, `MenuCommandBugDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0611

Scenario: value listener bug. Domain: offscreen. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `OffscreenContext`, `ValueListenerBugDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0612

Scenario: localization issue. Domain: i18n. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `I18nContext`, `LocalizationIssueDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0613

Scenario: script not running. Domain: import-export. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ImportExportContext`, `ScriptNotRunningDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0614

Scenario: GM API undefined. Domain: updates. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `UpdatesContext`, `GmApiUndefinedDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0615

Scenario: cross-origin request blocked. Domain: diagnostics. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DiagnosticsContext`, `Cross-originRequestBlockedDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0616

Scenario: dashboard stale state. Domain: security. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SecurityContext`, `DashboardStaleStateDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0617

Scenario: editor save conflict. Domain: popup. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PopupContext`, `EditorSaveConflictDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0618

Scenario: import duplicates. Domain: cookies. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `CookiesContext`, `ImportDuplicatesDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0619

Scenario: update dangerous permissions. Domain: downloads. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DownloadsContext`, `UpdateDangerousPermissionsDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0620

Scenario: MV3 intermittent issue. Domain: resources. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ResourcesContext`, `Mv3IntermittentIssueDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0621

Scenario: cookie access bug. Domain: metadata. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MetadataContext`, `CookieAccessBugDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0622

Scenario: menu command bug. Domain: matching. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MatchingContext`, `MenuCommandBugDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0623

Scenario: value listener bug. Domain: sandbox. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SandboxContext`, `ValueListenerBugDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0624

Scenario: localization issue. Domain: gm-api. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `GmApiContext`, `LocalizationIssueDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0625

Scenario: script not running. Domain: network. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `NetworkContext`, `ScriptNotRunningDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0626

Scenario: GM API undefined. Domain: storage. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `StorageContext`, `GmApiUndefinedDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0627

Scenario: cross-origin request blocked. Domain: sync. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SyncContext`, `Cross-originRequestBlockedDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0628

Scenario: dashboard stale state. Domain: dashboard. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DashboardContext`, `DashboardStaleStateDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0629

Scenario: editor save conflict. Domain: editor. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `EditorContext`, `EditorSaveConflictDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0630

Scenario: import duplicates. Domain: permissions. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PermissionsContext`, `ImportDuplicatesDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0631

Scenario: update dangerous permissions. Domain: offscreen. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `OffscreenContext`, `UpdateDangerousPermissionsDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0632

Scenario: MV3 intermittent issue. Domain: i18n. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `I18nContext`, `Mv3IntermittentIssueDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0633

Scenario: cookie access bug. Domain: import-export. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ImportExportContext`, `CookieAccessBugDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0634

Scenario: menu command bug. Domain: updates. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `UpdatesContext`, `MenuCommandBugDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0635

Scenario: value listener bug. Domain: diagnostics. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DiagnosticsContext`, `ValueListenerBugDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0636

Scenario: localization issue. Domain: security. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SecurityContext`, `LocalizationIssueDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0637

Scenario: script not running. Domain: popup. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PopupContext`, `ScriptNotRunningDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0638

Scenario: GM API undefined. Domain: cookies. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `CookiesContext`, `GmApiUndefinedDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0639

Scenario: cross-origin request blocked. Domain: downloads. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DownloadsContext`, `Cross-originRequestBlockedDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0640

Scenario: dashboard stale state. Domain: resources. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ResourcesContext`, `DashboardStaleStateDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0641

Scenario: editor save conflict. Domain: metadata. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MetadataContext`, `EditorSaveConflictDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0642

Scenario: import duplicates. Domain: matching. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MatchingContext`, `ImportDuplicatesDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0643

Scenario: update dangerous permissions. Domain: sandbox. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SandboxContext`, `UpdateDangerousPermissionsDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0644

Scenario: MV3 intermittent issue. Domain: gm-api. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `GmApiContext`, `Mv3IntermittentIssueDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0645

Scenario: cookie access bug. Domain: network. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `NetworkContext`, `CookieAccessBugDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0646

Scenario: menu command bug. Domain: storage. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `StorageContext`, `MenuCommandBugDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0647

Scenario: value listener bug. Domain: sync. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SyncContext`, `ValueListenerBugDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0648

Scenario: localization issue. Domain: dashboard. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DashboardContext`, `LocalizationIssueDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0649

Scenario: script not running. Domain: editor. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `EditorContext`, `ScriptNotRunningDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0650

Scenario: GM API undefined. Domain: permissions. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PermissionsContext`, `GmApiUndefinedDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0651

Scenario: cross-origin request blocked. Domain: offscreen. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `OffscreenContext`, `Cross-originRequestBlockedDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0652

Scenario: dashboard stale state. Domain: i18n. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `I18nContext`, `DashboardStaleStateDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0653

Scenario: editor save conflict. Domain: import-export. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ImportExportContext`, `EditorSaveConflictDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0654

Scenario: import duplicates. Domain: updates. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `UpdatesContext`, `ImportDuplicatesDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0655

Scenario: update dangerous permissions. Domain: diagnostics. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DiagnosticsContext`, `UpdateDangerousPermissionsDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0656

Scenario: MV3 intermittent issue. Domain: security. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SecurityContext`, `Mv3IntermittentIssueDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0657

Scenario: cookie access bug. Domain: popup. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PopupContext`, `CookieAccessBugDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0658

Scenario: menu command bug. Domain: cookies. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `CookiesContext`, `MenuCommandBugDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0659

Scenario: value listener bug. Domain: downloads. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DownloadsContext`, `ValueListenerBugDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0660

Scenario: localization issue. Domain: resources. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ResourcesContext`, `LocalizationIssueDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.
