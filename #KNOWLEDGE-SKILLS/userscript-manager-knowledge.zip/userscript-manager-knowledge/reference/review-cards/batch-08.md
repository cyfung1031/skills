# Review Card Batch 8

Readable issue/review cards for userscript manager agents.


## Review card 0421

Scenario: script not running. Domain: metadata. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MetadataContext`, `ScriptNotRunningDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0422

Scenario: GM API undefined. Domain: matching. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MatchingContext`, `GmApiUndefinedDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0423

Scenario: cross-origin request blocked. Domain: sandbox. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SandboxContext`, `Cross-originRequestBlockedDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0424

Scenario: dashboard stale state. Domain: gm-api. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `GmApiContext`, `DashboardStaleStateDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0425

Scenario: editor save conflict. Domain: network. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `NetworkContext`, `EditorSaveConflictDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0426

Scenario: import duplicates. Domain: storage. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `StorageContext`, `ImportDuplicatesDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0427

Scenario: update dangerous permissions. Domain: sync. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SyncContext`, `UpdateDangerousPermissionsDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0428

Scenario: MV3 intermittent issue. Domain: dashboard. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DashboardContext`, `Mv3IntermittentIssueDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0429

Scenario: cookie access bug. Domain: editor. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `EditorContext`, `CookieAccessBugDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0430

Scenario: menu command bug. Domain: permissions. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PermissionsContext`, `MenuCommandBugDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0431

Scenario: value listener bug. Domain: offscreen. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `OffscreenContext`, `ValueListenerBugDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0432

Scenario: localization issue. Domain: i18n. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `I18nContext`, `LocalizationIssueDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0433

Scenario: script not running. Domain: import-export. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ImportExportContext`, `ScriptNotRunningDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0434

Scenario: GM API undefined. Domain: updates. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `UpdatesContext`, `GmApiUndefinedDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0435

Scenario: cross-origin request blocked. Domain: diagnostics. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DiagnosticsContext`, `Cross-originRequestBlockedDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0436

Scenario: dashboard stale state. Domain: security. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SecurityContext`, `DashboardStaleStateDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0437

Scenario: editor save conflict. Domain: popup. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PopupContext`, `EditorSaveConflictDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0438

Scenario: import duplicates. Domain: cookies. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `CookiesContext`, `ImportDuplicatesDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0439

Scenario: update dangerous permissions. Domain: downloads. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DownloadsContext`, `UpdateDangerousPermissionsDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0440

Scenario: MV3 intermittent issue. Domain: resources. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ResourcesContext`, `Mv3IntermittentIssueDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0441

Scenario: cookie access bug. Domain: metadata. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MetadataContext`, `CookieAccessBugDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0442

Scenario: menu command bug. Domain: matching. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MatchingContext`, `MenuCommandBugDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0443

Scenario: value listener bug. Domain: sandbox. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SandboxContext`, `ValueListenerBugDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0444

Scenario: localization issue. Domain: gm-api. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `GmApiContext`, `LocalizationIssueDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0445

Scenario: script not running. Domain: network. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `NetworkContext`, `ScriptNotRunningDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0446

Scenario: GM API undefined. Domain: storage. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `StorageContext`, `GmApiUndefinedDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0447

Scenario: cross-origin request blocked. Domain: sync. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SyncContext`, `Cross-originRequestBlockedDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0448

Scenario: dashboard stale state. Domain: dashboard. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DashboardContext`, `DashboardStaleStateDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0449

Scenario: editor save conflict. Domain: editor. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `EditorContext`, `EditorSaveConflictDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0450

Scenario: import duplicates. Domain: permissions. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PermissionsContext`, `ImportDuplicatesDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0451

Scenario: update dangerous permissions. Domain: offscreen. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `OffscreenContext`, `UpdateDangerousPermissionsDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0452

Scenario: MV3 intermittent issue. Domain: i18n. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `I18nContext`, `Mv3IntermittentIssueDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0453

Scenario: cookie access bug. Domain: import-export. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ImportExportContext`, `CookieAccessBugDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0454

Scenario: menu command bug. Domain: updates. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `UpdatesContext`, `MenuCommandBugDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0455

Scenario: value listener bug. Domain: diagnostics. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DiagnosticsContext`, `ValueListenerBugDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0456

Scenario: localization issue. Domain: security. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SecurityContext`, `LocalizationIssueDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0457

Scenario: script not running. Domain: popup. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PopupContext`, `ScriptNotRunningDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0458

Scenario: GM API undefined. Domain: cookies. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `CookiesContext`, `GmApiUndefinedDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0459

Scenario: cross-origin request blocked. Domain: downloads. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DownloadsContext`, `Cross-originRequestBlockedDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0460

Scenario: dashboard stale state. Domain: resources. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ResourcesContext`, `DashboardStaleStateDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0461

Scenario: editor save conflict. Domain: metadata. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MetadataContext`, `EditorSaveConflictDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0462

Scenario: import duplicates. Domain: matching. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `MatchingContext`, `ImportDuplicatesDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0463

Scenario: update dangerous permissions. Domain: sandbox. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SandboxContext`, `UpdateDangerousPermissionsDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0464

Scenario: MV3 intermittent issue. Domain: gm-api. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `GmApiContext`, `Mv3IntermittentIssueDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0465

Scenario: cookie access bug. Domain: network. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `NetworkContext`, `CookieAccessBugDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0466

Scenario: menu command bug. Domain: storage. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `StorageContext`, `MenuCommandBugDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0467

Scenario: value listener bug. Domain: sync. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SyncContext`, `ValueListenerBugDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0468

Scenario: localization issue. Domain: dashboard. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DashboardContext`, `LocalizationIssueDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0469

Scenario: script not running. Domain: editor. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `EditorContext`, `ScriptNotRunningDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0470

Scenario: GM API undefined. Domain: permissions. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PermissionsContext`, `GmApiUndefinedDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check grants, aliases, compatibility mode, and bridge generation. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0471

Scenario: cross-origin request blocked. Domain: offscreen. Task: implement.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `OffscreenContext`, `Cross-originRequestBlockedDiagnosis`, or `ImplementChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0472

Scenario: dashboard stale state. Domain: i18n. Task: review.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `I18nContext`, `DashboardStaleStateDiagnosis`, or `ReviewChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check repository event emission, view-model refresh, selected script ID, and filter state. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0473

Scenario: editor save conflict. Domain: import-export. Task: debug.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ImportExportContext`, `EditorSaveConflictDiagnosis`, or `DebugChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check dirty state, source hash, metadata parse result, and conflict recovery UI. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0474

Scenario: import duplicates. Domain: updates. Task: refactor.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `UpdatesContext`, `ImportDuplicatesDiagnosis`, or `RefactorChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check identity mapping, namespace/name/version rules, and dry-run conflict report. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0475

Scenario: update dangerous permissions. Domain: diagnostics. Task: test.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DiagnosticsContext`, `UpdateDangerousPermissionsDiagnosis`, or `TestChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Compare old/new grants, connect hosts, match scope, resources, and prompt text. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0476

Scenario: MV3 intermittent issue. Domain: security. Task: document.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `SecurityContext`, `Mv3IntermittentIssueDiagnosis`, or `DocumentChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0477

Scenario: cookie access bug. Domain: popup. Task: migrate.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `PopupContext`, `CookieAccessBugDiagnosis`, or `MigrateChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check cookie permission, URL scope, incognito store, and user prompt. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0478

Scenario: menu command bug. Domain: cookies. Task: harden.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `CookiesContext`, `MenuCommandBugDiagnosis`, or `HardenChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0479

Scenario: value listener bug. Domain: downloads. Task: profile.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `DownloadsContext`, `ValueListenerBugDiagnosis`, or `ProfileChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check namespace, port lifetime, old/new value serialization, and listener cleanup. Confirm the result in UI, background diagnostics, and a focused regression test.


## Review card 0480

Scenario: localization issue. Domain: resources. Task: localize.

Start by collecting: script name, script ID, page URL, frame ID, metadata directives, grants, connect hosts, enabled state, run-at, sandbox mode, and last visible UI action.

Readable coding direction: introduce or reuse a named object such as `ResourcesContext`, `LocalizationIssueDiagnosis`, or `LocalizeChangePlan`. Avoid anonymous bags like `data` or `info` when crossing message or storage boundaries.

Fix validation: Check message key, placeholder names, pluralization, and UI text consistency. Confirm the result in UI, background diagnostics, and a focused regression test.
