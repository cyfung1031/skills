# CSS Selector Atlas

This atlas lists selector vocabulary only; it does not copy CSS rule bodies. Use it to understand UI state names, editor decorations, dashboard layout concepts, and popup/options surfaces.

## Selectors

| Selector | Mentions | Readable guidance |
| --- | --- | --- |
| to | 60 | selector vocabulary; inspect corresponding UI component before editing |
| 0% | 60 | selector vocabulary; inspect corresponding UI component before editing |
| button | 29 | selector vocabulary; inspect corresponding UI component before editing |
| textarea | 20 | selector vocabulary; inspect corresponding UI component before editing |
| body | 17 | selector vocabulary; inspect corresponding UI component before editing |
| select | 17 | selector vocabulary; inspect corresponding UI component before editing |
| 50% | 14 | selector vocabulary; inspect corresponding UI component before editing |
| code | 13 | selector vocabulary; inspect corresponding UI component before editing |
| .monaco-editor | 13 | selector vocabulary; inspect corresponding UI component before editing |
| .darker #action | 13 | selector vocabulary; inspect corresponding UI component before editing |
| :root | 11 | selector vocabulary; inspect corresponding UI component before editing |
| kbd | 10 | selector vocabulary; inspect corresponding UI component before editing |
| input | 10 | selector vocabulary; inspect corresponding UI component before editing |
| a | 9 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-scrollbar-filler | 9 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutter-filler | 9 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutters | 9 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost | 9 | selector vocabulary; inspect corresponding UI component before editing |
| h1 | 8 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror | 8 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-comment | 7 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-string-2 | 7 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-hints | 7 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-modal | 7 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-tooltip-bottom>i | 7 | selector vocabulary; inspect corresponding UI component before editing |
| * | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-lines | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror pre.CodeMirror-line | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror pre.CodeMirror-line-like | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-linenumber | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-cursor | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-scroll | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-sizer | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-vscrollbar | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-hscrollbar | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutter | 6 | selector vocabulary; inspect corresponding UI component before editing |
| 100% | 6 | selector vocabulary; inspect corresponding UI component before editing |
| from | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-modal-backdrop | 6 | selector vocabulary; inspect corresponding UI component before editing |
| h2 | 6 | selector vocabulary; inspect corresponding UI component before editing |
| h3 | 6 | selector vocabulary; inspect corresponding UI component before editing |
| button:focus | 6 | selector vocabulary; inspect corresponding UI component before editing |
| select:focus | 6 | selector vocabulary; inspect corresponding UI component before editing |
| textarea:focus | 6 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=number] | 6 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=password] | 6 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=search] | 6 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=text] | 6 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=url] | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost:focus | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost:hover | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .sep | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .sep:after | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .fixed-full | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .abs-full | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .editor-code .CodeMirror | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-tooltip>i | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-tooltip-top>i | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-tooltip-left>i | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-tooltip-right>i | 6 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-header | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-keyword | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-atom | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-number | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-def | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-variable-2 | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-variable-3 | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-type | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-string | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-builtin | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-bracket | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-tag | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-attribute | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-link | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-error | 5 | selector vocabulary; inspect corresponding UI component before editing |
| div.CodeMirror span.CodeMirror-matchingbracket | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-activeline-background | 5 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-hint | 5 | selector vocabulary; inspect corresponding UI component before editing |
| li.CodeMirror-hint-active | 5 | selector vocabulary; inspect corresponding UI component before editing |
| aside | 5 | selector vocabulary; inspect corresponding UI component before editing |
| aside>* | 5 | selector vocabulary; inspect corresponding UI component before editing |
| html | 4 | selector vocabulary; inspect corresponding UI component before editing |
| 20% | 4 | selector vocabulary; inspect corresponding UI component before editing |
| hr | 4 | selector vocabulary; inspect corresponding UI component before editing |
| fieldset | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-trailingspace | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-foldgutter-folded | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .scripttable tr | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .section | 4 | selector vocabulary; inspect corresponding UI component before editing |
| a:hover | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .editorbuttonbar input.button | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .CodeMirror-hscrollbar | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .CodeMirror-vscrollbar | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker::-webkit-scrollbar | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker ::-webkit-scrollbar | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker::-webkit-scrollbar-button:single-button | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker ::-webkit-scrollbar-button:single-button | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker::-webkit-scrollbar-thumb:horizontal | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker ::-webkit-scrollbar-thumb:horizontal | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker::-webkit-scrollbar-thumb:vertical | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .darker ::-webkit-scrollbar-thumb:vertical | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .message | 4 | selector vocabulary; inspect corresponding UI component before editing |
| a:focus | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .vl-dropdown-menu | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .editor-search input | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror .CodeMirror-line ::selection | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror .CodeMirror-line ::-moz-selection | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-matchhighlight | 4 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-string-2.cm-regexp | 4 | selector vocabulary; inspect corresponding UI component before editing |
| body[arco-theme=dark] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .arco-dropdown-menu-item | 3 | selector vocabulary; inspect corresponding UI component before editing |
| sup | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .arco-menu-vertical .arco-menu-pop-header | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .arco-menu-vertical .arco-menu-inline-header | 3 | selector vocabulary; inspect corresponding UI component before editing |
| h1.arco-typography | 3 | selector vocabulary; inspect corresponding UI component before editing |
| h2.arco-typography | 3 | selector vocabulary; inspect corresponding UI component before editing |
| h3.arco-typography | 3 | selector vocabulary; inspect corresponding UI component before editing |
| h4.arco-typography | 3 | selector vocabulary; inspect corresponding UI component before editing |
| h5.arco-typography | 3 | selector vocabulary; inspect corresponding UI component before editing |
| h6.arco-typography | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .monaco-editor .suggest-widget .monaco-list .monaco-list-row>.contents>.main>.right>.details-label | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .monaco-editor .sticky-widget | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .editor-banner | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-guttermarker | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-guttermarker-subtle | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror div.CodeMirror-secondarycursor | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-fat-cursor .CodeMirror-cursor | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-fat-cursor div.CodeMirror-cursors | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-tab | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-rulers | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-ruler | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-quote | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-negative | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-positive | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-header | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-strong | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-em | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-link | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-strikethrough | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-meta | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-qualifier | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-s-default .cm-hr | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-invalidchar | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-composing | 3 | selector vocabulary; inspect corresponding UI component before editing |
| div.CodeMirror span.CodeMirror-nonmatchingbracket | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-matchingtag | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutter-wrapper | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutter-background | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutter-elt | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutter-wrapper ::selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-gutter-wrapper ::-moz-selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-wrap pre.CodeMirror-line | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-wrap pre.CodeMirror-line-like | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-linebackground | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-linewidget | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-rtl pre | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-code | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-measure | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-measure pre | 3 | selector vocabulary; inspect corresponding UI component before editing |
| div.CodeMirror-cursors | 3 | selector vocabulary; inspect corresponding UI component before editing |
| div.CodeMirror-dragcursors | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-focused div.CodeMirror-cursors | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-selected | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-focused .CodeMirror-selected | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-crosshair | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-line::selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-line>span::selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-line>span>span::selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-line::-moz-selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-line>span::-moz-selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-line>span>span::-moz-selection | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-searching | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-force-border | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror div.CodeMirror-cursors | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .cm-tab-wrap-hack:after | 3 | selector vocabulary; inspect corresponding UI component before editing |
| span.CodeMirror-selectedtext | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-foldmarker | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-foldgutter | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-foldgutter-open | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-foldgutter-open:after | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-foldgutter-folded:after | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .submenu | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .far | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .actiontable tr | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .multiselect .filter | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .trash_script_details dt | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .footer a | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .submenu tr.entry i:before | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker input[type=checkbox] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .section | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker button | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker input[type=button] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .button | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .ask_action_buttons .button | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .section.type_reset input | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .darker .submenu tr.entry:not(.sep) * | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .message input | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .message-body>p | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .message-body>p:nth-last-child(2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .message-body>p:not(:first-child) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| :not(select) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| span:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=checkbox] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=checkbox]:focus+* | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[disabled]~* | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=number][disabled] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=password][disabled] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=search][disabled] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=text][disabled] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=url][disabled] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| :focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .icon | 3 | selector vocabulary; inspect corresponding UI component before editing |
| svg | 3 | selector vocabulary; inspect corresponding UI component before editing |
| button:not([disabled]):hover | 3 | selector vocabulary; inspect corresponding UI component before editing |
| button:active | 3 | selector vocabulary; inspect corresponding UI component before editing |
| button[disabled] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| button:not([disabled]) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| button:hover | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost>.icon | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost.active | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost.disabled | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-danger | 3 | selector vocabulary; inspect corresponding UI component before editing |
| a[tabindex="0"] | 3 | selector vocabulary; inspect corresponding UI component before editing |
| a:not([href]):hover | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ol | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ul | 3 | selector vocabulary; inspect corresponding UI component before editing |
| li | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .inline-block | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .flex | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .flex-col | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .flex-wrap | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .flex-auto | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .flex-col>.flex-auto | 3 | selector vocabulary; inspect corresponding UI component before editing |
| :not(.flex-col)>.flex-auto | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .flex-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .center-items | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .stretch-self | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .pos-rel | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .ml-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .ml-1c>:nth-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mr-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mr-1c>:nth-last-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .ml-2 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .ml-2c>:nth-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mr-2 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mr-2c>:nth-last-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mt-0 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mt-0c>:nth-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mt-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mt-1c>:nth-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mb-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mb-1c>:nth-last-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mb-2 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mb-2c>:nth-last-child(n+2) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mx-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .mx-1c>* | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .my-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .my-1c>* | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .h-screen | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .h-100 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .w-100 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .w-1 | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .ellipsis | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .pre | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .text-center | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .text-right | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .scroll-y | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .subtle | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .frame | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .frame-block | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .CodeMirror-hints.default | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .monospace-font | 3 | selector vocabulary; inspect corresponding UI component before editing |
| body .vl-tooltip | 3 | selector vocabulary; inspect corresponding UI component before editing |
| body .vl-tooltip>i | 3 | selector vocabulary; inspect corresponding UI component before editing |
| body .vl-tooltip-content | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .modal-content | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost.has-error | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .has-error | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type].has-error | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .btn-ghost.has-error:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .has-error:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type].has-error:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .scary-switch:checked | 3 | selector vocabulary; inspect corresponding UI component before editing |
| .scary-switch:checked+span | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=checkbox]:not(:checked) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=radio]:not(:checked) | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=number]:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=password]:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=search]:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=text]:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| input[type=url]:focus | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar-button:single-button | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar-button:single-button:hover | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar-button:single-button:active | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar-track-piece | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar-track-piece:hover | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar-track-piece:active | 3 | selector vocabulary; inspect corresponding UI component before editing |
| ::-webkit-scrollbar-thumb | 3 | selector vocabulary; inspect corresponding UI component before editing |

## Classes

| Class | Mentions | Readable guidance |
| --- | --- | --- |
| monaco-editor | 612 | class name; use as UI state/search hint |
| arco-col-rtl | 593 | class name; use as UI state/search hint |
| darker | 484 | class name; use as UI state/search hint |
| cm-s-default | 163 | class name; use as UI state/search hint |
| arco-tag-checked | 147 | class name; use as UI state/search hint |
| dark | 140 | class name; use as UI state/search hint |
| codicon | 129 | class name; use as UI state/search hint |
| arco-select | 109 | class name; use as UI state/search hint |
| arco-icon | 104 | class name; use as UI state/search hint |
| arco-input-inner-wrapper | 102 | class name; use as UI state/search hint |
| arco-btn-disabled | 101 | class name; use as UI state/search hint |
| arco-select-view | 97 | class name; use as UI state/search hint |
| CodeMirror | 91 | class name; use as UI state/search hint |
| arco-input-group-wrapper | 90 | class name; use as UI state/search hint |
| arco-input-group-addbefore | 89 | class name; use as UI state/search hint |
| arco-steps-item | 89 | class name; use as UI state/search hint |
| arco-input | 88 | class name; use as UI state/search hint |
| arco-input-group-addafter | 87 | class name; use as UI state/search hint |
| monaco-list | 87 | class name; use as UI state/search hint |
| monaco-list-row | 81 | class name; use as UI state/search hint |
| group-size | 80 | class name; use as UI state/search hint |
| mobile | 77 | class name; use as UI state/search hint |
| arco-btn-group | 76 | class name; use as UI state/search hint |
| CodeMirror-line | 76 | class name; use as UI state/search hint |
| scripttable | 76 | class name; use as UI state/search hint |
| monaco-workbench | 73 | class name; use as UI state/search hint |
| arco-tabs-header-title | 67 | class name; use as UI state/search hint |
| arco-input-tag-has-placeholder | 64 | class name; use as UI state/search hint |
| monaco-hover | 62 | class name; use as UI state/search hint |
| cm-s-solarized | 62 | class name; use as UI state/search hint |
| actiontable | 61 | class name; use as UI state/search hint |
| script | 60 | class name; use as UI state/search hint |
| monaco-scrollable-element | 59 | class name; use as UI state/search hint |
| suggest-widget | 59 | class name; use as UI state/search hint |
| arco-cascader-multiple | 58 | class name; use as UI state/search hint |
| arco-input-group | 58 | class name; use as UI state/search hint |
| arco-icon-hover | 56 | class name; use as UI state/search hint |
| arco-menu-inline-header | 56 | class name; use as UI state/search hint |
| arco-steps-mode-arrow | 55 | class name; use as UI state/search hint |
| cm-s-diff | 55 | class name; use as UI state/search hint |
| cm-s-monokai | 55 | class name; use as UI state/search hint |
| arco-menu-item | 54 | class name; use as UI state/search hint |
| far | 54 | class name; use as UI state/search hint |
| arco-menu-light | 53 | class name; use as UI state/search hint |
| arco-menu-horizontal | 53 | class name; use as UI state/search hint |
| arco-menu-dark | 53 | class name; use as UI state/search hint |
| arco-table-rtl | 53 | class name; use as UI state/search hint |
| arco-select-multiple | 52 | class name; use as UI state/search hint |
| arco-tree-select-multiple | 52 | class name; use as UI state/search hint |
| arco-menu-group-title | 51 | class name; use as UI state/search hint |
| arco-steps-mode-dot | 51 | class name; use as UI state/search hint |
| disabled | 51 | class name; use as UI state/search hint |
| page-confirm | 51 | class name; use as UI state/search hint |
| arco-menu-pop-header | 50 | class name; use as UI state/search hint |
| edit-externals | 50 | class name; use as UI state/search hint |
| arco-menu-selected | 48 | class name; use as UI state/search hint |
| find-widget | 48 | class name; use as UI state/search hint |
| arco-table-td | 47 | class name; use as UI state/search hint |
| arco-btn-loading | 46 | class name; use as UI state/search hint |
| arco-cascader-view | 46 | class name; use as UI state/search hint |
| arco-tree-select-view | 46 | class name; use as UI state/search hint |
| arco-input-custom-height | 46 | class name; use as UI state/search hint |
| arco-menu-vertical | 46 | class name; use as UI state/search hint |
| arco-menu-rtl | 46 | class name; use as UI state/search hint |
| monaco-action-bar | 46 | class name; use as UI state/search hint |
| cm-s-mdn-like | 45 | class name; use as UI state/search hint |
| monaco-diff-editor | 44 | class name; use as UI state/search hint |
| arco-btn-rtl | 44 | class name; use as UI state/search hint |
| hc-black | 43 | class name; use as UI state/search hint |
| quick-input-list | 43 | class name; use as UI state/search hint |
| btn-ghost | 43 | class name; use as UI state/search hint |
| select | 43 | class name; use as UI state/search hint |
| arco-steps-rtl | 42 | class name; use as UI state/search hint |
| arco-steps-item-title | 41 | class name; use as UI state/search hint |
| hc-light | 41 | class name; use as UI state/search hint |
| arco-input-tag | 39 | class name; use as UI state/search hint |
| arco-select-single | 39 | class name; use as UI state/search hint |
| action-label | 39 | class name; use as UI state/search hint |
| arco-picker-disabled | 38 | class name; use as UI state/search hint |
| arco-trigger-arrow | 38 | class name; use as UI state/search hint |
| arco-menu-icon-suffix | 37 | class name; use as UI state/search hint |
| arco-tabs-header-title-active | 37 | class name; use as UI state/search hint |
| arco-form-item-status-validating | 36 | class name; use as UI state/search hint |
| arco-form-item-status-success | 36 | class name; use as UI state/search hint |
| arco-form-item-status-warning | 36 | class name; use as UI state/search hint |
| arco-form-item-status-error | 36 | class name; use as UI state/search hint |
| main | 36 | class name; use as UI state/search hint |
| tv_tab | 36 | class name; use as UI state/search hint |
| vl-tooltip-wrap | 36 | class name; use as UI state/search hint |
| arco-cascader | 35 | class name; use as UI state/search hint |
| arco-picker-date | 35 | class name; use as UI state/search hint |
| arco-tree-select | 35 | class name; use as UI state/search hint |
| arco-tabs-header-nav-card | 35 | class name; use as UI state/search hint |
| arco-input-tag-input-mirror | 34 | class name; use as UI state/search hint |
| arco-color-picker-panel | 34 | class name; use as UI state/search hint |
| arco-form-item-has-feedback | 34 | class name; use as UI state/search hint |
| button | 34 | class name; use as UI state/search hint |
| contents | 34 | class name; use as UI state/search hint |
| scripts | 34 | class name; use as UI state/search hint |
| arco-typography | 33 | class name; use as UI state/search hint |
| arco-descriptions-border | 33 | class name; use as UI state/search hint |
| arco-textarea | 33 | class name; use as UI state/search hint |
| arco-steps-size-small | 33 | class name; use as UI state/search hint |
| action | 33 | class name; use as UI state/search hint |
| monaco-sash | 33 | class name; use as UI state/search hint |
| cm-s-claude | 33 | class name; use as UI state/search hint |
| submenu | 33 | class name; use as UI state/search hint |
| arco-trigger | 32 | class name; use as UI state/search hint |
| arco-tabs-header-nav-card-gutter | 32 | class name; use as UI state/search hint |
| icon | 32 | class name; use as UI state/search hint |
| focused | 32 | class name; use as UI state/search hint |
| arco-checkbox | 31 | class name; use as UI state/search hint |
| suggest-details | 31 | class name; use as UI state/search hint |
| arco-switch-checked | 30 | class name; use as UI state/search hint |
| arco-tag-checkable | 30 | class name; use as UI state/search hint |
| active | 30 | class name; use as UI state/search hint |
| arco-btn-status-warning | 29 | class name; use as UI state/search hint |
| arco-btn-status-danger | 29 | class name; use as UI state/search hint |
| arco-btn-status-success | 29 | class name; use as UI state/search hint |
| arco-input-group-wrapper-rtl | 29 | class name; use as UI state/search hint |
| arco-steps-vertical | 29 | class name; use as UI state/search hint |
| arco-tag-icon-hover | 29 | class name; use as UI state/search hint |
| action-item | 29 | class name; use as UI state/search hint |
| cm-s-zenburn | 29 | class name; use as UI state/search hint |
| monkey-clip | 29 | class name; use as UI state/search hint |
| arco-btn-text | 28 | class name; use as UI state/search hint |
| arco-btn-shape-round | 28 | class name; use as UI state/search hint |
| arco-tag-bordered | 28 | class name; use as UI state/search hint |
| parameter-hints-widget | 28 | class name; use as UI state/search hint |
| cm-comment | 28 | class name; use as UI state/search hint |
| cm-s-eclipse | 28 | class name; use as UI state/search hint |
| arco-calendar-panel | 27 | class name; use as UI state/search hint |
| arco-input-group-compact | 27 | class name; use as UI state/search hint |
| arco-table | 27 | class name; use as UI state/search hint |
| monaco-icon-label | 27 | class name; use as UI state/search hint |
| clickable | 27 | class name; use as UI state/search hint |
| arco-steps-item-tail | 26 | class name; use as UI state/search hint |
| arco-table-col-has-sorter | 26 | class name; use as UI state/search hint |
| arco-table-th | 26 | class name; use as UI state/search hint |
| arco-tabs-header-nav-capsule | 26 | class name; use as UI state/search hint |
| arco-tabs-header-nav-vertical | 26 | class name; use as UI state/search hint |
| monaco-inputbox | 26 | class name; use as UI state/search hint |
| message | 26 | class name; use as UI state/search hint |
| cm-s-railscasts | 26 | class name; use as UI state/search hint |
| arco-carousel-card | 25 | class name; use as UI state/search hint |
| arco-picker-date-value | 25 | class name; use as UI state/search hint |
| arco-menu | 25 | class name; use as UI state/search hint |
| ask_action_buttons | 25 | class name; use as UI state/search hint |
| multiselect | 25 | class name; use as UI state/search hint |
| arco-btn-outline | 24 | class name; use as UI state/search hint |
| arco-btn-dashed | 24 | class name; use as UI state/search hint |
| arco-input-inner-wrapper-focus | 24 | class name; use as UI state/search hint |
| arco-input-group-suffix | 24 | class name; use as UI state/search hint |
| arco-input-number-mode-button | 24 | class name; use as UI state/search hint |
| arco-radio-button | 24 | class name; use as UI state/search hint |
| arco-steps-item-description | 24 | class name; use as UI state/search hint |
| arco-table-col-has-filter | 24 | class name; use as UI state/search hint |
| action-widget | 24 | class name; use as UI state/search hint |
| arco-btn-primary | 23 | class name; use as UI state/search hint |
| arco-form-rtl | 23 | class name; use as UI state/search hint |
| arco-steps-item-content | 23 | class name; use as UI state/search hint |
| arco-switch-type-line | 23 | class name; use as UI state/search hint |
| vertical | 23 | class name; use as UI state/search hint |
| CodeMirror-gutters | 23 | class name; use as UI state/search hint |
| arco-dropdown-menu-item | 22 | class name; use as UI state/search hint |
| arco-btn-secondary | 22 | class name; use as UI state/search hint |
| arco-btn-size-mini | 22 | class name; use as UI state/search hint |
| arco-btn-size-small | 22 | class name; use as UI state/search hint |
| arco-btn-size-default | 22 | class name; use as UI state/search hint |
| arco-btn-size-large | 22 | class name; use as UI state/search hint |
| arco-cascader-disabled | 22 | class name; use as UI state/search hint |
| arco-select-disabled | 22 | class name; use as UI state/search hint |
| arco-tree-select-disabled | 22 | class name; use as UI state/search hint |
| arco-steps-item-icon | 22 | class name; use as UI state/search hint |
| arco-timeline-alternate | 22 | class name; use as UI state/search hint |
| right | 22 | class name; use as UI state/search hint |
| cm-fat-cursor | 22 | class name; use as UI state/search hint |
| default | 22 | class name; use as UI state/search hint |
| arco-dropdown-menu-pop-header | 21 | class name; use as UI state/search hint |
| arco-textarea-focus | 21 | class name; use as UI state/search hint |
| arco-input-group-wrapper-mini | 21 | class name; use as UI state/search hint |
| arco-input-group-wrapper-small | 21 | class name; use as UI state/search hint |
| arco-input-group-wrapper-large | 21 | class name; use as UI state/search hint |
| arco-select-rtl | 21 | class name; use as UI state/search hint |
| arco-switch-dot | 21 | class name; use as UI state/search hint |
| arco-tabs-header-nav-line | 21 | class name; use as UI state/search hint |
| arco-timeline-item-label-relative | 21 | class name; use as UI state/search hint |
| arco-tree-select-rtl | 21 | class name; use as UI state/search hint |
| monaco-button | 21 | class name; use as UI state/search hint |
| monaco-findInput | 21 | class name; use as UI state/search hint |
| CodeMirror-linenumber | 21 | class name; use as UI state/search hint |
| CodeMirror-cursor | 21 | class name; use as UI state/search hint |
| actionpostd | 21 | class name; use as UI state/search hint |
| arco-calendar-cell | 20 | class name; use as UI state/search hint |
| arco-cascader-rtl | 20 | class name; use as UI state/search hint |
| arco-picker-cell | 20 | class name; use as UI state/search hint |
| arco-input-group-prefix | 20 | class name; use as UI state/search hint |
| item-style | 20 | class name; use as UI state/search hint |
| arco-menu-disabled | 20 | class name; use as UI state/search hint |
| arco-table-th-item | 20 | class name; use as UI state/search hint |
| actions | 20 | class name; use as UI state/search hint |
| diff-hidden-lines | 20 | class name; use as UI state/search hint |
| head | 20 | class name; use as UI state/search hint |
| body | 20 | class name; use as UI state/search hint |
| cm-def | 20 | class name; use as UI state/search hint |
| entry | 20 | class name; use as UI state/search hint |
| moremenu | 20 | class name; use as UI state/search hint |
| vl-tooltip-bottom | 20 | class name; use as UI state/search hint |
| arco-picker | 19 | class name; use as UI state/search hint |
| arco-cascader-single | 19 | class name; use as UI state/search hint |
| arco-tree-select-single | 19 | class name; use as UI state/search hint |
| group-size-mini | 19 | class name; use as UI state/search hint |
| group-size-small | 19 | class name; use as UI state/search hint |
| group-size-large | 19 | class name; use as UI state/search hint |
| arco-tabs-header-title-text | 19 | class name; use as UI state/search hint |
| arco-tabs-rtl | 19 | class name; use as UI state/search hint |
| arco-transfer-view | 19 | class name; use as UI state/search hint |
| quick-input-widget | 19 | class name; use as UI state/search hint |
| margin-view-overlays | 19 | class name; use as UI state/search hint |
| global_hint | 19 | class name; use as UI state/search hint |
| viewer_info | 19 | class name; use as UI state/search hint |
| arco-carousel-horizontal | 18 | class name; use as UI state/search hint |
| arco-descriptions-item-label | 18 | class name; use as UI state/search hint |
| arco-descriptions-item-value | 18 | class name; use as UI state/search hint |
| arco-descriptions-rtl | 18 | class name; use as UI state/search hint |
| arco-input-number-step-button | 18 | class name; use as UI state/search hint |
| arco-steps-item-active | 18 | class name; use as UI state/search hint |
| arco-switch-rtl | 18 | class name; use as UI state/search hint |
| arco-table-content-scroll | 18 | class name; use as UI state/search hint |
| arco-tabs-header-extra | 18 | class name; use as UI state/search hint |
| monaco-button-dropdown | 18 | class name; use as UI state/search hint |
| highlight | 18 | class name; use as UI state/search hint |
| reference-zone-widget | 18 | class name; use as UI state/search hint |
| docs | 18 | class name; use as UI state/search hint |
| cm-string-2 | 18 | class name; use as UI state/search hint |
| cm-tag | 18 | class name; use as UI state/search hint |
| sep | 18 | class name; use as UI state/search hint |
| script_name | 18 | class name; use as UI state/search hint |
| section | 18 | class name; use as UI state/search hint |
| vl-tooltip | 18 | class name; use as UI state/search hint |
| has-error | 18 | class name; use as UI state/search hint |
| vl-tooltip-top | 18 | class name; use as UI state/search hint |
| arco-picker-focused | 17 | class name; use as UI state/search hint |
| arco-panel-week | 17 | class name; use as UI state/search hint |
| arco-steps-item-finish | 17 | class name; use as UI state/search hint |
| arco-tabs-header-title-disabled | 17 | class name; use as UI state/search hint |
| arco-tabs-header-nav-text | 17 | class name; use as UI state/search hint |
| monaco-split-view2 | 17 | class name; use as UI state/search hint |
| monaco-select-box-dropdown-container | 17 | class name; use as UI state/search hint |
| CodeMirror-activeline-background | 17 | class name; use as UI state/search hint |
| CodeMirror-selected | 17 | class name; use as UI state/search hint |
| enabler | 17 | class name; use as UI state/search hint |
| edit-values-row | 17 | class name; use as UI state/search hint |
| arco-btn | 16 | class name; use as UI state/search hint |
| arco-select-popup | 16 | class name; use as UI state/search hint |
| arco-carousel-indicator-item | 16 | class name; use as UI state/search hint |
| arco-checkbox-mask | 16 | class name; use as UI state/search hint |
| arco-form-label-item | 16 | class name; use as UI state/search hint |
| arco-steps-item-process | 16 | class name; use as UI state/search hint |
| arco-switch-small | 16 | class name; use as UI state/search hint |
| arco-table-border | 16 | class name; use as UI state/search hint |
| hover-row | 16 | class name; use as UI state/search hint |
| ibwrapper | 16 | class name; use as UI state/search hint |
| monaco-highlighted-label | 16 | class name; use as UI state/search hint |
| error | 16 | class name; use as UI state/search hint |
| workbench-hover | 16 | class name; use as UI state/search hint |
| peekview-widget | 16 | class name; use as UI state/search hint |
| monaco-editor-overlaymessage | 16 | class name; use as UI state/search hint |
| cm-keyword | 16 | class name; use as UI state/search hint |
| CodeMirror-matchingbracket | 16 | class name; use as UI state/search hint |
| solarized | 16 | class name; use as UI state/search hint |
| icon16 | 16 | class name; use as UI state/search hint |
| editormenu | 16 | class name; use as UI state/search hint |
| editor-search | 16 | class name; use as UI state/search hint |
| edit-values | 16 | class name; use as UI state/search hint |
| edit | 16 | class name; use as UI state/search hint |
| menu-item | 16 | class name; use as UI state/search hint |
| arco-carousel-negative | 15 | class name; use as UI state/search hint |
| arco-cascader-list-item | 15 | class name; use as UI state/search hint |
| arco-table-size-middle | 15 | class name; use as UI state/search hint |
| arco-table-size-small | 15 | class name; use as UI state/search hint |
| arco-table-size-mini | 15 | class name; use as UI state/search hint |
| arco-tag-icon | 15 | class name; use as UI state/search hint |
| arco-tag-loading-icon | 15 | class name; use as UI state/search hint |
| cm-attribute | 15 | class name; use as UI state/search hint |
| tag | 15 | class name; use as UI state/search hint |
| speech-bubble | 15 | class name; use as UI state/search hint |
| flex-auto | 15 | class name; use as UI state/search hint |
| vl-dropdown-menu | 15 | class name; use as UI state/search hint |
| arco-input-disabled | 14 | class name; use as UI state/search hint |
| arco-list-item | 14 | class name; use as UI state/search hint |
| arco-menu-collapse | 14 | class name; use as UI state/search hint |
| arco-progress-line-text | 14 | class name; use as UI state/search hint |
| arco-table-cell-with-sorter | 14 | class name; use as UI state/search hint |
| arco-table-expand-content | 14 | class name; use as UI state/search hint |
| arco-table-tr | 14 | class name; use as UI state/search hint |
| arco-timeline-item-dot-wrapper | 14 | class name; use as UI state/search hint |
| arco-tooltip-arrow | 14 | class name; use as UI state/search hint |
| top | 14 | class name; use as UI state/search hint |
| controls | 14 | class name; use as UI state/search hint |

## IDs

| ID | Mentions | Readable guidance |
| --- | --- | --- |
| fff | 82 | id selector; likely tightly coupled to markup or editor |
| action | 17 | id selector; likely tightly coupled to markup or editor |
| eeeeed | 14 | id selector; likely tightly coupled to markup or editor |
| d7d4f0 | 13 | id selector; likely tightly coupled to markup or editor |
| b9f | 12 | id selector; likely tightly coupled to markup or editor |
| d3d3d3 | 12 | id selector; likely tightly coupled to markup or editor |
| eee | 11 | id selector; likely tightly coupled to markup or editor |
| e6e6e6 | 11 | id selector; likely tightly coupled to markup or editor |
| f92672 | 9 | id selector; likely tightly coupled to markup or editor |
| ffffff4d | 8 | id selector; likely tightly coupled to markup or editor |
| ccc | 8 | id selector; likely tightly coupled to markup or editor |
| f8f8f2 | 8 | id selector; likely tightly coupled to markup or editor |
| ae81ff | 8 | id selector; likely tightly coupled to markup or editor |
| ddd | 7 | id selector; likely tightly coupled to markup or editor |
| f7f7f7 | 6 | id selector; likely tightly coupled to markup or editor |
| aaa | 6 | id selector; likely tightly coupled to markup or editor |
| d0d0d0 | 6 | id selector; likely tightly coupled to markup or editor |
| f8f8f0 | 6 | id selector; likely tightly coupled to markup or editor |
| eee8d5 | 6 | id selector; likely tightly coupled to markup or editor |
| a9a9a9 | 6 | id selector; likely tightly coupled to markup or editor |
| bbb | 5 | id selector; likely tightly coupled to markup or editor |
| script-list | 5 | id selector; likely tightly coupled to markup or editor |
| d44 | 5 | id selector; likely tightly coupled to markup or editor |
| a6e22e | 5 | id selector; likely tightly coupled to markup or editor |
| dcdccc | 5 | id selector; likely tightly coupled to markup or editor |
| e13d14 | 5 | id selector; likely tightly coupled to markup or editor |
| ffffffe6 | 4 | id selector; likely tightly coupled to markup or editor |
| f0f0f0 | 4 | id selector; likely tightly coupled to markup or editor |
| ffffff80 | 4 | id selector; likely tightly coupled to markup or editor |
| ff0 | 4 | id selector; likely tightly coupled to markup or editor |
| fff3 | 4 | id selector; likely tightly coupled to markup or editor |
| e1e1e1 | 4 | id selector; likely tightly coupled to markup or editor |
| f50 | 4 | id selector; likely tightly coupled to markup or editor |
| e8f2ff | 4 | id selector; likely tightly coupled to markup or editor |
| e6db74 | 4 | id selector; likely tightly coupled to markup or editor |
| abb2bf | 4 | id selector; likely tightly coupled to markup or editor |
| e06c75 | 4 | id selector; likely tightly coupled to markup or editor |
| b58900 | 4 | id selector; likely tightly coupled to markup or editor |
| cb4b16 | 4 | id selector; likely tightly coupled to markup or editor |
| d33682 | 4 | id selector; likely tightly coupled to markup or editor |
| efefec | 4 | id selector; likely tightly coupled to markup or editor |
| f008 | 4 | id selector; likely tightly coupled to markup or editor |
| a50 | 3 | id selector; likely tightly coupled to markup or editor |
| a11 | 3 | id selector; likely tightly coupled to markup or editor |
| a22 | 3 | id selector; likely tightly coupled to markup or editor |
| d9d9d9 | 3 | id selector; likely tightly coupled to markup or editor |
| ffa | 3 | id selector; likely tightly coupled to markup or editor |
| cfc | 3 | id selector; likely tightly coupled to markup or editor |
| bc9262 | 3 | id selector; likely tightly coupled to markup or editor |
| bc6283 | 3 | id selector; likely tightly coupled to markup or editor |
| fd971f | 3 | id selector; likely tightly coupled to markup or editor |
| b6b3eb | 3 | id selector; likely tightly coupled to markup or editor |
| da4939 | 3 | id selector; likely tightly coupled to markup or editor |
| dc322f | 3 | id selector; likely tightly coupled to markup or editor |
| dfaf8f | 3 | id selector; likely tightly coupled to markup or editor |
| EEEEED | 3 | id selector; likely tightly coupled to markup or editor |
| a5a5a5 | 3 | id selector; likely tightly coupled to markup or editor |
| b4b4b4 | 3 | id selector; likely tightly coupled to markup or editor |
| c3c3c3 | 3 | id selector; likely tightly coupled to markup or editor |
| d2d2d2 | 3 | id selector; likely tightly coupled to markup or editor |
| f002 | 3 | id selector; likely tightly coupled to markup or editor |
| ffffff0a | 2 | id selector; likely tightly coupled to markup or editor |
| f6f6f6 | 2 | id selector; likely tightly coupled to markup or editor |
| ffffff14 | 2 | id selector; likely tightly coupled to markup or editor |
| f0f | 2 | id selector; likely tightly coupled to markup or editor |
| fdff00cc | 2 | id selector; likely tightly coupled to markup or editor |
| ffffff70 | 2 | id selector; likely tightly coupled to markup or editor |
| bbb6 | 2 | id selector; likely tightly coupled to markup or editor |
| c7cacf | 2 | id selector; likely tightly coupled to markup or editor |
| d19a66 | 2 | id selector; likely tightly coupled to markup or editor |
| e5c07b | 2 | id selector; likely tightly coupled to markup or editor |
| c678dd | 2 | id selector; likely tightly coupled to markup or editor |
| f4f1ed | 2 | id selector; likely tightly coupled to markup or editor |
| d4cfc9 | 2 | id selector; likely tightly coupled to markup or editor |
| a5c261 | 2 | id selector; likely tightly coupled to markup or editor |
| fdf6e3 | 2 | id selector; likely tightly coupled to markup or editor |
| f0dfaf | 2 | id selector; likely tightly coupled to markup or editor |
| cc9393 | 2 | id selector; likely tightly coupled to markup or editor |
| f0efd0 | 2 | id selector; likely tightly coupled to markup or editor |
| c69817 | 2 | id selector; likely tightly coupled to markup or editor |
| EEEEEC | 2 | id selector; likely tightly coupled to markup or editor |
| eeeeec | 2 | id selector; likely tightly coupled to markup or editor |
| fdfffc | 2 | id selector; likely tightly coupled to markup or editor |
| efefef | 2 | id selector; likely tightly coupled to markup or editor |
| tr_Tm8gc2NyaXB0IGlzIHJ1bm5pbmdfdW5kZWZpbmVk_outer | 2 | id selector; likely tightly coupled to markup or editor |
| e8560010 | 2 | id selector; likely tightly coupled to markup or editor |
| e85600 | 2 | id selector; likely tightly coupled to markup or editor |
| d60 | 2 | id selector; likely tightly coupled to markup or editor |
| bcb149 | 2 | id selector; likely tightly coupled to markup or editor |
| ff00f7 | 2 | id selector; likely tightly coupled to markup or editor |
| ff4747 | 2 | id selector; likely tightly coupled to markup or editor |
| c34ec3 | 2 | id selector; likely tightly coupled to markup or editor |
| ff8c00 | 2 | id selector; likely tightly coupled to markup or editor |
| root | 1 | id selector; likely tightly coupled to markup or editor |
| install-app-container | 1 | id selector; likely tightly coupled to markup or editor |
| show-code-container | 1 | id selector; likely tightly coupled to markup or editor |
| show-code | 1 | id selector; likely tightly coupled to markup or editor |
| fff9 | 1 | id selector; likely tightly coupled to markup or editor |
| ffffffb3 | 1 | id selector; likely tightly coupled to markup or editor |
| ffffff1f | 1 | id selector; likely tightly coupled to markup or editor |
| ffffff29 | 1 | id selector; likely tightly coupled to markup or editor |
| f77234 | 1 | id selector; likely tightly coupled to markup or editor |
| fff0 | 1 | id selector; likely tightly coupled to markup or editor |
| ffffff03 | 1 | id selector; likely tightly coupled to markup or editor |
| ababab66 | 1 | id selector; likely tightly coupled to markup or editor |
| ffffffb5 | 1 | id selector; likely tightly coupled to markup or editor |
| aeafad | 1 | id selector; likely tightly coupled to markup or editor |
| f38518 | 1 | id selector; likely tightly coupled to markup or editor |
| ddd6 | 1 | id selector; likely tightly coupled to markup or editor |
| ccc6 | 1 | id selector; likely tightly coupled to markup or editor |
| ffd | 1 | id selector; likely tightly coupled to markup or editor |
| ff1717 | 1 | id selector; likely tightly coupled to markup or editor |
| cc7 | 1 | id selector; likely tightly coupled to markup or editor |
| f8f8f8 | 1 | id selector; likely tightly coupled to markup or editor |
| f90 | 1 | id selector; likely tightly coupled to markup or editor |
| ca7841 | 1 | id selector; likely tightly coupled to markup or editor |
| cda869 | 1 | id selector; likely tightly coupled to markup or editor |
| bd6b18 | 1 | id selector; likely tightly coupled to markup or editor |
| d6bb6d | 1 | id selector; likely tightly coupled to markup or editor |
| ff6400 | 1 | id selector; likely tightly coupled to markup or editor |
