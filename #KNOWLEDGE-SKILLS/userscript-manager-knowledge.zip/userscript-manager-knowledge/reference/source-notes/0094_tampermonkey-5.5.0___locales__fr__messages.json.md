# Source Note: `tampermonkey-5.5.0/_locales/fr/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `_locales/fr/messages.json` |
| Byte size | `53011` |
| SHA-256 | `5eccc22f1acc143e2f2b79bbe2ad33b82881b4b559e693c6498b074f6d3c3a06` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 107 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| security_privacy_isolation | 60 | Open related module: 06-network-permissions-security |
| storage_sync_backup | 58 | Open related module: 05-storage-sync-import-export |
| script_matching_and_scheduling | 45 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| extension_manifest_and_permissions | 32 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| mv3_offscreen_userScripts | 25 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| editor_lint_format | 20 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| userscript_metadata | 19 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| network_cookies_downloads | 18 | Open related module: 06-network-permissions-security |
| gm_api_runtime | 3 | Open related module: 03-execution-sandbox-gm-api |
| content_page_bridge | 2 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: message:660, script:67, content:61, pour:46, scripts:44, placeholders:43, Tampermonkey:36, name:36, vous:32, jour:23, utilisateur:18, votre:17.

Browser API vocabulary mentions: runtime:2, tabs:5, storage:1, notifications:2, cookies:2, downloads:1, commands:1, action:10, permissions:3.

GM/API compatibility vocabulary mentions: GM_xmlhttpRequest:2, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
