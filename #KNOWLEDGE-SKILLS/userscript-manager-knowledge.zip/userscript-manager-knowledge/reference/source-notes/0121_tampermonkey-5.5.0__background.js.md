# Source Note: `tampermonkey-5.5.0/background.js`

## Readable role

Background orchestrator: owns script registry, browser events, privileged APIs, matching, update checks, permissions, and long-running coordination.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `background.js` |
| Byte size | `614197` |
| SHA-256 | `ad82818a900bacfda35190757963f35a8b3f044879c7fb42c7ec8176a787dddb` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 1427 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| network_cookies_downloads | 597 | Open related module: 06-network-permissions-security |
| storage_sync_backup | 593 | Open related module: 05-storage-sync-import-export |
| security_privacy_isolation | 442 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 436 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| extension_manifest_and_permissions | 245 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| editor_lint_format | 163 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| mv3_offscreen_userScripts | 85 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| background_service_worker_or_event_page | 78 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| i18n_localization | 71 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| content_page_bridge | 41 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| userscript_metadata | 37 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| gm_api_runtime | 14 | Open related module: 03-execution-sandbox-gm-api |

Top identifier-like terms: const:1841, this:1815, return:1804, function:672, void:660, name:638, null:511, getMessage:473, length:457, value:385, push:373, await:351.

Browser API vocabulary mentions: runtime:70, tabs:53, storage:124, webNavigation:29, webRequest:56, contextMenus:10, notifications:5, cookies:5, alarms:10, declarativeNetRequest:5, scripting:6, userScripts:10, offscreen:13, downloads:20, commands:19, action:103, permissions:25, idle:5.

GM/API compatibility vocabulary mentions: GM_addElement:1, GM_addStyle:2, GM_deleteValue:2, GM_getResourceText:1, GM_getResourceURL:1, GM_getTab:2, GM_getTabs:1, GM_getValue:2, GM_info:2, GM_listValues:1, GM_log:1, GM_notification:1, GM_openInTab:1, GM_registerMenuCommand:1, GM_removeValueChangeListener:1, GM_saveTab:1, GM_setClipboard:1, GM_setValue:2, GM_xmlhttpRequest:1, GM.xmlHttpRequest:1, GM.download:1, GM.setValue:2, GM.getValue:2, unsafeWindow:2.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
