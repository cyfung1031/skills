# Source Note: `scriptcat-1.3.2/src/chunk.js`

## Readable role

Supporting source file: inspect alongside neighboring entry points to determine responsibility.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/chunk.js` |
| Byte size | `118404` |
| SHA-256 | `fdd038d42c88a670a5c7b50ff739ff6b7617bc7ea7f5e1d0bcc911f7334c8731` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 187 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 160 | Open related module: 05-storage-sync-import-export |
| editor_lint_format | 142 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| script_matching_and_scheduling | 107 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| network_cookies_downloads | 61 | Open related module: 06-network-permissions-security |
| extension_manifest_and_permissions | 58 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| security_privacy_isolation | 42 | Open related module: 06-network-permissions-security |
| i18n_localization | 15 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| gm_api_runtime | 13 | Open related module: 03-execution-sandbox-gm-api |
| mv3_offscreen_userScripts | 10 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| content_page_bridge | 5 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| userscript_metadata | 1 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |

Top identifier-like terms: return:328, this:273, string:213, error:110, function:106, chrome:100, void:91, Promise:79, test:75, boolean:72, script:64, once:63.

Browser API vocabulary mentions: runtime:44, tabs:4, storage:55, cookies:1, userScripts:5, action:22, permissions:1, idle:7.

GM/API compatibility vocabulary mentions: GM_addElement:2, GM_addStyle:1, GM_deleteValue:2, GM_getResourceText:1, GM_getResourceURL:1, GM_getTab:2, GM_getTabs:1, GM_getValue:2, GM_info:2, GM_listValues:1, GM_log:1, GM_notification:2, GM_openInTab:3, GM_registerMenuCommand:1, GM_removeValueChangeListener:1, GM_saveTab:1, GM_setClipboard:1, GM_setValue:2, GM_xmlhttpRequest:1, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
