# Source Note: `violentmonkey-2.41.0/injected-web.js`

## Readable role

Page-world or sandbox runtime: exposes allowed userscript globals and mediates GM APIs back to the extension.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `injected-web.js` |
| Byte size | `17597` |
| SHA-256 | `92669f535f67893943f02a1791e3fb85b77175485748b194a223529878716cf1` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 24 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 12 | Open related module: 05-storage-sync-import-export |
| network_cookies_downloads | 11 | Open related module: 06-network-permissions-security |
| gm_api_runtime | 9 | Open related module: 03-execution-sandbox-gm-api |
| content_page_bridge | 2 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |

Top identifier-like terms: const:85, null:78, return:64, function:37, this:31, length:27, __proto__:26, delete:26, post:19, void:18, data:15, value:14.

Browser API vocabulary mentions: none.

GM/API compatibility vocabulary mentions: GM_addElement:1, GM_addStyle:1, GM_deleteValue:2, GM_getResourceText:1, GM_getResourceURL:1, GM_getValue:2, GM_info:1, GM_listValues:1, GM_log:2, GM_notification:1, GM_openInTab:1, GM_registerMenuCommand:1, GM_removeValueChangeListener:1, GM_setClipboard:1, GM_setValue:2, GM_xmlhttpRequest:1, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
