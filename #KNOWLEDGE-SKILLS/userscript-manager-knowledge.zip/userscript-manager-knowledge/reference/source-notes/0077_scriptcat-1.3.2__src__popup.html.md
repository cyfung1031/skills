# Source Note: `scriptcat-1.3.2/src/popup.html`

## Readable role

Product UI: dashboard, popup, options, settings, dialogs, script list, editor launch, and user-facing permission decisions.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/popup.html` |
| Byte size | `1173` |
| SHA-256 | `22816df59de72fae3f92c51cfd2f278d2ff1085753ee26bee8078533ccdbc837` |
| Readable pattern name | `UserFacingScriptManagementViewModel` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| editor_lint_format | 2 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| dashboard_popup_options_ui | 2 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| i18n_localization | 2 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| security_privacy_isolation | 1 | Open related module: 06-network-permissions-security |

Top identifier-like terms: script:30, defer:14, lib_react:5, html:4, width:3, body:3, icons:3, link:3, href:3, stylesheet:3, head:2, meta:2.

Browser API vocabulary mentions: none.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
interface DashboardViewState {
  searchQuery: string;
  selectedTagNames: string[];
  visibleScripts: ScriptListItemViewModel[];
  selectedScriptId?: ScriptIdentifier;
  editorDirtyState: 'clean' | 'dirty' | 'saving' | 'conflict';
  permissionPrompts: PermissionPromptViewModel[];
  importExportProgress?: TransferProgressViewModel;
  activeToastMessages: ToastViewModel[];
}

function buildScriptListItemViewModel(scriptRecord: StoredUserscriptRecord): ScriptListItemViewModel {
  return {
    id: scriptRecord.id,
    title: scriptRecord.metadata.scriptName,
    subtitle: scriptRecord.metadata.description ?? scriptRecord.metadata.namespace,
    enabled: scriptRecord.enabled,
    version: scriptRecord.metadata.version,
    updateStatus: deriveUpdateBadge(scriptRecord),
    warningCount: countMetadataWarnings(scriptRecord.metadata),
    lastRunStatus: scriptRecord.lastRunStatus ?? 'not-run-yet',
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
