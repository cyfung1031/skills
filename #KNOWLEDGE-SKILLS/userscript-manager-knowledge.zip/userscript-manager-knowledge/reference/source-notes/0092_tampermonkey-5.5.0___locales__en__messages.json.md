# Source Note: `tampermonkey-5.5.0/_locales/en/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `_locales/en/messages.json` |
| Byte size | `50222` |
| SHA-256 | `990c2548e0252dbf8ea1f246e90252fd5fb8e78828570d00e5c4d31dd406654f` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 144 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| security_privacy_isolation | 102 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 70 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| storage_sync_backup | 63 | Open related module: 05-storage-sync-import-export |
| extension_manifest_and_permissions | 35 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| editor_lint_format | 29 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| mv3_offscreen_userScripts | 28 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| network_cookies_downloads | 22 | Open related module: 06-network-permissions-security |
| userscript_metadata | 20 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| background_service_worker_or_event_page | 2 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| content_page_bridge | 2 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| gm_api_runtime | 2 | Open related module: 03-execution-sandbox-gm-api |

Top identifier-like terms: message:694, content:75, script:61, placeholders:54, name:40, Tampermonkey:36, scripts:35, this:33, This:26, your:25, Userscript:21, want:20.

Browser API vocabulary mentions: runtime:4, tabs:10, storage:2, cookies:3, downloads:2, commands:2, action:8, permissions:7.

GM/API compatibility vocabulary mentions: GM_xmlhttpRequest:1, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
