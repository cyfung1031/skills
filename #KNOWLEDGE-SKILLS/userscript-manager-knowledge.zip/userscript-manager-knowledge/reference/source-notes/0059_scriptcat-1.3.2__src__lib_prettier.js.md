# Source Note: `scriptcat-1.3.2/src/lib_prettier.js`

## Readable role

Editor/linting toolchain: code editing, syntax services, metadata linting, formatting, workers, and validation feedback.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/lib_prettier.js` |
| Byte size | `593217` |
| SHA-256 | `6b92ed9ff8cc5a53dba503e64de308f6ad7371ef7c7ca41537e4318921ead063` |
| Readable pattern name | `VersionedScriptStorageRepository` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| storage_sync_backup | 890 | Open related module: 05-storage-sync-import-export |
| script_matching_and_scheduling | 477 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| dashboard_popup_options_ui | 191 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| security_privacy_isolation | 180 | Open related module: 06-network-permissions-security |
| editor_lint_format | 137 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| i18n_localization | 7 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| extension_manifest_and_permissions | 3 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: this:5451, return:2611, type:1633, case:1161, state:893, function:702, null:655, push:514, length:502, value:468, match:429, void:366.

Browser API vocabulary mentions: tabs:1, commands:1, action:2.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function saveScriptRecordWithVersionedSchema(record: StoredUserscriptRecord): Promise<void> {
  const validatedRecord = validateScriptRecordForCurrentSchema(record);
  const migrationPlan = planStorageMigrationIfNeeded(validatedRecord);
  await writeRepositoryTransaction(async transaction => {
    await transaction.saveScript(validatedRecord);
    await transaction.applyMigrationPlan(migrationPlan);
    await transaction.writeAuditEvent('script-record-saved', validatedRecord.id);
  });
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
