# Source Note: `tampermonkey-5.5.0/lint.js`

## Readable role

Editor/linting toolchain: code editing, syntax services, metadata linting, formatting, workers, and validation feedback.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `lint.js` |
| Byte size | `13927` |
| SHA-256 | `94affe1847372cda07d0542ba4260918063b8572729942793173782e953b65a3` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 34 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| script_matching_and_scheduling | 21 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| storage_sync_backup | 18 | Open related module: 05-storage-sync-import-export |
| mv3_offscreen_userScripts | 15 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| editor_lint_format | 13 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| network_cookies_downloads | 9 | Open related module: 06-network-permissions-security |
| userscript_metadata | 4 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| content_page_bridge | 3 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| security_privacy_isolation | 3 | Open related module: 06-network-permissions-security |
| gm_api_runtime | 1 | Open related module: 03-execution-sandbox-gm-api |

Top identifier-like terms: const:50, trim:36, line:27, type:21, value:21, start:21, return:19, metadata:19, report:19, messageId:19, exports:17, UserScript:17.

Browser API vocabulary mentions: webRequest:2.

GM/API compatibility vocabulary mentions: unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
