# Source Note: `violentmonkey-2.41.0/_locales/zh_CN/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `_locales/zh_CN/messages.json` |
| Byte size | `22850` |
| SHA-256 | `c893d7c77f3b0656b37ed624cbb8d86b9cf11487b713e29a9a2cf972113f2c80` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 51 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 34 | Open related module: 05-storage-sync-import-export |
| script_matching_and_scheduling | 19 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| userscript_metadata | 16 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| editor_lint_format | 12 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| security_privacy_isolation | 11 | Open related module: 06-network-permissions-security |
| network_cookies_downloads | 6 | Open related module: 06-network-permissions-security |
| extension_manifest_and_permissions | 2 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| content_page_bridge | 1 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| gm_api_runtime | 1 | Open related module: 03-execution-sandbox-gm-api |

Top identifier-like terms: message:276, code:44, name:8, JSON:4, with:4, date:3, HTTP:3, grant:3, match:3, only:3, cookies:3, enabled:3.

Browser API vocabulary mentions: cookies:3.

GM/API compatibility vocabulary mentions: unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
