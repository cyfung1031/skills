# Source Note: `tampermonkey-5.5.0/_locales/nl/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `_locales/nl/messages.json` |
| Byte size | `37460` |
| SHA-256 | `c3f37df63f28f77a7c1b9d8ce8df9cb50ce9aa17a5c8c9bb98e0a116df24b1ca` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 73 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| security_privacy_isolation | 52 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 42 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| storage_sync_backup | 36 | Open related module: 05-storage-sync-import-export |
| editor_lint_format | 25 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| network_cookies_downloads | 22 | Open related module: 06-network-permissions-security |
| userscript_metadata | 13 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| mv3_offscreen_userScripts | 10 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| extension_manifest_and_permissions | 6 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| gm_api_runtime | 3 | Open related module: 03-execution-sandbox-gm-api |
| content_page_bridge | 2 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |

Top identifier-like terms: message:542, script:32, Tampermonkey:30, content:29, placeholders:25, niet:22, scripts:21, name:20, door:14, voor:13, zijn:12, UserScript:12.

Browser API vocabulary mentions: runtime:2, tabs:2, storage:1, cookies:2, downloads:2, action:1, permissions:1.

GM/API compatibility vocabulary mentions: GM_xmlhttpRequest:2, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
