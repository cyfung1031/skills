# Source Note: `violentmonkey-2.41.0/injected.js`

## Readable role

Content/page bridge: enters each tab/frame, schedules scripts, forwards messages, and separates extension isolation from page-world behavior.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `injected.js` |
| Byte size | `16708` |
| SHA-256 | `c8f25cffac5d9bea8780da31586d66dcf1e07540733f3f0b2161070b14960ed9` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 34 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 26 | Open related module: 05-storage-sync-import-export |
| network_cookies_downloads | 21 | Open related module: 06-network-permissions-security |
| security_privacy_isolation | 6 | Open related module: 06-network-permissions-security |
| content_page_bridge | 5 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| script_matching_and_scheduling | 4 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| extension_manifest_and_permissions | 1 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| i18n_localization | 1 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| mv3_offscreen_userScripts | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: const:69, null:51, return:41, await:39, function:35, async:23, length:21, data:17, void:15, post:15, delete:14, catch:12.

Browser API vocabulary mentions: runtime:7, tabs:1, storage:1, idle:2.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
