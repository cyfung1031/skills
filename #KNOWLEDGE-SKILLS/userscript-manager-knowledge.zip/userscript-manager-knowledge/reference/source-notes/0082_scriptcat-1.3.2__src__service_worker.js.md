# Source Note: `scriptcat-1.3.2/src/service_worker.js`

## Readable role

Background orchestrator: owns script registry, browser events, privileged APIs, matching, update checks, permissions, and long-running coordination.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/service_worker.js` |
| Byte size | `1196003` |
| SHA-256 | `0926b10eea2d22d646fd927e7292a604fed1550e30630bc0b2379a2ba8d40a80` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 1956 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 1357 | Open related module: 05-storage-sync-import-export |
| network_cookies_downloads | 710 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 683 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| security_privacy_isolation | 526 | Open related module: 06-network-permissions-security |
| editor_lint_format | 364 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| extension_manifest_and_permissions | 335 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| i18n_localization | 174 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| mv3_offscreen_userScripts | 157 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| userscript_metadata | 87 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| gm_api_runtime | 69 | Open related module: 03-execution-sandbox-gm-api |
| background_service_worker_or_event_page | 42 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| content_page_bridge | 37 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |

Top identifier-like terms: this:5767, return:3999, function:2095, length:1321, null:849, type:632, case:623, typeof:568, void:566, options:512, arguments:501, throw:481.

Browser API vocabulary mentions: runtime:223, tabs:87, storage:125, webNavigation:4, webRequest:15, contextMenus:5, notifications:16, cookies:7, alarms:16, declarativeNetRequest:25, scripting:7, userScripts:29, offscreen:43, downloads:12, action:164, permissions:12, idle:2.

GM/API compatibility vocabulary mentions: GM_addElement:3, GM_addStyle:4, GM_deleteValue:8, GM_getResourceText:4, GM_getResourceURL:3, GM_getTab:12, GM_getTabs:4, GM_getValue:5, GM_info:4, GM_listValues:3, GM_log:5, GM_notification:19, GM_openInTab:12, GM_registerMenuCommand:10, GM_removeValueChangeListener:2, GM_saveTab:4, GM_setClipboard:5, GM_setValue:9, GM_xmlhttpRequest:10, GM.xmlHttpRequest:3, GM.download:1, GM.setValue:3, GM.getValue:3, unsafeWindow:2.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
