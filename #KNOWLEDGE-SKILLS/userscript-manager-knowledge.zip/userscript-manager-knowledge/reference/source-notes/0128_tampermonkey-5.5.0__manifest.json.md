# Source Note: `tampermonkey-5.5.0/manifest.json`

## Readable role

Extension manifest: declares runtime model, permissions, host scope, entry points, commands, and installation surface.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `manifest.json` |
| Byte size | `2067` |
| SHA-256 | `adde983662337d93334c67c374b3c163908e68b1b6d16b95728f57e590829749` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 18 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| extension_manifest_and_permissions | 13 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| background_service_worker_or_event_page | 5 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| network_cookies_downloads | 4 | Open related module: 06-network-permissions-security |
| i18n_localization | 4 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| security_privacy_isolation | 4 | Open related module: 06-network-permissions-security |
| mv3_offscreen_userScripts | 4 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| editor_lint_format | 1 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |

Top identifier-like terms: images:8, description:5, dashboard:4, html:3, open:3, Open:3, true:2, action:2, background:2, options:2, enable:2, with:2.

Browser API vocabulary mentions: tabs:1, storage:2, webNavigation:1, webRequest:2, contextMenus:1, notifications:1, cookies:1, alarms:1, declarativeNetRequest:1, scripting:1, userScripts:1, offscreen:1, downloads:1, commands:1, action:2, permissions:3, idle:1.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
