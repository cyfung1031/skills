# Source Note: `tampermonkey-5.5.0/page.js`

## Readable role

Page-world or sandbox runtime: exposes allowed userscript globals and mediates GM APIs back to the extension.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `page.js` |
| Byte size | `50024` |
| SHA-256 | `8cfffe6422307465cffb6b8c44cc282f02b5b7e542d2386ac434a7705fe070e5` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 139 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| network_cookies_downloads | 129 | Open related module: 06-network-permissions-security |
| content_page_bridge | 31 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| gm_api_runtime | 24 | Open related module: 03-execution-sandbox-gm-api |
| script_matching_and_scheduling | 23 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| extension_manifest_and_permissions | 14 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| security_privacy_isolation | 9 | Open related module: 06-network-permissions-security |
| storage_sync_backup | 6 | Open related module: 05-storage-sync-import-export |
| i18n_localization | 4 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| userscript_metadata | 2 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: const:273, return:210, void:150, null:89, function:81, value:80, else:62, uuid:54, typeof:36, prototype:35, this:34, delete:34.

Browser API vocabulary mentions: tabs:3, storage:2, webRequest:7, cookies:1, action:6, idle:1.

GM/API compatibility vocabulary mentions: GM_addElement:2, GM_addStyle:2, GM_deleteValue:4, GM_getResourceText:2, GM_getResourceURL:2, GM_getTab:4, GM_getTabs:2, GM_getValue:4, GM_info:1, GM_listValues:2, GM_log:2, GM_notification:3, GM_openInTab:2, GM_registerMenuCommand:2, GM_removeValueChangeListener:2, GM_saveTab:2, GM_setClipboard:2, GM_setValue:4, GM_xmlhttpRequest:2, GM.xmlHttpRequest:2, GM.download:2, GM.setValue:4, GM.getValue:4, unsafeWindow:4.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
