# Source Note: `violentmonkey-2.41.0/_locales/sv/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `_locales/sv/messages.json` |
| Byte size | `24198` |
| SHA-256 | `cbcf110db7481f888533946059bfff16ae378c781b47e92b39d305e69b8caf79` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 69 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 42 | Open related module: 05-storage-sync-import-export |
| script_matching_and_scheduling | 23 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| editor_lint_format | 13 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| security_privacy_isolation | 11 | Open related module: 06-network-permissions-security |
| network_cookies_downloads | 8 | Open related module: 06-network-permissions-security |
| userscript_metadata | 7 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| extension_manifest_and_permissions | 3 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| background_service_worker_or_event_page | 2 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| content_page_bridge | 1 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| gm_api_runtime | 1 | Open related module: 03-execution-sandbox-gm-api |

Top identifier-like terms: message:276, code:43, skript:35, eller:15, llningar:14, inte:14, till:11, efter:10, inst:9, Visa:8, fliken:8, Violentmonkey:7.

Browser API vocabulary mentions: cookies:5, commands:1.

GM/API compatibility vocabulary mentions: unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
