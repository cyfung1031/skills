# Source Note: `tampermonkey-5.5.0/vendor/eslint/eslint.js`

## Readable role

Editor/linting toolchain: code editing, syntax services, metadata linting, formatting, workers, and validation feedback.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `vendor/eslint/eslint.js` |
| Byte size | `1492251` |
| SHA-256 | `a64f2b3ed2b74468b6b72cffd6ffd49b6b3c7eba3e8d502ca3e0aaed01348476` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| storage_sync_backup | 1563 | Open related module: 05-storage-sync-import-export |
| dashboard_popup_options_ui | 1122 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| editor_lint_format | 920 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| security_privacy_isolation | 485 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 434 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| network_cookies_downloads | 60 | Open related module: 06-network-permissions-security |
| i18n_localization | 21 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| extension_manifest_and_permissions | 13 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| content_page_bridge | 13 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| gm_api_runtime | 8 | Open related module: 03-execution-sandbox-gm-api |
| mv3_offscreen_userScripts | 5 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: this:5607, return:3933, function:3752, false:1663, type:1418, length:1357, null:867, case:856, const:672, value:640, void:633, else:607.

Browser API vocabulary mentions: runtime:2, tabs:10, storage:5, offscreen:1, action:11.

GM/API compatibility vocabulary mentions: GM_addElement:1, GM_addStyle:1, GM_deleteValue:1, GM_getResourceText:1, GM_getResourceURL:1, GM_getTab:2, GM_getTabs:1, GM_getValue:1, GM_info:1, GM_listValues:1, GM_log:1, GM_notification:1, GM_openInTab:1, GM_registerMenuCommand:1, GM_removeValueChangeListener:1, GM_saveTab:1, GM_setClipboard:1, GM_setValue:1, GM_xmlhttpRequest:1, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
