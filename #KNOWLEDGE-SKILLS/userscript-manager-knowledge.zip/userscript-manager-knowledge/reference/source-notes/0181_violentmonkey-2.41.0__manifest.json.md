# Source Note: `violentmonkey-2.41.0/manifest.json`

## Readable role

Extension manifest: declares runtime model, permissions, host scope, entry points, commands, and installation surface.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `manifest.json` |
| Byte size | `2086` |
| SHA-256 | `9debff8becb973e8eb41603e997dc5ef66f80ea131d30cf553368a8f677f6b07` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 13 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| i18n_localization | 11 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| extension_manifest_and_permissions | 10 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| content_page_bridge | 5 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| network_cookies_downloads | 3 | Open related module: 06-network-permissions-security |
| background_service_worker_or_event_page | 2 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| script_matching_and_scheduling | 2 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| security_privacy_isolation | 1 | Open related module: 06-network-permissions-security |

Top identifier-like terms: description:8, public:8, images:8, true:3, index:3, __MSG_extName__:2, html:2, background:2, settings:2, injected:2, all_urls:2, name:1.

Browser API vocabulary mentions: tabs:1, storage:1, webRequest:2, contextMenus:1, notifications:1, cookies:1, commands:1, action:2, permissions:1.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
