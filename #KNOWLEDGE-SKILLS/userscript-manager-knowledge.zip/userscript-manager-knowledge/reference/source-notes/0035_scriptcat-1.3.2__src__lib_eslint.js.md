# Source Note: `scriptcat-1.3.2/src/lib_eslint.js`

## Readable role

Editor/linting toolchain: code editing, syntax services, metadata linting, formatting, workers, and validation feedback.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/lib_eslint.js` |
| Byte size | `39967` |
| SHA-256 | `f4bd26e16ec673953963b2f8305bd4888fd3b56b3a9006c5b829f7e366f0191f` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 50 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| script_matching_and_scheduling | 28 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| storage_sync_backup | 22 | Open related module: 05-storage-sync-import-export |
| gm_api_runtime | 21 | Open related module: 03-execution-sandbox-gm-api |
| mv3_offscreen_userScripts | 20 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| network_cookies_downloads | 19 | Open related module: 06-network-permissions-security |
| userscript_metadata | 6 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| security_privacy_isolation | 4 | Open related module: 06-network-permissions-security |
| editor_lint_format | 2 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| content_page_bridge | 1 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |

Top identifier-like terms: type:239, versionConstraint:217, Object:98, tampermonkey:98, violentmonkey:69, enumerable:67, typeof:46, return:46, greasemonkey:46, value:41, default:41, line:37.

Browser API vocabulary mentions: webRequest:3.

GM/API compatibility vocabulary mentions: GM_addElement:1, GM_addStyle:3, GM_deleteValue:3, GM_getResourceText:3, GM_getResourceURL:2, GM_getTab:2, GM_getTabs:1, GM_getValue:3, GM_info:2, GM_listValues:2, GM_log:1, GM_notification:2, GM_openInTab:2, GM_registerMenuCommand:3, GM_removeValueChangeListener:1, GM_saveTab:1, GM_setClipboard:2, GM_setValue:3, GM_xmlhttpRequest:2, GM.xmlHttpRequest:2, GM.download:1, GM.setValue:3, GM.getValue:3, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
