# Source Note: `tampermonkey-5.5.0/content.js`

## Readable role

Content/page bridge: enters each tab/frame, schedules scripts, forwards messages, and separates extension isolation from page-world behavior.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `content.js` |
| Byte size | `44968` |
| SHA-256 | `d6843622d4df0d203079bce0d5ee650678dce1ec1e2b8b2969de735db7c4b515` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 161 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| network_cookies_downloads | 152 | Open related module: 06-network-permissions-security |
| content_page_bridge | 66 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| storage_sync_backup | 14 | Open related module: 05-storage-sync-import-export |
| security_privacy_isolation | 14 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 10 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| gm_api_runtime | 9 | Open related module: 03-execution-sandbox-gm-api |
| mv3_offscreen_userScripts | 7 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| extension_manifest_and_permissions | 5 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| background_service_worker_or_event_page | 2 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| editor_lint_format | 2 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |

Top identifier-like terms: const:194, return:130, addListener:82, void:71, function:66, disconnect:62, else:43, postMessage:42, method:40, prototype:38, onMessage:36, document:34.

Browser API vocabulary mentions: runtime:7, tabs:2, storage:2, webRequest:3, userScripts:3, offscreen:3, idle:1.

GM/API compatibility vocabulary mentions: GM_info:1, unsafeWindow:8.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
