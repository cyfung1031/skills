# Source Note: `violentmonkey-2.41.0/common-ui.js`

## Readable role

Product UI: dashboard, popup, options, settings, dialogs, script list, editor launch, and user-facing permission decisions.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `common-ui.js` |
| Byte size | `178078` |
| SHA-256 | `82af1fd74dbc4a0103d409898c77d452ba29a4664de6b1054db3750a391be12a` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 197 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| script_matching_and_scheduling | 76 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| storage_sync_backup | 68 | Open related module: 05-storage-sync-import-export |
| editor_lint_format | 33 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| extension_manifest_and_permissions | 16 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| security_privacy_isolation | 13 | Open related module: 06-network-permissions-security |
| background_service_worker_or_event_page | 12 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| network_cookies_downloads | 12 | Open related module: 06-network-permissions-security |
| content_page_bridge | 10 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| gm_api_runtime | 10 | Open related module: 03-execution-sandbox-gm-api |
| userscript_metadata | 9 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| i18n_localization | 9 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |

Top identifier-like terms: const:758, return:626, null:461, this:457, function:435, value:211, length:181, void:173, type:137, else:108, default:94, props:87.

Browser API vocabulary mentions: runtime:10, tabs:2, storage:1, commands:8, idle:1.

GM/API compatibility vocabulary mentions: GM_addElement:1, GM_addStyle:2, GM_deleteValue:2, GM_getResourceText:1, GM_getResourceURL:1, GM_getValue:2, GM_info:1, GM_listValues:1, GM_log:1, GM_notification:1, GM_openInTab:1, GM_registerMenuCommand:1, GM_removeValueChangeListener:1, GM_setClipboard:1, GM_setValue:2, GM_xmlhttpRequest:1, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
