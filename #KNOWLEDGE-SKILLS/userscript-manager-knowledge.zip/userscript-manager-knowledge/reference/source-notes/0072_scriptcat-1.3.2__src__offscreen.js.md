# Source Note: `scriptcat-1.3.2/src/offscreen.js`

## Readable role

Offscreen document helper: performs DOM/network/download tasks that a Manifest V3 service worker cannot safely or consistently perform alone.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/offscreen.js` |
| Byte size | `36867` |
| SHA-256 | `8a68ada2e7dcbf35b284258fdf7bb6da1dc951095cf5d381bffc953eb9df2dfb` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| network_cookies_downloads | 165 | Open related module: 06-network-permissions-security |
| dashboard_popup_options_ui | 70 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 32 | Open related module: 05-storage-sync-import-export |
| extension_manifest_and_permissions | 29 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| mv3_offscreen_userScripts | 22 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| content_page_bridge | 16 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| editor_lint_format | 14 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| security_privacy_isolation | 13 | Open related module: 06-network-permissions-security |
| background_service_worker_or_event_page | 5 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: this:392, return:122, type:55, null:54, data:50, length:45, function:42, typeof:40, chrome:40, runtime:37, else:34, error:30.

Browser API vocabulary mentions: runtime:37, tabs:2, webRequest:2, declarativeNetRequest:2, userScripts:1, offscreen:18, action:23.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
