# Source Note: `violentmonkey-2.41.0/background/index.js`

## Readable role

Background orchestrator: owns script registry, browser events, privileged APIs, matching, update checks, permissions, and long-running coordination.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `background/index.js` |
| Byte size | `230983` |
| SHA-256 | `54ce5b7bf466df30c29a224475036a625bbde4b655445a77a3d51a2c806235eb` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| storage_sync_backup | 276 | Open related module: 05-storage-sync-import-export |
| dashboard_popup_options_ui | 253 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| network_cookies_downloads | 131 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 102 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| security_privacy_isolation | 33 | Open related module: 06-network-permissions-security |
| editor_lint_format | 17 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| userscript_metadata | 15 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| extension_manifest_and_permissions | 11 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| content_page_bridge | 9 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| background_service_worker_or_event_page | 6 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| i18n_localization | 4 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| gm_api_runtime | 1 | Open related module: 03-execution-sandbox-gm-api |
| mv3_offscreen_userScripts | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: const:514, return:441, function:287, null:280, this:259, length:190, await:169, async:112, void:88, name:79, slice:66, push:65.

Browser API vocabulary mentions: runtime:19, tabs:28, storage:11, webRequest:11, contextMenus:1, notifications:4, cookies:7, commands:1, action:3, idle:1.

GM/API compatibility vocabulary mentions: GM_info:1, GM_setClipboard:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
