# Source Note: `tampermonkey-5.5.0/extension.js`

## Readable role

Product UI: dashboard, popup, options, settings, dialogs, script list, editor launch, and user-facing permission decisions.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `extension.js` |
| Byte size | `534898` |
| SHA-256 | `71a9ca4cc1fe04b1fa86dac8595f9118963a38455df4c28d62f2f02f03fbff89` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 1112 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| script_matching_and_scheduling | 341 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| editor_lint_format | 323 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| storage_sync_backup | 321 | Open related module: 05-storage-sync-import-export |
| network_cookies_downloads | 320 | Open related module: 06-network-permissions-security |
| extension_manifest_and_permissions | 173 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| security_privacy_isolation | 142 | Open related module: 06-network-permissions-security |
| content_page_bridge | 108 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| mv3_offscreen_userScripts | 47 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| i18n_localization | 35 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| background_service_worker_or_event_page | 23 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| gm_api_runtime | 12 | Open related module: 03-execution-sandbox-gm-api |
| userscript_metadata | 11 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |

Top identifier-like terms: this:1483, const:1396, return:1226, function:710, appendChild:497, uuid:472, name:471, null:469, length:444, void:372, value:326, push:242.

Browser API vocabulary mentions: runtime:28, tabs:92, storage:59, webNavigation:5, webRequest:7, contextMenus:4, notifications:2, cookies:3, alarms:2, declarativeNetRequest:3, scripting:2, userScripts:2, downloads:2, commands:4, action:78, permissions:21, idle:2.

GM/API compatibility vocabulary mentions: GM_addElement:1, GM_addStyle:2, GM_deleteValue:1, GM_getResourceText:1, GM_getResourceURL:1, GM_getTab:2, GM_getTabs:1, GM_getValue:1, GM_info:1, GM_listValues:1, GM_log:1, GM_notification:1, GM_openInTab:1, GM_registerMenuCommand:1, GM_removeValueChangeListener:1, GM_saveTab:1, GM_setClipboard:1, GM_setValue:2, GM_xmlhttpRequest:2, GM.xmlHttpRequest:1, GM.setValue:1, unsafeWindow:2.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
