# Source Note: `scriptcat-1.3.2/src/inject.js`

## Readable role

Supporting source file: inspect alongside neighboring entry points to determine responsibility.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/inject.js` |
| Byte size | `60586` |
| SHA-256 | `3b32a40b95955a6ba818a162c4dc842eb6464cd597324f383218464775e8cf6e` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 183 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| network_cookies_downloads | 128 | Open related module: 06-network-permissions-security |
| gm_api_runtime | 54 | Open related module: 03-execution-sandbox-gm-api |
| extension_manifest_and_permissions | 29 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| storage_sync_backup | 28 | Open related module: 05-storage-sync-import-export |
| security_privacy_isolation | 18 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 17 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| content_page_bridge | 11 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| i18n_localization | 1 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |

Top identifier-like terms: this:410, return:249, null:167, prototype:108, typeof:97, case:74, void:67, function:59, Object:56, data:56, length:53, error:53.

Browser API vocabulary mentions: runtime:8, storage:3, scripting:3, action:23, idle:1.

GM/API compatibility vocabulary mentions: GM_addElement:6, GM_addStyle:5, GM_deleteValue:5, GM_getResourceText:4, GM_getResourceURL:4, GM_getTab:10, GM_getTabs:5, GM_getValue:8, GM_info:4, GM_listValues:2, GM_log:5, GM_notification:9, GM_openInTab:8, GM_registerMenuCommand:8, GM_removeValueChangeListener:4, GM_saveTab:5, GM_setClipboard:5, GM_setValue:13, GM_xmlhttpRequest:6, GM.xmlHttpRequest:2, GM.download:2, GM.setValue:5, GM.getValue:4, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
