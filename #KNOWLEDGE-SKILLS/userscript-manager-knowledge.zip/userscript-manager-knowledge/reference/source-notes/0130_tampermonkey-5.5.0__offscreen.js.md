# Source Note: `tampermonkey-5.5.0/offscreen.js`

## Readable role

Offscreen document helper: performs DOM/network/download tasks that a Manifest V3 service worker cannot safely or consistently perform alone.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `offscreen.js` |
| Byte size | `54530` |
| SHA-256 | `0b109f9dd914e38fdbccaa9186147c7e00736e8cbcd0c45e329a98043be24435` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| network_cookies_downloads | 151 | Open related module: 06-network-permissions-security |
| dashboard_popup_options_ui | 55 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 52 | Open related module: 05-storage-sync-import-export |
| script_matching_and_scheduling | 24 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| extension_manifest_and_permissions | 6 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| content_page_bridge | 5 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| mv3_offscreen_userScripts | 5 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| editor_lint_format | 4 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| background_service_worker_or_event_page | 2 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| security_privacy_isolation | 2 | Open related module: 06-network-permissions-security |

Top identifier-like terms: this:249, const:228, return:165, ncom:133, void:102, await:66, null:62, else:51, async:47, length:37, type:36, function:35.

Browser API vocabulary mentions: runtime:8, storage:1, offscreen:5, action:6.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
