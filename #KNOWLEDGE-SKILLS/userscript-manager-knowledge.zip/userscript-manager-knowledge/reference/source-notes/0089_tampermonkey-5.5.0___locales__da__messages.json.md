# Source Note: `tampermonkey-5.5.0/_locales/da/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `_locales/da/messages.json` |
| Byte size | `46484` |
| SHA-256 | `9c0f7507a0b7a9deacb4d645c4837f6f4d33fb7915d98445d03e21922e9f3a84` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 95 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| security_privacy_isolation | 50 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 45 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| storage_sync_backup | 39 | Open related module: 05-storage-sync-import-export |
| mv3_offscreen_userScripts | 24 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| network_cookies_downloads | 22 | Open related module: 06-network-permissions-security |
| editor_lint_format | 19 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| userscript_metadata | 17 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| extension_manifest_and_permissions | 13 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| gm_api_runtime | 3 | Open related module: 03-execution-sandbox-gm-api |
| content_page_bridge | 2 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| i18n_localization | 1 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |

Top identifier-like terms: message:628, content:60, placeholders:42, script:42, Tampermonkey:32, name:32, ikke:32, scripts:29, dette:23, blev:22, Dette:22, alle:20.

Browser API vocabulary mentions: runtime:2, tabs:3, storage:1, cookies:2, downloads:2, commands:1, action:5, permissions:1, idle:3.

GM/API compatibility vocabulary mentions: GM_xmlhttpRequest:2, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
