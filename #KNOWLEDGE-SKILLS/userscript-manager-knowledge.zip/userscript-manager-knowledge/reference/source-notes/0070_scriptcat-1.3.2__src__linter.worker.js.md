# Source Note: `scriptcat-1.3.2/src/linter.worker.js`

## Readable role

Editor/linting toolchain: code editing, syntax services, metadata linting, formatting, workers, and validation feedback.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/linter.worker.js` |
| Byte size | `1378255` |
| SHA-256 | `472239eacf3e4a282e9540bb083d21aae8d4680961da39f7409cd5d25e888093` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| editor_lint_format | 2107 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| dashboard_popup_options_ui | 1511 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 1152 | Open related module: 05-storage-sync-import-export |
| security_privacy_isolation | 596 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 515 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| network_cookies_downloads | 73 | Open related module: 06-network-permissions-security |
| gm_api_runtime | 29 | Open related module: 03-execution-sandbox-gm-api |
| extension_manifest_and_permissions | 25 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| mv3_offscreen_userScripts | 24 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| i18n_localization | 14 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| content_page_bridge | 10 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| userscript_metadata | 6 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |

Top identifier-like terms: this:5594, return:3848, type:2502, function:2273, length:1148, case:926, null:918, value:741, parent:609, name:577, push:534, start:504.

Browser API vocabulary mentions: runtime:1, tabs:13, storage:6, webRequest:3, offscreen:1, action:22.

GM/API compatibility vocabulary mentions: GM_addElement:2, GM_addStyle:4, GM_deleteValue:4, GM_getResourceText:4, GM_getResourceURL:3, GM_getTab:4, GM_getTabs:2, GM_getValue:4, GM_info:3, GM_listValues:3, GM_log:2, GM_notification:3, GM_openInTab:3, GM_registerMenuCommand:4, GM_removeValueChangeListener:2, GM_saveTab:2, GM_setClipboard:3, GM_setValue:4, GM_xmlhttpRequest:3, GM.xmlHttpRequest:2, GM.download:1, GM.setValue:3, GM.getValue:3, unsafeWindow:2.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
