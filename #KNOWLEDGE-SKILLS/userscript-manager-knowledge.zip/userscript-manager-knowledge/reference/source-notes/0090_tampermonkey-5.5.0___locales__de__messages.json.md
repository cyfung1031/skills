# Source Note: `tampermonkey-5.5.0/_locales/de/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `_locales/de/messages.json` |
| Byte size | `47410` |
| SHA-256 | `a949c1c15339810df6e065bf2ba6b45fa77bac3118ce7655b47cdcf13d0c53de` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 105 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 58 | Open related module: 05-storage-sync-import-export |
| security_privacy_isolation | 56 | Open related module: 06-network-permissions-security |
| script_matching_and_scheduling | 53 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| mv3_offscreen_userScripts | 32 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| editor_lint_format | 30 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| userscript_metadata | 24 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| extension_manifest_and_permissions | 20 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| network_cookies_downloads | 17 | Open related module: 06-network-permissions-security |
| gm_api_runtime | 3 | Open related module: 03-execution-sandbox-gm-api |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| content_page_bridge | 1 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |

Top identifier-like terms: message:516, Userscript:69, content:63, placeholders:45, name:38, Tampermonkey:36, werden:28, Userscripte:25, wird:23, wurde:22, Userscripts:21, nicht:19.

Browser API vocabulary mentions: runtime:2, tabs:5, storage:1, cookies:1, downloads:1, commands:1, action:4, permissions:3.

GM/API compatibility vocabulary mentions: GM_xmlhttpRequest:2, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
