# Source Note: `violentmonkey-2.41.0/options/index.html`

## Readable role

Product UI: dashboard, popup, options, settings, dialogs, script list, editor launch, and user-facing permission decisions.

## File facts

| Fact | Value |
| --- | --- |
| Project | `violentmonkey-2.41.0` |
| Relative path | `options/index.html` |
| Byte size | `332` |
| SHA-256 | `78719cacfe5e5f0ac58930652c5bc8d7a53d4d1417ccddc95da19657cc8e11ac` |
| Readable pattern name | `UserFacingScriptManagementViewModel` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 2 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| editor_lint_format | 1 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |

Top identifier-like terms: script:6, scale:3, meta:2, title:2, width:2, options:2, index:2, DOCTYPE:1, html:1, charset:1, Violentmonkey:1, name:1.

Browser API vocabulary mentions: none.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
interface DashboardViewState {
  searchQuery: string;
  selectedTagNames: string[];
  visibleScripts: ScriptListItemViewModel[];
  selectedScriptId?: ScriptIdentifier;
  editorDirtyState: 'clean' | 'dirty' | 'saving' | 'conflict';
  permissionPrompts: PermissionPromptViewModel[];
  importExportProgress?: TransferProgressViewModel;
  activeToastMessages: ToastViewModel[];
}

function buildScriptListItemViewModel(scriptRecord: StoredUserscriptRecord): ScriptListItemViewModel {
  return {
    id: scriptRecord.id,
    title: scriptRecord.metadata.scriptName,
    subtitle: scriptRecord.metadata.description ?? scriptRecord.metadata.namespace,
    enabled: scriptRecord.enabled,
    version: scriptRecord.metadata.version,
    updateStatus: deriveUpdateBadge(scriptRecord),
    warningCount: countMetadataWarnings(scriptRecord.metadata),
    lastRunStatus: scriptRecord.lastRunStatus ?? 'not-run-yet',
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
