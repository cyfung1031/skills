# Source Note: `tampermonkey-5.5.0/_locales/pt_PT/messages.json`

## Readable role

Localization catalog: names every user-facing concept and exposes UI areas that must stay consistent.

## File facts

| Fact | Value |
| --- | --- |
| Project | `tampermonkey-5.5.0` |
| Relative path | `_locales/pt_PT/messages.json` |
| Byte size | `54686` |
| SHA-256 | `e0ad0d8de3827a8e433e35d618ccbce8947dad635aca5b6245c21c8fd6d9bc6a` |
| Readable pattern name | `GrantGatedUserscriptApiBridge` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 102 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| security_privacy_isolation | 56 | Open related module: 06-network-permissions-security |
| storage_sync_backup | 49 | Open related module: 05-storage-sync-import-export |
| script_matching_and_scheduling | 46 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| mv3_offscreen_userScripts | 33 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| editor_lint_format | 24 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| extension_manifest_and_permissions | 20 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| userscript_metadata | 20 | Open related module: 02-userscript-lifecycle / 08-metadata-linting |
| network_cookies_downloads | 17 | Open related module: 06-network-permissions-security |
| content_page_bridge | 2 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| gm_api_runtime | 2 | Open related module: 03-execution-sandbox-gm-api |
| background_service_worker_or_event_page | 1 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |

Top identifier-like terms: message:694, content:72, script:60, para:56, placeholders:54, scripts:45, name:38, Tampermonkey:36, atualiza:18, description:18, Este:17, number:16.

Browser API vocabulary mentions: runtime:2, tabs:5, storage:1, cookies:3, downloads:1, commands:1, action:4, permissions:3.

GM/API compatibility vocabulary mentions: GM_xmlhttpRequest:1, unsafeWindow:1.

## Human-readable implementation model


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
