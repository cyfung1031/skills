# Source Note: `scriptcat-1.3.2/src/editor.worker.js`

## Readable role

Editor/linting toolchain: code editing, syntax services, metadata linting, formatting, workers, and validation feedback.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/editor.worker.js` |
| Byte size | `300085` |
| SHA-256 | `e35fec706bbf4b50c7e43f7ed9b0afc603cc2c2b13d9405d19269a144c17cfd8` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 259 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| storage_sync_backup | 111 | Open related module: 05-storage-sync-import-export |
| editor_lint_format | 106 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| script_matching_and_scheduling | 62 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| network_cookies_downloads | 22 | Open related module: 06-network-permissions-security |
| i18n_localization | 17 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| content_page_bridge | 9 | Open related module: 03-execution-sandbox-gm-api / 04-messaging-offscreen-ports |
| security_privacy_isolation | 8 | Open related module: 06-network-permissions-security |
| extension_manifest_and_permissions | 7 | Open related module: 01-extension-architecture / 06-network-permissions-security |

Top identifier-like terms: this:2115, return:1087, length:500, function:303, startLineNumber:216, null:166, static:166, charCodeAt:163, void:144, class:138, constructor:124, Math:111.

Browser API vocabulary mentions: action:5.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
