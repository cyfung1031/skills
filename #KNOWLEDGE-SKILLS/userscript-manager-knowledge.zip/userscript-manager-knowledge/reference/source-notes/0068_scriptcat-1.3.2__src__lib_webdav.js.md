# Source Note: `scriptcat-1.3.2/src/lib_webdav.js`

## Readable role

Vendored dependency: editor, linter, diffing, parsing, cryptography, DOM sanitization, storage, network, or UI framework support.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `src/lib_webdav.js` |
| Byte size | `103482` |
| SHA-256 | `a66e7c4d8ab1255d3469e6a12a3df75fca75c2ddf9e16e28be792814174bfceb` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| dashboard_popup_options_ui | 148 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| script_matching_and_scheduling | 54 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |
| network_cookies_downloads | 49 | Open related module: 06-network-permissions-security |
| storage_sync_backup | 18 | Open related module: 05-storage-sync-import-export |
| security_privacy_isolation | 10 | Open related module: 06-network-permissions-security |
| extension_manifest_and_permissions | 8 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| editor_lint_format | 2 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |

Top identifier-like terms: this:722, return:582, function:382, length:357, arguments:259, void:130, options:118, typeof:107, throw:91, else:84, push:73, null:67.

Browser API vocabulary mentions: action:1.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
