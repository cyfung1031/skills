# Source Note: `scriptcat-1.3.2/manifest.json`

## Readable role

Extension manifest: declares runtime model, permissions, host scope, entry points, commands, and installation surface.

## File facts

| Fact | Value |
| --- | --- |
| Project | `scriptcat-1.3.2` |
| Relative path | `manifest.json` |
| Byte size | `895` |
| SHA-256 | `ecd89b32d9911851a575f159a5e378bea8c427286482804ddaec62c5db7251b9` |
| Readable pattern name | `PermissionCheckedNetworkRequestGateway` |

## Extracted source signals

| Detected domain | Mentions | Where to learn more |
| --- | --- | --- |
| extension_manifest_and_permissions | 13 | Open related module: 01-extension-architecture / 06-network-permissions-security |
| dashboard_popup_options_ui | 9 | Open related module: 07-dashboard-editor-uiux / 12-userscript-manager-uiux-design |
| background_service_worker_or_event_page | 6 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| security_privacy_isolation | 6 | Open related module: 06-network-permissions-security |
| mv3_offscreen_userScripts | 4 | Open related module: 01-extension-architecture / 04-messaging-offscreen-ports |
| network_cookies_downloads | 3 | Open related module: 06-network-permissions-security |
| editor_lint_format | 3 | Open related module: 07-dashboard-editor-uiux / 08-metadata-linting |
| i18n_localization | 3 | Open related module: 07-dashboard-editor-uiux / reference/ui-localization-glossary.generated.md |
| script_matching_and_scheduling | 1 | Open related module: 02-userscript-lifecycle / 09-debugging-issue-fix |

Top identifier-like terms: html:4, service_worker:3, background:2, assets:2, logo:2, userScripts:2, all_urls:2, sandbox:2, manifest_version:1, name:1, __MSG_scriptcat__:1, version:1.

Browser API vocabulary mentions: tabs:1, storage:1, webNavigation:1, webRequest:1, contextMenus:1, notifications:1, cookies:1, alarms:1, declarativeNetRequest:1, scripting:1, userScripts:2, offscreen:1, downloads:1, action:1, permissions:3.

GM/API compatibility vocabulary mentions: none.

## Human-readable implementation model


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


## Review checklist for this file

- Identify which runtime context owns this file: manifest, background, content, page, offscreen, UI, editor, worker, locale, style, or dependency.
- Check whether the file crosses a privilege boundary. If yes, require explicit script ID, tab ID, frame ID, URL, grant, and permission decision.
- Check whether user-visible text or UI state is affected. If yes, update localization and diagnostics.
- Check whether this file participates in installation, update, import/export, or deletion. If yes, preserve recoverability.
- Check whether MV3 service-worker suspension can interrupt its work. If yes, avoid in-memory-only state.

## Debug questions

- What user-visible symptom would point to this file?
- What upstream context must be valid before this file can work?
- What downstream response or UI state proves the file completed its job?
- What log fields would make failures searchable?
- Which module should an agent open next if this file is suspected?
