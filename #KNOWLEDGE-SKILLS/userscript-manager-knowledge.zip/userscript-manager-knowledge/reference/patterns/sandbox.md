# Sandbox Patterns

Readable coding patterns for the `sandbox` domain.


## Implement pattern

```ts
interface SandboxImplementPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function implementSandboxChange(plan: SandboxImplementPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'implement',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `implement`. Keep names descriptive, preserve context, and make the result reviewable.


## Review pattern

```ts
interface SandboxReviewPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function reviewSandboxChange(plan: SandboxReviewPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'review',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `review`. Keep names descriptive, preserve context, and make the result reviewable.


## Debug pattern

```ts
interface SandboxDebugPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function debugSandboxChange(plan: SandboxDebugPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'debug',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `debug`. Keep names descriptive, preserve context, and make the result reviewable.


## Refactor pattern

```ts
interface SandboxRefactorPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function refactorSandboxChange(plan: SandboxRefactorPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'refactor',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `refactor`. Keep names descriptive, preserve context, and make the result reviewable.


## Test pattern

```ts
interface SandboxTestPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function testSandboxChange(plan: SandboxTestPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'test',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `test`. Keep names descriptive, preserve context, and make the result reviewable.


## Document pattern

```ts
interface SandboxDocumentPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function documentSandboxChange(plan: SandboxDocumentPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'document',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `document`. Keep names descriptive, preserve context, and make the result reviewable.


## Migrate pattern

```ts
interface SandboxMigratePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function migrateSandboxChange(plan: SandboxMigratePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'migrate',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `migrate`. Keep names descriptive, preserve context, and make the result reviewable.


## Harden pattern

```ts
interface SandboxHardenPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function hardenSandboxChange(plan: SandboxHardenPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'harden',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `harden`. Keep names descriptive, preserve context, and make the result reviewable.


## Profile pattern

```ts
interface SandboxProfilePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function profileSandboxChange(plan: SandboxProfilePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'profile',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `profile`. Keep names descriptive, preserve context, and make the result reviewable.


## Localize pattern

```ts
interface SandboxLocalizePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function localizeSandboxChange(plan: SandboxLocalizePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'sandbox',
    taskName: 'localize',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `sandbox` and the requested action is `localize`. Keep names descriptive, preserve context, and make the result reviewable.
