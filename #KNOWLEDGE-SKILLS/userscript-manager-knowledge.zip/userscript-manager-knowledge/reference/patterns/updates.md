# Updates Patterns

Readable coding patterns for the `updates` domain.


## Implement pattern

```ts
interface UpdatesImplementPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function implementUpdatesChange(plan: UpdatesImplementPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'implement',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `implement`. Keep names descriptive, preserve context, and make the result reviewable.


## Review pattern

```ts
interface UpdatesReviewPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function reviewUpdatesChange(plan: UpdatesReviewPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'review',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `review`. Keep names descriptive, preserve context, and make the result reviewable.


## Debug pattern

```ts
interface UpdatesDebugPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function debugUpdatesChange(plan: UpdatesDebugPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'debug',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `debug`. Keep names descriptive, preserve context, and make the result reviewable.


## Refactor pattern

```ts
interface UpdatesRefactorPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function refactorUpdatesChange(plan: UpdatesRefactorPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'refactor',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `refactor`. Keep names descriptive, preserve context, and make the result reviewable.


## Test pattern

```ts
interface UpdatesTestPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function testUpdatesChange(plan: UpdatesTestPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'test',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `test`. Keep names descriptive, preserve context, and make the result reviewable.


## Document pattern

```ts
interface UpdatesDocumentPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function documentUpdatesChange(plan: UpdatesDocumentPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'document',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `document`. Keep names descriptive, preserve context, and make the result reviewable.


## Migrate pattern

```ts
interface UpdatesMigratePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function migrateUpdatesChange(plan: UpdatesMigratePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'migrate',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `migrate`. Keep names descriptive, preserve context, and make the result reviewable.


## Harden pattern

```ts
interface UpdatesHardenPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function hardenUpdatesChange(plan: UpdatesHardenPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'harden',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `harden`. Keep names descriptive, preserve context, and make the result reviewable.


## Profile pattern

```ts
interface UpdatesProfilePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function profileUpdatesChange(plan: UpdatesProfilePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'profile',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `profile`. Keep names descriptive, preserve context, and make the result reviewable.


## Localize pattern

```ts
interface UpdatesLocalizePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function localizeUpdatesChange(plan: UpdatesLocalizePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'updates',
    taskName: 'localize',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `updates` and the requested action is `localize`. Keep names descriptive, preserve context, and make the result reviewable.
