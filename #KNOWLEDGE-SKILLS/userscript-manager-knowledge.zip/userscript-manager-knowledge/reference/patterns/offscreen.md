# Offscreen Patterns

Readable coding patterns for the `offscreen` domain.


## Implement pattern

```ts
interface OffscreenImplementPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function implementOffscreenChange(plan: OffscreenImplementPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'implement',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `implement`. Keep names descriptive, preserve context, and make the result reviewable.


## Review pattern

```ts
interface OffscreenReviewPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function reviewOffscreenChange(plan: OffscreenReviewPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'review',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `review`. Keep names descriptive, preserve context, and make the result reviewable.


## Debug pattern

```ts
interface OffscreenDebugPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function debugOffscreenChange(plan: OffscreenDebugPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'debug',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `debug`. Keep names descriptive, preserve context, and make the result reviewable.


## Refactor pattern

```ts
interface OffscreenRefactorPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function refactorOffscreenChange(plan: OffscreenRefactorPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'refactor',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `refactor`. Keep names descriptive, preserve context, and make the result reviewable.


## Test pattern

```ts
interface OffscreenTestPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function testOffscreenChange(plan: OffscreenTestPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'test',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `test`. Keep names descriptive, preserve context, and make the result reviewable.


## Document pattern

```ts
interface OffscreenDocumentPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function documentOffscreenChange(plan: OffscreenDocumentPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'document',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `document`. Keep names descriptive, preserve context, and make the result reviewable.


## Migrate pattern

```ts
interface OffscreenMigratePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function migrateOffscreenChange(plan: OffscreenMigratePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'migrate',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `migrate`. Keep names descriptive, preserve context, and make the result reviewable.


## Harden pattern

```ts
interface OffscreenHardenPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function hardenOffscreenChange(plan: OffscreenHardenPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'harden',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `harden`. Keep names descriptive, preserve context, and make the result reviewable.


## Profile pattern

```ts
interface OffscreenProfilePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function profileOffscreenChange(plan: OffscreenProfilePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'profile',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `profile`. Keep names descriptive, preserve context, and make the result reviewable.


## Localize pattern

```ts
interface OffscreenLocalizePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function localizeOffscreenChange(plan: OffscreenLocalizePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'offscreen',
    taskName: 'localize',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `offscreen` and the requested action is `localize`. Keep names descriptive, preserve context, and make the result reviewable.
