# Editor Patterns

Readable coding patterns for the `editor` domain.


## Implement pattern

```ts
interface EditorImplementPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function implementEditorChange(plan: EditorImplementPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'implement',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `implement`. Keep names descriptive, preserve context, and make the result reviewable.


## Review pattern

```ts
interface EditorReviewPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function reviewEditorChange(plan: EditorReviewPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'review',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `review`. Keep names descriptive, preserve context, and make the result reviewable.


## Debug pattern

```ts
interface EditorDebugPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function debugEditorChange(plan: EditorDebugPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'debug',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `debug`. Keep names descriptive, preserve context, and make the result reviewable.


## Refactor pattern

```ts
interface EditorRefactorPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function refactorEditorChange(plan: EditorRefactorPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'refactor',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `refactor`. Keep names descriptive, preserve context, and make the result reviewable.


## Test pattern

```ts
interface EditorTestPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function testEditorChange(plan: EditorTestPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'test',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `test`. Keep names descriptive, preserve context, and make the result reviewable.


## Document pattern

```ts
interface EditorDocumentPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function documentEditorChange(plan: EditorDocumentPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'document',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `document`. Keep names descriptive, preserve context, and make the result reviewable.


## Migrate pattern

```ts
interface EditorMigratePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function migrateEditorChange(plan: EditorMigratePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'migrate',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `migrate`. Keep names descriptive, preserve context, and make the result reviewable.


## Harden pattern

```ts
interface EditorHardenPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function hardenEditorChange(plan: EditorHardenPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'harden',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `harden`. Keep names descriptive, preserve context, and make the result reviewable.


## Profile pattern

```ts
interface EditorProfilePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function profileEditorChange(plan: EditorProfilePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'profile',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `profile`. Keep names descriptive, preserve context, and make the result reviewable.


## Localize pattern

```ts
interface EditorLocalizePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function localizeEditorChange(plan: EditorLocalizePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'editor',
    taskName: 'localize',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `editor` and the requested action is `localize`. Keep names descriptive, preserve context, and make the result reviewable.
