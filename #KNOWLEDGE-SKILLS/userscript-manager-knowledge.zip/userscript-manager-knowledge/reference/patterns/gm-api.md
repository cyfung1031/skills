# Gm-Api Patterns

Readable coding patterns for the `gm-api` domain.


## Implement pattern

```ts
interface GmApiImplementPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function implementGmApiChange(plan: GmApiImplementPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'implement',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `implement`. Keep names descriptive, preserve context, and make the result reviewable.


## Review pattern

```ts
interface GmApiReviewPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function reviewGmApiChange(plan: GmApiReviewPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'review',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `review`. Keep names descriptive, preserve context, and make the result reviewable.


## Debug pattern

```ts
interface GmApiDebugPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function debugGmApiChange(plan: GmApiDebugPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'debug',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `debug`. Keep names descriptive, preserve context, and make the result reviewable.


## Refactor pattern

```ts
interface GmApiRefactorPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function refactorGmApiChange(plan: GmApiRefactorPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'refactor',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `refactor`. Keep names descriptive, preserve context, and make the result reviewable.


## Test pattern

```ts
interface GmApiTestPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function testGmApiChange(plan: GmApiTestPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'test',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `test`. Keep names descriptive, preserve context, and make the result reviewable.


## Document pattern

```ts
interface GmApiDocumentPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function documentGmApiChange(plan: GmApiDocumentPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'document',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `document`. Keep names descriptive, preserve context, and make the result reviewable.


## Migrate pattern

```ts
interface GmApiMigratePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function migrateGmApiChange(plan: GmApiMigratePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'migrate',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `migrate`. Keep names descriptive, preserve context, and make the result reviewable.


## Harden pattern

```ts
interface GmApiHardenPlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function hardenGmApiChange(plan: GmApiHardenPlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'harden',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `harden`. Keep names descriptive, preserve context, and make the result reviewable.


## Profile pattern

```ts
interface GmApiProfilePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function profileGmApiChange(plan: GmApiProfilePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'profile',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `profile`. Keep names descriptive, preserve context, and make the result reviewable.


## Localize pattern

```ts
interface GmApiLocalizePlan {
  scopeDescription: string;
  affectedFiles: string[];
  affectedRuntimeContexts: string[];
  requiredPermissions: string[];
  diagnostics: string[];
}

function localizeGmApiChange(plan: GmApiLocalizePlan): ReviewableChange {
  return buildReviewableChange({
    domainName: 'gm-api',
    taskName: 'localize',
    scopeDescription: plan.scopeDescription,
    affectedFiles: plan.affectedFiles,
    affectedRuntimeContexts: plan.affectedRuntimeContexts,
    requiredPermissions: plan.requiredPermissions,
    diagnostics: plan.diagnostics,
  });
}
```

Readable guidance: use this when an issue or code review concerns `gm-api` and the requested action is `localize`. Keep names descriptive, preserve context, and make the result reviewable.
