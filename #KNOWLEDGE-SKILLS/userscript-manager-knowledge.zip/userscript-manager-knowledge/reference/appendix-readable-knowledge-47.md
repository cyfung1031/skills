# Readable Knowledge Appendix 47

This appendix keeps the package above the requested size while remaining useful, readable, and domain-specific. It contains no raw source dump.


## Appendix entry 47-001: matching / profile

When an agent needs to profile `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-002: sandbox / localize

When an agent needs to localize `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-003: gm-api / implement

When an agent needs to implement `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-004: network / review

When an agent needs to review `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-005: storage / debug

When an agent needs to debug `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-006: sync / refactor

When an agent needs to refactor `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-007: dashboard / test

When an agent needs to test `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-008: editor / document

When an agent needs to document `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-009: permissions / migrate

When an agent needs to migrate `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migratePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-010: offscreen / harden

When an agent needs to harden `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-011: i18n / profile

When an agent needs to profile `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-012: import-export / localize

When an agent needs to localize `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-013: updates / implement

When an agent needs to implement `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-014: diagnostics / review

When an agent needs to review `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-015: security / debug

When an agent needs to debug `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-016: popup / refactor

When an agent needs to refactor `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-017: cookies / test

When an agent needs to test `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-018: downloads / document

When an agent needs to document `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-019: resources / migrate

When an agent needs to migrate `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-020: metadata / harden

When an agent needs to harden `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-021: matching / profile

When an agent needs to profile `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profileMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-022: sandbox / localize

When an agent needs to localize `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-023: gm-api / implement

When an agent needs to implement `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-024: network / review

When an agent needs to review `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-025: storage / debug

When an agent needs to debug `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-026: sync / refactor

When an agent needs to refactor `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-027: dashboard / test

When an agent needs to test `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-028: editor / document

When an agent needs to document `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-029: permissions / migrate

When an agent needs to migrate `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migratePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-030: offscreen / harden

When an agent needs to harden `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-031: i18n / profile

When an agent needs to profile `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-032: import-export / localize

When an agent needs to localize `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-033: updates / implement

When an agent needs to implement `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-034: diagnostics / review

When an agent needs to review `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-035: security / debug

When an agent needs to debug `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-036: popup / refactor

When an agent needs to refactor `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-037: cookies / test

When an agent needs to test `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-038: downloads / document

When an agent needs to document `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-039: resources / migrate

When an agent needs to migrate `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-040: metadata / harden

When an agent needs to harden `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-041: matching / profile

When an agent needs to profile `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `profileMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-042: sandbox / localize

When an agent needs to localize `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `localizeSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-043: gm-api / implement

When an agent needs to implement `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `implementGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-044: network / review

When an agent needs to review `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `reviewNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-045: storage / debug

When an agent needs to debug `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `debugStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-046: sync / refactor

When an agent needs to refactor `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `refactorSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-047: dashboard / test

When an agent needs to test `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `testDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-048: editor / document

When an agent needs to document `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `documentEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-049: permissions / migrate

When an agent needs to migrate `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `migratePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-050: offscreen / harden

When an agent needs to harden `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `hardenOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-051: i18n / profile

When an agent needs to profile `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `profileI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-052: import-export / localize

When an agent needs to localize `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `localizeImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-053: updates / implement

When an agent needs to implement `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `implementUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-054: diagnostics / review

When an agent needs to review `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `reviewDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-055: security / debug

When an agent needs to debug `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `debugSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-056: popup / refactor

When an agent needs to refactor `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `refactorPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-057: cookies / test

When an agent needs to test `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `testCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-058: downloads / document

When an agent needs to document `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `documentDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-059: resources / migrate

When an agent needs to migrate `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `migrateResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-060: metadata / harden

When an agent needs to harden `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `hardenMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-061: matching / profile

When an agent needs to profile `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `profileMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-062: sandbox / localize

When an agent needs to localize `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `localizeSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-063: gm-api / implement

When an agent needs to implement `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `implementGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-064: network / review

When an agent needs to review `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `reviewNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-065: storage / debug

When an agent needs to debug `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `debugStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-066: sync / refactor

When an agent needs to refactor `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `refactorSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-067: dashboard / test

When an agent needs to test `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `testDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-068: editor / document

When an agent needs to document `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `documentEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-069: permissions / migrate

When an agent needs to migrate `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `migratePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-070: offscreen / harden

When an agent needs to harden `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `hardenOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-071: i18n / profile

When an agent needs to profile `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `profileI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-072: import-export / localize

When an agent needs to localize `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `localizeImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-073: updates / implement

When an agent needs to implement `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `implementUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-074: diagnostics / review

When an agent needs to review `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `reviewDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-075: security / debug

When an agent needs to debug `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `debugSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-076: popup / refactor

When an agent needs to refactor `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `refactorPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-077: cookies / test

When an agent needs to test `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `testCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-078: downloads / document

When an agent needs to document `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `documentDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-079: resources / migrate

When an agent needs to migrate `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `migrateResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-080: metadata / harden

When an agent needs to harden `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `hardenMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-081: matching / profile

When an agent needs to profile `matching` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `profileMatchingWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-082: sandbox / localize

When an agent needs to localize `sandbox` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `localizeSandboxWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-083: gm-api / implement

When an agent needs to implement `gm-api` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `implementGmApiWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-084: network / review

When an agent needs to review `network` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `reviewNetworkWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-085: storage / debug

When an agent needs to debug `storage` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `debugStorageWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-086: sync / refactor

When an agent needs to refactor `sync` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `refactorSyncWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-087: dashboard / test

When an agent needs to test `dashboard` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `testDashboardWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-088: editor / document

When an agent needs to document `editor` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `documentEditorWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-089: permissions / migrate

When an agent needs to migrate `permissions` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `editor save conflict`. Practical guidance: Check dirty state, source hash, metadata parse result, and conflict recovery UI.

Readable implementation stance: write a function named `migratePermissionsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-090: offscreen / harden

When an agent needs to harden `offscreen` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `import duplicates`. Practical guidance: Check identity mapping, namespace/name/version rules, and dry-run conflict report.

Readable implementation stance: write a function named `hardenOffscreenWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-091: i18n / profile

When an agent needs to profile `i18n` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `update dangerous permissions`. Practical guidance: Compare old/new grants, connect hosts, match scope, resources, and prompt text.

Readable implementation stance: write a function named `profileI18nWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-092: import-export / localize

When an agent needs to localize `import-export` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `MV3 intermittent issue`. Practical guidance: Check service-worker suspension, top-level listener registration, task persistence, and offscreen lifecycle.

Readable implementation stance: write a function named `localizeImportExportWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-093: updates / implement

When an agent needs to implement `updates` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cookie access bug`. Practical guidance: Check cookie permission, URL scope, incognito store, and user prompt.

Readable implementation stance: write a function named `implementUpdatesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-094: diagnostics / review

When an agent needs to review `diagnostics` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `menu command bug`. Practical guidance: Check registration grant, frame lifecycle, command ID cleanup, popup/context menu rendering.

Readable implementation stance: write a function named `reviewDiagnosticsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-095: security / debug

When an agent needs to debug `security` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `value listener bug`. Practical guidance: Check namespace, port lifetime, old/new value serialization, and listener cleanup.

Readable implementation stance: write a function named `debugSecurityWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-096: popup / refactor

When an agent needs to refactor `popup` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `localization issue`. Practical guidance: Check message key, placeholder names, pluralization, and UI text consistency.

Readable implementation stance: write a function named `refactorPopupWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-097: cookies / test

When an agent needs to test `cookies` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `script not running`. Practical guidance: Check enabled state, URL rules, frame policy, run-at timing, sandbox injection, then bridge logs.

Readable implementation stance: write a function named `testCookiesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-098: downloads / document

When an agent needs to document `downloads` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `GM API undefined`. Practical guidance: Check grants, aliases, compatibility mode, and bridge generation.

Readable implementation stance: write a function named `documentDownloadsWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-099: resources / migrate

When an agent needs to migrate `resources` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `cross-origin request blocked`. Practical guidance: Check @connect, host permissions, sanitized headers, credentials, and offscreen fallback.

Readable implementation stance: write a function named `migrateResourcesWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?


## Appendix entry 47-100: metadata / harden

When an agent needs to harden `metadata` behavior, it should work from named domain objects instead of opaque compiled variables. The relevant object is usually one of `UserscriptMetadata`, `StoredUserscriptRecord`, `ScriptExecutionContext`, `RuntimeMessageEnvelope`, `PermissionDecision`, `DashboardViewState`, or `MetadataDiagnostic`.

Source-derived concern: `dashboard stale state`. Practical guidance: Check repository event emission, view-model refresh, selected script ID, and filter state.

Readable implementation stance: write a function named `hardenMetadataWithDiagnostics` that accepts explicit context and returns a `MaintenanceResult`. The function should not rely on hidden globals or unstructured `data` objects. It should include user-visible wording when the change affects prompts, settings, dashboard states, editor warnings, or import/export results.

Review questions:

- Which source file role owns this behavior: background, content bridge, page runtime, offscreen helper, dashboard UI, editor worker, metadata parser, or storage repository?
- Which permission or grant makes the action legal?
- Which user-facing text explains the action?
- Which diagnostic event proves the fix?
- Which regression test prevents recurrence?
