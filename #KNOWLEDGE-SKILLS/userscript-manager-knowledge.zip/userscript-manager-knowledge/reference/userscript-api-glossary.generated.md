# Userscript API, Metadata, and Browser API Glossary

This glossary is source-derived but rewritten for readability. Counts are approximate text mentions across inspected bundles and are used only as search hints.

## GM and userscript APIs

| API/grant vocabulary | Mentions | Category | Agent rule |
| --- | --- | --- | --- |
| GM.download | 12 | network | Expose only when the matching grant or compatibility mode allows it. |
| GM.fetch | 0 | network | Expose only when the matching grant or compatibility mode allows it. |
| GM.getValue | 27 | storage | Expose only when the matching grant or compatibility mode allows it. |
| GM.setValue | 31 | storage | Expose only when the matching grant or compatibility mode allows it. |
| GM.xmlHttpRequest | 17 | network | Expose only when the matching grant or compatibility mode allows it. |
| GM_addElement | 33 | ui | Expose only when the matching grant or compatibility mode allows it. |
| GM_addStyle | 37 | ui | Expose only when the matching grant or compatibility mode allows it. |
| GM_deleteValue | 44 | storage | Expose only when the matching grant or compatibility mode allows it. |
| GM_getResourceText | 31 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_getResourceURL | 28 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_getTab | 60 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_getTabs | 28 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_getValue | 50 | storage | Expose only when the matching grant or compatibility mode allows it. |
| GM_info | 32 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_listValues | 22 | storage | Expose only when the matching grant or compatibility mode allows it. |
| GM_log | 35 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_notification | 61 | ui | Expose only when the matching grant or compatibility mode allows it. |
| GM_openInTab | 51 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_registerMenuCommand | 49 | ui | Expose only when the matching grant or compatibility mode allows it. |
| GM_removeValueChangeListener | 25 | storage | Expose only when the matching grant or compatibility mode allows it. |
| GM_saveTab | 28 | runtime | Expose only when the matching grant or compatibility mode allows it. |
| GM_setClipboard | 34 | ui | Expose only when the matching grant or compatibility mode allows it. |
| GM_setValue | 70 | storage | Expose only when the matching grant or compatibility mode allows it. |
| GM_xmlhttpRequest | 74 | network | Expose only when the matching grant or compatibility mode allows it. |
| unsafeWindow | 88 | runtime | Expose only when the matching grant or compatibility mode allows it. |

## Metadata directives

| Directive | Mentions | Kind | Agent rule |
| --- | --- | --- | --- |
| @name | 182 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @namespace | 92 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @version | 23 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @description | 10 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @author | 12 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @match | 179 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @include | 191 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @exclude | 115 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @exclude-match | 30 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @require | 113 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @resource | 49 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @grant | 120 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @connect | 163 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @run-at | 50 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @run-in | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @sandbox | 30 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @noframes | 1 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @unwrap | 1 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @icon | 6 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @iconURL | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @icon64 | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @icon64URL | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @defaulticon | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @downloadURL | 35 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @updateURL | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @homepage | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @homepageURL | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @supportURL | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @website | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @license | 2 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @copyright | 2 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @antifeature | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @tag | 47 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @compatible | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |
| @incompatible | 0 | metadata directive | Parse, normalize, validate, and show relevant warnings. |

## Browser extension APIs and permissions

| Vocabulary | Mentions | Kind | Agent rule |
| --- | --- | --- | --- |
| action | 2647 | browser/extension API | Requires manifest permission and context-aware use. |
| alarms | 33 | browser/extension API | Requires manifest permission and context-aware use. |
| commands | 193 | browser/extension API | Requires manifest permission and context-aware use. |
| contextMenus | 23 | browser/extension API | Requires manifest permission and context-aware use. |
| cookies | 199 | browser/extension API | Requires manifest permission and context-aware use. |
| declarativeNetRequest | 37 | browser/extension API | Requires manifest permission and context-aware use. |
| downloads | 74 | browser/extension API | Requires manifest permission and context-aware use. |
| idle | 54 | browser/extension API | Requires manifest permission and context-aware use. |
| notifications | 33 | browser/extension API | Requires manifest permission and context-aware use. |
| offscreen | 95 | browser/extension API | Requires manifest permission and context-aware use. |
| permissions | 145 | browser/extension API | Requires manifest permission and context-aware use. |
| runtime | 825 | browser/extension API | Requires manifest permission and context-aware use. |
| scripting | 28 | browser/extension API | Requires manifest permission and context-aware use. |
| storage | 579 | browser/extension API | Requires manifest permission and context-aware use. |
| tabs | 1048 | browser/extension API | Requires manifest permission and context-aware use. |
| userScripts | 63 | browser/extension API | Requires manifest permission and context-aware use. |
| webNavigation | 40 | browser/extension API | Requires manifest permission and context-aware use. |
| webRequest | 114 | browser/extension API | Requires manifest permission and context-aware use. |
