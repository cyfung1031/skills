# Readable Implementation Patterns

These patterns are universal, named, and written for agents/humans. They are not copied from bundled source.

## MetadataParser

Parse, normalize, validate, and report userscript metadata.


```ts
function parseUserscriptMetadataBlock(sourceCode: string): UserscriptMetadataParseResult {
  const headerBlock = extractDelimitedMetadataHeader(sourceCode);
  const parsedDirectives = parseMetadataDirectives(headerBlock.lines);
  const normalizedRules = normalizeMatchIncludeExcludeRules(parsedDirectives);
  const grantedApis = resolveGrantList(parsedDirectives.grantDirectives);
  const allowedConnectHosts = resolveConnectPermissionRules(parsedDirectives.connectDirectives);

  return {
    metadata: {
      scriptName: requireDirective(parsedDirectives, 'name'),
      namespace: optionalDirective(parsedDirectives, 'namespace') ?? 'user-script',
      version: optionalDirective(parsedDirectives, 'version') ?? '0.0.0',
      description: optionalDirective(parsedDirectives, 'description'),
      matchRules: normalizedRules.matchRules,
      includeRules: normalizedRules.includeRules,
      excludeRules: normalizedRules.excludeRules,
      grantedApis,
      allowedConnectHosts,
      requiredResources: collectResourceReferences(parsedDirectives),
      requiredLibraries: collectRequiredLibraries(parsedDirectives),
      runAt: resolveRunAt(parsedDirectives),
      noFrames: hasBooleanDirective(parsedDirectives, 'noframes'),
      updateUrl: optionalDirective(parsedDirectives, 'updateURL'),
      downloadUrl: optionalDirective(parsedDirectives, 'downloadURL'),
    },
    warnings: buildMetadataWarnings(parsedDirectives),
    errors: buildMetadataErrors(parsedDirectives),
  };
}
```


### Review checklist

- Are input and output types explicit?
- Does the function name describe the domain action?
- Are permission, frame, and script identifiers preserved?
- Is the failure mode represented as data, not only console output?

## RunnableScriptSelector

Choose scripts for a frame URL with enabled state, frame policy, URL rules, and ordering.


```ts
function selectRunnableScriptsForFrame(
  installedScripts: StoredUserscriptRecord[],
  frameContext: BrowserFrameContext,
): RunnableUserscript[] {
  return installedScripts
    .filter(scriptRecord => scriptRecord.enabled)
    .filter(scriptRecord => frameMatchesFramePolicy(scriptRecord.metadata, frameContext))
    .filter(scriptRecord => urlMatchesScriptRules(scriptRecord.metadata, frameContext.pageUrl))
    .filter(scriptRecord => !urlIsExcludedByScriptRules(scriptRecord.metadata, frameContext.pageUrl))
    .map(scriptRecord => buildRunnableUserscript(scriptRecord, frameContext))
    .sort(compareScriptsByPositionAndInstallOrder);
}
```


### Review checklist

- Are input and output types explicit?
- Does the function name describe the domain action?
- Are permission, frame, and script identifiers preserved?
- Is the failure mode represented as data, not only console output?

## RuntimeMessageRouter

Route bridge messages through explicit command handlers and permission checks.


```ts
async function routeRuntimeMessage<Payload>(
  envelope: RuntimeMessageEnvelope<Payload>,
  services: UserscriptManagerServices,
): Promise<RuntimeMessageResponse> {
  assertKnownSender(envelope.senderContext);
  assertExpectedTarget(envelope.targetContext, 'background');
  assertCommandIsRegistered(envelope.commandName);

  const commandHandler = services.commandRegistry.get(envelope.commandName);
  const permissionDecision = await services.permissionService.authorizeCommand(envelope);
  if (permissionDecision.decision === 'deny') {
    return buildDeniedResponse(envelope, permissionDecision.reason);
  }

  const commandResult = await commandHandler.handle(envelope.payload, buildCommandContext(envelope));
  return buildSuccessfulResponse(envelope, commandResult);
}
```


### Review checklist

- Are input and output types explicit?
- Does the function name describe the domain action?
- Are permission, frame, and script identifiers preserved?
- Is the failure mode represented as data, not only console output?

## GrantGatedGmApiBridge

Expose only granted userscript APIs in the selected execution world.


```ts
function createGrantGatedGmApiBridge(context: ScriptExecutionContext): UserscriptGlobalApi {
  const grantedApis = context.grantedApis;
  return {
    GM_info: createReadonlyScriptInfo(context),
    GM_getValue: grantedApis.has('GM_getValue') ? getScriptValue : undefined,
    GM_setValue: grantedApis.has('GM_setValue') ? setScriptValue : undefined,
    GM_xmlhttpRequest: grantedApis.has('GM_xmlhttpRequest')
      ? requestThroughBackgroundNetworkGateway
      : undefined,
    GM_registerMenuCommand: grantedApis.has('GM_registerMenuCommand')
      ? registerScriptMenuCommand
      : undefined,
    unsafeWindow: createUnsafeWindowProxy(context),
  };
}
```


### Review checklist

- Are input and output types explicit?
- Does the function name describe the domain action?
- Are permission, frame, and script identifiers preserved?
- Is the failure mode represented as data, not only console output?

## NetworkPermissionGateway

Authorize and perform GM_xmlhttpRequest/fetch/download through background/offscreen.


```ts
async function requestThroughBackgroundNetworkGateway(
  request: UserscriptNetworkRequest,
  context: ScriptExecutionContext,
): Promise<UserscriptNetworkResponse> {
  const targetOrigin = getOriginForPermissionCheck(request.url);
  const connectDecision = evaluateConnectPermission(context.allowedConnectHosts, targetOrigin);
  if (connectDecision.decision !== 'allow') {
    throw new UserscriptPermissionError(connectDecision.reason);
  }

  const sanitizedHeaders = removeForbiddenAndSpoofedHeaders(request.headers);
  const transportRequest = buildBrowserCompatibleNetworkRequest(request, sanitizedHeaders);
  const response = await performRequestInBestAvailableContext(transportRequest);
  return convertBrowserResponseToUserscriptResponse(response, request.responseType);
}
```


### Review checklist

- Are input and output types explicit?
- Does the function name describe the domain action?
- Are permission, frame, and script identifiers preserved?
- Is the failure mode represented as data, not only console output?

## SafeScriptUpdater

Fetch, validate, compare, and atomically replace installed script source.


```ts
async function updateInstalledUserscript(
  scriptRecord: StoredUserscriptRecord,
  services: UserscriptManagerServices,
): Promise<ScriptUpdateResult> {
  const candidateSource = await services.updateFetcher.fetchCandidateSource(scriptRecord.metadata);
  const candidateMetadata = parseUserscriptMetadataBlock(candidateSource).metadata;
  assertUpdateBelongsToSameScript(scriptRecord.metadata, candidateMetadata);
  assertUpdateVersionIsNewerOrAllowed(scriptRecord.metadata.version, candidateMetadata.version);

  const requiredResources = await services.resourceCache.fetchResources(candidateMetadata);
  const migratedValueStore = await services.valueStore.prepareMigration(scriptRecord, candidateMetadata);
  return services.scriptRepository.replaceScriptSource({
    existingScriptId: scriptRecord.id,
    sourceCode: candidateSource,
    metadata: candidateMetadata,
    resources: requiredResources,
    migratedValueStore,
  });
}
```


### Review checklist

- Are input and output types explicit?
- Does the function name describe the domain action?
- Are permission, frame, and script identifiers preserved?
- Is the failure mode represented as data, not only console output?

## DashboardViewModel

Represent script list, editor, permission prompts, and long-running UI operations.


```ts
interface DashboardViewState {
  searchQuery: string;
  selectedTagNames: string[];
  visibleScripts: ScriptListItemViewModel[];
  selectedScriptId?: ScriptIdentifier;
  editorDirtyState: 'clean' | 'dirty' | 'saving' | 'conflict';
  permissionPrompts: PermissionPromptViewModel[];
  importExportProgress?: TransferProgressViewModel;
  activeToastMessages: ToastViewModel[];
}

function buildScriptListItemViewModel(scriptRecord: StoredUserscriptRecord): ScriptListItemViewModel {
  return {
    id: scriptRecord.id,
    title: scriptRecord.metadata.scriptName,
    subtitle: scriptRecord.metadata.description ?? scriptRecord.metadata.namespace,
    enabled: scriptRecord.enabled,
    version: scriptRecord.metadata.version,
    updateStatus: deriveUpdateBadge(scriptRecord),
    warningCount: countMetadataWarnings(scriptRecord.metadata),
    lastRunStatus: scriptRecord.lastRunStatus ?? 'not-run-yet',
  };
}
```


### Review checklist

- Are input and output types explicit?
- Does the function name describe the domain action?
- Are permission, frame, and script identifiers preserved?
- Is the failure mode represented as data, not only console output?


## MetadataImplementPlan

Purpose: implement the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementMetadataChange(plan: MetadataImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataReviewPlan

Purpose: review the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewMetadataChange(plan: MetadataReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataDebugPlan

Purpose: debug the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugMetadataChange(plan: MetadataDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataRefactorPlan

Purpose: refactor the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorMetadataChange(plan: MetadataRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataTestPlan

Purpose: test the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testMetadataChange(plan: MetadataTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataDocumentPlan

Purpose: document the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentMetadataChange(plan: MetadataDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataMigratePlan

Purpose: migrate the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateMetadataChange(plan: MetadataMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataHardenPlan

Purpose: harden the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenMetadataChange(plan: MetadataHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataProfilePlan

Purpose: profile the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileMetadataChange(plan: MetadataProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MetadataLocalizePlan

Purpose: localize the `metadata` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MetadataLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeMetadataChange(plan: MetadataLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `metadata` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingImplementPlan

Purpose: implement the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementMatchingChange(plan: MatchingImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingReviewPlan

Purpose: review the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewMatchingChange(plan: MatchingReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingDebugPlan

Purpose: debug the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugMatchingChange(plan: MatchingDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingRefactorPlan

Purpose: refactor the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorMatchingChange(plan: MatchingRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingTestPlan

Purpose: test the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testMatchingChange(plan: MatchingTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingDocumentPlan

Purpose: document the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentMatchingChange(plan: MatchingDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingMigratePlan

Purpose: migrate the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateMatchingChange(plan: MatchingMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingHardenPlan

Purpose: harden the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenMatchingChange(plan: MatchingHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingProfilePlan

Purpose: profile the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileMatchingChange(plan: MatchingProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## MatchingLocalizePlan

Purpose: localize the `matching` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface MatchingLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeMatchingChange(plan: MatchingLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `matching` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxImplementPlan

Purpose: implement the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementSandboxChange(plan: SandboxImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxReviewPlan

Purpose: review the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewSandboxChange(plan: SandboxReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxDebugPlan

Purpose: debug the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugSandboxChange(plan: SandboxDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxRefactorPlan

Purpose: refactor the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorSandboxChange(plan: SandboxRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxTestPlan

Purpose: test the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testSandboxChange(plan: SandboxTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxDocumentPlan

Purpose: document the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentSandboxChange(plan: SandboxDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxMigratePlan

Purpose: migrate the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateSandboxChange(plan: SandboxMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxHardenPlan

Purpose: harden the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenSandboxChange(plan: SandboxHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxProfilePlan

Purpose: profile the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileSandboxChange(plan: SandboxProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SandboxLocalizePlan

Purpose: localize the `sandbox` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SandboxLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeSandboxChange(plan: SandboxLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sandbox` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiImplementPlan

Purpose: implement the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementGmApiChange(plan: GmApiImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiReviewPlan

Purpose: review the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewGmApiChange(plan: GmApiReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiDebugPlan

Purpose: debug the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugGmApiChange(plan: GmApiDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiRefactorPlan

Purpose: refactor the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorGmApiChange(plan: GmApiRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiTestPlan

Purpose: test the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testGmApiChange(plan: GmApiTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiDocumentPlan

Purpose: document the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentGmApiChange(plan: GmApiDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiMigratePlan

Purpose: migrate the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateGmApiChange(plan: GmApiMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiHardenPlan

Purpose: harden the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenGmApiChange(plan: GmApiHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiProfilePlan

Purpose: profile the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileGmApiChange(plan: GmApiProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## GmApiLocalizePlan

Purpose: localize the `gm-api` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface GmApiLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeGmApiChange(plan: GmApiLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `gm-api` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkImplementPlan

Purpose: implement the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementNetworkChange(plan: NetworkImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkReviewPlan

Purpose: review the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewNetworkChange(plan: NetworkReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkDebugPlan

Purpose: debug the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugNetworkChange(plan: NetworkDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkRefactorPlan

Purpose: refactor the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorNetworkChange(plan: NetworkRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkTestPlan

Purpose: test the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testNetworkChange(plan: NetworkTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkDocumentPlan

Purpose: document the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentNetworkChange(plan: NetworkDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkMigratePlan

Purpose: migrate the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateNetworkChange(plan: NetworkMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkHardenPlan

Purpose: harden the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenNetworkChange(plan: NetworkHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkProfilePlan

Purpose: profile the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileNetworkChange(plan: NetworkProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## NetworkLocalizePlan

Purpose: localize the `network` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface NetworkLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeNetworkChange(plan: NetworkLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `network` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageImplementPlan

Purpose: implement the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementStorageChange(plan: StorageImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageReviewPlan

Purpose: review the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewStorageChange(plan: StorageReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageDebugPlan

Purpose: debug the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugStorageChange(plan: StorageDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageRefactorPlan

Purpose: refactor the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorStorageChange(plan: StorageRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageTestPlan

Purpose: test the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testStorageChange(plan: StorageTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageDocumentPlan

Purpose: document the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentStorageChange(plan: StorageDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageMigratePlan

Purpose: migrate the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateStorageChange(plan: StorageMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageHardenPlan

Purpose: harden the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenStorageChange(plan: StorageHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageProfilePlan

Purpose: profile the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileStorageChange(plan: StorageProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## StorageLocalizePlan

Purpose: localize the `storage` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface StorageLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeStorageChange(plan: StorageLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `storage` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncImplementPlan

Purpose: implement the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementSyncChange(plan: SyncImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncReviewPlan

Purpose: review the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewSyncChange(plan: SyncReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncDebugPlan

Purpose: debug the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugSyncChange(plan: SyncDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncRefactorPlan

Purpose: refactor the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorSyncChange(plan: SyncRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncTestPlan

Purpose: test the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testSyncChange(plan: SyncTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncDocumentPlan

Purpose: document the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentSyncChange(plan: SyncDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncMigratePlan

Purpose: migrate the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateSyncChange(plan: SyncMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncHardenPlan

Purpose: harden the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenSyncChange(plan: SyncHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncProfilePlan

Purpose: profile the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileSyncChange(plan: SyncProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SyncLocalizePlan

Purpose: localize the `sync` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SyncLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeSyncChange(plan: SyncLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `sync` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardImplementPlan

Purpose: implement the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementDashboardChange(plan: DashboardImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardReviewPlan

Purpose: review the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewDashboardChange(plan: DashboardReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardDebugPlan

Purpose: debug the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugDashboardChange(plan: DashboardDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardRefactorPlan

Purpose: refactor the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorDashboardChange(plan: DashboardRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardTestPlan

Purpose: test the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testDashboardChange(plan: DashboardTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardDocumentPlan

Purpose: document the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentDashboardChange(plan: DashboardDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardMigratePlan

Purpose: migrate the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateDashboardChange(plan: DashboardMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardHardenPlan

Purpose: harden the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenDashboardChange(plan: DashboardHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardProfilePlan

Purpose: profile the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileDashboardChange(plan: DashboardProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DashboardLocalizePlan

Purpose: localize the `dashboard` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DashboardLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeDashboardChange(plan: DashboardLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `dashboard` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorImplementPlan

Purpose: implement the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementEditorChange(plan: EditorImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorReviewPlan

Purpose: review the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewEditorChange(plan: EditorReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorDebugPlan

Purpose: debug the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugEditorChange(plan: EditorDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorRefactorPlan

Purpose: refactor the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorEditorChange(plan: EditorRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorTestPlan

Purpose: test the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testEditorChange(plan: EditorTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorDocumentPlan

Purpose: document the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentEditorChange(plan: EditorDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorMigratePlan

Purpose: migrate the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateEditorChange(plan: EditorMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorHardenPlan

Purpose: harden the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenEditorChange(plan: EditorHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorProfilePlan

Purpose: profile the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileEditorChange(plan: EditorProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## EditorLocalizePlan

Purpose: localize the `editor` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface EditorLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeEditorChange(plan: EditorLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `editor` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsImplementPlan

Purpose: implement the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementPermissionsChange(plan: PermissionsImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsReviewPlan

Purpose: review the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewPermissionsChange(plan: PermissionsReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsDebugPlan

Purpose: debug the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugPermissionsChange(plan: PermissionsDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsRefactorPlan

Purpose: refactor the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorPermissionsChange(plan: PermissionsRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsTestPlan

Purpose: test the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testPermissionsChange(plan: PermissionsTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsDocumentPlan

Purpose: document the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentPermissionsChange(plan: PermissionsDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsMigratePlan

Purpose: migrate the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migratePermissionsChange(plan: PermissionsMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsHardenPlan

Purpose: harden the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenPermissionsChange(plan: PermissionsHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsProfilePlan

Purpose: profile the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profilePermissionsChange(plan: PermissionsProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PermissionsLocalizePlan

Purpose: localize the `permissions` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PermissionsLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizePermissionsChange(plan: PermissionsLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `permissions` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenImplementPlan

Purpose: implement the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementOffscreenChange(plan: OffscreenImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenReviewPlan

Purpose: review the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewOffscreenChange(plan: OffscreenReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenDebugPlan

Purpose: debug the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugOffscreenChange(plan: OffscreenDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenRefactorPlan

Purpose: refactor the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorOffscreenChange(plan: OffscreenRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenTestPlan

Purpose: test the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testOffscreenChange(plan: OffscreenTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenDocumentPlan

Purpose: document the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentOffscreenChange(plan: OffscreenDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenMigratePlan

Purpose: migrate the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateOffscreenChange(plan: OffscreenMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenHardenPlan

Purpose: harden the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenOffscreenChange(plan: OffscreenHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenProfilePlan

Purpose: profile the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileOffscreenChange(plan: OffscreenProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## OffscreenLocalizePlan

Purpose: localize the `offscreen` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface OffscreenLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeOffscreenChange(plan: OffscreenLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `offscreen` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nImplementPlan

Purpose: implement the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementI18nChange(plan: I18nImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nReviewPlan

Purpose: review the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewI18nChange(plan: I18nReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nDebugPlan

Purpose: debug the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugI18nChange(plan: I18nDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nRefactorPlan

Purpose: refactor the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorI18nChange(plan: I18nRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nTestPlan

Purpose: test the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testI18nChange(plan: I18nTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nDocumentPlan

Purpose: document the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentI18nChange(plan: I18nDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nMigratePlan

Purpose: migrate the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateI18nChange(plan: I18nMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nHardenPlan

Purpose: harden the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenI18nChange(plan: I18nHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nProfilePlan

Purpose: profile the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileI18nChange(plan: I18nProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## I18nLocalizePlan

Purpose: localize the `i18n` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface I18nLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeI18nChange(plan: I18nLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `i18n` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportImplementPlan

Purpose: implement the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementImportExportChange(plan: ImportExportImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportReviewPlan

Purpose: review the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewImportExportChange(plan: ImportExportReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportDebugPlan

Purpose: debug the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugImportExportChange(plan: ImportExportDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportRefactorPlan

Purpose: refactor the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorImportExportChange(plan: ImportExportRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportTestPlan

Purpose: test the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testImportExportChange(plan: ImportExportTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportDocumentPlan

Purpose: document the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentImportExportChange(plan: ImportExportDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportMigratePlan

Purpose: migrate the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateImportExportChange(plan: ImportExportMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportHardenPlan

Purpose: harden the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenImportExportChange(plan: ImportExportHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportProfilePlan

Purpose: profile the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileImportExportChange(plan: ImportExportProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ImportExportLocalizePlan

Purpose: localize the `import-export` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ImportExportLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeImportExportChange(plan: ImportExportLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `import-export` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesImplementPlan

Purpose: implement the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementUpdatesChange(plan: UpdatesImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesReviewPlan

Purpose: review the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewUpdatesChange(plan: UpdatesReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesDebugPlan

Purpose: debug the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugUpdatesChange(plan: UpdatesDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesRefactorPlan

Purpose: refactor the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorUpdatesChange(plan: UpdatesRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesTestPlan

Purpose: test the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testUpdatesChange(plan: UpdatesTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesDocumentPlan

Purpose: document the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentUpdatesChange(plan: UpdatesDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesMigratePlan

Purpose: migrate the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateUpdatesChange(plan: UpdatesMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesHardenPlan

Purpose: harden the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenUpdatesChange(plan: UpdatesHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesProfilePlan

Purpose: profile the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileUpdatesChange(plan: UpdatesProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## UpdatesLocalizePlan

Purpose: localize the `updates` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface UpdatesLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeUpdatesChange(plan: UpdatesLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `updates` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsImplementPlan

Purpose: implement the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementDiagnosticsChange(plan: DiagnosticsImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsReviewPlan

Purpose: review the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewDiagnosticsChange(plan: DiagnosticsReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsDebugPlan

Purpose: debug the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugDiagnosticsChange(plan: DiagnosticsDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsRefactorPlan

Purpose: refactor the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorDiagnosticsChange(plan: DiagnosticsRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsTestPlan

Purpose: test the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testDiagnosticsChange(plan: DiagnosticsTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsDocumentPlan

Purpose: document the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentDiagnosticsChange(plan: DiagnosticsDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsMigratePlan

Purpose: migrate the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateDiagnosticsChange(plan: DiagnosticsMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsHardenPlan

Purpose: harden the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenDiagnosticsChange(plan: DiagnosticsHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsProfilePlan

Purpose: profile the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileDiagnosticsChange(plan: DiagnosticsProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DiagnosticsLocalizePlan

Purpose: localize the `diagnostics` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DiagnosticsLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeDiagnosticsChange(plan: DiagnosticsLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `diagnostics` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityImplementPlan

Purpose: implement the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementSecurityChange(plan: SecurityImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityReviewPlan

Purpose: review the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewSecurityChange(plan: SecurityReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityDebugPlan

Purpose: debug the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugSecurityChange(plan: SecurityDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityRefactorPlan

Purpose: refactor the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorSecurityChange(plan: SecurityRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityTestPlan

Purpose: test the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testSecurityChange(plan: SecurityTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityDocumentPlan

Purpose: document the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentSecurityChange(plan: SecurityDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityMigratePlan

Purpose: migrate the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateSecurityChange(plan: SecurityMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityHardenPlan

Purpose: harden the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenSecurityChange(plan: SecurityHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityProfilePlan

Purpose: profile the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileSecurityChange(plan: SecurityProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## SecurityLocalizePlan

Purpose: localize the `security` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface SecurityLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeSecurityChange(plan: SecurityLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `security` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupImplementPlan

Purpose: implement the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementPopupChange(plan: PopupImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupReviewPlan

Purpose: review the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewPopupChange(plan: PopupReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupDebugPlan

Purpose: debug the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugPopupChange(plan: PopupDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupRefactorPlan

Purpose: refactor the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorPopupChange(plan: PopupRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupTestPlan

Purpose: test the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testPopupChange(plan: PopupTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupDocumentPlan

Purpose: document the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentPopupChange(plan: PopupDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupMigratePlan

Purpose: migrate the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migratePopupChange(plan: PopupMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupHardenPlan

Purpose: harden the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenPopupChange(plan: PopupHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupProfilePlan

Purpose: profile the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profilePopupChange(plan: PopupProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## PopupLocalizePlan

Purpose: localize the `popup` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface PopupLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizePopupChange(plan: PopupLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `popup` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesImplementPlan

Purpose: implement the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementCookiesChange(plan: CookiesImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesReviewPlan

Purpose: review the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewCookiesChange(plan: CookiesReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesDebugPlan

Purpose: debug the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugCookiesChange(plan: CookiesDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesRefactorPlan

Purpose: refactor the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorCookiesChange(plan: CookiesRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesTestPlan

Purpose: test the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testCookiesChange(plan: CookiesTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesDocumentPlan

Purpose: document the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentCookiesChange(plan: CookiesDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesMigratePlan

Purpose: migrate the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateCookiesChange(plan: CookiesMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesHardenPlan

Purpose: harden the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenCookiesChange(plan: CookiesHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesProfilePlan

Purpose: profile the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileCookiesChange(plan: CookiesProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## CookiesLocalizePlan

Purpose: localize the `cookies` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface CookiesLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeCookiesChange(plan: CookiesLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `cookies` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsImplementPlan

Purpose: implement the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementDownloadsChange(plan: DownloadsImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsReviewPlan

Purpose: review the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewDownloadsChange(plan: DownloadsReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsDebugPlan

Purpose: debug the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugDownloadsChange(plan: DownloadsDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsRefactorPlan

Purpose: refactor the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorDownloadsChange(plan: DownloadsRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsTestPlan

Purpose: test the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testDownloadsChange(plan: DownloadsTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsDocumentPlan

Purpose: document the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentDownloadsChange(plan: DownloadsDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsMigratePlan

Purpose: migrate the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateDownloadsChange(plan: DownloadsMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsHardenPlan

Purpose: harden the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenDownloadsChange(plan: DownloadsHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsProfilePlan

Purpose: profile the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileDownloadsChange(plan: DownloadsProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## DownloadsLocalizePlan

Purpose: localize the `downloads` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface DownloadsLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeDownloadsChange(plan: DownloadsLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `downloads` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesImplementPlan

Purpose: implement the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesImplementPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function implementResourcesChange(plan: ResourcesImplementPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesReviewPlan

Purpose: review the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesReviewPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function reviewResourcesChange(plan: ResourcesReviewPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesDebugPlan

Purpose: debug the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesDebugPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function debugResourcesChange(plan: ResourcesDebugPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesRefactorPlan

Purpose: refactor the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesRefactorPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function refactorResourcesChange(plan: ResourcesRefactorPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesTestPlan

Purpose: test the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesTestPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function testResourcesChange(plan: ResourcesTestPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesDocumentPlan

Purpose: document the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesDocumentPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function documentResourcesChange(plan: ResourcesDocumentPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesMigratePlan

Purpose: migrate the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesMigratePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function migrateResourcesChange(plan: ResourcesMigratePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesHardenPlan

Purpose: harden the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesHardenPlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function hardenResourcesChange(plan: ResourcesHardenPlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesProfilePlan

Purpose: profile the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesProfilePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function profileResourcesChange(plan: ResourcesProfilePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.


## ResourcesLocalizePlan

Purpose: localize the `resources` part of a userscript manager while keeping source, policy, UI, and runtime context readable.

```ts
interface ResourcesLocalizePlan {
  affectedScriptId?: ScriptIdentifier;
  affectedRuntimeContext?: ScriptExecutionContext;
  userVisibleReason: string;
  securityBoundaryTouched: boolean;
  storageMigrationNeeded: boolean;
  localizationUpdateNeeded: boolean;
  diagnosticsToAdd: string[];
}

async function localizeResourcesChange(plan: ResourcesLocalizePlan, services: UserscriptManagerServices): Promise<MaintenanceResult> {
  const validatedPlan = await services.permissionService.validateMaintenancePlan(plan);
  const beforeState = await services.diagnostics.captureBeforeState(validatedPlan);
  const appliedChange = await services.scriptRepository.applyReadableMaintenancePlan(validatedPlan);
  const afterState = await services.diagnostics.captureAfterState(validatedPlan);
  return services.auditLogger.recordMaintenanceResult(beforeState, appliedChange, afterState);
}
```

Agent checklist:

- Name the script, tab, frame, URL, grant, or UI route affected by this `resources` change.
- Preserve privilege boundaries and do not use implicit globals for cross-context data.
- Add a diagnostic message that a future user can understand without reading source code.
- Keep UI text and localization consistent if the user can observe the behavior.
