---
name: userscript-manager-knowledge
title: Userscript Manager Knowledge
version: 1.0.0
entrypoint: SKILL.md
skill_type: domain_knowledge
format: modular_markdown
language: en
summary: >
  Readable engineering knowledge for building, debugging, reviewing, and
  designing browser userscript managers such as Tampermonkey, Violentmonkey,
  ScriptCat, and compatible WebExtension-based tools.
primary_domains:
  - browser-extension architecture
  - userscript lifecycle
  - metadata parsing and linting
  - sandboxed script execution
  - GM API compatibility
  - messaging, ports, and offscreen workers
  - storage, sync, import, export, and migration
  - network, permissions, and security
  - dashboard, editor, popup, and permission UI/UX
agent_use_cases:
  - coding
  - debugging
  - issue fixing
  - code review
  - architecture review
  - UI/UX design review
load_policy:
  default: load_index_first
  detail_strategy: open_only_targeted_modules
readability_policy:
  raw_compiled_chunks: false
  minified_code_dumps: false
  examples: named_type_script_style_patterns
---

# Userscript Manager Knowledge

A compact index for a large, readable, modular domain-knowledge skill. Load this file first, then open only the module, recipe, diagnostic, or reference file needed for the task.

## Start here
- `modules/00-orientation.md` — task routing and package scope
- `modules/11-universal-coding-models.md` — shared named types, interfaces, and implementation vocabulary
- `modules/12-userscript-manager-uiux-design.md` — complete userscript manager product and UI/UX design guidance

## Core modules
- `modules/01-extension-architecture.md` — MV2/MV3 extension topology, service workers, content scripts
- `modules/02-userscript-lifecycle.md` — install, parse, match, enable, update, delete, migrate
- `modules/03-execution-sandbox-gm-api.md` — run timing, isolated worlds, GM APIs, unsafeWindow, resources
- `modules/04-messaging-offscreen-ports.md` — bridge protocols, ports, ACKs, offscreen work, retries
- `modules/05-storage-sync-import-export.md` — schema, script values, resources, sync, backup, restore
- `modules/06-network-permissions-security.md` — @connect, XHR/fetch, cookies, downloads, CSP, DNR, host access
- `modules/07-dashboard-editor-uiux.md` — dashboard, popup, editor, settings, permission prompts
- `modules/08-metadata-linting.md` — metadata grammar, linting, compatibility checks
- `modules/09-debugging-issue-fix.md` — symptom-first triage and field diagnostics
- `modules/10-code-review-maintenance.md` — invariants, regression risks, maintenance checks

## Task recipes
- `recipes/README.md`
- `recipes/debug-script-not-running.md`
- `recipes/fix-cross-origin-xhr.md`
- `recipes/add-or-review-gm-api.md`
- `recipes/handle-mv3-offscreen-task.md`
- `recipes/import-export-migration.md`
- `recipes/permission-prompt-design.md`
- `recipes/review-dashboard-ui-change.md`

## Diagnostics and references
- `diagnostics/userscript-manager-diagnostics.generated.md` — failure-mode matrix
- `diagnostics/scenario-playbooks.generated.md` — issue-fix playbooks
- `reference/README.md` — reference map
- `reference/source-map.generated.md` — readable source atlas
- `reference/source-notes/` — per-file responsibility notebooks, not raw source dumps
- `reference/userscript-api-glossary.generated.md` — GM APIs, metadata keys, browser APIs
- `reference/message-protocol-atlas.generated.md` — message vocabulary and bridge patterns
- `reference/ui-localization-glossary.generated.md` — user-facing concepts by product area
- `reference/css-selector-atlas.generated.md` — selector vocabulary and naming implications
- `reference/readable-implementation-patterns.generated.md` — named universal coding examples
- `reference/agent-question-cards.generated.md` — searchable Q/A cards
