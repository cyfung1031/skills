# Fix cross-origin XHR or fetch

## Goal

Use this recipe when a user asks an agent to fix cross-origin xhr or fetch in a userscript manager.

## Steps

- Identify target URL origin.
- Compare against @connect and user policy.
- Check browser host permission and optional permission prompt.
- Sanitize forbidden headers.
- Verify responseType, progress, abort, timeout, and error mapping.
- Test credentials and anonymous modes separately.

## Readable implementation sketch

```ts
async function performFixCrossOriginXhrOrFetch(context: UserscriptMaintenanceContext): Promise<MaintenanceResult> {
  const diagnosis = await context.diagnostics.collectRelevantFacts();
  const plannedChange = await context.planner.createSafeChangePlan(diagnosis);
  await context.reviewer.assertNoPrivilegeBoundaryRegression(plannedChange);
  return context.executor.applyChangeWithRecovery(plannedChange);
}
```

## Completion criteria

The issue is fixed only when the original user-visible symptom is gone, the relevant boundary has a diagnostic trail, and the patch does not broaden privileges without explicit review.
