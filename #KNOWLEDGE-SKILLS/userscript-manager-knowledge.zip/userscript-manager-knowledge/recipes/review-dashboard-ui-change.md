# Review dashboard UI change

## Goal

Use this recipe when a user asks an agent to review dashboard ui change in a userscript manager.

## Steps

- Check list/detail/editor state separation.
- Verify localization keys and empty states.
- Ensure destructive actions have recovery.
- Confirm keyboard and focus behavior.
- Update diagnostics and help text if terminology changed.

## Readable implementation sketch

```ts
async function performReviewDashboardUiChange(context: UserscriptMaintenanceContext): Promise<MaintenanceResult> {
  const diagnosis = await context.diagnostics.collectRelevantFacts();
  const plannedChange = await context.planner.createSafeChangePlan(diagnosis);
  await context.reviewer.assertNoPrivilegeBoundaryRegression(plannedChange);
  return context.executor.applyChangeWithRecovery(plannedChange);
}
```

## Completion criteria

The issue is fixed only when the original user-visible symptom is gone, the relevant boundary has a diagnostic trail, and the patch does not broaden privileges without explicit review.
