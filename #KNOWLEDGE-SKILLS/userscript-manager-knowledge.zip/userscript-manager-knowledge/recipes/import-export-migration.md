# Design import/export migration

## Goal

Use this recipe when a user asks an agent to design import/export migration in a userscript manager.

## Steps

- Read backup schema version.
- Dry-run parse scripts and values.
- Build ID mapping and conflict list.
- Warn on broader permissions.
- Apply changes atomically.
- Write recovery log.

## Readable implementation sketch

```ts
async function performDesignImportExportMigration(context: UserscriptMaintenanceContext): Promise<MaintenanceResult> {
  const diagnosis = await context.diagnostics.collectRelevantFacts();
  const plannedChange = await context.planner.createSafeChangePlan(diagnosis);
  await context.reviewer.assertNoPrivilegeBoundaryRegression(plannedChange);
  return context.executor.applyChangeWithRecovery(plannedChange);
}
```

## Completion criteria

The issue is fixed only when the original user-visible symptom is gone, the relevant boundary has a diagnostic trail, and the patch does not broaden privileges without explicit review.
