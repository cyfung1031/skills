# Handle an MV3 offscreen task

## Goal

Use this recipe when a user asks an agent to handle an mv3 offscreen task in a userscript manager.

## Steps

- Check whether the task really needs DOM/offscreen.
- Create or reuse one offscreen document.
- Store a task ID and response resolver.
- Serialize payloads with safe clones.
- Close or idle the helper after work.
- Retry idempotent tasks after worker restart.

## Readable implementation sketch

```ts
async function performHandleAnMv3OffscreenTask(context: UserscriptMaintenanceContext): Promise<MaintenanceResult> {
  const diagnosis = await context.diagnostics.collectRelevantFacts();
  const plannedChange = await context.planner.createSafeChangePlan(diagnosis);
  await context.reviewer.assertNoPrivilegeBoundaryRegression(plannedChange);
  return context.executor.applyChangeWithRecovery(plannedChange);
}
```

## Completion criteria

The issue is fixed only when the original user-visible symptom is gone, the relevant boundary has a diagnostic trail, and the patch does not broaden privileges without explicit review.
