# Design a permission prompt

## Goal

Use this recipe when a user asks an agent to design a permission prompt in a userscript manager.

## Steps

- Name script, target host, requested capability, and consequence.
- Offer allow once, always allow, deny once, always deny where appropriate.
- Show why the request was triggered.
- Persist decisions by script and host, not globally by accident.
- Make the decision auditable in diagnostics.

## Readable implementation sketch

```ts
async function performDesignAPermissionPrompt(context: UserscriptMaintenanceContext): Promise<MaintenanceResult> {
  const diagnosis = await context.diagnostics.collectRelevantFacts();
  const plannedChange = await context.planner.createSafeChangePlan(diagnosis);
  await context.reviewer.assertNoPrivilegeBoundaryRegression(plannedChange);
  return context.executor.applyChangeWithRecovery(plannedChange);
}
```

## Completion criteria

The issue is fixed only when the original user-visible symptom is gone, the relevant boundary has a diagnostic trail, and the patch does not broaden privileges without explicit review.
