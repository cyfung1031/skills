# Recipes

| File | Purpose |
| --- | --- |
| debug-script-not-running.md | Debug a script that does not run |
| add-or-review-gm-api.md | Add or review a GM API |
| fix-cross-origin-xhr.md | Fix cross-origin XHR or fetch |
| import-export-migration.md | Design import/export migration |
| review-dashboard-ui-change.md | Review dashboard UI change |
| handle-mv3-offscreen-task.md | Handle an MV3 offscreen task |
| permission-prompt-design.md | Design a permission prompt |
