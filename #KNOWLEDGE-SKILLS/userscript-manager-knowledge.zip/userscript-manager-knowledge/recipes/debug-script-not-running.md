# Debug a script that does not run

## Goal

Use this recipe when a user asks an agent to debug a script that does not run in a userscript manager.

## Steps

- Confirm enabled state and manager global toggle.
- Open metadata and normalize match/include/exclude rules.
- Check frame policy: top frame, iframe, all_frames, @noframes.
- Check run-at timing and page lifecycle.
- Verify sandbox selection and injection result.
- Inspect console and background logs with script ID and frame ID.

## Readable implementation sketch

```ts
async function performDebugAScriptThatDoesNotRun(context: UserscriptMaintenanceContext): Promise<MaintenanceResult> {
  const diagnosis = await context.diagnostics.collectRelevantFacts();
  const plannedChange = await context.planner.createSafeChangePlan(diagnosis);
  await context.reviewer.assertNoPrivilegeBoundaryRegression(plannedChange);
  return context.executor.applyChangeWithRecovery(plannedChange);
}
```

## Completion criteria

The issue is fixed only when the original user-visible symptom is gone, the relevant boundary has a diagnostic trail, and the patch does not broaden privileges without explicit review.
