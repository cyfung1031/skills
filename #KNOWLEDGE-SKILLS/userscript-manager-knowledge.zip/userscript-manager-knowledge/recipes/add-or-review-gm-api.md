# Add or review a GM API

## Goal

Use this recipe when a user asks an agent to add or review a gm api in a userscript manager.

## Steps

- Define the grant name and aliases.
- Expose the API only through the grant-gated bridge.
- Route privileged work through a named background command.
- Validate script ID, frame URL, and permission decision.
- Serialize callback and promise behavior consistently.
- Add diagnostics for missing grants.

## Readable implementation sketch

```ts
async function performAddOrReviewAGmApi(context: UserscriptMaintenanceContext): Promise<MaintenanceResult> {
  const diagnosis = await context.diagnostics.collectRelevantFacts();
  const plannedChange = await context.planner.createSafeChangePlan(diagnosis);
  await context.reviewer.assertNoPrivilegeBoundaryRegression(plannedChange);
  return context.executor.applyChangeWithRecovery(plannedChange);
}
```

## Completion criteria

The issue is fixed only when the original user-visible symptom is gone, the relevant boundary has a diagnostic trail, and the patch does not broaden privileges without explicit review.
