---
name: appkit-textkit-layout
title: AppKit TextKit Layout
description: >
  AppKit and TextKit domain knowledge for macOS agents working with
  NSTextView, NSTextStorage, NSLayoutManager, custom text layout,
  glyph drawing, editor views, scroll/ruler synchronization, and
  SwiftUI NSViewRepresentable bridges.
version: 1.0.0
domains:
  - macOS
  - AppKit
  - TextKit
  - TextKit 1
  - NSLayoutManager
  - NSTextView
  - NSTextStorage
  - NSScrollView
  - SwiftUI-AppKit interop
use_when:
  - Building or debugging macOS text editors.
  - Working with NSTextView, NSLayoutManager, NSTextStorage, or NSTextContainer.
  - Implementing custom glyph, line, row, selection, or background drawing.
  - Bridging AppKit text views into SwiftUI with NSViewRepresentable.
  - Diagnosing layout invalidation, scrolling, ruler, or text measurement bugs.
avoid_when:
  - The task is iOS-only UIKit text layout.
  - The task only needs basic SwiftUI Text or TextEditor usage.
  - The task is unrelated to macOS UI, text rendering, or AppKit layout.
entrypoint: SKILL.md
language: markdown
tags:
  - appkit
  - textkit
  - nslayoutmanager
  - nstextview
  - nstextstorage
  - nstextcontainer
  - macos
  - swift
  - swiftui
  - nsviewrepresentable
  - custom-drawing
  - editor
  - layout-invalidation
---

# AppKit TextKit Layout

Use this skill for macOS/AppKit/TextKit 1 work involving `NSTextView`, `NSTextStorage`, `NSLayoutManager`, SwiftUI bridges, custom drawing, diff editors, markdown previews, and AppKit layout.

## Index
- `modules/00-orientation.md` — source-derived map and how to use the skill
- `modules/01-textkit1-architecture.md` — TextKit 1 object graph and responsibilities
- `modules/02-nslayoutmanager-custom-drawing.md` — drawBackground, glyph/char range mapping, block backgrounds
- `modules/03-nstextview-configuration.md` — editor/preview/diff text view configuration
- `modules/04-swiftui-bridges.md` — NSViewRepresentable lifecycle for AppKit views
- `modules/05-attributed-strings.md` — attributes, custom keys, markdown rendering, tables/images/links
- `modules/06-nstextstorage-highlighting.md` — incremental and background syntax highlighting
- `modules/07-diff-textview-rulers.md` — row backgrounds, line starts, rulers, phantom rows
- `modules/08-scrolling-and-geometry.md` — scroll restore, heading jumps, row jumps, overview viewport
- `modules/09-appkit-layout.md` — NSStackView, constraints, split panes, table cell reuse
- `modules/10-window-menu-actions.md` — AppKit app shell, windows, panels, menu validation
- `modules/11-performance-threading.md` — large text, non-contiguous layout, off-main rendering
- `modules/12-appearance-theme.md` — NSColor, NSFont, dynamic colors, dark-mode handling
- `modules/13-debugging-checklists.md` — debug routes and AppKit/TextKit pitfalls
- `recipes/README.md` — recipe index
- `reference/source-map.generated.md` — all Swift files, symbols, roles, comments, term counts
- `reference/appkit-callsite-atlas.generated.md` — all AppKit/TextKit callsites with context
- `reference/api-glossary.generated.md` — API-by-API notes and source locations
- `reference/agent-question-cards.generated.md` — searchable Q/A cards for agents
- `diagnostics/textkit-diagnostics.generated.md` — failure-mode matrix and remedies
- `reference/chunks/` — split generated lookup chunks for low-token search

Start with `modules/00-orientation.md`, then open only the needed module/reference.
