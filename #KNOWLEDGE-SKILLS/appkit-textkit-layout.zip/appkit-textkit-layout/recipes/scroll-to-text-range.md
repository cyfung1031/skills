# Recipe: Scroll to a Text Range

1. Find a semantic `NSRange` in `NSTextStorage`.
2. Call `layoutManager.ensureLayout(for: textContainer)`.
3. Convert character range to glyph range.
4. Get bounding rect in the text container.
5. Add `textContainerInset` for `NSTextView` content inset or use `textContainerOrigin` depending on the API path.
6. Scroll `scrollView.contentView` to a clamped point.
7. Call `scrollView.reflectScrolledClipView(scrollView.contentView)`.
