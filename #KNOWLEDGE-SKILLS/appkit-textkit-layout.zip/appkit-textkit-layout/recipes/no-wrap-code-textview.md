# Recipe: Build a No-Wrap Code NSTextView

Use this for diff/code panes that need horizontal scrolling and one source line per display row.

- Create `NSScrollView` with vertical and horizontal scrollers.
- Create `NSTextView`/subclass with a reasonable initial frame.
- Set monospaced font, plain text/rich-text flags, editability, selection, and inset.
- Set `isHorizontallyResizable = true` and `isVerticallyResizable = true`.
- Set max size to greatest finite magnitude.
- Set `textContainer.widthTracksTextView = false`.
- Set `textContainer.containerSize.width = CGFloat.greatestFiniteMagnitude`.
- Assign as scroll view document view.
