# Recipe: Background Syntax Highlighting Without TextKit Races

1. On main, copy `String(textStorage.string)`.
2. Increment a generation counter.
3. Dispatch token collection to a background queue using only the copied string.
4. Return token ranges as UTF-16 `NSRange` values.
5. On main, verify the generation is still current.
6. Fetch live `textStorage` and wrap attribute application in `beginEditing` / `endEditing`.
7. Do not read `NSTextStorage` on the background queue.
