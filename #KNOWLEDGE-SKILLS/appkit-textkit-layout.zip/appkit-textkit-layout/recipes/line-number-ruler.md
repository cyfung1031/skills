# Recipe: Add Line Numbers with NSRulerView

1. Create a custom `NSRulerView` subclass.
2. Store a weak reference to the text view.
3. Use visible glyph range to find visible character range.
4. Map character offset to row index using row start offsets.
5. Draw labels for visible rows only.
6. Use `lineFragmentRect(forGlyphAt:)` for vertical placement.
7. Subtract `textView.visibleRect.minY` for ruler coordinates.
8. Invalidate ruler when text, scroll, or row metadata changes.
