# Recipe: SwiftUI Wrapper for a Serious NSTextView Editor

- Let `NSTextView` own live text.
- Use coordinator delegates for text changes and selection.
- Push text to SwiftUI/app state with debounce.
- Apply appearance settings in `updateNSView` without replacing text.
- Use an external command channel for load/reload/clear.
- Suppress delegate echo during programmatic replacement.
- Save cached text on disappear/deinit if SwiftUI recreates the bridge.
