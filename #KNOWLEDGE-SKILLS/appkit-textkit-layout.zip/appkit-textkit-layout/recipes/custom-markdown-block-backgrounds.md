# Recipe: Add a New Markdown Block Background

1. Define a semantic custom `NSAttributedString.Key` or reuse `.markdownBlockBackground` with a new value.
2. During rendering, attach the attribute to the UTF-16 range covering the block including its line terminator if the background should extend through the row.
3. In `MarkdownLayoutManager.drawBackground`, enumerate the attribute inside the visible character range.
4. Convert the range to glyphs, enumerate line fragments, union rects, adjust x/width to container padding, then fill.
5. Keep `super.drawBackground` ordering so selection remains visible.
6. Test single-line, multi-line, wrapped, first-block, last-block, and selected text cases.
