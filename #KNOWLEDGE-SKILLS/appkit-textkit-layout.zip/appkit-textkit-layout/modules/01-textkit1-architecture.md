# TextKit 1 Architecture for These Apps

## Object graph

The source uses TextKit 1 rather than TextKit 2. The relevant graph is:

- `NSTextStorage`: mutable attributed string plus edit notifications. It is the only safe place to apply syntax and markdown attributes that should participate in layout.
- `NSLayoutManager`: glyph generation, line-fragment calculation, drawing hooks, character/glyph range conversion.
- `NSTextContainer`: geometric constraint for layout. Its `containerSize`, `widthTracksTextView`, and `lineFragmentPadding` decide wrapping and horizontal extent.
- `NSTextView`: event handling, selection, editing, link clicks, background drawing, view coordinate conversion.
- `NSScrollView`: clip view, scrollers, document view, scroll restoration, synchronized scrolling.

## Source-derived patterns

### Manual TextKit stack for custom layout manager

`MarkdownPreviewTextView` does not use `NSTextView.scrollableTextView()` because it needs to inject `MarkdownLayoutManager`. It constructs `NSTextStorage`, `MarkdownLayoutManager`, and `NSTextContainer`, connects them, then creates `NSTextView(frame:textContainer:)`. Use this pattern whenever the layout manager subclass is part of the feature.

### Convenience TextKit stack for normal editing

`MarkdownEditorView` uses `NSTextView.scrollableTextView()` because the default layout manager is enough; the editor customizes behavior through `NSTextView`, `NSTextStorageDelegate`, and syntax attributes.

### Custom `NSTextView` subclass for diff panes

`DiffTextView` subclasses `NSTextView` because row backgrounds and keyboard handling belong at the view drawing/event layer. It overrides `drawBackground(in:)`, not the layout manager, because backgrounds are tied to display rows and full view width rather than semantic attributed ranges.

## Main-thread rule

AppKit and TextKit view/storage mutation is main-thread work. The code computes heavy data off-main, but applies results to `NSTextStorage` on main. Important examples:

- MackDown collects syntax tokens on a background queue, then wraps `MarkdownSyntaxHighlighter.applyTokens` in `storage.beginEditing()` / `storage.endEditing()` on the main queue.
- MacMerge builds `PaneContent` off-main, then calls `textStorage?.setAttributedString(...)` from controller state application.

## When to choose each extension point

| Requirement | Prefer | Why |
|---|---|---|
| Per-token foreground/background | `NSAttributedString` attributes on `NSTextStorage` | Participates in normal glyph layout and selection. |
| Full-width paragraph/block backgrounds | `NSLayoutManager.drawBackground(forGlyphRange:at:)` | Layout manager knows line fragments and can paint before glyphs. |
| Full-width diff row backgrounds based on row table | `NSTextView.drawBackground(in:)` | Row index table is a view concern; draw to view bounds, not text width. |
| Line numbers aligned to rows | `NSRulerView.drawHashMarksAndLabels(in:)` | Ruler shares the scroll view and can map visible glyphs to row labels. |
| Selection popover geometry | `layoutManager.boundingRect(forGlyphRange:in:)` + `textContainerInset` + window conversion | Needs text glyph geometry and screen coordinates. |
| Jump to heading/row | `ensureLayout`, char→glyph conversion, line fragment/bounding rect, then `NSClipView.scroll(to:)` | Geometry must exist before scrolling. |

## Invariants to preserve

- Store offsets as UTF-16 `NSRange`/`NSString` lengths when interacting with TextKit.
- Apply UI mutations to `NSTextStorage` and `NSTextView` on the main thread.
- Ensure layout before using layout-manager geometry after replacing content.
- Keep row metadata (`lineStartOffsets`, `rowBackgrounds`, labels) synchronized with the exact attributed string installed in the text view.
- Avoid pushing full document text through SwiftUI state on each keystroke.
