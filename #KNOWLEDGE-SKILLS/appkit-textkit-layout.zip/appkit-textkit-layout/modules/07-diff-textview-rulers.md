# DiffTextView, Full-Width Row Backgrounds, and Rulers

MacMerge uses a custom `NSTextView` subclass and a custom `NSRulerView` for diff panes.

## Data model

`PaneContent` bundles the exact data required by the view layer:

- `attributed`: the text to install into `NSTextStorage`.
- `lineStartOffsets`: UTF-16 start offset for each display row.
- `rowBackgrounds`: row index → `NSColor` for full-width row tint.
- `labels`: row index → line number label; phantom rows use empty labels.

These arrays must stay in lockstep.

## Full-width row backgrounds

Normal `.backgroundColor` attributes only paint behind glyphs. Diff apps need row tints across the entire pane width, including empty line area. `DiffTextView.drawBackground(in:)` handles this.

Algorithm:

1. Call `super.drawBackground(in:)` first for normal text background.
2. Use `layoutManager.glyphRange(forBoundingRect:in:)` for the dirty/visible rect.
3. Convert glyph range to character range.
4. Binary-search `lineStartOffsets` to find the first row.
5. Iterate rows while row start is within the visible character range.
6. For each tinted row, find its line fragment rect using `glyphIndexForCharacter(at:)` and `lineFragmentRect(forGlyphAt:)`.
7. Add `textContainerOrigin.y` to convert fragment y into view coordinates.
8. Fill `NSRect(x: 0, y: frag.minY, width: bounds.width, height: frag.height)`.

## Highlighted current difference

The current diff target is stored as `highlightedRows: Range<Int>?`. Setting it invalidates display. Drawing computes the first and last fragment rect and strokes a rounded `NSBezierPath` around the union.

## Line number ruler

`LineNumberRuler` subclasses `NSRulerView` and implements `drawHashMarksAndLabels(in:)`.

It maps visible glyphs to character range, then row indexes, then draws each visible label aligned vertically to its line fragment. The y coordinate subtracts `visibleRect.minY` because ruler drawing is in ruler coordinates, not text view coordinates.

## Phantom rows

Phantom rows represent inserted/deleted placeholders or collapsed context markers. They may have row backgrounds but no line number label. Always preserve row count even when the textual line is empty.

## No-wrap assumptions

The diff pane disables wrapping, so one display row generally maps to one source line plus trailing newline. If wrapping is re-enabled, row start offsets alone no longer represent visible line fragments and ruler/background logic must be redesigned.

## Keyboard override

Read-only diff panes override Escape to send `goBack:` to the responder chain. Editable merge-output panes keep normal text editing behavior.

## Agent checklist for row features

- Update `textStorage`, `lineStartOffsets`, `rowBackgrounds`, and ruler labels in one state transaction.
- Invalidate both `textView.needsDisplay` and `ruler.needsDisplay` when row metadata changes.
- Use UTF-16 offsets for row starts.
- Clamp row jumps to available row range.
- Convert fragment coordinates carefully: layout fragment → text container origin → view/ruler/scroll coordinates.
