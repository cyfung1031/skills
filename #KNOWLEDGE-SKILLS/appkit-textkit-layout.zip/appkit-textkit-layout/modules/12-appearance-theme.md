# Appearance, Theme, Color, and Font

The source uses AppKit dynamic colors, monospaced fonts, and explicit theme palettes for editor/diff semantics.

## Dynamic NSColor

Use `NSColor(name:nil) { appearance in ... }` to create colors that react to light/dark appearances. Query `appearance.bestMatch(from: [.darkAqua, .vibrantDark])` when choosing between variants.

## Effective appearance

For current runtime decisions such as syntax colors, the code checks `NSApp.effectiveAppearance`. For views that must update on appearance change, MacGit observes `NSApp.effectiveAppearance` and reloads a table view.

## Semantic colors

Prefer AppKit semantic colors where possible:

- `.labelColor`, `.secondaryLabelColor`, `.tertiaryLabelColor`,
- `.textColor`, `.controlBackgroundColor`, `.windowBackgroundColor`,
- `.controlAccentColor`, system red/green/blue/orange.

Semantic colors adapt better across appearances and accessibility settings.

## Diff colors

Diff UI uses different colors for:

- added/removed full-row backgrounds,
- changed row backgrounds,
- whitespace-only row backgrounds,
- strong intra-line emphasis,
- phantom/collapsed rows,
- overview strip markers.

Do not collapse these into one color pair; they encode different comparison semantics.

## Fonts

Text/code surfaces use monospaced system fonts. Line numbers use monospaced digit fonts. Markdown preview uses body/code/heading fonts from theme settings.

## Layer backgrounds

Reusable row views use `wantsLayer = true` and set `layer?.backgroundColor`. Reconfigure layer color on every reuse so stale tint does not leak between rows.

## Link appearance

Preview link appearance is configured with `linkTextAttributes`, including underline and pointing-hand cursor. Foreground color comes from renderer/theme attributes so visited/special links can stay consistent with markdown styling.

## Agent checklist

- Choose semantic AppKit colors before fixed RGB.
- For app-specific palettes, centralize in a theme type.
- Recompute appearance-dependent tokens/colors when dark mode changes.
- Keep editor font, tab stops, syntax colors, and paragraph styles synchronized.
- Remember `NSColor` and SwiftUI `Color` bridging may need explicit conversions.
