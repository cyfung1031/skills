# Scrolling, Geometry, and Synchronization

The source uses layout-manager geometry for three tasks: restoring scroll after preview re-render, jumping to markdown headings, and navigating to diff rows/changes.

## Restore scroll after re-render

Preview re-render replaces the attributed string, which changes layout and document height. The source captures `scrollView.contentView.bounds.origin` before replacement and restores it in `layoutManager(_:didCompleteLayoutFor:atEnd:)` only when layout finished.

Restoration clamps y to `documentRect.height - clipHeight` so it does not scroll beyond the shorter new document.

## Jump to markdown heading

Algorithm:

1. Enumerate `.markdownHeadingTitle` over the full text storage.
2. Match normalized title and occurrence index.
3. Call `layoutManager.ensureLayout(for: textContainer)`.
4. Convert heading character range to glyph range.
5. Get `boundingRect(forGlyphRange:in:)`.
6. Offset by `textContainerInset`.
7. Scroll the clip view to a y coordinate slightly above the heading.
8. Call `reflectScrolledClipView`.

## Jump to diff row

Algorithm:

1. Clamp row index.
2. Convert row start offset to glyph index.
3. Ask layout manager for `lineFragmentRect(forGlyphAt:)`.
4. Add `textContainerOrigin.y`.
5. Choose a target y, often with context above.
6. Scroll both left and right panes to the same point if they are synchronized.

## Synchronized panes

The file diff controller observes clip-view bounds changes. When one scroll view scrolls, it updates the other scroll view and the overview viewport. Avoid feedback loops by detecting which clip view changed and applying the same origin to the other.

## Overview viewport

The overview strip maps document row ranges to strip y positions. To compute visible rows, the controller maps the left text view's visible rect to glyph and character range, then uses `DiffTextView.rowIndex` for first and last visible rows.

## Coordinate spaces

Common spaces in this codebase:

- **Text container coordinates**: rects returned by `NSLayoutManager` methods.
- **Text view coordinates**: add `textContainerOrigin` or `textContainerInset` depending on API path.
- **Clip view/document coordinates**: `scrollView.contentView.bounds.origin` and `documentRect`.
- **Window/screen coordinates**: use `textView.convert(rect, to:nil)` then `window.convertToScreen`.
- **Ruler coordinates**: subtract `textView.visibleRect.minY` when drawing aligned labels.

## Geometry preconditions

- `textStorage.length > 0` when asking for glyph at character.
- Clamp character index to `storage.length - 1`.
- Ensure layout before using geometry after content replacement.
- Do not use a zero-width text container for initial layout; it can create one fragment per character.

## Common bugs

- Jump lands too low: forgot `textContainerInset` or `textContainerOrigin`.
- Scroll restore bounces: restored before layout finished.
- Ruler labels drift: using view y directly instead of subtracting visible origin.
- Overview wrong after reload: row metadata not reset with the attributed string.
- Large document stalls on load: layout forced for entire document instead of visible glyphs.
