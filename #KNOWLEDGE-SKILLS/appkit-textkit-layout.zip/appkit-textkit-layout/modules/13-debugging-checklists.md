# Debugging Checklists

## TextKit drawing bug

1. Confirm the custom attribute exists over the expected UTF-16 range.
2. Convert character range to glyph range and verify it is nonempty.
3. Check whether layout has completed.
4. Inspect `textContainer.containerSize`, `lineFragmentPadding`, and text view inset.
5. Verify drawing order relative to `super.drawBackground`.
6. Ensure the rect is in the expected coordinate space.

## Scroll/jump bug

1. Is `textStorage.length > 0`?
2. Is the target offset clamped to length - 1?
3. Did you call `ensureLayout(for:)` after content replacement?
4. Did you add `textContainerInset` or `textContainerOrigin` where appropriate?
5. Are you scrolling the `contentView`, not the document view directly?
6. Did you call `reflectScrolledClipView`?

## Syntax highlight bug

1. Did delegate ignore non-character edits?
2. Is the programmatic load flag suppressing the right paths?
3. Was a snapshot string copied before background tokenization?
4. Did stale generation results get dropped?
5. Are attributes applied on main inside `beginEditing`/`endEditing`?
6. Are UTF-16 ranges clamped after tokenization?

## Diff row/ruler bug

1. Do `lineStartOffsets`, `rowBackgrounds`, labels, and attributed text represent the same rows?
2. Does the row index binary search handle first/last rows?
3. Is wrapping disabled if row logic assumes one display row per source line?
4. Are phantom rows present in all row arrays?
5. Are ruler y coordinates adjusted by `visibleRect.minY`?
6. Are text view and ruler invalidated after metadata changes?

## SwiftUI bridge bug

1. Is the content being reset from `updateNSView` too often?
2. Are delegate callbacks echoing external assignments?
3. Are coordinator references weak where necessary?
4. Are observations/cancellables cleaned up?
5. Does the coordinator retain the state needed for save/disappear?
6. Are AppKit view mutations on main?

## AppKit layout bug

1. Is `translatesAutoresizingMaskIntoConstraints` false for manually constrained views?
2. Are constraints activated after subviews are added?
3. Is an `NSStackView` distribution/hugging priority fighting explicit constraints?
4. Is a scroll view document view configured for the intended wrapping behavior?
5. Are reusable table row views fully reconfigured?
6. Are layer-backed views setting `wantsLayer` before setting layer color?
