# NSLayoutManager Custom Drawing

## Why subclass `NSLayoutManager`

The MackDown preview renders markdown as attributed text but needs backgrounds that regular attributes cannot express well:

- code block and front-matter backgrounds spanning the readable width,
- blockquote left bars across multiple line fragments,
- inline-code rounded capsules that may span line fragments,
- selection remaining visible above custom background fills.

`MarkdownLayoutManager` solves this by overriding `drawBackground(forGlyphRange:at:)`.

## Drawing order

The inspected layout manager uses this order:

1. Convert `glyphsToShow` to `charRange` with `characterRange(forGlyphRange:actualGlyphRange:)`.
2. Enumerate custom attributes in `NSTextStorage` only inside that character range.
3. Draw full-width block backgrounds by unioning line fragment rects.
4. Draw blockquote bars using `container.lineFragmentPadding` plus per-depth offsets.
5. Draw inline code backgrounds by intersecting the inline-code glyph range with each visible line fragment.
6. Call `super.drawBackground(...)` last so normal selection highlights and table backgrounds are preserved on top.

## Full-width background recipe

Use a custom `NSAttributedString.Key` whose value contains color and inset data. During drawing:

- map attribute range to glyph range,
- call `enumerateLineFragments(forGlyphRange:)`,
- union the fragment rects,
- replace `origin.x` with `container.lineFragmentPadding`,
- replace width with `container.containerSize.width - padding * 2`,
- offset by `origin`,
- apply top/bottom inset,
- fill a rounded `NSBezierPath`.

## Inline capsule recipe

Inline code is not a paragraph block; it should hug glyph bounds. The source uses this approach:

- Convert the inline code character range to glyph range.
- Enumerate line fragments for that glyph range.
- Intersect the inline glyph range with the current line fragment's glyph range.
- Get `boundingRect(forGlyphRange:in:)` for the intersection.
- Use the line fragment height for vertical alignment, expand a few points horizontally/vertically, then fill a rounded rect.

This is better than one bounding rect for the whole range because inline ranges can wrap across lines.

## Attribute design

Custom attributes found in source:

- `.markdownBlockBackground`: stores `MarkdownBlockBackground` with fill color, optional border, top/bottom insets.
- `.markdownBlockLeftBorders`: stores an `NSObject` wrapper containing an array of left-border entries. The wrapper matters because `NSAttributedString` copies attribute values.
- `.markdownInlineCode`: stores an `NSColor` for inline code capsule fill.
- `.markdownCopyCode`: stores code text for copy links.
- `.markdownHeadingTitle`: stores normalized heading titles for outline jumps.

## Common failure modes

- **Background does not fill width**: the rect is based on glyph bounds; use line fragment rects and container width instead.
- **Custom background covers selection**: call `super.drawBackground` after custom fills, not before, when selection must win.
- **Hairline gaps between blockquote bars**: extend adjacent bar rects by about one point vertically.
- **Drawing outside visible glyphs is slow**: enumerate only `glyphsToShow` → `charRange`.
- **Wrong x origin**: remember `origin` is the text container origin passed by TextKit, not the view origin.

## Decision rule

Use `NSLayoutManager` for semantic glyph-range drawing. Use `NSTextView.drawBackground(in:)` for view-width row drawing keyed by line indexes or external display models.
