# Attributed Strings and Markdown Rendering

The source uses attributed strings in two modes:

1. Semantic rich preview rendering for markdown.
2. Fast code/diff rendering with token colors and row metadata.

## Custom keys

MackDown extends `NSAttributedString.Key` for markdown-specific drawing and interaction. Keys are intentionally namespaced with app-specific strings.

Use custom keys for data that belongs to rendered text but is not directly visible as standard font/color attributes:

- block background specs,
- blockquote left-border lists,
- copy-code payloads,
- inline-code capsule color,
- heading titles for outline navigation.

## Attribute values

Attribute values should be copy-safe. If an attribute stores a collection or a nontrivial structure, wrap it in an `NSObject` class when needed so attributed-string copying and storage enumeration are stable.

## Markdown preview pipeline

The renderer parses markdown into block/inline structures, emits `NSMutableAttributedString`, assigns fonts/colors/paragraph styles, and attaches custom attributes for the layout manager. The layout manager then uses those custom attributes during drawing.

Important separation:

- Renderer decides semantic ranges and values.
- Layout manager decides geometry and painting.

## Diff pane pipeline

`PaneBuilder` accumulates a single `NSMutableAttributedString` and side metadata:

- `lineStartOffsets`: UTF-16 start offset of each display row.
- `rowBackgrounds`: row index to full-width background color.
- `labels`: line-number strings, with empty labels for phantom/marker rows.
- Inline emphasis uses `.backgroundColor` only for the changed span; full-row tint is not stored as a normal attribute because it must span the entire pane width.

## UTF-16 rule

TextKit APIs consume `NSRange` in UTF-16 code units. The source uses `NSString.length`, `NSRange`, and offset accounting rather than Swift `String.Index` where TextKit geometry is involved.

When converting Swift ranges to `NSRange`:

- validate bounds against `attr.length - 1` if excluding a trailing newline,
- clamp lower/upper bounds,
- discard empty ranges,
- keep row-start offsets aligned with the exact string passed to TextKit.

## Paragraph style use

The editor applies tab stops by building a `NSMutableParagraphStyle`, setting `defaultTabInterval`, clearing explicit `tabStops`, then assigning it to `textView.defaultParagraphStyle` and `typingAttributes[.paragraphStyle]`.

This affects new typing; existing text may need attributed paragraph style updates if the app expects old paragraphs to reflow immediately.

## Link attributes and semantic links

Preview links use standard `.link` behavior with customized `linkTextAttributes`. The delegate intercepts special URL schemes:

- `copycode:` copies code payload from a custom attribute.
- `toggle:` toggles checkbox state by source line.
- nil-scheme relative URLs are delegated to document navigation.
- external schemes fall through to AppKit/Workspace handling.

## Checklist before applying attributes

- Are ranges UTF-16 and clamped?
- Is mutation on the main thread when touching `NSTextStorage`?
- Should the attribute affect glyph rendering, custom drawing, interaction, or metadata lookup?
- Should this be a normal attribute (`foregroundColor`, `backgroundColor`, `font`) or a custom key consumed by custom drawing/delegate code?
- Does the attribute survive copy/replace operations?
