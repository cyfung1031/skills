# AppKit Layout Patterns

The inspected AppKit controllers build UI programmatically with `NSStackView`, `NSScrollView`, constraints, and reusable table/outline views.

## NSStackView composition

MacMerge uses vertical stacks for the whole controller and horizontal stacks for controls/content/status bars. This keeps layout readable while still using anchors for critical relationships.

Typical structure:

- Control bar: buttons, labels, spinner, spacer, popup.
- Content row: left scroll view, right scroll view, overview strip.
- Status bar: status labels and spacer.
- Main vertical stack pinned to a container view with top/bottom/leading/trailing constraints.

## Spacer views

A plain `NSView` with low horizontal content hugging priority can push controls apart inside an `NSStackView`. This is used in control/status bars.

## Constraints to preserve symmetry

For side-by-side panes, constrain the left scroll view width equal to the right scroll view width. Give the overview strip a fixed width.

## Programmatic constraints checklist

- Set `translatesAutoresizingMaskIntoConstraints = false` on views you constrain manually.
- Activate constraints after adding subviews.
- Pin main content to container edges.
- Use fixed widths sparingly for narrow accessory views such as overview strips or gutters.
- Prefer stack view spacing/edgeInsets over many individual padding constraints.

## Table-view virtualization

MacGit uses `NSTableView` inside `NSScrollView` for large diff previews. Each row returns reusable views by identifier. Text fields inside row views use constraints and clipping rather than building new SwiftUI views for every row.

Rules:

- Use `makeView(withIdentifier:owner:)` before creating row subviews.
- Reconfigure every reused view fully.
- Assign stable `NSUserInterfaceItemIdentifier` values to row views and child fields.
- Use layer-backed row backgrounds for cheap tinting.
- Keep row heights deterministic for performance.

## Outline/table controllers

Folder compare uses `NSOutlineView` data source/delegate and menu validation. Use AppKit outline/table views when hierarchical or virtualized datasets are core to the UI and SwiftUI lists would churn too much state.

## Auto Layout vs autoresizing masks

Text views inside scroll views often rely on autoresizing masks and text container sizing. Programmatic controller layout uses constraints. Do not mix constraints into text-container behavior without understanding wrapping and scroll-view document sizing.

## AppKit-hosted SwiftUI

Window manager code hosts SwiftUI welcome/new-comparison panels in `NSHostingController` while file diff/merge/folder compare remain AppKit controllers. This is a pragmatic split: SwiftUI for form-like screens, AppKit for editor-like panes.
