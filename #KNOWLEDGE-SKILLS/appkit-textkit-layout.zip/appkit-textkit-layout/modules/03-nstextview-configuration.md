# NSTextView Configuration

The source contains three distinct `NSTextView` configurations: live markdown editor, rich markdown preview, and no-wrap diff/merge pane. Do not copy settings blindly; each configuration encodes product intent.

## Live editor settings

The live markdown editor is editable, plain-text, undo-enabled, and performance-sensitive.

Key settings:

- `isRichText = false` to keep markdown source plain.
- Disable automatic substitutions, grammar, continuous spell checking, and smart quotes/dashes to avoid mutating source text.
- `allowsUndo = true` for editing.
- `layoutManager?.allowsNonContiguousLayout = true` so large documents display visible glyphs without full-document layout.
- `textContainerInset = NSSize(width: 16, height: 16)` for readable padding.
- Dynamic AppKit background colors applied to both scroll view and text view.
- `textStorage?.delegate = coordinator` to drive incremental syntax highlighting.

## Rich preview settings

The preview is read-only but selectable and link-aware.

Key settings:

- Manually created `NSTextView(frame:textContainer:)` to use a custom `MarkdownLayoutManager`.
- `isEditable = false`, `isSelectable = true`, `isRichText = true`.
- `drawsBackground = false` so surrounding SwiftUI/AppKit background can show through.
- Larger `textContainerInset` for preview reading.
- Link attributes specify underline and pointing-hand cursor; actual link decisions are made in `textView(_:clickedOnLink:at:)`.
- Editing assistance disabled because preview should not spellcheck or complete.

## Diff/merge pane settings

Diff panes prioritize monospace alignment, horizontal scrolling, row metadata, and read-only behavior unless used as merge output.

Key settings:

- Custom subclass `DiffTextView`.
- `isRichText = false` for plain code/text display, but content is still installed as `NSAttributedString` for colors.
- `font = Theme.editorFont`.
- `textContainerInset = NSSize(width: 4, height: 4)`.
- Horizontal scrolling/no wrapping: `isHorizontallyResizable = true`, `textContainer.widthTracksTextView = false`, and `containerSize.width = greatestFiniteMagnitude`.
- Editable flag controls undo and Escape-key behavior.

## No-wrap TextKit checklist

For code/diff panes with horizontal scrolling:

1. `scrollView.hasHorizontalScroller = true`.
2. `textView.isHorizontallyResizable = true`.
3. `textView.maxSize.width = CGFloat.greatestFiniteMagnitude`.
4. `textView.textContainer?.widthTracksTextView = false`.
5. `textView.textContainer?.containerSize.width = CGFloat.greatestFiniteMagnitude`.
6. Keep line-fragment assumptions aligned with the no-wrap choice.

## Read-only interaction checklist

For preview/diff views:

- Set `isEditable = false`.
- Keep `isSelectable = true` if copy/select is desired.
- Override or delegate link/key behavior where AppKit defaults conflict with app commands.
- Disable automatic text transformations.

## Updating content

- Use `textStorage?.setAttributedString(...)` when replacing a rendered preview/diff pane.
- Preserve scroll origin if the replacement is a re-render of equivalent content.
- Reset any row metadata and rulers at the same time as the attributed string.
- After replacing content, geometry-dependent operations should run after layout completion or call `ensureLayout(for:)`.
