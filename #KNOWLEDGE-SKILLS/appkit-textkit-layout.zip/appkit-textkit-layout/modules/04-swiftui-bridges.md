# SwiftUI ↔ AppKit Bridges

The source uses `NSViewRepresentable` to place AppKit views inside SwiftUI while keeping AppKit responsible for text editing and layout.

## Bridge lifecycle

- `makeCoordinator()` creates an object that owns delegates, observers, debouncers, and bridge state.
- `makeNSView(context:)` constructs and configures AppKit views once.
- `updateNSView(_:context:)` synchronizes settings or external commands, but should avoid full text churn.

## Editor bridge principle

The MackDown editor deliberately avoids a `@Binding var text` that updates every keystroke. The editor owns live text in `NSTextView`. The coordinator pushes text to app state with a debounce and saves the last main-thread snapshot for view disappearance.

This prevents SwiftUI invalidation from becoming the typing hot path.

## Preview bridge principle

The MackDown preview receives a new `NSAttributedString` when markdown renders. It compares object identity with `lastAttributedString` to skip redundant re-installs. When content changes, it captures scroll origin, installs the attributed string, and restores scroll after layout completes.

## Virtualized table bridge principle

MacGit wraps an `NSTableView` in `NSScrollView` for diff previews. The coordinator is the table data source/delegate and stores the visual model. `updateNSView` only reloads the table when item counts change.

## Coordinator responsibilities

A coordinator may safely own:

- `NSTextViewDelegate`, `NSTextStorageDelegate`, `NSLayoutManagerDelegate`, `NSTableViewDataSource`, or `NSTableViewDelegate` conformance.
- Weak references to AppKit views.
- Debounce work items.
- KVO observations, notification observers, and Combine cancellables.
- Generation counters for asynchronous work.

It should not create retain cycles with views, windows, publishers, or panels.

## SwiftUI update pitfalls

- Do not install full text in `updateNSView` on each keystroke.
- Do not assume `updateNSView` means content changed; it can be called for unrelated environment/state changes.
- Avoid re-creating AppKit views to apply appearance settings; mutate existing view properties.
- Keep AppKit delegate callbacks from echoing programmatic text assignments back into SwiftUI state.

## External text push pattern

For load/reload/toggle/clear operations:

1. Push text through an explicit publisher or command channel.
2. Set an `isInitialLoad` or `isApplyingExternalText` flag.
3. Replace `textView.string` or `textStorage` content.
4. Update coordinator cache (`lastText`).
5. Restore selection based on line/UTF-16 offsets if needed.
6. Clear the flag.
7. Schedule full syntax highlight asynchronously.

## AppKit identity rule

When a SwiftUI view wraps an AppKit text view, the AppKit view is the durable identity. Use the coordinator to bridge state; do not let transient SwiftUI value updates destroy text storage, undo state, selection, or scroll position.
