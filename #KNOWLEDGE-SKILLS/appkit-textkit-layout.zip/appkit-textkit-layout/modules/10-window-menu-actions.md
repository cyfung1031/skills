# Window, Menu, and App Actions

The source contains conventional AppKit app-shell code around editor/diff panes.

## App delegate responsibilities

App delegates initialize menu/window infrastructure, support secure state restoration, decide termination behavior after last window closes, and handle reopen events.

## Window manager responsibilities

The window manager opens welcome screens, new comparison panels, file diff windows, folder compare windows, merge windows, and sessions. It tracks controllers so windows remain retained while open and removes them on `windowWillClose`.

## Window presentation pattern

- Create an `NSViewController` or `NSHostingController`.
- Create `NSWindow(contentViewController:)`.
- Configure title, frame, toolbar/titlebar style if needed.
- Wrap in `NSWindowController` and retain it.
- Set delegate for lifecycle cleanup.
- Optionally add as tab to a host window.

## Menus

Main menu construction is programmatic. Menu items target the responder chain for commands such as close, fullscreen, navigation, refresh, save session, generate patch, and app actions.

Use `NSMenuItemValidation` in controllers to enable/disable actions based on current state.

## Panels and pickers

File actions use `NSOpenPanel`, `NSSavePanel`, and `NSAlert` with sheet presentation when a window is available. Prefer sheet modal for window-scoped errors.

## Responder-chain commands

Custom views/controllers send actions such as `goBack:` via `NSApp.sendAction` or expose `@objc` methods for menu/toolbar buttons. This lets keyboard/menu commands find the active controller without hard references.

## Agent rules

- When adding a command, define selector, button/menu item, validation, and responder-chain behavior together.
- Keep windows/controllers retained until close.
- Use sheet presentation when a source window exists.
- Avoid mixing SwiftUI sheet state with AppKit windows for the editor-heavy screens unless ownership is explicit.
