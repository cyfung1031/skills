# Performance and Threading

The source repeatedly optimizes for large text files, markdown documents, and diffs.

## Avoid SwiftUI text churn

The live editor owns text in `NSTextView`. App state receives debounced snapshots. This avoids copying full document strings through SwiftUI on every keystroke.

## Non-contiguous layout

`allowsNonContiguousLayout = true` lets the layout manager typeset visible glyphs first. It is especially useful for large documents where first paint matters more than complete layout.

## Avoid zero-width containers

The editor pre-sizes the scroll view so the text container has a real width before assigning the initial string. A zero-width container can produce pathological layout such as one line fragment per character.

## Off-main work

Safe off-main work in this source:

- parsing/diffing text files,
- building display models,
- constructing `NSAttributedString` content before it is installed,
- collecting syntax tokens from an immutable string snapshot,
- detecting file encodings or binary/hex data.

Unsafe off-main work:

- reading or mutating `NSTextStorage`,
- calling AppKit view methods,
- changing windows/menus/controls,
- applying attributes to live storage.

## Batch mutation

Wrap large `NSTextStorage` attribute changes in `beginEditing`/`endEditing`. This coalesces layout invalidation and delegate notifications.

## Generation counters

Every async result that can be superseded needs a generation or cancellation check. The highlighter uses `highlightGeneration`; diff loading uses task/generation style patterns in controllers.

## Memory control

Binary compare reads a capped amount for hex rendering while retaining true file size for status. This prevents the UI from mapping very large binaries into memory just to render a preview.

## Virtualization

MacGit avoids rendering huge diffs as a single SwiftUI stack by using `NSTableView` and a visual line cap. Table row reuse and deterministic heights are central to responsiveness.

## Performance smell checklist

- Full string copied every keystroke.
- Full document layout forced before first paint.
- Attribute application outside `beginEditing`/`endEditing`.
- Stale async syntax results apply after newer edits.
- Geometry queries run before layout or with zero-width container.
- Diff/render work done directly in `viewDidLoad` on main.
- Recreating row views instead of reusing AppKit identifiers.
