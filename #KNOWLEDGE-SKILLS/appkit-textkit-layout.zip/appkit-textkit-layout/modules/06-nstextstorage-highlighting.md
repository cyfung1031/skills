# NSTextStorage Delegate and Syntax Highlighting

The MackDown editor combines immediate paragraph highlighting with debounced background full-document highlighting.

## Why both paths exist

- Immediate inline pass: gives visible feedback near the edit without scanning the full file.
- Debounced full pass: corrects multi-line constructs such as fenced code blocks and applies global tokens after typing settles.

## Delegate entry point

`textStorage(_:didProcessEditing:range:changeInLength:)` is used because it receives the edited character range after TextKit has processed changes. The code only reacts to `.editedCharacters`.

## Initial/programmatic load suppression

During initial load or external text replacement, the coordinator sets `isInitialLoad` to suppress synchronous highlight and text-change echo. Full highlighting is then scheduled separately.

Use the same guard for reloads, toggle operations, and programmatic formatting actions.

## Immediate paragraph pass

The source computes an `NSString` paragraph range around the edit location. If the paragraph or document contains backticks/fences, it expands the scan window so code-block context is not temporarily stripped until the full pass runs.

This is a practical compromise: markdown tokens can depend on surrounding lines, but scanning the whole document on every keystroke is too expensive.

## Background full pass

The source snapshots the string with `String(textStorage.string)` before dispatching. This avoids aliasing live `NSTextStorage` backing memory on a background thread.

The background queue computes tokens only. The main queue checks a generation counter, then applies attributes inside `beginEditing` / `endEditing`.

## Generation counter

Every scheduled highlight increments `highlightGeneration`. When a background result completes, it only applies if its generation is still current. This prevents stale syntax results from overwriting newer edits.

## Debouncing

Typing schedules a full pass after a delay. New edits cancel the old work item. External load/reload uses zero delay because text is already visible and full highlighting should begin immediately.

## Undo/redo handling

Undo/redo has native cursor behavior. Avoid custom cursor offset math unless absolutely necessary. The inspected code records edit location/delta but explicitly avoids fighting AppKit undo selection placement.

## Rules for agents

- Never run token collection by reading `NSTextStorage` on a background thread.
- Snapshot text on main first.
- Apply to `NSTextStorage` only on main.
- Wrap batch mutations in `beginEditing`/`endEditing`.
- Use generation checks for every async text analysis result.
- Suppress delegate echo during programmatic replacements.
- Keep a cached `lastText` updated on main if deinit/disappear needs content.
