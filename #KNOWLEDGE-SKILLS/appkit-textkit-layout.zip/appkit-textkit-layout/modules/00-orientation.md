# Orientation

This skill was built by inspecting 72 Swift source files from the uploaded MacGit, MackDown, and MacMerge source archives. It is intentionally modular: `SKILL.md` is only an index, while the detailed domain knowledge lives in modules and generated references.

## What the source code teaches

The codebase contains three overlapping AppKit/TextKit domains:

1. **MackDown editor and preview**: a SwiftUI app embeds AppKit `NSTextView` in `NSViewRepresentable`. The live editor owns its text inside `NSTextView` rather than pushing every keystroke through SwiftUI bindings. The preview manually builds a TextKit 1 stack so a custom `MarkdownLayoutManager` can draw full-width markdown block backgrounds and inline-code capsules.
2. **MacMerge diff and merge UI**: pure AppKit controllers construct panes with `NSStackView`, `NSScrollView`, `DiffTextView`, custom `NSRulerView`, an overview strip, and synchronized scrolling. Diff panes precompute `NSAttributedString`, row start offsets, line-number labels, and row background metadata.
3. **MacGit virtualized diff preview**: a SwiftUI app uses an `NSViewRepresentable` wrapper around `NSTableView` for scalable diff previews, reusable row views, layer backgrounds, monospaced labels, and AppKit constraints inside table cells.

## Open these modules by task

- Need to change custom `NSLayoutManager` painting? Open `modules/02-nslayoutmanager-custom-drawing.md` and `reference/api-glossary.generated.md`.
- Need to fix text editor lag or syntax highlighting? Open `modules/06-nstextstorage-highlighting.md` and `modules/11-performance-threading.md`.
- Need to add line numbers, row backgrounds, or diff navigation? Open `modules/07-diff-textview-rulers.md` and `modules/08-scrolling-and-geometry.md`.
- Need to embed AppKit in SwiftUI? Open `modules/04-swiftui-bridges.md`.
- Need source-specific symbols and exact locations? Open `reference/source-map.generated.md` or `reference/appkit-callsite-atlas.generated.md`.

## Mental model

Treat TextKit 1 as a pipeline:

`NSTextStorage` stores characters + attributes → `NSLayoutManager` turns characters into glyphs and line fragments → `NSTextContainer` defines layout geometry → `NSTextView` displays/interacts → `NSScrollView` clips and scrolls.

The inspected apps intentionally keep expensive work out of the display path. They precompute attributed strings or syntax tokens, mutate `NSTextStorage` only on the main thread, use TextKit geometry only after layout is ensured, and keep per-row metadata separate from inline attributes when drawing full-width backgrounds.
