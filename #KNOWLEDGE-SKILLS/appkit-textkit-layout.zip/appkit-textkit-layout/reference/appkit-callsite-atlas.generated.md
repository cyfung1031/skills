# AppKit/TextKit Callsite Atlas (Generated)

Every entry is a source-derived callsite/context snippet. Use this when an agent needs exact local idioms or filenames.


## `AnyCancellable` (2 hits)


### `MackDown/Sources/MackDownApp/MackDownApp.swift` L175

```swift
173:     private(set) var currentURL: URL?
174:     private var fileWatcher: FileWatcher?
175:     private var willChangeSink: AnyCancellable?
176: 
177:     // Pushes text into the editor view without a SwiftUI round-trip (R-0048-02).
```

Agent note: `AnyCancellable` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L171

```swift
169:         private var debounceTimer: DispatchWorkItem?
170:         // Subscription to AppState.externalTextPublisher for load/reload/toggle/clear.
171:         private var externalTextSink: AnyCancellable?
172:         // Background highlight coordination (R-0049-01/02).
173:         // Incremented on each background highlight dispatch; stale completions compare and bail.
```

Agent note: `AnyCancellable` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `AppKit` (30 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L1

```swift
1: import AppKit
2: import SwiftUI
3: import MacGitCore
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1

```swift
1: import AppKit
2: import SwiftUI
3: import UniformTypeIdentifiers
```

Agent note: `AppKit` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1695

```swift
1693: @MainActor
1694: private final class DiffPreviewModel: ObservableObject {
1695:     // R-0038-04 / R-0039-01: cap for SwiftUI path; AppKit path uses visualMaxLines.
1696:     nonisolated static let maxLines = 2000
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
```

Agent note: `AppKit` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1697

```swift
1695:     // R-0038-04 / R-0039-01: cap for SwiftUI path; AppKit path uses visualMaxLines.
1696:     nonisolated static let maxLines = 2000
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
1698:     nonisolated static let visualMaxLines = 50_000
1699:     // Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.
```

Agent note: `AppKit` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1699

```swift
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
1698:     nonisolated static let visualMaxLines = 50_000
1699:     // Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.
1700:     nonisolated static let swiftUIThreshold = 500
1701: 
```

Agent note: `AppKit` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2067

```swift
2065: }
2066: 
2067: // MARK: - Phase 6: Virtualized diff renderer (AppKit NSTableView for large visual diffs)
2068: 
2069: private struct VirtualizedDiffView: NSViewRepresentable {
```

Agent note: `AppKit` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/DiffCore/DiffTypes.swift` L1

```swift
1: /// DiffCore — pure diff engine. No AppKit, no I/O. (SPEC §11.1)
2: 
3: public enum DiffAlgorithm: String, Sendable, Codable, CaseIterable {
```

Agent note: `AppKit` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/AppDelegate.swift` L1

```swift
1: import AppKit
2: import SessionKit
3: 
```

Agent note: `AppKit` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L1

```swift
1: import AppKit
2: 
3: /// NSTextView (TextKit 1) with full-width row background painting and a
```

Agent note: `AppKit` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L1

```swift
1: import AppKit
2: import DiffCore
3: import TextEngine
```

Agent note: `AppKit` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L1

```swift
1: import AppKit
2: 
3: /// Whole-document map of change positions on the trailing edge (SPEC §5.3).
```

Agent note: `AppKit` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L1

```swift
1: import AppKit
2: import DiffCore
3: import TextEngine
```

Agent note: `AppKit` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L1

```swift
1: import AppKit
2: import FolderCompareKit
3: import SessionKit
```

Agent note: `AppKit` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/MacMergeApp.swift` L1

```swift
1: import AppKit
2: 
3: // SwiftPM executable entry point — no nib, no storyboard, no Xcode project.
```

Agent note: `AppKit` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L1

```swift
1: import AppKit
2: import DiffCore
3: import TextEngine
```

Agent note: `AppKit` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L1

```swift
1: import AppKit
2: import SessionKit
3: import UniformTypeIdentifiers
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L1

```swift
1: import AppKit
2: 
3: /// Programmatic menu bar (SPEC §6). Every command lives here; comparison
```

Agent note: `AppKit` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L1

```swift
1: import AppKit
2: import SyntaxKit
3: 
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L1

```swift
1: import AppKit
2: import SwiftUI
3: import SessionKit
```

Agent note: `AppKit` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L1

```swift
1: import AppKit
2: import SwiftUI
3: 
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L1

```swift
1: import AppKit
2: import SwiftUI
3: 
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L1

```swift
1: import AppKit
2: import Combine
3: import SwiftUI
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L1

```swift
1: import AppKit
2: import Markdown
3: 
```

Agent note: `AppKit` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L4

```swift
2: import Markdown
3: 
4: // Resolve name conflicts with AppKit
5: typealias MDText  = Markdown.Text
6: typealias MDLink  = Markdown.Link
```

Agent note: `AppKit` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L1

```swift
1: import AppKit
2: import Combine
3: import SwiftUI
```

Agent note: `AppKit` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L332

```swift
330:             // Cache current text on main thread for safe use in deinit (R-0050-03).
331:             lastText = tv.string
332:             // For undo/redo, rely on AppKit's native cursor placement via the undo stack
333:             // (shouldChangeText registers cursor state). Custom offset math conflicts with
334:             // programmatic format replacements and causes incorrect shifts (R-0050-01).
```

Agent note: `AppKit` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L1

```swift
1: import AppKit
2: import SwiftUI
3: 
```

Agent note: `AppKit` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L1

```swift
1: import AppKit
2: 
3: // MARK: - Token type (produced by background thread, consumed on main thread)
```

Agent note: `AppKit` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L1

```swift
1: import AppKit
2: 
3: // MARK: - Theme
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L1

```swift
1: import AppKit
2: import SwiftUI
3: 
```

Agent note: `AppKit` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `DispatchQueue` (18 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2120

```swift
2118:             tableView = tv
2119:             appearanceObservation = NSApp.observe(\.effectiveAppearance) { [weak self] _, _ in
2120:                 DispatchQueue.main.async { self?.tableView?.reloadData() }
2121:             }
2122:         }
```

Agent note: `DispatchQueue` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/GitClient.swift` L98

```swift
96:         let errReader = PipeDrain(stderr.fileHandleForReading, maxBytes: 256 * 1024)
97:         let drainGroup = DispatchGroup()
98:         let drainQueue = DispatchQueue(label: "local.macgit.git.pipe-drain", attributes: .concurrent)
99:         drainQueue.async(group: drainGroup) { outReader.read() }
100:         drainQueue.async(group: drainGroup) { errReader.read() }
```

Agent note: `DispatchQueue` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L93

```swift
91:         }
92: 
93:         FSEventStreamSetDispatchQueue(fsStream, DispatchQueue.global(qos: .background))
94:         FSEventStreamStart(fsStream)
95:         self.stream = fsStream
```

Agent note: `DispatchQueue` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/GitSupport/Git.swift` L86

```swift
84:         let group = DispatchGroup()
85:         group.enter()
86:         DispatchQueue.global().async {
87:             stdout = out.fileHandleForReading.readDataToEndOfFile()
88:             group.leave()
```

Agent note: `DispatchQueue` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/GitSupport/Git.swift` L91

```swift
89:         }
90:         group.enter()
91:         DispatchQueue.global().async {
92:             stderr = err.fileHandleForReading.readDataToEndOfFile()
93:             group.leave()
```

Agent note: `DispatchQueue` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L243

```swift
241:         subtreePassCache.removeAll()
242:         flatCache = nil
243:         DispatchQueue.main.async { [weak self] in
244:             guard let self else { return }
245:             self.outline.reloadData()
```

Agent note: `DispatchQueue` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/FileWatcher.swift` L58

```swift
56:         }
57:         debounce = work
58:         DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: work)
59:     }
60: }
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/ContentView.swift` L36

```swift
34:             _ = provider.loadObject(ofClass: URL.self) { url, _ in
35:                 guard let url, isMarkdownURL(url) else { return }
36:                 DispatchQueue.main.async { appState.load(url: url) }
37:             }
38:             return true
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L458

```swift
456:         let t_dispatch   = CFAbsoluteTimeGetCurrent()
457:         benchLog("[BENCH] updateBlocksAsync dispatched chars=\(source.count) gen=\(gen)")
458:         DispatchQueue.main.async { benchLog(String(format: "[BENCH] main-next-idle Δ=%.1fms", (CFAbsoluteTimeGetCurrent()-t_dispatch)*1000)) }
459:         DispatchQueue.global(qos: .userInitiated).async { [weak self] in
460:             let t0   = CFAbsoluteTimeGetCurrent()
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L459

```swift
457:         benchLog("[BENCH] updateBlocksAsync dispatched chars=\(source.count) gen=\(gen)")
458:         DispatchQueue.main.async { benchLog(String(format: "[BENCH] main-next-idle Δ=%.1fms", (CFAbsoluteTimeGetCurrent()-t_dispatch)*1000)) }
459:         DispatchQueue.global(qos: .userInitiated).async { [weak self] in
460:             let t0   = CFAbsoluteTimeGetCurrent()
461:             let attr = parseAttributed(from: source, appearance: appearance, baseURL: baseURL)
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L466

```swift
464:             let t1   = CFAbsoluteTimeGetCurrent()
465:             benchLog(String(format: "[BENCH] parseAttributed=%.1fms wc=%d gen=%d", (t1-t0)*1000, wc, gen))
466:             DispatchQueue.main.async {
467:                 guard let self, self.parseGeneration == gen else { return }
468:                 let t2 = CFAbsoluteTimeGetCurrent()
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L538

```swift
536:         fileWatcher?.stop()
537:         fileWatcher = FileWatcher(url: url) { [weak self] in
538:             DispatchQueue.main.async { [weak self] in
539:                 guard let self else { return }
540:                 if self.isDirty {
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L553

```swift
551: 
552:     private func restartWatcherAfterWrite() {
553:         DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in
554:             guard let self, let u = self.currentURL else { return }
555:             self.startWatching(url: u)
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L683

```swift
681:                 lastTick = now
682:             }
683:             DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
684:                 AppState.shared.load(url: URL(fileURLWithPath: path))
685:             }
```

Agent note: `DispatchQueue` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L351

```swift
349:             }
350:             debounceTimer = work
351:             DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: work)
352:         }
353: 
```

Agent note: `DispatchQueue` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L398

```swift
396:                 let tokens = MarkdownSyntaxHighlighter.collectTokensFull(
397:                     text: text, fontSize: fontSize, family: family, enabled: enabled, colors: colors)
398:                 DispatchQueue.main.async { [weak self] in
399:                     guard let self, self.highlightGeneration == gen else { return }
400:                     guard let storage = self.textViewRef?.textStorage else { return }
```

Agent note: `DispatchQueue` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L408

```swift
406:             highlightDebounceTimer = work
407:             if delay <= 0 {
408:                 DispatchQueue.global(qos: .userInitiated).async(execute: work)
409:             } else {
410:                 DispatchQueue.global(qos: .userInitiated).asyncAfter(
```

Agent note: `DispatchQueue` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L410

```swift
408:                 DispatchQueue.global(qos: .userInitiated).async(execute: work)
409:             } else {
410:                 DispatchQueue.global(qos: .userInitiated).asyncAfter(
411:                     deadline: .now() + delay, execute: work)
412:             }
```

Agent note: `DispatchQueue` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `KVO` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L357

```swift
355:             guard let tv = notification.object as? NSTextView,
356:                   tv === textViewRef else { return }
357:             // Lazily set up first-responder KVO once the text view has a window.
358:             if firstResponderObservation == nil, let win = tv.window {
359:                 firstResponderObservation = win.observe(\.firstResponder, options: []) { [weak self] win, _ in
```

Agent note: `KVO` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `MainActor` (33 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L22

```swift
20: 
21: /// Manages the console state: lines buffer, history, running process (SPEC §3.1).
22: @MainActor
23: final class ConsoleStore: ObservableObject {
24:     @Published private(set) var lines: [ConsoleLine] = []
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L123

```swift
121:             await r.run(command) { [weak self] event in
122:                 guard let self else { return }
123:                 await MainActor.run {
124:                     switch event {
125:                     case .output(let text, let color):
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1693

```swift
1691: // MARK: - Visual Diff (M11-C)
1692: 
1693: @MainActor
1694: private final class DiffPreviewModel: ObservableObject {
1695:     // R-0038-04 / R-0039-01: cap for SwiftUI path; AppKit path uses visualMaxLines.
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1730

```swift
1728:             let (vis, visTotal) = DiffPreviewModel.buildVisual(files)
1729:             let (spl, splTotal) = DiffPreviewModel.buildSplit(files)
1730:             await MainActor.run { [weak self] in
1731:                 guard let self, self.parseGeneration == gen else { return }
1732:                 self.visualItems = vis
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2109

```swift
2107:     }
2108: 
2109:     @MainActor
2110:     final class Coordinator: NSObject, NSTableViewDataSource, NSTableViewDelegate {
2111:         var items: [DiffPreviewModel.VisualItem] = []
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2329

```swift
2327: }
2328: 
2329: @MainActor
2330: private final class FolderViewModel: ObservableObject {
2331:     @Published private(set) var rootNodes: [FileNode] = []
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2821

```swift
2819: }
2820: 
2821: @MainActor
2822: private final class RepositoryStore: ObservableObject {
2823:     struct RecentRepository: Identifiable, Equatable {
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3022

```swift
3020:             }
3021: 
3022:             Task { @MainActor in
3023:                 await self.openRepository(at: url)
3024:             }
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4115

```swift
4113: // MARK: - History View
4114: 
4115: @MainActor
4116: private final class HistoryViewModel: ObservableObject {
4117:     struct HistoryRow: Identifiable {
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4260

```swift
4258:             do {
4259:                 try text.write(to: tempURL, atomically: true, encoding: .utf8)
4260:                 _ = await MainActor.run { NSWorkspace.shared.open(tempURL) }
4261:             } catch {}
4262:         }
```

Agent note: `MainActor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L26

```swift
24: /// Listens on a UNIX domain socket in TMPDIR and dispatches edit/askpass sheets.
25: /// The socket path is written to the environment so child processes can find it.
26: @MainActor
27: final class SocketBridge: ObservableObject {
28:     /// Single-item enum so only one bridge sheet is presented at a time.
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/AppDelegate.swift` L4

```swift
2: import SessionKit
3: 
4: @MainActor
5: final class AppDelegate: NSObject, NSApplicationDelegate {
6: 
```

Agent note: `MainActor` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L268

```swift
266:             return try Self.textPayload(left: l, right: r, ignore: ignore, context: context)
267:         }
268:         reloadTask = Task { @MainActor [weak self, bg] in
269:             defer { bg.cancel() }
270:             do {
```

Agent note: `MainActor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L212

```swift
210:         let l = leftRoot, r = rightRoot
211:         let options = scanOptions
212:         scanTask = Task { @MainActor [weak self] in
213:             do {
214:                 let root = try await Task.detached(priority: .userInitiated) {
```

Agent note: `MainActor` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L410

```swift
408:         spinner.startAnimation(nil)
409:         summaryLabel.stringValue = "Working…"
410:         Task { @MainActor [weak self] in
411:             let result: Result<Void, Error> = await Task.detached(priority: .userInitiated) {
412:                 do { try operation(); return .success(()) }
```

Agent note: `MainActor` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/MacMergeApp.swift` L7

```swift
5: // binary also works for development.
6: @main
7: @MainActor
8: struct MacMergeApp {
9:     static func main() {
```

Agent note: `MainActor` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L233

```swift
231:             )
232:         }
233:         reloadTask = Task { @MainActor [weak self, bg] in
234:             defer { bg.cancel() }
235:             do {
```

Agent note: `MainActor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L6

```swift
4: 
5: /// Shared entry points used by both the menu bar and the Welcome window.
6: @MainActor
7: enum AppActions {
8: 
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L26

```swift
24: }
25: 
26: @MainActor
27: enum Pickers {
28: 
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L45

```swift
43: 
44: /// Save-panel helper for `.mmsession` documents.
45: @MainActor
46: enum SessionWriter {
47:     static func save(_ session: ComparisonSession, suggestedName: String, in window: NSWindow?) {
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/FileWatcher.swift` L11

```swift
9: /// fires. Editors that replace files (write-to-temp + rename) invalidate the
10: /// descriptor; we re-arm by re-opening the path after a short debounce.
11: @MainActor
12: final class FileWatcher {
13:     private let urls: [URL]
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/FileWatcher.swift` L14

```swift
12: final class FileWatcher {
13:     private let urls: [URL]
14:     private let onChange: @MainActor () -> Void
15:     private var sources: [DispatchSourceFileSystemObject] = []
16:     private var debounce: DispatchWorkItem?
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/FileWatcher.swift` L18

```swift
16:     private var debounce: DispatchWorkItem?
17: 
18:     init(urls: [URL], onChange: @escaping @MainActor () -> Void) {
19:         self.urls = urls
20:         self.onChange = onChange
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L6

```swift
4: /// commands use nil-target actions resolved through the responder chain to
5: /// the front tab's view controller.
6: @MainActor
7: enum MainMenu {
8: 
```

Agent note: `MainActor` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L16

```swift
14: }
15: 
16: @MainActor
17: final class WindowManager: NSObject {
18: 
```

Agent note: `MainActor` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L6

```swift
4: /// Shared state for the "New Comparison" chooser.
5: /// WindowManager holds a reference so drops on any screen fill slots sequentially (L→R→Base).
6: @MainActor
7: final class NewComparisonModel: ObservableObject {
8:     @Published var leftPath: String
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L37

```swift
35: /// an optional Base well for three-way merges. The comparison mode
36: /// (file/folder) is inferred from what was chosen, WinMerge-style.
37: @MainActor
38: struct NewComparisonView: View {
39: 
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L77

```swift
75:         .frame(width: 560)
76:         .onDrop(of: [.fileURL], isTargeted: $dropTargeted) { providers in
77:             Task { @MainActor in
78:                 for provider in providers {
79:                     if let url = await loadURL(from: provider) {
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L156

```swift
154: 
155: /// One side's path input: editable text field + Browse… + drop target.
156: @MainActor
157: private struct PathWell: View {
158:     let label: String
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L186

```swift
184:             _ = provider.loadObject(ofClass: URL.self) { url, _ in
185:                 guard let url else { return }
186:                 Task { @MainActor in
187:                     path = url.path
188:                 }
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L7

```swift
5: /// Welcome window (SPEC §5.1): actions, recents, and whole-window drop target.
6: /// Single drops fill slot A then B; two or three drops open immediately.
7: @MainActor
8: struct WelcomeView: View {
9: 
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L102

```swift
100:     private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
101:         guard !providers.isEmpty else { return false }
102:         Task { @MainActor in
103:             for provider in providers {
104:                 guard let url = await loadURL(from: provider) else { continue }
```

Agent note: `MainActor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/SessionKit/SessionKit.swift` L74

```swift
72: }
73: 
74: @MainActor
75: public final class RecentsStore: ObservableObject {
76: 
```

Agent note: `MainActor` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

## `NSAlert` (14 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L280

```swift
278:                 self.counterLabel.stringValue = "Failed to load"
279:                 self.pendingTarget = .none
280:                 let alert = NSAlert(error: error)
281:                 if let window = self.view.window {
282:                     alert.beginSheetModal(for: window, completionHandler: nil)
```

Agent note: `NSAlert` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L588

```swift
586:         guard !isHexMode, let leftDoc, let rightDoc else { NSSound.beep(); return }
587:         guard !ignoreWhitespace else {
588:             let alert = NSAlert()
589:             alert.messageText = "Patch export requires exact comparison"
590:             alert.informativeText = "Turn off \"Ignore Whitespace\" before exporting a patch."
```

Agent note: `NSAlert` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L617

```swift
615:                 try Data(patch.utf8).write(to: url, options: [.atomic])
616:             } catch {
617:                 NSAlert(error: error).runModal()
618:             }
619:         }
```

Agent note: `NSAlert` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L231

```swift
229:                 self.spinner.stopAnimation(nil)
230:                 self.summaryLabel.stringValue = "Scan failed"
231:                 NSAlert(error: error).runModal()
232:             }
233:         }
```

Agent note: `NSAlert` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L422

```swift
420:             case .failure(let error):
421:                 self.spinner.stopAnimation(nil)
422:                 NSAlert(error: error).runModal()
423:             }
424:         }
```

Agent note: `NSAlert` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L244

```swift
242:                 self.spinner.stopAnimation(nil)
243:                 self.counterLabel.stringValue = "Failed to load"
244:                 NSAlert(error: error).runModal()
245:             }
246:         }
```

Agent note: `NSAlert` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L337

```swift
335:             counterLabel.stringValue = "Saved to \(url.lastPathComponent)"
336:         } catch {
337:             NSAlert(error: error).runModal()
338:         }
339:     }
```

Agent note: `NSAlert` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L343

```swift
341:     @objc func refresh(_ sender: Any?) {
342:         if isOutputDirty {
343:             let alert = NSAlert()
344:             alert.messageText = "Discard unsaved output?"
345:             alert.informativeText = "Your edits to the merge output will be lost."
```

Agent note: `NSAlert` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L58

```swift
56:                 try session.write(to: url)
57:             } catch {
58:                 NSAlert(error: error).runModal()
59:             }
60:         }
```

Agent note: `NSAlert` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L171

```swift
169:             }
170:         } catch {
171:             NSAlert(error: error).runModal()
172:         }
173:     }
```

Agent note: `NSAlert` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L230

```swift
228: 
229:     private func presentMessage(_ message: String) {
230:         let alert = NSAlert()
231:         alert.messageText = "MacMerge"
232:         alert.informativeText = message
```

Agent note: `NSAlert` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L229

```swift
227:     func confirmDiscardIfDirty(then proceed: () -> Void) {
228:         guard isDirty else { proceed(); return }
229:         let alert = NSAlert()
230:         alert.messageText = "Save changes to \"\(filename)\"?"
231:         alert.informativeText = "Your changes will be lost if you don't save them."
```

Agent note: `NSAlert` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L366

```swift
364:         } catch {
365:             restartWatcherAfterWrite()
366:             let alert = NSAlert()
367:             alert.alertStyle = .critical
368:             alert.messageText = "Could not save \"\(filename)\""
```

Agent note: `NSAlert` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L430

```swift
428:             } catch {
429:                 restartWatcherAfterWrite()
430:                 let alert = NSAlert()
431:                 alert.alertStyle = .critical
432:                 alert.messageText = "Could not update \"\(filename)\""
```

Agent note: `NSAlert` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSAttributedString` (74 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L154

```swift
152:         let starts = tv.lineStartOffsets
153: 
154:         let attrs: [NSAttributedString.Key: Any] = [
155:             .font: Theme.lineNumberFont,
156:             .foregroundColor: NSColor.secondaryLabelColor,
```

Agent note: `NSAttributedString` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L9

```swift
7: /// only `textStorage.setAttributedString` happens on main. (SPEC §9)
8: struct PaneContent {
9:     var attributed: NSAttributedString
10:     var lineStartOffsets: [Int]
11:     var rowBackgrounds: [Int: NSColor]
```

Agent note: `NSAttributedString` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L125

```swift
123:     private struct Accumulator {
124:         let language: Language
125:         let baseAttributes: [NSAttributedString.Key: Any] = [
126:             .font: Theme.editorFont,
127:             .foregroundColor: NSColor.textColor,
```

Agent note: `NSAttributedString` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L145

```swift
143:             labels.append("")
144:             backgrounds[starts.count - 1] = Theme.phantomBackground
145:             let attr = NSAttributedString(string: marker + "\n", attributes: [
146:                 .font: Theme.editorFont,
147:                 .foregroundColor: NSColor.tertiaryLabelColor,
```

Agent note: `NSAttributedString` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L146

```swift
144: 
145:     // Attributed string derived from source. Updated on background queue, published on main.
146:     private(set) var parsedAttributed: NSAttributedString = NSAttributedString() {
147:         willSet { if !_isBatching { objectWillChange.send() } }
148:     }
```

Agent note: `NSAttributedString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L274

```swift
272:             batchUpdate {
273:                 source             = text
274:                 parsedAttributed   = NSAttributedString()
275:                 outlineEntries     = []
276:                 isDirty            = false
```

Agent note: `NSAttributedString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L315

```swift
313:             batchUpdate {
314:                 source             = text
315:                 parsedAttributed   = NSAttributedString()
316:                 outlineEntries     = []
317:                 isDirty            = false
```

Agent note: `NSAttributedString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L340

```swift
338:             currentURL         = nil
339:             source             = ""
340:             parsedAttributed   = NSAttributedString()
341:             outlineEntries     = []
342:             isDirty            = false
```

Agent note: `NSAttributedString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L12

```swift
10: // MARK: - Custom block-background attribute
11: 
12: extension NSAttributedString.Key {
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L13

```swift
11: 
12: extension NSAttributedString.Key {
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L14

```swift
12: extension NSAttributedString.Key {
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L15

```swift
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
17:     static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L16

```swift
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
17:     static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")
18: }
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L17

```swift
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
17:     static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")
18: }
19: 
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L33

```swift
31: }
32: 
33: // NSObject wrapper so NSAttributedString can store/copy the array safely.
34: final class MarkdownBlockLeftBorders: NSObject {
35:     let list: [MarkdownBlockLeftBorderEntry]
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L142

```swift
140: func parseAttributed(from source: String,
141:                      appearance: AppearanceSettings,
142:                      baseURL: URL? = nil) -> NSAttributedString {
143:     let theme    = MarkdownTheme.current(appearance: appearance)
144:     let renderer = MarkdownAttributedRenderer(theme: theme, baseURL: baseURL)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L165

```swift
163:     }
164: 
165:     func render(from source: String) -> NSAttributedString {
166:         let parsed = parseFrontMatter(from: source)
167:         let doc    = Document(parsing: parsed.markdownBody)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L176

```swift
174:     // MARK: - Block dispatch
175: 
176:     private func renderBlock(_ markup: any Markup) -> NSAttributedString {
177:         switch markup {
178:         case let h  as Heading:      return renderHeading(h)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L204

```swift
202:     }
203: 
204:     private func renderInline(_ markup: any Markup) -> NSAttributedString {
205:         switch markup {
206:         case let t  as MDText:        return NSAttributedString(string: t.string)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L206

```swift
204:     private func renderInline(_ markup: any Markup) -> NSAttributedString {
205:         switch markup {
206:         case let t  as MDText:        return NSAttributedString(string: t.string)
207:         case is SoftBreak:            return NSAttributedString(string: " ")
208:         case is LineBreak:            return NSAttributedString(string: "\n")
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L207

```swift
205:         switch markup {
206:         case let t  as MDText:        return NSAttributedString(string: t.string)
207:         case is SoftBreak:            return NSAttributedString(string: " ")
208:         case is LineBreak:            return NSAttributedString(string: "\n")
209:         case let s  as Strong:        return applyBold(renderInlines(s))
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L208

```swift
206:         case let t  as MDText:        return NSAttributedString(string: t.string)
207:         case is SoftBreak:            return NSAttributedString(string: " ")
208:         case is LineBreak:            return NSAttributedString(string: "\n")
209:         case let s  as Strong:        return applyBold(renderInlines(s))
210:         case let em as Emphasis:      return applyItalic(renderInlines(em))
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L215

```swift
213:         case let lk as MDLink:        return renderLink(lk)
214:         case let img as MDImage:      return renderImage(img)
215:         case let ih as InlineHTML:    return NSAttributedString(string: ih.rawHTML)
216:         default:
217:             let out = NSMutableAttributedString()
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L225

```swift
223:     // MARK: - Heading
224: 
225:     private func renderHeadingRule() -> NSAttributedString {
226:         let para = NSMutableParagraphStyle()
227:         para.paragraphSpacingBefore = 0
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L232

```swift
230:         // so the colored band covers only the ~font-height, not the post-rule gap.
231:         let bg = MarkdownBlockBackground(color: theme.hrColor, borderColor: nil, topInset: 0, bottomInset: 18)
232:         return NSAttributedString(string: " \n", attributes: [
233:             .font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.3, 5)),
234:             .foregroundColor:         NSColor.clear,
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L240

```swift
238:     }
239: 
240:     private func renderHeading(_ heading: Heading) -> NSAttributedString {
241:         let level  = heading.level
242:         let font   = theme.headingFont(level: level)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L255

```swift
253:         let inner = renderInlines(heading)
254:         let result = NSMutableAttributedString(attributedString: inner)
255:         result.append(NSAttributedString(string: "\n"))
256:         let all = NSRange(location: 0, length: result.length)
257:         result.addAttributes([.font: font, .foregroundColor: color, .paragraphStyle: para], range: all)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L265

```swift
263:     // MARK: - Paragraph
264: 
265:     private func renderParagraph(_ paragraph: Paragraph) -> NSAttributedString {
266:         let inner  = renderInlines(paragraph)
267:         let result = NSMutableAttributedString(attributedString: inner)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L268

```swift
266:         let inner  = renderInlines(paragraph)
267:         let result = NSMutableAttributedString(attributedString: inner)
268:         result.append(NSAttributedString(string: "\n"))
269:         let all  = NSRange(location: 0, length: result.length)
270:         let para = bodyParagraphStyle()
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L278

```swift
276:     // MARK: - Code block
277: 
278:     private func renderCodeBlock(_ block: CodeBlock) -> NSAttributedString {
279:         let code = block.code.hasSuffix("\n") ? String(block.code.dropLast()) : block.code
280:         return renderCodeBlock(language: block.language, code: code)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L283

```swift
281:     }
282: 
283:     private func renderCodeBlock(language: String?, code: String) -> NSAttributedString {
284:         let bg  = MarkdownBlockBackground(color: theme.codeBlockBackground,
285:                                           borderColor: theme.codeBlockBorderColor)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L340

```swift
338:     // MARK: - Block quote
339: 
340:     private func renderBlockQuote(_ blockQuote: BlockQuote, depth: Int) -> NSAttributedString {
341:         let result = NSMutableAttributedString()
342:         for child in blockQuote.children {
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L382

```swift
380:     // MARK: - Lists
381: 
382:     private func renderUnorderedList(_ list: UnorderedList, depth: Int) -> NSAttributedString {
383:         let hasCheckboxes = list.children.contains { ($0 as? ListItem)?.checkbox != nil }
384:         let result = NSMutableAttributedString()
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L394

```swift
392:     }
393: 
394:     private func renderOrderedList(_ list: OrderedList, depth: Int) -> NSAttributedString {
395:         let result = NSMutableAttributedString()
396:         let start  = Int(list.startIndex)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L404

```swift
402:     }
403: 
404:     private func renderBulletItem(_ item: ListItem, depth: Int) -> NSAttributedString {
405:         let result = NSMutableAttributedString()
406:         let para   = listParagraphStyle(depth: depth, bulletWidth: 16)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L407

```swift
405:         let result = NSMutableAttributedString()
406:         let para   = listParagraphStyle(depth: depth, bulletWidth: 16)
407:         let baseAttrs: [NSAttributedString.Key: Any] = [
408:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
409:         ]
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L415

```swift
413:                 let str = NSMutableAttributedString()
414:                 if firstPara {
415:                     str.append(NSAttributedString(string: "•\t",
416:                         attributes: [.font: theme.bodyFont, .foregroundColor: theme.secondaryTextColor]))
417:                     firstPara = false
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L420

```swift
418:                 }
419:                 str.append(renderInlines(p))
420:                 str.append(NSAttributedString(string: "\n"))
421:                 str.addAttributes(baseAttrs, range: NSRange(location: 0, length: str.length))
422:                 result.append(str)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L432

```swift
430:     }
431: 
432:     private func renderOrderedItem(_ item: ListItem, number: Int, depth: Int) -> NSAttributedString {
433:         let result = NSMutableAttributedString()
434:         let para   = listParagraphStyle(depth: depth, bulletWidth: 28)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L435

```swift
433:         let result = NSMutableAttributedString()
434:         let para   = listParagraphStyle(depth: depth, bulletWidth: 28)
435:         let baseAttrs: [NSAttributedString.Key: Any] = [
436:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
437:         ]
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L443

```swift
441:                 let str = NSMutableAttributedString()
442:                 if firstPara {
443:                     str.append(NSAttributedString(string: "\(number).\t",
444:                         attributes: [.font: theme.bodyFont, .foregroundColor: theme.secondaryTextColor]))
445:                     firstPara = false
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L448

```swift
446:                 }
447:                 str.append(renderInlines(p))
448:                 str.append(NSAttributedString(string: "\n"))
449:                 str.addAttributes(baseAttrs, range: NSRange(location: 0, length: str.length))
450:                 result.append(str)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L460

```swift
458:     }
459: 
460:     private func renderTaskItem(_ item: ListItem) -> NSAttributedString {
461:         let isChecked = item.checkbox == .checked
462:         let lineNum   = item.range?.lowerBound.line ?? 0
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L467

```swift
465: 
466:         let para = listParagraphStyle(depth: 0, bulletWidth: 22)
467:         let baseAttrs: [NSAttributedString.Key: Any] = [
468:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
469:         ]
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L470

```swift
468:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
469:         ]
470:         let cbAttrs: [NSAttributedString.Key: Any] = [
471:             .link:           toggleURL,
472:             .foregroundColor: isChecked ? theme.linkColor : theme.secondaryTextColor,
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L477

```swift
475: 
476:         let result = NSMutableAttributedString()
477:         result.append(NSAttributedString(string: checkChar + "\t", attributes: cbAttrs))
478:         for child in item.children {
479:             guard let p = child as? Paragraph else { continue }
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L491

```swift
489:             break
490:         }
491:         result.append(NSAttributedString(string: "\n"))
492:         result.addAttributes(baseAttrs, range: NSRange(location: 0, length: result.length))
493:         // Re-apply checkbox link attributes (overrides baseAttrs on first two chars)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L500

```swift
498:     // MARK: - Table
499: 
500:     private func renderTable(_ table: MDTable) -> NSAttributedString {
501:         let alignments = table.columnAlignments
502:         var headers: [MDTable.Cell] = []
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L514

```swift
512:         }
513:         let colCount = max(headers.count, rows.first?.count ?? 0)
514:         guard colCount > 0 else { return NSAttributedString() }
515: 
516:         let nsTable = NSTextTable()
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L567

```swift
565:                     .paragraphStyle: cellPara
566:                 ], range: NSRange(location: 0, length: content.length))
567:                 content.append(NSAttributedString(string: "\n"))
568:                 output.append(content)
569:             }
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L571

```swift
569:             }
570:         }
571:         output.append(NSAttributedString(string: "\n", attributes: [.font: theme.bodyFont]))
572:         return output
573:     }
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L577

```swift
575:     // MARK: - Thematic break
576: 
577:     private func renderThematicBreak() -> NSAttributedString {
578:         let para = NSMutableParagraphStyle()
579:         para.paragraphSpacingBefore = 12
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L584

```swift
582:         // Colored band covers only the font line height between the two spacing regions.
583:         let bg = MarkdownBlockBackground(color: theme.hrColor, borderColor: nil, topInset: 12, bottomInset: 12)
584:         return NSAttributedString(string: " \n", attributes: [
585:             .font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.4, 6)),
586:             .foregroundColor:         NSColor.clear,
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L594

```swift
592:     // MARK: - Front matter
593: 
594:     private func renderFrontMatter(_ fm: FrontMatter) -> NSAttributedString {
595:         let bg  = MarkdownBlockBackground(color: theme.frontMatterBackground,
596:                                           borderColor: theme.tableBorderColor)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L610

```swift
608:                 .markdownBlockBackground: bg
609:             ])
610:             line.append(NSAttributedString(string: value + "\n", attributes: [
611:                 .font:                    mono,
612:                 .foregroundColor:         theme.frontMatterTextColor,
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L618

```swift
616:             result.append(line)
617:         }
618:         result.append(NSAttributedString(string: "\n", attributes: [.font: theme.bodyFont]))
619:         return result
620:     }
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L624

```swift
622:     // MARK: - Inline formatting
623: 
624:     private func applyBold(_ str: NSMutableAttributedString) -> NSAttributedString {
625:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
626:             let f    = (val as? NSFont) ?? theme.bodyFont
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L633

```swift
631:     }
632: 
633:     private func applyItalic(_ str: NSMutableAttributedString) -> NSAttributedString {
634:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
635:             let f      = (val as? NSFont) ?? theme.bodyFont
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L644

```swift
642:     }
643: 
644:     private func applyStrikethrough(_ str: NSMutableAttributedString) -> NSAttributedString {
645:         str.addAttribute(.strikethroughStyle, value: NSUnderlineStyle.single.rawValue,
646:                          range: NSRange(location: 0, length: str.length))
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L650

```swift
648:     }
649: 
650:     private func renderInlineCode(_ code: InlineCode) -> NSAttributedString {
651:         NSAttributedString(string: code.code, attributes: [
652:             .font:               theme.codeFont,
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L651

```swift
649: 
650:     private func renderInlineCode(_ code: InlineCode) -> NSAttributedString {
651:         NSAttributedString(string: code.code, attributes: [
652:             .font:               theme.codeFont,
653:             .foregroundColor:    theme.codeTextColor,
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L658

```swift
656:     }
657: 
658:     private func renderLink(_ link: MDLink) -> NSAttributedString {
659:         let inner  = renderInlines(link)
660:         let result = NSMutableAttributedString(attributedString: inner)
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L670

```swift
668:     }
669: 
670:     private func renderImage(_ image: MDImage) -> NSAttributedString {
671:         if let src = image.source,
672:            !src.hasPrefix("http://"), !src.hasPrefix("https://"),
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L687

```swift
685:                                            size: CGSize(width:  natural.width  * scale,
686:                                                         height: natural.height * scale))
687:                 return NSAttributedString(attachment: attachment)
688:             }
689:         }
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L691

```swift
689:         }
690:         let alt = image.title ?? image.plainText
691:         return NSAttributedString(string: alt.isEmpty ? "🖼" : "[\(alt)]", attributes: [
692:             .foregroundColor: theme.secondaryTextColor,
693:             .font:            theme.bodyFont
```

Agent note: `NSAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L7

```swift
5: 
6: struct MarkdownPreviewTextView: NSViewRepresentable {
7:     let attributedString:  NSAttributedString
8:     let onToggleCheckbox:  (Int) -> Void
9:     let onRelativeLink:    ((URL) -> Void)?
```

Agent note: `NSAttributedString` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L12

```swift
10:     let outlineJump:       MarkdownOutlineJump?
11: 
12:     init(attributedString: NSAttributedString,
13:          onToggleCheckbox: @escaping (Int) -> Void,
14:          onRelativeLink: ((URL) -> Void)? = nil,
```

Agent note: `NSAttributedString` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L110

```swift
108:         weak var textViewRef:         NSTextView?
109:         weak var scrollViewRef:       NSScrollView?
110:         weak var lastAttributedString: NSAttributedString?
111:         var pendingScrollOrigin:       NSPoint? = nil
112:         var lastOutlineJumpID:         UUID?
```

Agent note: `NSAttributedString` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L7

```swift
5: struct SyntaxToken {
6:     let range: NSRange
7:     let attributes: [NSAttributedString.Key: Any]
8: }
9: 
```

Agent note: `NSAttributedString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L261

```swift
259:         _ ns: NSString,
260:         _ range: NSRange,
261:         attrs: [NSAttributedString.Key: Any],
262:         into tokens: inout [SyntaxToken]
263:     ) {
```

Agent note: `NSAttributedString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L275

```swift
273:         _ ns: NSString,
274:         _ range: NSRange,
275:         contentAttrs: [NSAttributedString.Key: Any],
276:         delimLen: Int,
277:         into tokens: inout [SyntaxToken]
```

Agent note: `NSAttributedString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L280

```swift
278:     ) {
279:         guard let regex else { return }
280:         let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]
281:         regex.enumerateMatches(in: text, range: range) { match, _, _ in
282:             guard let r = match?.range, r.length > delimLen * 2 else { return }
```

Agent note: `NSAttributedString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L294

```swift
292:         _ ns: NSString,
293:         _ range: NSRange,
294:         textAttrs: [NSAttributedString.Key: Any],
295:         into tokens: inout [SyntaxToken]
296:     ) {
```

Agent note: `NSAttributedString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L298

```swift
296:     ) {
297:         guard let regex else { return }
298:         let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]
299:         regex.enumerateMatches(in: text, range: range) { match, _, _ in
300:             guard let m = match else { return }
```

Agent note: `NSAttributedString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

## `NSAttributedString.Key` (18 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L154

```swift
152:         let starts = tv.lineStartOffsets
153: 
154:         let attrs: [NSAttributedString.Key: Any] = [
155:             .font: Theme.lineNumberFont,
156:             .foregroundColor: NSColor.secondaryLabelColor,
```

Agent note: `NSAttributedString.Key` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L125

```swift
123:     private struct Accumulator {
124:         let language: Language
125:         let baseAttributes: [NSAttributedString.Key: Any] = [
126:             .font: Theme.editorFont,
127:             .foregroundColor: NSColor.textColor,
```

Agent note: `NSAttributedString.Key` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L12

```swift
10: // MARK: - Custom block-background attribute
11: 
12: extension NSAttributedString.Key {
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L13

```swift
11: 
12: extension NSAttributedString.Key {
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L14

```swift
12: extension NSAttributedString.Key {
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L15

```swift
13:     static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
17:     static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L16

```swift
14:     static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
17:     static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")
18: }
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L17

```swift
15:     static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")
16:     static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")
17:     static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")
18: }
19: 
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L407

```swift
405:         let result = NSMutableAttributedString()
406:         let para   = listParagraphStyle(depth: depth, bulletWidth: 16)
407:         let baseAttrs: [NSAttributedString.Key: Any] = [
408:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
409:         ]
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L435

```swift
433:         let result = NSMutableAttributedString()
434:         let para   = listParagraphStyle(depth: depth, bulletWidth: 28)
435:         let baseAttrs: [NSAttributedString.Key: Any] = [
436:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
437:         ]
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L467

```swift
465: 
466:         let para = listParagraphStyle(depth: 0, bulletWidth: 22)
467:         let baseAttrs: [NSAttributedString.Key: Any] = [
468:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
469:         ]
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L470

```swift
468:             .font: theme.bodyFont, .foregroundColor: theme.textColor, .paragraphStyle: para
469:         ]
470:         let cbAttrs: [NSAttributedString.Key: Any] = [
471:             .link:           toggleURL,
472:             .foregroundColor: isChecked ? theme.linkColor : theme.secondaryTextColor,
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L7

```swift
5: struct SyntaxToken {
6:     let range: NSRange
7:     let attributes: [NSAttributedString.Key: Any]
8: }
9: 
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L261

```swift
259:         _ ns: NSString,
260:         _ range: NSRange,
261:         attrs: [NSAttributedString.Key: Any],
262:         into tokens: inout [SyntaxToken]
263:     ) {
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L275

```swift
273:         _ ns: NSString,
274:         _ range: NSRange,
275:         contentAttrs: [NSAttributedString.Key: Any],
276:         delimLen: Int,
277:         into tokens: inout [SyntaxToken]
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L280

```swift
278:     ) {
279:         guard let regex else { return }
280:         let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]
281:         regex.enumerateMatches(in: text, range: range) { match, _, _ in
282:             guard let r = match?.range, r.length > delimLen * 2 else { return }
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L294

```swift
292:         _ ns: NSString,
293:         _ range: NSRange,
294:         textAttrs: [NSAttributedString.Key: Any],
295:         into tokens: inout [SyntaxToken]
296:     ) {
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L298

```swift
296:     ) {
297:         guard let regex else { return }
298:         let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]
299:         regex.enumerateMatches(in: text, range: range) { match, _, _ in
300:             guard let m = match else { return }
```

Agent note: `NSAttributedString.Key` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

## `NSBezierPath` (5 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L62

```swift
60:             )
61:             if outline.intersects(rect.insetBy(dx: -4, dy: -4)) {
62:                 let path = NSBezierPath(roundedRect: outline, xRadius: 3, yRadius: 3)
63:                 path.lineWidth = 2
64:                 NSColor.controlAccentColor.setStroke()
```

Agent note: `NSBezierPath` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L62

```swift
60:             rect.origin.y    += bg.topInset
61:             rect.size.height -= bg.topInset + bg.bottomInset
62:             let path = NSBezierPath(roundedRect: rect, xRadius: 6, yRadius: 6)
63:             bg.color.setFill(); path.fill()
64:             if let border = bg.borderColor {
```

Agent note: `NSBezierPath` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L66

```swift
64:             if let border = bg.borderColor {
65:                 border.setStroke()
66:                 let bp = NSBezierPath(roundedRect: rect.insetBy(dx: 0.5, dy: 0.5), xRadius: 6, yRadius: 6)
67:                 bp.lineWidth = 1; bp.stroke()
68:             }
```

Agent note: `NSBezierPath` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L104

```swift
102:                 )
103:                 entry.color.setFill()
104:                 NSBezierPath(rect: barRect).fill()
105:             }
106:         }
```

Agent note: `NSBezierPath` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L127

```swift
125:                 r = r.insetBy(dx: -3, dy: -1)
126:                 guard r.width > 0 && r.height > 0 else { return }
127:                 let path = NSBezierPath(roundedRect: r, xRadius: 3, yRadius: 3)
128:                 color.setFill()
129:                 path.fill()
```

Agent note: `NSBezierPath` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

## `NSButton` (13 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L57

```swift
55:     private let rightStatus = NSTextField(labelWithString: "")
56:     private let fileNavLabel = NSTextField(labelWithString: "")
57:     private var backButton: NSButton!
58:     private var prevFileButton: NSButton!
59:     private var nextFileButton: NSButton!
```

Agent note: `NSButton` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L58

```swift
56:     private let fileNavLabel = NSTextField(labelWithString: "")
57:     private var backButton: NSButton!
58:     private var prevFileButton: NSButton!
59:     private var nextFileButton: NSButton!
60:     private var contextPopup: NSPopUpButton!
```

Agent note: `NSButton` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L59

```swift
57:     private var backButton: NSButton!
58:     private var prevFileButton: NSButton!
59:     private var nextFileButton: NSButton!
60:     private var contextPopup: NSPopUpButton!
61:     private let spinner = NSProgressIndicator()
```

Agent note: `NSButton` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L190

```swift
188:     }
189: 
190:     private func symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector) -> NSButton {
191:         let image = NSImage(systemSymbolName: symbol, accessibilityDescription: tooltip) ?? NSImage()
192:         let button = NSButton(image: image, target: self, action: action)
```

Agent note: `NSButton` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L192

```swift
190:     private func symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector) -> NSButton {
191:         let image = NSImage(systemSymbolName: symbol, accessibilityDescription: tooltip) ?? NSImage()
192:         let button = NSButton(image: image, target: self, action: action)
193:         button.bezelStyle = .texturedRounded
194:         button.toolTip = tooltip
```

Agent note: `NSButton` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L56

```swift
54:     private let spinner = NSProgressIndicator()
55:     private var filterPopup: NSPopUpButton!
56:     private var flattenCheckbox: NSButton!
57: 
58:     private static let sizeFormatter = ByteCountFormatter()
```

Agent note: `NSButton` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L102

```swift
100:         filterPopup.action = #selector(filterPopupChanged(_:))
101: 
102:         flattenCheckbox = NSButton(checkboxWithTitle: "Flatten", target: self, action: #selector(flattenChanged(_:)))
103:         flattenCheckbox.toolTip = "Show a flat list of files (no folder hierarchy)"
104: 
```

Agent note: `NSButton` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L106

```swift
104: 
105:         let backImage = NSImage(systemSymbolName: "chevron.backward", accessibilityDescription: "Back") ?? NSImage()
106:         let backButton = NSButton(image: backImage, target: self, action: #selector(goBack(_:)))
107:         backButton.bezelStyle = .texturedRounded
108:         backButton.toolTip = "Back to Welcome (Esc, ⌘[)"
```

Agent note: `NSButton` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L111

```swift
109: 
110:         let refreshImage = NSImage(systemSymbolName: "arrow.clockwise", accessibilityDescription: "Refresh") ?? NSImage()
111:         let refreshButton = NSButton(image: refreshImage, target: self, action: #selector(refresh(_:)))
112:         refreshButton.bezelStyle = .texturedRounded
113:         refreshButton.toolTip = "Re-compare (⌘R)"
```

Agent note: `NSButton` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L336

```swift
334:     }
335: 
336:     @objc private func flattenChanged(_ sender: NSButton) {
337:         flattened = sender.state == .on
338:         applyViewOptions()
```

Agent note: `NSButton` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L127

```swift
125:         let prevButton = symbolButton("chevron.up", "Previous conflict", #selector(previousConflict(_:)))
126:         let nextButton = symbolButton("chevron.down", "Next conflict", #selector(nextConflict(_:)))
127:         let saveButton = NSButton(title: "Save Output", target: self, action: #selector(saveOutput(_:)))
128:         saveButton.bezelStyle = .texturedRounded
129:         counterLabel.font = .systemFont(ofSize: 12)
```

Agent note: `NSButton` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L159

```swift
157:     }
158: 
159:     private func symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector) -> NSButton {
160:         let image = NSImage(systemSymbolName: symbol, accessibilityDescription: tooltip) ?? NSImage()
161:         let button = NSButton(image: image, target: self, action: action)
```

Agent note: `NSButton` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L161

```swift
159:     private func symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector) -> NSButton {
160:         let image = NSImage(systemSymbolName: symbol, accessibilityDescription: tooltip) ?? NSImage()
161:         let button = NSButton(image: image, target: self, action: action)
162:         button.bezelStyle = .texturedRounded
163:         button.toolTip = tooltip
```

Agent note: `NSButton` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `NSColor` (102 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2191

```swift
2189:             let alpha: CGFloat = isFile ? 0.12 : 0.06
2190:             v.wantsLayer = true
2191:             v.layer?.backgroundColor = NSColor.secondaryLabelColor.withAlphaComponent(alpha).cgColor
2192:             if let label = v.subviews.first(where: { $0.identifier?.rawValue == "lbl" }) as? NSTextField {
2193:                 label.stringValue = text
```

Agent note: `NSColor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2260

```swift
2258: 
2259:         private func configureLine(_ v: NSView, line: DiffLine) {
2260:             let bg: NSColor
2261:             switch line.kind {
2262:             case .added:   bg = NSColor.systemGreen.withAlphaComponent(0.15)
```

Agent note: `NSColor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2262

```swift
2260:             let bg: NSColor
2261:             switch line.kind {
2262:             case .added:   bg = NSColor.systemGreen.withAlphaComponent(0.15)
2263:             case .removed: bg = NSColor.systemRed.withAlphaComponent(0.15)
2264:             default:       bg = .clear
```

Agent note: `NSColor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2263

```swift
2261:             switch line.kind {
2262:             case .added:   bg = NSColor.systemGreen.withAlphaComponent(0.15)
2263:             case .removed: bg = NSColor.systemRed.withAlphaComponent(0.15)
2264:             default:       bg = .clear
2265:             }
```

Agent note: `NSColor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2270

```swift
2268: 
2269:             let markerStr: String
2270:             let markerColor: NSColor
2271:             switch line.kind {
2272:             case .added:   markerStr = "+"; markerColor = .systemGreen
```

Agent note: `NSColor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L10

```swift
8: 
9:     /// Display row index → row background color.
10:     var rowBackgrounds: [Int: NSColor] = [:]
11:     /// UTF-16 character offset of each display row's start, ascending.
12:     var lineStartOffsets: [Int] = []
```

Agent note: `NSColor` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L64

```swift
62:                 let path = NSBezierPath(roundedRect: outline, xRadius: 3, yRadius: 3)
63:                 path.lineWidth = 2
64:                 NSColor.controlAccentColor.setStroke()
65:                 path.stroke()
66:             }
```

Agent note: `NSColor` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L156

```swift
154:         let attrs: [NSAttributedString.Key: Any] = [
155:             .font: Theme.lineNumberFont,
156:             .foregroundColor: NSColor.secondaryLabelColor,
157:         ]
158: 
```

Agent note: `NSColor` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L371

```swift
369:         overview.marks = model.changeRowRanges.map { range in
370:             let row = model.rows[range.lowerBound]
371:             let color: NSColor
372:             switch row.kind {
373:             case .insert: color = Theme.addedAccent
```

Agent note: `NSColor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L9

```swift
7:     struct Mark {
8:         var rowRange: Range<Int>
9:         var color: NSColor
10:     }
11: 
```

Agent note: `NSColor` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L23

```swift
21: 
22:     override func draw(_ dirtyRect: NSRect) {
23:         NSColor.windowBackgroundColor.setFill()
24:         bounds.fill()
25: 
```

Agent note: `NSColor` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L41

```swift
39:             let y = CGFloat(visibleRows.lowerBound) * scale
40:             let height = max(8, CGFloat(visibleRows.count) * scale)
41:             NSColor.secondaryLabelColor.withAlphaComponent(0.35).setFill()
42:             NSRect(x: 0, y: y, width: bounds.width, height: height).fill()
43:         }
```

Agent note: `NSColor` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L11

```swift
9:     var attributed: NSAttributedString
10:     var lineStartOffsets: [Int]
11:     var rowBackgrounds: [Int: NSColor]
12:     var labels: [String]
13: }
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L82

```swift
80:     static func buildPlain(
81:         lines: [String], fileExtension: String,
82:         lineBackgrounds: [Int: NSColor]
83:     ) -> PaneContent {
84:         let language = LanguageDetector.language(forFileExtension: fileExtension)
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L100

```swift
98:     private static func background(
99:         for row: DiffDisplayModel.Row, hasLine: Bool, isRewrite: Bool, side: Side
100:     ) -> NSColor? {
101:         switch row.kind {
102:         case .equal:
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L127

```swift
125:         let baseAttributes: [NSAttributedString.Key: Any] = [
126:             .font: Theme.editorFont,
127:             .foregroundColor: NSColor.textColor,
128:         ]
129:         var text = NSMutableAttributedString()
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L131

```swift
129:         var text = NSMutableAttributedString()
130:         var starts: [Int] = []
131:         var backgrounds: [Int: NSColor] = [:]
132:         var labels: [String] = []
133:         var offset = 0
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L147

```swift
145:             let attr = NSAttributedString(string: marker + "\n", attributes: [
146:                 .font: Theme.editorFont,
147:                 .foregroundColor: NSColor.tertiaryLabelColor,
148:             ])
149:             text.append(attr)
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L155

```swift
153:         mutating func appendRow(
154:             line: String?, lineNumber: Int?,
155:             background: NSColor?,
156:             emphasis: [Range<Int>], emphasisColor: NSColor
157:         ) {
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L156

```swift
154:             line: String?, lineNumber: Int?,
155:             background: NSColor?,
156:             emphasis: [Range<Int>], emphasisColor: NSColor
157:         ) {
158:             let rowIndex = starts.count
```

Agent note: `NSColor` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L530

```swift
528:             case .equivalent:
529:                 field.stringValue = "≈"
530:                 field.textColor = NSColor.systemTeal
531:                 field.toolTip = "Identical ignoring line endings"
532:             case .different:
```

Agent note: `NSColor` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L196

```swift
194:             )
195: 
196:             var leftBG: [Int: NSColor] = [:]
197:             var baseBG: [Int: NSColor] = [:]
198:             var rightBG: [Int: NSColor] = [:]
```

Agent note: `NSColor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L197

```swift
195: 
196:             var leftBG: [Int: NSColor] = [:]
197:             var baseBG: [Int: NSColor] = [:]
198:             var rightBG: [Int: NSColor] = [:]
199:             for segment in segments {
```

Agent note: `NSColor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L198

```swift
196:             var leftBG: [Int: NSColor] = [:]
197:             var baseBG: [Int: NSColor] = [:]
198:             var rightBG: [Int: NSColor] = [:]
199:             for segment in segments {
200:                 switch segment.kind {
```

Agent note: `NSColor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L218

```swift
216:                 }
217:             }
218:             var outputBG: [Int: NSColor] = [:]
219:             for range in merged.conflictLineRanges {
220:                 for i in range { outputBG[i] = Theme.conflictBackground }
```

Agent note: `NSColor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L10

```swift
8: enum Theme {
9: 
10:     static func dynamic(light: NSColor, dark: NSColor) -> NSColor {
11:         NSColor(name: nil) { appearance in
12:             appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua ? dark : light
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L11

```swift
9: 
10:     static func dynamic(light: NSColor, dark: NSColor) -> NSColor {
11:         NSColor(name: nil) { appearance in
12:             appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua ? dark : light
13:         }
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L16

```swift
14:     }
15: 
16:     private static func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> NSColor {
17:         NSColor(srgbRed: r, green: g, blue: b, alpha: 1)
18:     }
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L17

```swift
15: 
16:     private static func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> NSColor {
17:         NSColor(srgbRed: r, green: g, blue: b, alpha: 1)
18:     }
19: 
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L39

```swift
37: 
38:     // Overview strip / status glyph accents
39:     static let addedAccent = NSColor.systemGreen
40:     static let removedAccent = NSColor.systemRed
41:     static let changedAccent = NSColor.systemBlue
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L40

```swift
38:     // Overview strip / status glyph accents
39:     static let addedAccent = NSColor.systemGreen
40:     static let removedAccent = NSColor.systemRed
41:     static let changedAccent = NSColor.systemBlue
42:     static let conflictAccent = NSColor.systemOrange
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L41

```swift
39:     static let addedAccent = NSColor.systemGreen
40:     static let removedAccent = NSColor.systemRed
41:     static let changedAccent = NSColor.systemBlue
42:     static let conflictAccent = NSColor.systemOrange
43: 
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L42

```swift
40:     static let removedAccent = NSColor.systemRed
41:     static let changedAccent = NSColor.systemBlue
42:     static let conflictAccent = NSColor.systemOrange
43: 
44:     // Syntax (placeholder palette for SyntaxKit's keyword tokenizer)
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L50

```swift
48:     static let syntaxNumber = dynamic(light: rgb(0.11, 0.10, 0.81), dark: rgb(0.84, 0.78, 0.44))
49: 
50:     static func color(for tokenKind: TokenKind) -> NSColor {
51:         switch tokenKind {
52:         case .keyword: return syntaxKeyword
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L7

```swift
5: 
6: struct SyntaxHighlightColors {
7:     var heading, code, italic, link, blockquote, listMarker, strikethrough, frontMatter, image: NSColor
8: }
9: 
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L12

```swift
10: // MARK: - Color hex helpers
11: 
12: extension NSColor {
13:     convenience init?(hex: String) {
14:         var h = hex.trimmingCharacters(in: .whitespaces)
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L35

```swift
33: extension Color {
34:     init?(hex: String) {
35:         guard let ns = NSColor(hex: hex) else { return nil }
36:         self.init(ns)
37:     }
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L38

```swift
36:         self.init(ns)
37:     }
38:     var hexString: String { NSColor(self).hexString }
39: }
40: 
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L133

```swift
131: 
132:     func syntaxColors(dark isDark: Bool) -> SyntaxHighlightColors {
133:         func c(_ light: String, _ dark: String) -> NSColor {
134:             NSColor(hex: isDark ? dark : light) ?? .labelColor
135:         }
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L134

```swift
132:     func syntaxColors(dark isDark: Bool) -> SyntaxHighlightColors {
133:         func c(_ light: String, _ dark: String) -> NSColor {
134:             NSColor(hex: isDark ? dark : light) ?? .labelColor
135:         }
136:         return SyntaxHighlightColors(
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L199

```swift
197:             switch self {
198:             // White in light mode; system window background (dark-gray) in dark mode.
199:             case .adaptive: return Color(nsColor: NSColor(name: nil) { t in
200:                 t.bestMatch(from: [.darkAqua, .vibrantDark]) != nil ? .windowBackgroundColor : .white
201:             })
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L21

```swift
19: 
20: struct MarkdownBlockBackground {
21:     let color:       NSColor
22:     let borderColor: NSColor?
23:     var topInset:    CGFloat = 2
```

Agent note: `NSColor` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L22

```swift
20: struct MarkdownBlockBackground {
21:     let color:       NSColor
22:     let borderColor: NSColor?
23:     var topInset:    CGFloat = 2
24:     var bottomInset: CGFloat = 2
```

Agent note: `NSColor` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L28

```swift
26: 
27: struct MarkdownBlockLeftBorderEntry {
28:     let color:   NSColor
29:     let xOffset: CGFloat  // distance from container lineFragmentPadding
30:     let width:   CGFloat  // typically 4pt
```

Agent note: `NSColor` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L110

```swift
108:         // 3. Draw inline code rounded backgrounds (drawn before super so selection renders on top).
109:         storage.enumerateAttribute(.markdownInlineCode, in: charRange, options: []) { val, range, _ in
110:             guard let color = val as? NSColor else { return }
111:             let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)
112:             enumerateLineFragments(forGlyphRange: gr) { lineFragRect, _, _, lineGlyphRange, _ in
```

Agent note: `NSColor` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L234

```swift
232:         return NSAttributedString(string: " \n", attributes: [
233:             .font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.3, 5)),
234:             .foregroundColor:         NSColor.clear,
235:             .paragraphStyle:          para,
236:             .markdownBlockBackground: bg
```

Agent note: `NSColor` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L586

```swift
584:         return NSAttributedString(string: " \n", attributes: [
585:             .font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.4, 6)),
586:             .foregroundColor:         NSColor.clear,
587:             .paragraphStyle:          para,
588:             .markdownBlockBackground: bg
```

Agent note: `NSColor` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L122

```swift
120:     // MARK: - Dynamic background color
121: 
122:     static var editorBackground: NSColor {
123:         NSColor(name: nil) { appearance in
124:             if appearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil {
```

Agent note: `NSColor` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L123

```swift
121: 
122:     static var editorBackground: NSColor {
123:         NSColor(name: nil) { appearance in
124:             if appearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil {
125:                 return NSColor(white: 0.18, alpha: 1.0)
```

Agent note: `NSColor` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L125

```swift
123:         NSColor(name: nil) { appearance in
124:             if appearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil {
125:                 return NSColor(white: 0.18, alpha: 1.0)
126:             } else {
127:                 return .controlBackgroundColor
```

Agent note: `NSColor` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L34

```swift
32:     // MARK: - Dynamic code background (evaluates appearance at draw time, safe to store in tokens)
33: 
34:     private static let codeBackground = NSColor(name: nil) { app in
35:         app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
36:             ? NSColor(white: 1.0, alpha: 0.09)
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L36

```swift
34:     private static let codeBackground = NSColor(name: nil) { app in
35:         app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
36:             ? NSColor(white: 1.0, alpha: 0.09)
37:             : NSColor(white: 0.0, alpha: 0.06)
38:     }
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L37

```swift
35:         app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
36:             ? NSColor(white: 1.0, alpha: 0.09)
37:             : NSColor(white: 0.0, alpha: 0.06)
38:     }
39: 
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L67

```swift
65:     //
66:     // Call these from any thread. Pre-create font and color objects on the main thread
67:     // and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.
68: 
69:     static func collectTokensFull(
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L91

```swift
89:         tokens.append(SyntaxToken(range: fullRange, attributes: [
90:             .font: base,
91:             .foregroundColor: NSColor.labelColor,
92:             .strikethroughStyle: NSNumber(value: 0),
93:             .backgroundColor: NSColor.clear
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L93

```swift
91:             .foregroundColor: NSColor.labelColor,
92:             .strikethroughStyle: NSNumber(value: 0),
93:             .backgroundColor: NSColor.clear
94:         ]))
95: 
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L103

```swift
101:         collect(reSetextH1,      text, ns, fullRange, attrs: [.foregroundColor: colors.heading, .font: bold], into: &tokens)
102:         collect(reSetextH2,      text, ns, fullRange, attrs: [.foregroundColor: colors.heading, .font: bold], into: &tokens)
103:         collect(reHRule,         text, ns, fullRange, attrs: [.foregroundColor: NSColor.tertiaryLabelColor], into: &tokens)
104:         collect(reFrontMatter,   text, ns, fullRange, attrs: [.foregroundColor: colors.frontMatter], into: &tokens)
105: 
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L160

```swift
158:         tokens.append(SyntaxToken(range: safe, attributes: [
159:             .font: base,
160:             .foregroundColor: NSColor.labelColor,
161:             .strikethroughStyle: NSNumber(value: 0)
162:         ]))
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L166

```swift
164:         guard enabled else { return tokens }
165: 
166:         collect(reHRule, text, ns, safe, attrs: [.foregroundColor: NSColor.tertiaryLabelColor], into: &tokens)
167:         collectHeadingWithDim(reHeadingCapture, text, ns, safe,
168:                               textAttrs: [.foregroundColor: colors.heading, .font: bold], into: &tokens)
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L280

```swift
278:     ) {
279:         guard let regex else { return }
280:         let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]
281:         regex.enumerateMatches(in: text, range: range) { match, _, _ in
282:             guard let r = match?.range, r.length > delimLen * 2 else { return }
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L298

```swift
296:     ) {
297:         guard let regex else { return }
298:         let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]
299:         regex.enumerateMatches(in: text, range: range) { match, _, _ in
300:             guard let m = match else { return }
```

Agent note: `NSColor` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L7

```swift
5: struct MarkdownTheme {
6:     // Colors
7:     var textColor:             NSColor
8:     var secondaryTextColor:    NSColor
9:     var linkColor:             NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L8

```swift
6:     // Colors
7:     var textColor:             NSColor
8:     var secondaryTextColor:    NSColor
9:     var linkColor:             NSColor
10:     var codeTextColor:         NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L9

```swift
7:     var textColor:             NSColor
8:     var secondaryTextColor:    NSColor
9:     var linkColor:             NSColor
10:     var codeTextColor:         NSColor
11:     var inlineCodeBackground:  NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L10

```swift
8:     var secondaryTextColor:    NSColor
9:     var linkColor:             NSColor
10:     var codeTextColor:         NSColor
11:     var inlineCodeBackground:  NSColor
12:     var codeBlockBackground:   NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L11

```swift
9:     var linkColor:             NSColor
10:     var codeTextColor:         NSColor
11:     var inlineCodeBackground:  NSColor
12:     var codeBlockBackground:   NSColor
13:     var codeBlockBorderColor:  NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L12

```swift
10:     var codeTextColor:         NSColor
11:     var inlineCodeBackground:  NSColor
12:     var codeBlockBackground:   NSColor
13:     var codeBlockBorderColor:  NSColor
14:     var quoteBorderColor:      NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L13

```swift
11:     var inlineCodeBackground:  NSColor
12:     var codeBlockBackground:   NSColor
13:     var codeBlockBorderColor:  NSColor
14:     var quoteBorderColor:      NSColor
15:     var quoteTextColor:        NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L14

```swift
12:     var codeBlockBackground:   NSColor
13:     var codeBlockBorderColor:  NSColor
14:     var quoteBorderColor:      NSColor
15:     var quoteTextColor:        NSColor
16:     var tableHeaderBackground: NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L15

```swift
13:     var codeBlockBorderColor:  NSColor
14:     var quoteBorderColor:      NSColor
15:     var quoteTextColor:        NSColor
16:     var tableHeaderBackground: NSColor
17:     var tableBorderColor:      NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L16

```swift
14:     var quoteBorderColor:      NSColor
15:     var quoteTextColor:        NSColor
16:     var tableHeaderBackground: NSColor
17:     var tableBorderColor:      NSColor
18:     var tableAltRowBackground: NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L17

```swift
15:     var quoteTextColor:        NSColor
16:     var tableHeaderBackground: NSColor
17:     var tableBorderColor:      NSColor
18:     var tableAltRowBackground: NSColor
19:     var hrColor:               NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L18

```swift
16:     var tableHeaderBackground: NSColor
17:     var tableBorderColor:      NSColor
18:     var tableAltRowBackground: NSColor
19:     var hrColor:               NSColor
20:     var frontMatterBackground: NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L19

```swift
17:     var tableBorderColor:      NSColor
18:     var tableAltRowBackground: NSColor
19:     var hrColor:               NSColor
20:     var frontMatterBackground: NSColor
21:     var frontMatterTextColor:  NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L20

```swift
18:     var tableAltRowBackground: NSColor
19:     var hrColor:               NSColor
20:     var frontMatterBackground: NSColor
21:     var frontMatterTextColor:  NSColor
22:     var frontMatterKeyColor:   NSColor
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L21

```swift
19:     var hrColor:               NSColor
20:     var frontMatterBackground: NSColor
21:     var frontMatterTextColor:  NSColor
22:     var frontMatterKeyColor:   NSColor
23: 
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L22

```swift
20:     var frontMatterBackground: NSColor
21:     var frontMatterTextColor:  NSColor
22:     var frontMatterKeyColor:   NSColor
23: 
24:     // Fonts
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L52

```swift
50:             linkColor:             c("#0969da") ?? .linkColor,
51:             codeTextColor:         c("#24292f") ?? .labelColor,
52:             inlineCodeBackground:  c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
53:             codeBlockBackground:   c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
54:             codeBlockBorderColor:  c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L53

```swift
51:             codeTextColor:         c("#24292f") ?? .labelColor,
52:             inlineCodeBackground:  c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
53:             codeBlockBackground:   c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
54:             codeBlockBorderColor:  c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
55:             quoteBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L54

```swift
52:             inlineCodeBackground:  c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
53:             codeBlockBackground:   c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
54:             codeBlockBorderColor:  c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
55:             quoteBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
56:             quoteTextColor:        c("#57606a") ?? .secondaryLabelColor,
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L55

```swift
53:             codeBlockBackground:   c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
54:             codeBlockBorderColor:  c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
55:             quoteBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
56:             quoteTextColor:        c("#57606a") ?? .secondaryLabelColor,
57:             tableHeaderBackground: c("#eaeef2") ?? NSColor(white: 0.92, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L57

```swift
55:             quoteBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
56:             quoteTextColor:        c("#57606a") ?? .secondaryLabelColor,
57:             tableHeaderBackground: c("#eaeef2") ?? NSColor(white: 0.92, alpha: 1),
58:             tableBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
59:             tableAltRowBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L58

```swift
56:             quoteTextColor:        c("#57606a") ?? .secondaryLabelColor,
57:             tableHeaderBackground: c("#eaeef2") ?? NSColor(white: 0.92, alpha: 1),
58:             tableBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
59:             tableAltRowBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
60:             hrColor:               c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L59

```swift
57:             tableHeaderBackground: c("#eaeef2") ?? NSColor(white: 0.92, alpha: 1),
58:             tableBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
59:             tableAltRowBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
60:             hrColor:               c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
61:             frontMatterBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L60

```swift
58:             tableBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
59:             tableAltRowBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
60:             hrColor:               c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
61:             frontMatterBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
62:             frontMatterTextColor:  c("#24292f") ?? .labelColor,
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L61

```swift
59:             tableAltRowBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
60:             hrColor:               c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),
61:             frontMatterBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),
62:             frontMatterTextColor:  c("#24292f") ?? .labelColor,
63:             frontMatterKeyColor:   c("#0969da") ?? .linkColor,
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L79

```swift
77:             linkColor:             c("#58a6ff") ?? .linkColor,
78:             codeTextColor:         c("#e6edf3") ?? .labelColor,
79:             inlineCodeBackground:  c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
80:             codeBlockBackground:   c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
81:             codeBlockBorderColor:  c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L80

```swift
78:             codeTextColor:         c("#e6edf3") ?? .labelColor,
79:             inlineCodeBackground:  c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
80:             codeBlockBackground:   c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
81:             codeBlockBorderColor:  c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
82:             quoteBorderColor:      c("#3d444d") ?? NSColor(white: 0.25, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L81

```swift
79:             inlineCodeBackground:  c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
80:             codeBlockBackground:   c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
81:             codeBlockBorderColor:  c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
82:             quoteBorderColor:      c("#3d444d") ?? NSColor(white: 0.25, alpha: 1),
83:             quoteTextColor:        c("#8b949e") ?? .secondaryLabelColor,
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L82

```swift
80:             codeBlockBackground:   c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
81:             codeBlockBorderColor:  c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
82:             quoteBorderColor:      c("#3d444d") ?? NSColor(white: 0.25, alpha: 1),
83:             quoteTextColor:        c("#8b949e") ?? .secondaryLabelColor,
84:             tableHeaderBackground: c("#21262d") ?? NSColor(white: 0.14, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L84

```swift
82:             quoteBorderColor:      c("#3d444d") ?? NSColor(white: 0.25, alpha: 1),
83:             quoteTextColor:        c("#8b949e") ?? .secondaryLabelColor,
84:             tableHeaderBackground: c("#21262d") ?? NSColor(white: 0.14, alpha: 1),
85:             tableBorderColor:      c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
86:             tableAltRowBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L85

```swift
83:             quoteTextColor:        c("#8b949e") ?? .secondaryLabelColor,
84:             tableHeaderBackground: c("#21262d") ?? NSColor(white: 0.14, alpha: 1),
85:             tableBorderColor:      c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
86:             tableAltRowBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
87:             hrColor:               c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L86

```swift
84:             tableHeaderBackground: c("#21262d") ?? NSColor(white: 0.14, alpha: 1),
85:             tableBorderColor:      c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
86:             tableAltRowBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
87:             hrColor:               c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
88:             frontMatterBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L87

```swift
85:             tableBorderColor:      c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
86:             tableAltRowBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
87:             hrColor:               c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
88:             frontMatterBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
89:             frontMatterTextColor:  c("#e6edf3") ?? .labelColor,
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L88

```swift
86:             tableAltRowBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
87:             hrColor:               c("#30363d") ?? NSColor(white: 0.25, alpha: 1),
88:             frontMatterBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),
89:             frontMatterTextColor:  c("#e6edf3") ?? .labelColor,
90:             frontMatterKeyColor:   c("#58a6ff") ?? .linkColor,
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L112

```swift
110:         switch appearance.paperColor {
111:         case .sepia:
112:             let bg = NSColor(red: 0.91, green: 0.88, blue: 0.80, alpha: 1)
113:             let br = NSColor(red: 0.75, green: 0.72, blue: 0.64, alpha: 1)
114:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L113

```swift
111:         case .sepia:
112:             let bg = NSColor(red: 0.91, green: 0.88, blue: 0.80, alpha: 1)
113:             let br = NSColor(red: 0.75, green: 0.72, blue: 0.64, alpha: 1)
114:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
115:         case .dark:
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L116

```swift
114:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
115:         case .dark:
116:             let bg = NSColor(red: 0.14, green: 0.14, blue: 0.17, alpha: 1)
117:             let br = NSColor(red: 0.22, green: 0.22, blue: 0.26, alpha: 1)
118:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L117

```swift
115:         case .dark:
116:             let bg = NSColor(red: 0.14, green: 0.14, blue: 0.17, alpha: 1)
117:             let br = NSColor(red: 0.22, green: 0.22, blue: 0.26, alpha: 1)
118:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
119:         case .ink:
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L120

```swift
118:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
119:         case .ink:
120:             let bg = NSColor(red: 0.09, green: 0.09, blue: 0.11, alpha: 1)
121:             let br = NSColor(red: 0.15, green: 0.15, blue: 0.18, alpha: 1)
122:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L121

```swift
119:         case .ink:
120:             let bg = NSColor(red: 0.09, green: 0.09, blue: 0.11, alpha: 1)
121:             let br = NSColor(red: 0.15, green: 0.15, blue: 0.18, alpha: 1)
122:             theme.inlineCodeBackground = bg; theme.codeBlockBackground = bg; theme.codeBlockBorderColor = br
123:         default:
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L129

```swift
127:     }
128: 
129:     private static func c(_ hex: String) -> NSColor? { NSColor(hex: hex) }
130: 
131:     private static func makeBodyFont(size: CGFloat, family: String) -> NSFont {
```

Agent note: `NSColor` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSCursor` (3 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L442

```swift
440: 
441: private extension View {
442:     func cursor(_ cursor: NSCursor) -> some View {
443:         self.onHover { inside in
444:             if inside { cursor.push() } else { NSCursor.pop() }
```

Agent note: `NSCursor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L444

```swift
442:     func cursor(_ cursor: NSCursor) -> some View {
443:         self.onHover { inside in
444:             if inside { cursor.push() } else { NSCursor.pop() }
445:         }
446:     }
```

Agent note: `NSCursor` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L65

```swift
63:         textView.linkTextAttributes = [
64:             .underlineStyle: NSUnderlineStyle.single.rawValue,
65:             .cursor:         NSCursor.pointingHand
66:         ]
67: 
```

Agent note: `NSCursor` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSEvent` (7 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L84

```swift
82:     /// otherwise swallow it for completion). The editable merge-output
83:     /// pane keeps Esc for normal text editing.
84:     override func keyDown(with event: NSEvent) {
85:         if event.keyCode == 53, !isEditable { // 53 = Esc
86:             NSApp.sendAction(NSSelectorFromString("goBack:"), to: nil, from: self)
```

Agent note: `NSEvent` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L46

```swift
44:     }
45: 
46:     override func mouseDown(with event: NSEvent) {
47:         jump(to: event)
48:     }
```

Agent note: `NSEvent` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L50

```swift
48:     }
49: 
50:     override func mouseDragged(with event: NSEvent) {
51:         jump(to: event)
52:     }
```

Agent note: `NSEvent` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L54

```swift
52:     }
53: 
54:     private func jump(to event: NSEvent) {
55:         guard totalRows > 0, bounds.height > 0 else { return }
56:         let point = convert(event.locationInWindow, from: nil)
```

Agent note: `NSEvent` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L17

```swift
15:         override func viewDidMoveToWindow() {
16:             super.viewDidMoveToWindow()
17:             monitor.map { NSEvent.removeMonitor($0) }
18:             guard let win = window else { monitor = nil; return }
19:             monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak win] event in
```

Agent note: `NSEvent` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L19

```swift
17:             monitor.map { NSEvent.removeMonitor($0) }
18:             guard let win = window else { monitor = nil; return }
19:             monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak win] event in
20:                 guard event.window === win else { return event }
21:                 if event.keyCode == 53 { win?.close(); return nil }
```

Agent note: `NSEvent` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L25

```swift
23:             }
24:         }
25:         deinit { monitor.map { NSEvent.removeMonitor($0) } }
26:     }
27: }
```

Agent note: `NSEvent` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSFont` (37 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2210

```swift
2208:             box.identifier = nsId
2209:             box.wantsLayer = true
2210:             let monoCaption2: NSFont = .monospacedSystemFont(ofSize: 9, weight: .regular)
2211:             let monoCaption: NSFont = .monospacedSystemFont(ofSize: 11, weight: .regular)
2212: 
```

Agent note: `NSFont` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2211

```swift
2209:             box.wantsLayer = true
2210:             let monoCaption2: NSFont = .monospacedSystemFont(ofSize: 9, weight: .regular)
2211:             let monoCaption: NSFont = .monospacedSystemFont(ofSize: 11, weight: .regular)
2212: 
2213:             func numField(id: String) -> NSTextField {
```

Agent note: `NSFont` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L59

```swift
57:     }
58: 
59:     static let editorFont = NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)
60:     static let lineNumberFont = NSFont.monospacedDigitSystemFont(ofSize: 10, weight: .regular)
61: }
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L60

```swift
58: 
59:     static let editorFont = NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)
60:     static let lineNumberFont = NSFont.monospacedDigitSystemFont(ofSize: 10, weight: .regular)
61: }
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L233

```swift
231:         let bg = MarkdownBlockBackground(color: theme.hrColor, borderColor: nil, topInset: 0, bottomInset: 18)
232:         return NSAttributedString(string: " \n", attributes: [
233:             .font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.3, 5)),
234:             .foregroundColor:         NSColor.clear,
235:             .paragraphStyle:          para,
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L296

```swift
294:             lp.tailIndent             = -14
295:             let ls = NSMutableAttributedString(string: lang + "\n", attributes: [
296:                 .font:                    NSFont.monospacedSystemFont(ofSize: theme.codeFont.pointSize * 0.75, weight: .regular),
297:                 .foregroundColor:         theme.secondaryTextColor.withAlphaComponent(0.65),
298:                 .paragraphStyle:          lp,
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L312

```swift
310:             hp.tailIndent             = -14
311:             let hs = NSMutableAttributedString(string: "⎘\n", attributes: [
312:                 .font:                    NSFont.monospacedSystemFont(ofSize: theme.codeFont.pointSize * 0.75, weight: .regular),
313:                 .foregroundColor:         theme.secondaryTextColor.withAlphaComponent(0.65),
314:                 .paragraphStyle:          hp,
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L557

```swift
555:                 let cell    = colIdx < row.count ? row[colIdx] : nil
556:                 let content = cell.map { renderInlines($0) } ?? NSMutableAttributedString()
557:                 let cellFont: NSFont = isHeader
558:                     ? (NSFont(descriptor: theme.bodyFont.fontDescriptor.withSymbolicTraits(.bold),
559:                               size: theme.bodyFont.pointSize * 0.9) ?? theme.bodyFont)
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L558

```swift
556:                 let content = cell.map { renderInlines($0) } ?? NSMutableAttributedString()
557:                 let cellFont: NSFont = isHeader
558:                     ? (NSFont(descriptor: theme.bodyFont.fontDescriptor.withSymbolicTraits(.bold),
559:                               size: theme.bodyFont.pointSize * 0.9) ?? theme.bodyFont)
560:                     : (NSFont(descriptor: theme.bodyFont.fontDescriptor,
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L560

```swift
558:                     ? (NSFont(descriptor: theme.bodyFont.fontDescriptor.withSymbolicTraits(.bold),
559:                               size: theme.bodyFont.pointSize * 0.9) ?? theme.bodyFont)
560:                     : (NSFont(descriptor: theme.bodyFont.fontDescriptor,
561:                               size: theme.bodyFont.pointSize * 0.9) ?? theme.bodyFont)
562:                 content.addAttributes([
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L585

```swift
583:         let bg = MarkdownBlockBackground(color: theme.hrColor, borderColor: nil, topInset: 12, bottomInset: 12)
584:         return NSAttributedString(string: " \n", attributes: [
585:             .font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.4, 6)),
586:             .foregroundColor:         NSColor.clear,
587:             .paragraphStyle:          para,
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L603

```swift
601:             para.headIndent          = 14
602:             para.firstLineHeadIndent = 14
603:             let mono = NSFont.monospacedSystemFont(ofSize: theme.bodyFont.pointSize * 0.85, weight: .regular)
604:             let line = NSMutableAttributedString(string: key + ":  ", attributes: [
605:                 .font:                    NSFont(descriptor: mono.fontDescriptor.withSymbolicTraits(.bold), size: mono.pointSize) ?? mono,
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L605

```swift
603:             let mono = NSFont.monospacedSystemFont(ofSize: theme.bodyFont.pointSize * 0.85, weight: .regular)
604:             let line = NSMutableAttributedString(string: key + ":  ", attributes: [
605:                 .font:                    NSFont(descriptor: mono.fontDescriptor.withSymbolicTraits(.bold), size: mono.pointSize) ?? mono,
606:                 .foregroundColor:         theme.frontMatterKeyColor,
607:                 .paragraphStyle:          para,
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L626

```swift
624:     private func applyBold(_ str: NSMutableAttributedString) -> NSAttributedString {
625:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
626:             let f    = (val as? NSFont) ?? theme.bodyFont
627:             let bold = NSFont(descriptor: f.fontDescriptor.withSymbolicTraits(.bold), size: f.pointSize) ?? f
628:             str.addAttribute(.font, value: bold, range: range)
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L627

```swift
625:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
626:             let f    = (val as? NSFont) ?? theme.bodyFont
627:             let bold = NSFont(descriptor: f.fontDescriptor.withSymbolicTraits(.bold), size: f.pointSize) ?? f
628:             str.addAttribute(.font, value: bold, range: range)
629:         }
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L635

```swift
633:     private func applyItalic(_ str: NSMutableAttributedString) -> NSAttributedString {
634:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
635:             let f      = (val as? NSFont) ?? theme.bodyFont
636:             var traits = f.fontDescriptor.symbolicTraits
637:             traits.insert(.italic)
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L638

```swift
636:             var traits = f.fontDescriptor.symbolicTraits
637:             traits.insert(.italic)
638:             let italic = NSFont(descriptor: f.fontDescriptor.withSymbolicTraits(traits), size: f.pointSize) ?? f
639:             str.addAttribute(.font, value: italic, range: range)
640:         }
```

Agent note: `NSFont` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L14

```swift
12:     // MARK: - Fonts
13: 
14:     static func baseFont(size: Double = 13, family: String = "") -> NSFont {
15:         if !family.isEmpty, let f = NSFont(name: family, size: size) { return f }
16:         return NSFont.monospacedSystemFont(ofSize: size, weight: .regular)
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L15

```swift
13: 
14:     static func baseFont(size: Double = 13, family: String = "") -> NSFont {
15:         if !family.isEmpty, let f = NSFont(name: family, size: size) { return f }
16:         return NSFont.monospacedSystemFont(ofSize: size, weight: .regular)
17:     }
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L16

```swift
14:     static func baseFont(size: Double = 13, family: String = "") -> NSFont {
15:         if !family.isEmpty, let f = NSFont(name: family, size: size) { return f }
16:         return NSFont.monospacedSystemFont(ofSize: size, weight: .regular)
17:     }
18: 
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L19

```swift
17:     }
18: 
19:     private static func boldFont(size: Double = 13, family: String = "") -> NSFont {
20:         if !family.isEmpty {
21:             let base = NSFont(name: family, size: size) ?? NSFont.monospacedSystemFont(ofSize: size, weight: .regular)
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L21

```swift
19:     private static func boldFont(size: Double = 13, family: String = "") -> NSFont {
20:         if !family.isEmpty {
21:             let base = NSFont(name: family, size: size) ?? NSFont.monospacedSystemFont(ofSize: size, weight: .regular)
22:             return NSFontManager.shared.convert(base, toHaveTrait: .boldFontMask)
23:         }
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L22

```swift
20:         if !family.isEmpty {
21:             let base = NSFont(name: family, size: size) ?? NSFont.monospacedSystemFont(ofSize: size, weight: .regular)
22:             return NSFontManager.shared.convert(base, toHaveTrait: .boldFontMask)
23:         }
24:         return NSFont.monospacedSystemFont(ofSize: size, weight: .bold)
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L24

```swift
22:             return NSFontManager.shared.convert(base, toHaveTrait: .boldFontMask)
23:         }
24:         return NSFont.monospacedSystemFont(ofSize: size, weight: .bold)
25:     }
26: 
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L27

```swift
25:     }
26: 
27:     private static func italicFont(size: Double = 13, family: String = "") -> NSFont {
28:         let base = baseFont(size: size, family: family)
29:         return NSFontManager.shared.convert(base, toHaveTrait: .italicFontMask)
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L29

```swift
27:     private static func italicFont(size: Double = 13, family: String = "") -> NSFont {
28:         let base = baseFont(size: size, family: family)
29:         return NSFontManager.shared.convert(base, toHaveTrait: .italicFontMask)
30:     }
31: 
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L67

```swift
65:     //
66:     // Call these from any thread. Pre-create font and color objects on the main thread
67:     // and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.
68: 
69:     static func collectTokensFull(
```

Agent note: `NSFont` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L25

```swift
23: 
24:     // Fonts
25:     var bodyFont: NSFont
26:     var codeFont: NSFont
27: 
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L26

```swift
24:     // Fonts
25:     var bodyFont: NSFont
26:     var codeFont: NSFont
27: 
28:     // Spacing
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L34

```swift
32:     var contentInset:       NSSize
33: 
34:     func headingFont(level: Int) -> NSFont {
35:         let s = bodyFont.pointSize
36:         let sizes: [CGFloat] = [s * 2.0, s * 1.5, s * 1.25, s * 1.0, s * 0.875, s * 0.85]
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L38

```swift
36:         let sizes: [CGFloat] = [s * 2.0, s * 1.5, s * 1.25, s * 1.0, s * 0.875, s * 0.85]
37:         let sz = level >= 1 && level <= 6 ? sizes[level - 1] : s
38:         return NSFont(descriptor: bodyFont.fontDescriptor.withSymbolicTraits(.bold), size: sz)
39:             ?? NSFont.boldSystemFont(ofSize: sz)
40:     }
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L39

```swift
37:         let sz = level >= 1 && level <= 6 ? sizes[level - 1] : s
38:         return NSFont(descriptor: bodyFont.fontDescriptor.withSymbolicTraits(.bold), size: sz)
39:             ?? NSFont.boldSystemFont(ofSize: sz)
40:     }
41: }
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L65

```swift
63:             frontMatterKeyColor:   c("#0969da") ?? .linkColor,
64:             bodyFont:              makeBodyFont(size: bodySize, family: fontFamily),
65:             codeFont:              NSFont.monospacedSystemFont(ofSize: codeSize, weight: .regular),
66:             paragraphSpacing:      bodySize * 0.75,
67:             blockSpacing:          bodySize,
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L92

```swift
90:             frontMatterKeyColor:   c("#58a6ff") ?? .linkColor,
91:             bodyFont:              makeBodyFont(size: bodySize, family: fontFamily),
92:             codeFont:              NSFont.monospacedSystemFont(ofSize: codeSize, weight: .regular),
93:             paragraphSpacing:      bodySize * 0.75,
94:             blockSpacing:          bodySize,
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L131

```swift
129:     private static func c(_ hex: String) -> NSColor? { NSColor(hex: hex) }
130: 
131:     private static func makeBodyFont(size: CGFloat, family: String) -> NSFont {
132:         guard !family.isEmpty else { return NSFont.systemFont(ofSize: size) }
133:         return NSFont(name: family, size: size) ?? NSFont.systemFont(ofSize: size)
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L132

```swift
130: 
131:     private static func makeBodyFont(size: CGFloat, family: String) -> NSFont {
132:         guard !family.isEmpty else { return NSFont.systemFont(ofSize: size) }
133:         return NSFont(name: family, size: size) ?? NSFont.systemFont(ofSize: size)
134:     }
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L133

```swift
131:     private static func makeBodyFont(size: CGFloat, family: String) -> NSFont {
132:         guard !family.isEmpty else { return NSFont.systemFont(ofSize: size) }
133:         return NSFont(name: family, size: size) ?? NSFont.systemFont(ofSize: size)
134:     }
135: }
```

Agent note: `NSFont` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSHostingView` (2 hits)


### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L247

```swift
245:         hidesOnDeactivate  = true
246:         collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
247:         contentView        = NSHostingView(rootView: SelectionToolbarView())
248:     }
249: }
```

Agent note: `NSHostingView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L611

```swift
609:         defer: false
610:     )
611:     win.contentView = NSHostingView(rootView: content)
612:     win.center()
613:     win.delegate   = NSApp.delegate as? NSWindowDelegate
```

Agent note: `NSHostingView` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSLayoutConstraint` (5 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2179

```swift
2177:             label.translatesAutoresizingMaskIntoConstraints = false
2178:             box.addSubview(label)
2179:             NSLayoutConstraint.activate([
2180:                 label.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 8),
2181:                 label.centerYAnchor.constraint(equalTo: box.centerYAnchor),
```

Agent note: `NSLayoutConstraint` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2238

```swift
2236: 
2237:             [oldNum, newNum, marker, text].forEach { box.addSubview($0) }
2238:             NSLayoutConstraint.activate([
2239:                 oldNum.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 4),
2240:                 oldNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
```

Agent note: `NSLayoutConstraint` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L181

```swift
179:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))
180:         container.addSubview(main)
181:         NSLayoutConstraint.activate([
182:             main.topAnchor.constraint(equalTo: container.topAnchor),
183:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
```

Agent note: `NSLayoutConstraint` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L149

```swift
147:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))
148:         container.addSubview(main)
149:         NSLayoutConstraint.activate([
150:             main.topAnchor.constraint(equalTo: container.topAnchor),
151:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
```

Agent note: `NSLayoutConstraint` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L150

```swift
148:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1280, height: 800))
149:         container.addSubview(main)
150:         NSLayoutConstraint.activate([
151:             main.topAnchor.constraint(equalTo: container.topAnchor),
152:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
```

Agent note: `NSLayoutConstraint` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `NSLayoutManager` (5 hits)


### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L41

```swift
39: // MARK: - Layout manager that draws full-width paragraph backgrounds
40: 
41: final class MarkdownLayoutManager: NSLayoutManager {
42:     override func drawBackground(forGlyphRange glyphsToShow: NSRange, at origin: NSPoint) {
43:         guard let storage = textStorage, let container = textContainers.first else {
```

Agent note: `NSLayoutManager` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L40

```swift
38:         textView.drawsBackground   = true
39:         applyTabStops(to: textView, tabSize: appearance.editorTabSize, fontSize: appearance.editorFontSize, family: appearance.editorFontFamily)
40:         // Pre-size so NSLayoutManager gets a real container width before the first string
41:         // assignment. A zero-width container forces one line-fragment per character
42:         // (258K frags for 258 KB), causing a 400 ms+ display stall.
```

Agent note: `NSLayoutManager` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L100

```swift
98:         textView.textStorage?.setAttributedString(attributedString)
99:         // Scroll position is restored in layoutManager(_:didCompleteLayoutFor:atEnd:)
100:         // after NSLayoutManager finishes laying out the new content.
101:     }
102: 
```

Agent note: `NSLayoutManager` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105

```swift
103:     // MARK: - Coordinator
104: 
105:     final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {
106:         var onToggle:       (Int) -> Void
107:         var onRelativeLink: ((URL) -> Void)?
```

Agent note: `NSLayoutManager` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L119

```swift
117:         }
118: 
119:         func layoutManager(_ layoutManager: NSLayoutManager,
120:                            didCompleteLayoutFor textContainer: NSTextContainer?,
121:                            atEnd layoutFinishedFlag: Bool) {
```

Agent note: `NSLayoutManager` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSLayoutManagerDelegate` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105

```swift
103:     // MARK: - Coordinator
104: 
105:     final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {
106:         var onToggle:       (Int) -> Void
107:         var onRelativeLink: ((URL) -> Void)?
```

Agent note: `NSLayoutManagerDelegate` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSMenu` (19 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L643

```swift
641: }
642: 
643: extension FileDiffViewController: NSMenuItemValidation {
644:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
645:         switch menuItem.action {
```

Agent note: `NSMenu` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L644

```swift
642: 
643: extension FileDiffViewController: NSMenuItemValidation {
644:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
645:         switch menuItem.action {
646:         case #selector(nextDifference(_:)), #selector(previousDifference(_:)):
```

Agent note: `NSMenu` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L185

```swift
183:     }
184: 
185:     private func buildContextMenu() -> NSMenu {
186:         let menu = NSMenu()
187:         menu.addItem(withTitle: "Copy Left → Right", action: #selector(copyLeftToRight(_:)), keyEquivalent: "")
```

Agent note: `NSMenu` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L186

```swift
184: 
185:     private func buildContextMenu() -> NSMenu {
186:         let menu = NSMenu()
187:         menu.addItem(withTitle: "Copy Left → Right", action: #selector(copyLeftToRight(_:)), keyEquivalent: "")
188:         menu.addItem(withTitle: "Copy Right → Left", action: #selector(copyRightToLeft(_:)), keyEquivalent: "")
```

Agent note: `NSMenu` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L568

```swift
566: }
567: 
568: extension FolderCompareViewController: NSMenuItemValidation {
569:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
570:         switch menuItem.action {
```

Agent note: `NSMenu` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L569

```swift
567: 
568: extension FolderCompareViewController: NSMenuItemValidation {
569:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
570:         switch menuItem.action {
571:         case #selector(toggleDifferencesOnly(_:)):
```

Agent note: `NSMenu` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L395

```swift
393: }
394: 
395: extension MergeViewController: NSMenuItemValidation {
396:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
397:         switch menuItem.action {
```

Agent note: `NSMenu` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L396

```swift
394: 
395: extension MergeViewController: NSMenuItemValidation {
396:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
397:         switch menuItem.action {
398:         case #selector(nextConflict(_:)), #selector(previousConflict(_:)):
```

Agent note: `NSMenu` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L10

```swift
8: 
9:     static func install() {
10:         let main = NSMenu()
11:         main.addItem(makeAppMenu())
12:         main.addItem(makeFileMenu())
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L21

```swift
19:     }
20: 
21:     private static func submenu(_ title: String) -> (NSMenuItem, NSMenu) {
22:         let item = NSMenuItem()
23:         let menu = NSMenu(title: title)
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L22

```swift
20: 
21:     private static func submenu(_ title: String) -> (NSMenuItem, NSMenu) {
22:         let item = NSMenuItem()
23:         let menu = NSMenu(title: title)
24:         item.submenu = menu
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L23

```swift
21:     private static func submenu(_ title: String) -> (NSMenuItem, NSMenu) {
22:         let item = NSMenuItem()
23:         let menu = NSMenu(title: title)
24:         item.submenu = menu
25:         return (item, menu)
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L32

```swift
30:     }
31: 
32:     private static func makeAppMenu() -> NSMenuItem {
33:         let (item, menu) = submenu("MacMerge")
34:         menu.addItem(withTitle: "About MacMerge",
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L47

```swift
45:     }
46: 
47:     private static func makeFileMenu() -> NSMenuItem {
48:         let (item, menu) = submenu("File")
49:         menu.addItem(withTitle: "New Comparison…", action: #selector(AppDelegate.newComparison(_:)), keyEquivalent: "n")
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L64

```swift
62:     }
63: 
64:     private static func makeEditMenu() -> NSMenuItem {
65:         let (item, menu) = submenu("Edit")
66:         menu.addItem(withTitle: "Undo", action: NSSelectorFromString("undo:"), keyEquivalent: "z")
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L78

```swift
76:     }
77: 
78:     private static func makeViewMenu() -> NSMenuItem {
79:         let (item, menu) = submenu("View")
80:         let diffOnly = menu.addItem(withTitle: "Show Differences Only",
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L96

```swift
94:     }
95: 
96:     private static func makeNavigateMenu() -> NSMenuItem {
97:         let (item, menu) = submenu("Navigate")
98:         menu.addItem(withTitle: "Back", action: NSSelectorFromString("goBack:"), keyEquivalent: "[")
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L132

```swift
130:     }
131: 
132:     private static func makeWindowMenu() -> NSMenuItem {
133:         let (item, menu) = submenu("Window")
134:         menu.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L146

```swift
144:     }
145: 
146:     private static func makeHelpMenu() -> NSMenuItem {
147:         let (item, menu) = submenu("Help")
148:         menu.addItem(withTitle: "MacMerge Help", action: #selector(NSApplication.showHelp(_:)), keyEquivalent: "?")
```

Agent note: `NSMenu` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

## `NSMenuItemValidation` (3 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L643

```swift
641: }
642: 
643: extension FileDiffViewController: NSMenuItemValidation {
644:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
645:         switch menuItem.action {
```

Agent note: `NSMenuItemValidation` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L568

```swift
566: }
567: 
568: extension FolderCompareViewController: NSMenuItemValidation {
569:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
570:         switch menuItem.action {
```

Agent note: `NSMenuItemValidation` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L395

```swift
393: }
394: 
395: extension MergeViewController: NSMenuItemValidation {
396:     func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
397:         switch menuItem.action {
```

Agent note: `NSMenuItemValidation` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `NSMutableAttributedString` (29 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L129

```swift
127:             .foregroundColor: NSColor.textColor,
128:         ]
129:         var text = NSMutableAttributedString()
130:         var starts: [Int] = []
131:         var backgrounds: [Int: NSColor] = [:]
```

Agent note: `NSMutableAttributedString` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L163

```swift
161:             if let background { backgrounds[rowIndex] = background }
162: 
163:             let attr = NSMutableAttributedString(string: (line ?? "") + "\n", attributes: baseAttributes)
164:             if let line {
165:                 let contentLength = attr.length - 1 // excludes the trailing newline
```

Agent note: `NSMutableAttributedString` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L168

```swift
166:         let parsed = parseFrontMatter(from: source)
167:         let doc    = Document(parsing: parsed.markdownBody)
168:         let out    = NSMutableAttributedString()
169:         if let fm = parsed.frontMatter { out.append(renderFrontMatter(fm)) }
170:         for child in doc.children { out.append(renderBlock(child)) }
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L190

```swift
188:                                    code: html.rawHTML.trimmingCharacters(in: .newlines))
189:         default:
190:             let out = NSMutableAttributedString()
191:             for child in markup.children { out.append(renderBlock(child)) }
192:             return out
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L198

```swift
196:     // MARK: - Inline dispatch
197: 
198:     private func renderInlines(_ markup: any Markup) -> NSMutableAttributedString {
199:         let out = NSMutableAttributedString()
200:         for child in markup.children { out.append(renderInline(child)) }
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L199

```swift
197: 
198:     private func renderInlines(_ markup: any Markup) -> NSMutableAttributedString {
199:         let out = NSMutableAttributedString()
200:         for child in markup.children { out.append(renderInline(child)) }
201:         return out
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L217

```swift
215:         case let ih as InlineHTML:    return NSAttributedString(string: ih.rawHTML)
216:         default:
217:             let out = NSMutableAttributedString()
218:             for child in markup.children { out.append(renderInline(child)) }
219:             return out
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L254

```swift
252: 
253:         let inner = renderInlines(heading)
254:         let result = NSMutableAttributedString(attributedString: inner)
255:         result.append(NSAttributedString(string: "\n"))
256:         let all = NSRange(location: 0, length: result.length)
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L267

```swift
265:     private func renderParagraph(_ paragraph: Paragraph) -> NSAttributedString {
266:         let inner  = renderInlines(paragraph)
267:         let result = NSMutableAttributedString(attributedString: inner)
268:         result.append(NSAttributedString(string: "\n"))
269:         let all  = NSRange(location: 0, length: result.length)
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L287

```swift
285:                                           borderColor: theme.codeBlockBorderColor)
286:         let copyURL = URL(string: "copycode://click")!
287:         let result = NSMutableAttributedString()
288: 
289:         if let lang = language, !lang.isEmpty {
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L295

```swift
293:             lp.alignment              = .right
294:             lp.tailIndent             = -14
295:             let ls = NSMutableAttributedString(string: lang + "\n", attributes: [
296:                 .font:                    NSFont.monospacedSystemFont(ofSize: theme.codeFont.pointSize * 0.75, weight: .regular),
297:                 .foregroundColor:         theme.secondaryTextColor.withAlphaComponent(0.65),
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L311

```swift
309:             hp.alignment              = .right
310:             hp.tailIndent             = -14
311:             let hs = NSMutableAttributedString(string: "⎘\n", attributes: [
312:                 .font:                    NSFont.monospacedSystemFont(ofSize: theme.codeFont.pointSize * 0.75, weight: .regular),
313:                 .foregroundColor:         theme.secondaryTextColor.withAlphaComponent(0.65),
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L328

```swift
326:         cp.headIndent             = 14
327:         cp.firstLineHeadIndent    = 14
328:         let cs = NSMutableAttributedString(string: code + "\n", attributes: [
329:             .font:                    theme.codeFont,
330:             .foregroundColor:         theme.codeTextColor,
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L341

```swift
339: 
340:     private func renderBlockQuote(_ blockQuote: BlockQuote, depth: Int) -> NSAttributedString {
341:         let result = NSMutableAttributedString()
342:         for child in blockQuote.children {
343:             if let inner = child as? BlockQuote {
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L384

```swift
382:     private func renderUnorderedList(_ list: UnorderedList, depth: Int) -> NSAttributedString {
383:         let hasCheckboxes = list.children.contains { ($0 as? ListItem)?.checkbox != nil }
384:         let result = NSMutableAttributedString()
385:         for child in list.children {
386:             guard let item = child as? ListItem else { continue }
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L395

```swift
393: 
394:     private func renderOrderedList(_ list: OrderedList, depth: Int) -> NSAttributedString {
395:         let result = NSMutableAttributedString()
396:         let start  = Int(list.startIndex)
397:         for (i, child) in list.children.enumerated() {
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L405

```swift
403: 
404:     private func renderBulletItem(_ item: ListItem, depth: Int) -> NSAttributedString {
405:         let result = NSMutableAttributedString()
406:         let para   = listParagraphStyle(depth: depth, bulletWidth: 16)
407:         let baseAttrs: [NSAttributedString.Key: Any] = [
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L413

```swift
411:         for child in item.children {
412:             if let p = child as? Paragraph {
413:                 let str = NSMutableAttributedString()
414:                 if firstPara {
415:                     str.append(NSAttributedString(string: "•\t",
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L433

```swift
431: 
432:     private func renderOrderedItem(_ item: ListItem, number: Int, depth: Int) -> NSAttributedString {
433:         let result = NSMutableAttributedString()
434:         let para   = listParagraphStyle(depth: depth, bulletWidth: 28)
435:         let baseAttrs: [NSAttributedString.Key: Any] = [
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L441

```swift
439:         for child in item.children {
440:             if let p = child as? Paragraph {
441:                 let str = NSMutableAttributedString()
442:                 if firstPara {
443:                     str.append(NSAttributedString(string: "\(number).\t",
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L476

```swift
474:         ]
475: 
476:         let result = NSMutableAttributedString()
477:         result.append(NSAttributedString(string: checkChar + "\t", attributes: cbAttrs))
478:         for child in item.children {
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L521

```swift
519:         nsTable.hidesEmptyCells  = false
520: 
521:         let output  = NSMutableAttributedString()
522:         let allRows: [[MDTable.Cell?]] = [headers.map { Optional($0) }]
523:                                        + rows.map { $0.map { Optional($0) } }
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L556

```swift
554: 
555:                 let cell    = colIdx < row.count ? row[colIdx] : nil
556:                 let content = cell.map { renderInlines($0) } ?? NSMutableAttributedString()
557:                 let cellFont: NSFont = isHeader
558:                     ? (NSFont(descriptor: theme.bodyFont.fontDescriptor.withSymbolicTraits(.bold),
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L597

```swift
595:         let bg  = MarkdownBlockBackground(color: theme.frontMatterBackground,
596:                                           borderColor: theme.tableBorderColor)
597:         let result = NSMutableAttributedString()
598:         for (key, value) in fm.fields {
599:             let para = NSMutableParagraphStyle()
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L604

```swift
602:             para.firstLineHeadIndent = 14
603:             let mono = NSFont.monospacedSystemFont(ofSize: theme.bodyFont.pointSize * 0.85, weight: .regular)
604:             let line = NSMutableAttributedString(string: key + ":  ", attributes: [
605:                 .font:                    NSFont(descriptor: mono.fontDescriptor.withSymbolicTraits(.bold), size: mono.pointSize) ?? mono,
606:                 .foregroundColor:         theme.frontMatterKeyColor,
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L624

```swift
622:     // MARK: - Inline formatting
623: 
624:     private func applyBold(_ str: NSMutableAttributedString) -> NSAttributedString {
625:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
626:             let f    = (val as? NSFont) ?? theme.bodyFont
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L633

```swift
631:     }
632: 
633:     private func applyItalic(_ str: NSMutableAttributedString) -> NSAttributedString {
634:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
635:             let f      = (val as? NSFont) ?? theme.bodyFont
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L644

```swift
642:     }
643: 
644:     private func applyStrikethrough(_ str: NSMutableAttributedString) -> NSAttributedString {
645:         str.addAttribute(.strikethroughStyle, value: NSUnderlineStyle.single.rawValue,
646:                          range: NSRange(location: 0, length: str.length))
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L660

```swift
658:     private func renderLink(_ link: MDLink) -> NSAttributedString {
659:         let inner  = renderInlines(link)
660:         let result = NSMutableAttributedString(attributedString: inner)
661:         let all    = NSRange(location: 0, length: result.length)
662:         if let dest = link.destination, let url = URL(string: dest) {
```

Agent note: `NSMutableAttributedString` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

## `NSMutableParagraphStyle` (15 hits)


### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L226

```swift
224: 
225:     private func renderHeadingRule() -> NSAttributedString {
226:         let para = NSMutableParagraphStyle()
227:         para.paragraphSpacingBefore = 0
228:         para.paragraphSpacing       = 16
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L244

```swift
242:         let font   = theme.headingFont(level: level)
243:         let color  = level < 6 ? theme.textColor : theme.secondaryTextColor
244:         let para   = NSMutableParagraphStyle()
245:         para.lineHeightMultiple = 1.15
246:         switch level {
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L290

```swift
288: 
289:         if let lang = language, !lang.isEmpty {
290:             let lp = NSMutableParagraphStyle()
291:             lp.paragraphSpacingBefore = 0
292:             lp.paragraphSpacing       = 0
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L306

```swift
304:         } else {
305:             // No language label: add a minimal right-aligned copy hint.
306:             let hp = NSMutableParagraphStyle()
307:             hp.paragraphSpacingBefore = 0
308:             hp.paragraphSpacing       = 0
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L322

```swift
320:         }
321: 
322:         let cp = NSMutableParagraphStyle()
323:         cp.lineHeightMultiple     = 1.5
324:         cp.paragraphSpacingBefore = 2
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L355

```swift
353:         // Indent paragraph styles for this depth level.
354:         result.enumerateAttribute(.paragraphStyle, in: all, options: []) { val, range, _ in
355:             let para = ((val as? NSParagraphStyle)?.mutableCopy() as? NSMutableParagraphStyle)
356:                         ?? NSMutableParagraphStyle()
357:             para.headIndent          += indent
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L356

```swift
354:         result.enumerateAttribute(.paragraphStyle, in: all, options: []) { val, range, _ in
355:             let para = ((val as? NSParagraphStyle)?.mutableCopy() as? NSMutableParagraphStyle)
356:                         ?? NSMutableParagraphStyle()
357:             para.headIndent          += indent
358:             para.firstLineHeadIndent += indent
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L551

```swift
549:                 }()
550: 
551:                 let cellPara = NSMutableParagraphStyle()
552:                 cellPara.alignment  = align
553:                 cellPara.textBlocks = [block]
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L578

```swift
576: 
577:     private func renderThematicBreak() -> NSAttributedString {
578:         let para = NSMutableParagraphStyle()
579:         para.paragraphSpacingBefore = 12
580:         para.paragraphSpacing       = 12
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L599

```swift
597:         let result = NSMutableAttributedString()
598:         for (key, value) in fm.fields {
599:             let para = NSMutableParagraphStyle()
600:             para.paragraphSpacing    = 2
601:             para.headIndent          = 14
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L699

```swift
697:     // MARK: - Paragraph style helpers
698: 
699:     private func bodyParagraphStyle() -> NSMutableParagraphStyle {
700:         let para = NSMutableParagraphStyle()
701:         para.lineHeightMultiple = theme.lineHeightMultiple
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L700

```swift
698: 
699:     private func bodyParagraphStyle() -> NSMutableParagraphStyle {
700:         let para = NSMutableParagraphStyle()
701:         para.lineHeightMultiple = theme.lineHeightMultiple
702:         para.paragraphSpacing   = theme.paragraphSpacing
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L706

```swift
704:     }
705: 
706:     private func listParagraphStyle(depth: Int, bulletWidth: CGFloat) -> NSMutableParagraphStyle {
707:         let indent = CGFloat(depth) * 24
708:         let para   = NSMutableParagraphStyle()
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L708

```swift
706:     private func listParagraphStyle(depth: Int, bulletWidth: CGFloat) -> NSMutableParagraphStyle {
707:         let indent = CGFloat(depth) * 24
708:         let para   = NSMutableParagraphStyle()
709:         para.lineHeightMultiple  = theme.lineHeightMultiple
710:         para.paragraphSpacing    = theme.paragraphSpacing * 0.35
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L443

```swift
441:         let charWidth = font.maximumAdvancement.width
442:         let tabInterval = charWidth * CGFloat(tabSize)
443:         let style = NSMutableParagraphStyle()
444:         style.defaultTabInterval = tabInterval
445:         style.tabStops = []
```

Agent note: `NSMutableParagraphStyle` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `NSOpenPanel` (4 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2926

```swift
2924: 
2925:     func openRepositoryPanel() {
2926:         let panel = NSOpenPanel()
2927:         panel.canChooseFiles = false
2928:         panel.canChooseDirectories = true
```

Agent note: `NSOpenPanel` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L30

```swift
28: 
29:     static func pickOne(message: String, allowedExtensions: [String]? = nil) -> URL? {
30:         let panel = NSOpenPanel()
31:         panel.canChooseFiles = true
32:         panel.canChooseDirectories = false
```

Agent note: `NSOpenPanel` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L195

```swift
193: 
194:     private func browse() {
195:         let panel = NSOpenPanel()
196:         panel.canChooseFiles = true
197:         panel.canChooseDirectories = true
```

Agent note: `NSOpenPanel` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L248

```swift
246: 
247:     func openFile() {
248:         let panel = NSOpenPanel()
249:         panel.allowedContentTypes = [
250:             .init(filenameExtension: "md") ?? .plainText,
```

Agent note: `NSOpenPanel` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSOutlineView` (6 hits)


### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L50

```swift
48:     private var flatCache: [FolderEntry]?
49: 
50:     private let outline = NSOutlineView()
51:     private let scroll = NSScrollView()
52:     private let summaryLabel = NSTextField(labelWithString: "")
```

Agent note: `NSOutlineView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L469

```swift
467: // MARK: - Outline data source / delegate
468: 
469: extension FolderCompareViewController: NSOutlineViewDataSource, NSOutlineViewDelegate {
470: 
471:     func outlineView(_ outlineView: NSOutlineView, numberOfChildrenOfItem item: Any?) -> Int {
```

Agent note: `NSOutlineView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L471

```swift
469: extension FolderCompareViewController: NSOutlineViewDataSource, NSOutlineViewDelegate {
470: 
471:     func outlineView(_ outlineView: NSOutlineView, numberOfChildrenOfItem item: Any?) -> Int {
472:         if flattened {
473:             return item == nil ? flatFiles().count : 0
```

Agent note: `NSOutlineView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L479

```swift
477:     }
478: 
479:     func outlineView(_ outlineView: NSOutlineView, child index: Int, ofItem item: Any?) -> Any {
480:         if flattened {
481:             return flatFiles()[index]
```

Agent note: `NSOutlineView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L487

```swift
485:     }
486: 
487:     func outlineView(_ outlineView: NSOutlineView, isItemExpandable item: Any) -> Bool {
488:         guard !flattened, let entry = item as? FolderEntry else { return false }
489:         return entry.isDirectory && !visibleChildren(of: entry).isEmpty
```

Agent note: `NSOutlineView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L492

```swift
490:     }
491: 
492:     func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {
493:         guard let entry = item as? FolderEntry, let column = tableColumn else { return nil }
494:         let field: NSTextField
```

Agent note: `NSOutlineView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

## `NSPasteboard` (20 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L818

```swift
816:             Button("Copy Path") {
817:                 if let path = repositoryURL?.path {
818:                     NSPasteboard.general.clearContents()
819:                     NSPasteboard.general.setString(path, forType: .string)
820:                 }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L819

```swift
817:                 if let path = repositoryURL?.path {
818:                     NSPasteboard.general.clearContents()
819:                     NSPasteboard.general.setString(path, forType: .string)
820:                 }
821:             }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L824

```swift
822:             if let remote = remoteURL {
823:                 Button("Copy Remote URL") {
824:                     NSPasteboard.general.clearContents()
825:                     NSPasteboard.general.setString(remote, forType: .string)
826:                 }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L825

```swift
823:                 Button("Copy Remote URL") {
824:                     NSPasteboard.general.clearContents()
825:                     NSPasteboard.general.setString(remote, forType: .string)
826:                 }
827:             }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2615

```swift
2613:         Divider()
2614:         Button {
2615:             NSPasteboard.general.clearContents()
2616:             NSPasteboard.general.setString(
2617:                 node.id.trimmingCharacters(in: CharacterSet(charactersIn: "/")),
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2616

```swift
2614:         Button {
2615:             NSPasteboard.general.clearContents()
2616:             NSPasteboard.general.setString(
2617:                 node.id.trimmingCharacters(in: CharacterSet(charactersIn: "/")),
2618:                 forType: .string)
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2623

```swift
2621:         }
2622:         Button {
2623:             NSPasteboard.general.clearContents()
2624:             NSPasteboard.general.setString(fileURL.path, forType: .string)
2625:         } label: {
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2624

```swift
2622:         Button {
2623:             NSPasteboard.general.clearContents()
2624:             NSPasteboard.general.setString(fileURL.path, forType: .string)
2625:         } label: {
2626:             Label("Copy Full Path", systemImage: "doc.on.clipboard.fill")
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3225

```swift
3223: 
3224:     func copyRelativePath(_ change: FileChange) {
3225:         NSPasteboard.general.clearContents()
3226:         NSPasteboard.general.setString(change.path, forType: .string)
3227:     }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3226

```swift
3224:     func copyRelativePath(_ change: FileChange) {
3225:         NSPasteboard.general.clearContents()
3226:         NSPasteboard.general.setString(change.path, forType: .string)
3227:     }
3228: 
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3231

```swift
3229:     func copyFullPath(_ change: FileChange) {
3230:         guard let repositoryURL else { return }
3231:         NSPasteboard.general.clearContents()
3232:         NSPasteboard.general.setString(repositoryURL.appendingPathComponent(change.path).path, forType: .string)
3233:     }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3232

```swift
3230:         guard let repositoryURL else { return }
3231:         NSPasteboard.general.clearContents()
3232:         NSPasteboard.general.setString(repositoryURL.appendingPathComponent(change.path).path, forType: .string)
3233:     }
3234: 
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4481

```swift
4479:                     Divider()
4480:                     Button {
4481:                         NSPasteboard.general.clearContents()
4482:                         NSPasteboard.general.setString(stat.path, forType: .string)
4483:                     } label: {
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4482

```swift
4480:                     Button {
4481:                         NSPasteboard.general.clearContents()
4482:                         NSPasteboard.general.setString(stat.path, forType: .string)
4483:                     } label: {
4484:                         Label("Copy Path", systemImage: "doc.on.clipboard")
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4628

```swift
4626:             Divider()
4627:             Button("Copy SHA") {
4628:                 NSPasteboard.general.clearContents()
4629:                 NSPasteboard.general.setString(sha, forType: .string)
4630:             }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4629

```swift
4627:             Button("Copy SHA") {
4628:                 NSPasteboard.general.clearContents()
4629:                 NSPasteboard.general.setString(sha, forType: .string)
4630:             }
4631:             Button("Copy Full SHA") {
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4632

```swift
4630:             }
4631:             Button("Copy Full SHA") {
4632:                 NSPasteboard.general.clearContents()
4633:                 NSPasteboard.general.setString(sha, forType: .string)
4634:             }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4633

```swift
4631:             Button("Copy Full SHA") {
4632:                 NSPasteboard.general.clearContents()
4633:                 NSPasteboard.general.setString(sha, forType: .string)
4634:             }
4635:         }
```

Agent note: `NSPasteboard` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L142

```swift
140:                                                            at: charIndex,
141:                                                            effectiveRange: nil) as? String {
142:                 NSPasteboard.general.clearContents()
143:                 NSPasteboard.general.setString(code, forType: .string)
144:                 return true
```

Agent note: `NSPasteboard` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L143

```swift
141:                                                            effectiveRange: nil) as? String {
142:                 NSPasteboard.general.clearContents()
143:                 NSPasteboard.general.setString(code, forType: .string)
144:                 return true
145:             }
```

Agent note: `NSPasteboard` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSRange` (57 hits)


### `MacMerge/Sources/DiffCore/IntraLine.swift` L2

```swift
1: /// Word-level refinement of a changed line pair. Returns changed character
2: /// ranges as UTF-16 offsets (directly convertible to NSRange by UI layers).
3: 
4: public struct IntraLineDiff: Sendable, Equatable {
```

Agent note: `NSRange` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L179

```swift
177:         }
178: 
179:         private func clamp(_ range: Range<Int>, to length: Int) -> NSRange? {
180:             let lower = max(0, min(range.lowerBound, length))
181:             let upper = max(lower, min(range.upperBound, length))
```

Agent note: `NSRange` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L183

```swift
181:             let upper = max(lower, min(range.upperBound, length))
182:             guard upper > lower else { return nil }
183:             return NSRange(location: lower, length: upper - lower)
184:         }
185:     }
```

Agent note: `NSRange` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/SyntaxKit/SyntaxKit.swift` L21

```swift
19: public struct Token: Sendable, Equatable {
20:     public let kind: TokenKind
21:     /// UTF-16 offsets within the line (convertible directly to NSRange).
22:     public let utf16Range: Range<Int>
23: 
```

Agent note: `NSRange` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L56

```swift
54: 
55: private func wrapInline(_ sel: String, pre: String, suf: String, placeholder: String,
56:                          at range: NSRange, tv: NSTextView) {
57:     let text   = tv.string as NSString
58:     let preLen = (pre as NSString).length
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L74

```swift
72:         let sufStart = range.location + selLen
73:         if sufStart + sufLen <= text.length {
74:             let preStr = text.substring(with: NSRange(location: preStart, length: preLen))
75:             let sufStr = text.substring(with: NSRange(location: sufStart, length: sufLen))
76:             if preStr == pre && sufStr == suf {
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L75

```swift
73:         if sufStart + sufLen <= text.length {
74:             let preStr = text.substring(with: NSRange(location: preStart, length: preLen))
75:             let sufStr = text.substring(with: NSRange(location: sufStart, length: sufLen))
76:             if preStr == pre && sufStr == suf {
77:                 let outerRange = NSRange(location: preStart, length: preLen + selLen + sufLen)
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L77

```swift
75:             let sufStr = text.substring(with: NSRange(location: sufStart, length: sufLen))
76:             if preStr == pre && sufStr == suf {
77:                 let outerRange = NSRange(location: preStart, length: preLen + selLen + sufLen)
78:                 replaceAndSelect(sel, at: outerRange, tv: tv, offset: 0, len: selLen)
79:                 return
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L92

```swift
90: }
91: 
92: private func toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange) {
93:     let text      = tv.string as NSString
94:     let fullLen   = text.length
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L95

```swift
93:     let text      = tv.string as NSString
94:     let fullLen   = text.length
95:     let lineRange = text.lineRange(for: NSRange(location: sel.location, length: 0))
96:     let lineStr   = text.substring(with: lineRange)
97:     let pLen      = (prefix as NSString).length
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L100

```swift
98:     if lineStr.hasPrefix(prefix) {
99:         // Remove prefix: cursor shifts left by pLen, clamped to line start.
100:         guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: pLen), replacementString: "") else { return }
101:         tv.replaceCharacters(in: NSRange(location: lineRange.location, length: pLen), with: "")
102:         tv.didChangeText()
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L101

```swift
99:         // Remove prefix: cursor shifts left by pLen, clamped to line start.
100:         guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: pLen), replacementString: "") else { return }
101:         tv.replaceCharacters(in: NSRange(location: lineRange.location, length: pLen), with: "")
102:         tv.didChangeText()
103:         let newLoc = max(lineRange.location, originalSel.location - pLen)
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L105

```swift
103:         let newLoc = max(lineRange.location, originalSel.location - pLen)
104:         let newLen = max(0, min(originalSel.length, fullLen - pLen - newLoc))
105:         tv.setSelectedRange(NSRange(location: newLoc, length: newLen))
106:     } else {
107:         // Add prefix: cursor shifts right by pLen.
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L108

```swift
106:     } else {
107:         // Add prefix: cursor shifts right by pLen.
108:         guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: 0), replacementString: prefix) else { return }
109:         tv.replaceCharacters(in: NSRange(location: lineRange.location, length: 0), with: prefix)
110:         tv.didChangeText()
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L109

```swift
107:         // Add prefix: cursor shifts right by pLen.
108:         guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: 0), replacementString: prefix) else { return }
109:         tv.replaceCharacters(in: NSRange(location: lineRange.location, length: 0), with: prefix)
110:         tv.didChangeText()
111:         let newLoc = originalSel.location + pLen
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L113

```swift
111:         let newLoc = originalSel.location + pLen
112:         let newLen = min(originalSel.length, max(0, fullLen + pLen - newLoc))
113:         tv.setSelectedRange(NSRange(location: newLoc, length: newLen))
114:     }
115: }
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L117

```swift
115: }
116: 
117: private func replaceAndSelect(_ rep: String, at range: NSRange, tv: NSTextView,
118:                                offset: Int, len: Int) {
119:     guard tv.shouldChangeText(in: range, replacementString: rep) else { return }
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L122

```swift
120:     tv.replaceCharacters(in: range, with: rep)
121:     tv.didChangeText()
122:     tv.setSelectedRange(NSRange(location: range.location + offset, length: len))
123: }
124: 
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L412

```swift
410:         let i = line - 1
411:         let ln = lines[i]
412:         let range = NSRange(location: 0, length: (ln as NSString).length)
413:         guard let match = Self.checkboxRegex?.firstMatch(in: ln, range: range),
414:               let stateRange = Range(match.range(at: 2), in: ln) else { return }
```

Agent note: `NSRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L42

```swift
40: 
41: final class MarkdownLayoutManager: NSLayoutManager {
42:     override func drawBackground(forGlyphRange glyphsToShow: NSRange, at origin: NSPoint) {
43:         guard let storage = textStorage, let container = textContainers.first else {
44:             super.drawBackground(forGlyphRange: glyphsToShow, at: origin)
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L48

```swift
46:         }
47:         let charRange = characterRange(forGlyphRange: glyphsToShow, actualGlyphRange: nil)
48:         var prev: (MarkdownBlockBackground, NSRange)? = nil
49: 
50:         func flush(_ range: NSRange, _ bg: MarkdownBlockBackground) {
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L50

```swift
48:         var prev: (MarkdownBlockBackground, NSRange)? = nil
49: 
50:         func flush(_ range: NSRange, _ bg: MarkdownBlockBackground) {
51:             let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)
52:             var rects: [NSRect] = []
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L117

```swift
115:                 guard iEnd > iStart else { return }
116:                 let codeRect = self.boundingRect(
117:                     forGlyphRange: NSRange(location: iStart, length: iEnd - iStart),
118:                     in: container)
119:                 let vMargin: CGFloat = 1
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L256

```swift
254:         let result = NSMutableAttributedString(attributedString: inner)
255:         result.append(NSAttributedString(string: "\n"))
256:         let all = NSRange(location: 0, length: result.length)
257:         result.addAttributes([.font: font, .foregroundColor: color, .paragraphStyle: para], range: all)
258:         result.addAttribute(.markdownHeadingTitle, value: inner.string, range: all)
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L269

```swift
267:         let result = NSMutableAttributedString(attributedString: inner)
268:         result.append(NSAttributedString(string: "\n"))
269:         let all  = NSRange(location: 0, length: result.length)
270:         let para = bodyParagraphStyle()
271:         result.addAttributes([.font: theme.bodyFont, .foregroundColor: theme.textColor,
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L351

```swift
349: 
350:         let indent = CGFloat(16)
351:         let all    = NSRange(location: 0, length: result.length)
352: 
353:         // Indent paragraph styles for this depth level.
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L369

```swift
367:             width:   4
368:         )
369:         var borderUpdates: [(NSRange, MarkdownBlockLeftBorders)] = []
370:         result.enumerateAttribute(.markdownBlockLeftBorders, in: all, options: []) { val, range, _ in
371:             let existing = (val as? MarkdownBlockLeftBorders)?.list ?? []
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L421

```swift
419:                 str.append(renderInlines(p))
420:                 str.append(NSAttributedString(string: "\n"))
421:                 str.addAttributes(baseAttrs, range: NSRange(location: 0, length: str.length))
422:                 result.append(str)
423:             } else if let ul = child as? UnorderedList {
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L449

```swift
447:                 str.append(renderInlines(p))
448:                 str.append(NSAttributedString(string: "\n"))
449:                 str.addAttributes(baseAttrs, range: NSRange(location: 0, length: str.length))
450:                 result.append(str)
451:             } else if let ul = child as? UnorderedList {
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L484

```swift
482:                 inline.addAttribute(.strikethroughStyle,
483:                                     value: NSUnderlineStyle.single.rawValue,
484:                                     range: NSRange(location: 0, length: inline.length))
485:                 inline.addAttribute(.foregroundColor, value: theme.secondaryTextColor,
486:                                     range: NSRange(location: 0, length: inline.length))
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L486

```swift
484:                                     range: NSRange(location: 0, length: inline.length))
485:                 inline.addAttribute(.foregroundColor, value: theme.secondaryTextColor,
486:                                     range: NSRange(location: 0, length: inline.length))
487:             }
488:             result.append(inline)
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L492

```swift
490:         }
491:         result.append(NSAttributedString(string: "\n"))
492:         result.addAttributes(baseAttrs, range: NSRange(location: 0, length: result.length))
493:         // Re-apply checkbox link attributes (overrides baseAttrs on first two chars)
494:         result.addAttributes(cbAttrs, range: NSRange(location: 0, length: min(2, result.length)))
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L494

```swift
492:         result.addAttributes(baseAttrs, range: NSRange(location: 0, length: result.length))
493:         // Re-apply checkbox link attributes (overrides baseAttrs on first two chars)
494:         result.addAttributes(cbAttrs, range: NSRange(location: 0, length: min(2, result.length)))
495:         return result
496:     }
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L566

```swift
564:                     .foregroundColor: theme.textColor,
565:                     .paragraphStyle: cellPara
566:                 ], range: NSRange(location: 0, length: content.length))
567:                 content.append(NSAttributedString(string: "\n"))
568:                 output.append(content)
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L625

```swift
623: 
624:     private func applyBold(_ str: NSMutableAttributedString) -> NSAttributedString {
625:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
626:             let f    = (val as? NSFont) ?? theme.bodyFont
627:             let bold = NSFont(descriptor: f.fontDescriptor.withSymbolicTraits(.bold), size: f.pointSize) ?? f
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L634

```swift
632: 
633:     private func applyItalic(_ str: NSMutableAttributedString) -> NSAttributedString {
634:         str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in
635:             let f      = (val as? NSFont) ?? theme.bodyFont
636:             var traits = f.fontDescriptor.symbolicTraits
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L646

```swift
644:     private func applyStrikethrough(_ str: NSMutableAttributedString) -> NSAttributedString {
645:         str.addAttribute(.strikethroughStyle, value: NSUnderlineStyle.single.rawValue,
646:                          range: NSRange(location: 0, length: str.length))
647:         return str
648:     }
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L661

```swift
659:         let inner  = renderInlines(link)
660:         let result = NSMutableAttributedString(attributedString: inner)
661:         let all    = NSRange(location: 0, length: result.length)
662:         if let dest = link.destination, let url = URL(string: dest) {
663:             result.addAttribute(.link, value: url, range: all)
```

Agent note: `NSRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L158

```swift
156:         var isInitialLoad: Bool = false
157:         /// Persists the last known selection so toolbar buttons can restore it after focus change.
158:         var savedSelectedRange: NSRange = NSRange(location: 0, length: 0)
159:         /// True while a toolbar format action is being applied; suppresses savedSelectedRange updates.
160:         var isApplyingFormat: Bool = false
```

Agent note: `NSRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L195

```swift
193:                 let rLen = min(coordinator.savedSelectedRange.length, len - loc)
194:                 coordinator.isApplyingFormat = true
195:                 tv.setSelectedRange(NSRange(location: loc, length: rLen))
196:                 applyMarkdownFormat(format, to: tv)
197:                 coordinator.isApplyingFormat = false
```

Agent note: `NSRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L258

```swift
256:                     return min(pos, nsNew.length)
257:                 }()
258:                 tv.setSelectedRange(NSRange(location: lineStart, length: 0))
259:                 // Background highlight: text is visible first, coloring follows on background
260:                 // thread so large files don't block the main thread (R-0049-01).
```

Agent note: `NSRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L276

```swift
274:             _ textStorage: NSTextStorage,
275:             didProcessEditing editedMask: NSTextStorageEditActions,
276:             range editedRange: NSRange,
277:             changeInLength delta: Int
278:         ) {
```

Agent note: `NSRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L301

```swift
299:             // No isLargeFile gate — syntax highlighting is never disabled for any file size (R-0049-02).
300:             let loc       = min(editedRange.location, fullLen - 1)
301:             var evalRange = str.paragraphRange(for: NSRange(location: loc, length: 0))
302: 
303:             // Expand scan window when the paragraph contains backticks or the document has
```

Agent note: `NSRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L311

```swift
309:                 let start = max(0, evalRange.location - 250)
310:                 let end   = min(fullLen, NSMaxRange(evalRange) + 250)
311:                 evalRange = NSRange(location: start, length: end - start)
312:             }
313: 
```

Agent note: `NSRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L415

```swift
413:         }
414: 
415:         private func showFloatingPanel(for tv: NSTextView, selectionRange: NSRange) {
416:             guard let lm = tv.layoutManager, let tc = tv.textContainer else { return }
417:             let glyphRange = lm.glyphRange(forCharacterRange: selectionRange, actualCharacterRange: nil)
```

Agent note: `NSRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L167

```swift
165:                   let scrollView = scrollViewRef else { return }
166:             var seen = 0
167:             var target: NSRange?
168:             let fullRange = NSRange(location: 0, length: storage.length)
169:             storage.enumerateAttribute(.markdownHeadingTitle, in: fullRange, options: []) { value, range, stop in
```

Agent note: `NSRange` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L168

```swift
166:             var seen = 0
167:             var target: NSRange?
168:             let fullRange = NSRange(location: 0, length: storage.length)
169:             storage.enumerateAttribute(.markdownHeadingTitle, in: fullRange, options: []) { value, range, stop in
170:                 guard let title = value as? String,
```

Agent note: `NSRange` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L6

```swift
4: 
5: struct SyntaxToken {
6:     let range: NSRange
7:     let attributes: [NSAttributedString.Key: Any]
8: }
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L79

```swift
77:         let ns       = text as NSString
78:         let fullLen  = ns.length
79:         let fullRange = NSRange(location: 0, length: fullLen)
80:         let base   = baseFont(size: fontSize, family: family)
81:         let bold   = boldFont(size: fontSize, family: family)
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L136

```swift
134:     static func collectTokensInline(
135:         text: String,
136:         paragraphRange: NSRange,
137:         fontSize: Double = 13,
138:         family: String = "",
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L148

```swift
146:         let len  = min(paragraphRange.length, fullLen - loc)
147:         guard len > 0 else { return [] }
148:         let safe = NSRange(location: loc, length: len)
149: 
150:         let base   = baseFont(size: fontSize, family: family)
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L225

```swift
223:         enabled: Bool = true,
224:         colors: SyntaxHighlightColors,
225:         paragraphRange: NSRange
226:     ) {
227:         let tokens = collectTokensInline(text: storage.string, paragraphRange: paragraphRange,
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L260

```swift
258:         _ text: String,
259:         _ ns: NSString,
260:         _ range: NSRange,
261:         attrs: [NSAttributedString.Key: Any],
262:         into tokens: inout [SyntaxToken]
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L274

```swift
272:         _ text: String,
273:         _ ns: NSString,
274:         _ range: NSRange,
275:         contentAttrs: [NSAttributedString.Key: Any],
276:         delimLen: Int,
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L284

```swift
282:             guard let r = match?.range, r.length > delimLen * 2 else { return }
283:             tokens.append(SyntaxToken(range: r, attributes: contentAttrs))
284:             tokens.append(SyntaxToken(range: NSRange(location: r.location, length: delimLen), attributes: dim))
285:             tokens.append(SyntaxToken(range: NSRange(location: NSMaxRange(r) - delimLen, length: delimLen), attributes: dim))
286:         }
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L285

```swift
283:             tokens.append(SyntaxToken(range: r, attributes: contentAttrs))
284:             tokens.append(SyntaxToken(range: NSRange(location: r.location, length: delimLen), attributes: dim))
285:             tokens.append(SyntaxToken(range: NSRange(location: NSMaxRange(r) - delimLen, length: delimLen), attributes: dim))
286:         }
287:     }
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L293

```swift
291:         _ text: String,
292:         _ ns: NSString,
293:         _ range: NSRange,
294:         textAttrs: [NSAttributedString.Key: Any],
295:         into tokens: inout [SyntaxToken]
```

Agent note: `NSRange` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

## `NSRulerView` (1 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L126

```swift
124: 
125: /// Line numbers per display row; phantom rows show no number.
126: final class LineNumberRuler: NSRulerView {
127: 
128:     weak var diffTextView: DiffTextView?
```

Agent note: `NSRulerView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

## `NSSavePanel` (3 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L609

```swift
607:             return
608:         }
609:         let panel = NSSavePanel()
610:         panel.nameFieldStringValue = leftURL.deletingPathExtension().lastPathComponent + ".patch"
611:         guard let window = view.window else { return }
```

Agent note: `NSSavePanel` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L310

```swift
308:             write(to: url)
309:         } else {
310:             let panel = NSSavePanel()
311:             panel.nameFieldStringValue = baseURL.lastPathComponent
312:             panel.directoryURL = baseURL.deletingLastPathComponent()
```

Agent note: `NSSavePanel` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L48

```swift
46: enum SessionWriter {
47:     static func save(_ session: ComparisonSession, suggestedName: String, in window: NSWindow?) {
48:         let panel = NSSavePanel()
49:         panel.nameFieldStringValue = "\(suggestedName).\(ComparisonSession.fileExtension)"
50:         if let type = UTType(filenameExtension: ComparisonSession.fileExtension, conformingTo: .json) {
```

Agent note: `NSSavePanel` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSScrollView` (16 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2075

```swift
2073:     func makeCoordinator() -> Coordinator { Coordinator() }
2074: 
2075:     func makeNSView(context: Context) -> NSScrollView {
2076:         let tv = NSTableView()
2077:         tv.headerView = nil
```

Agent note: `NSScrollView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2091

```swift
2089:         tv.dataSource = context.coordinator
2090:         context.coordinator.attachAppearanceObserver(to: tv)
2091:         let sv = NSScrollView()
2092:         sv.documentView = tv
2093:         sv.hasVerticalScroller = true
```

Agent note: `NSScrollView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2100

```swift
2098:     }
2099: 
2100:     func updateNSView(_ sv: NSScrollView, context: Context) {
2101:         guard let tv = sv.documentView as? NSTableView else { return }
2102:         let coord = context.coordinator
```

Agent note: `NSScrollView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L93

```swift
91: 
92:     /// Standard no-wrap diff editor configuration.
93:     static func makePane(editable: Bool) -> (scrollView: NSScrollView, textView: DiffTextView) {
94:         let scrollView = NSScrollView()
95:         scrollView.hasVerticalScroller = true
```

Agent note: `NSScrollView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L94

```swift
92:     /// Standard no-wrap diff editor configuration.
93:     static func makePane(editable: Bool) -> (scrollView: NSScrollView, textView: DiffTextView) {
94:         let scrollView = NSScrollView()
95:         scrollView.hasVerticalScroller = true
96:         scrollView.hasHorizontalScroller = true
```

Agent note: `NSScrollView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L133

```swift
131:     }
132: 
133:     init(scrollView: NSScrollView, textView: DiffTextView) {
134:         super.init(scrollView: scrollView, orientation: .verticalRuler)
135:         clientView = textView
```

Agent note: `NSScrollView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L46

```swift
44:     private var pendingTarget: PendingTarget = .none
45: 
46:     private var leftScroll: NSScrollView!
47:     private var rightScroll: NSScrollView!
48:     private var leftText: DiffTextView!
```

Agent note: `NSScrollView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L47

```swift
45: 
46:     private var leftScroll: NSScrollView!
47:     private var rightScroll: NSScrollView!
48:     private var leftText: DiffTextView!
49:     private var rightText: DiffTextView!
```

Agent note: `NSScrollView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L538

```swift
536:         if !syncing {
537:             syncing = true
538:             let other: NSScrollView = (clipView === leftScroll.contentView) ? rightScroll : leftScroll
539:             other.contentView.scroll(to: clipView.bounds.origin)
540:             other.reflectScrolledClipView(other.contentView)
```

Agent note: `NSScrollView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L51

```swift
49: 
50:     private let outline = NSOutlineView()
51:     private let scroll = NSScrollView()
52:     private let summaryLabel = NSTextField(labelWithString: "")
53:     private let pathLabel = NSTextField(labelWithString: "")
```

Agent note: `NSScrollView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L14

```swift
12:     @EnvironmentObject var appearance: AppearanceSettings
13: 
14:     func makeNSView(context: Context) -> NSScrollView {
15:         let scrollView = NSTextView.scrollableTextView()
16:         guard let textView = scrollView.documentView as? NSTextView else { return scrollView }
```

Agent note: `NSScrollView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L80

```swift
78:     }
79: 
80:     func updateNSView(_ scrollView: NSScrollView, context: Context) {
81:         guard let textView = scrollView.documentView as? NSTextView else { return }
82:         let cW = Int(textView.textContainer?.containerSize.width ?? -1)
```

Agent note: `NSScrollView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L26

```swift
24:     }
25: 
26:     func makeNSView(context: Context) -> NSScrollView {
27:         // Manual construction so we can inject MarkdownLayoutManager.
28:         let textStorage = NSTextStorage()
```

Agent note: `NSScrollView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L74

```swift
72:         context.coordinator.lastAttributedString = attributedString
73: 
74:         let scrollView = NSScrollView()
75:         scrollView.documentView        = textView
76:         scrollView.hasVerticalScroller  = true
```

Agent note: `NSScrollView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L84

```swift
82:     }
83: 
84:     func updateNSView(_ scrollView: NSScrollView, context: Context) {
85:         context.coordinator.onToggle       = onToggleCheckbox
86:         context.coordinator.onRelativeLink = onRelativeLink
```

Agent note: `NSScrollView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L109

```swift
107:         var onRelativeLink: ((URL) -> Void)?
108:         weak var textViewRef:         NSTextView?
109:         weak var scrollViewRef:       NSScrollView?
110:         weak var lastAttributedString: NSAttributedString?
111:         var pendingScrollOrigin:       NSPoint? = nil
```

Agent note: `NSScrollView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSStackView` (12 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L146

```swift
144:         let spacer = NSView()
145:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
146:         let controlBar = NSStackView(views: [
147:             backButton, prevButton, nextButton, counterLabel, spinner, spacer,
148:             prevFileButton, fileNavLabel, nextFileButton,
```

Agent note: `NSStackView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L155

```swift
153:         controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
154: 
155:         let contentRow = NSStackView(views: [leftScroll, rightScroll, overview])
156:         contentRow.orientation = .horizontal
157:         contentRow.spacing = 1
```

Agent note: `NSStackView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L170

```swift
168:         let statusSpacer = NSView()
169:         statusSpacer.setContentHuggingPriority(.init(1), for: .horizontal)
170:         let statusBar = NSStackView(views: [leftStatus, statusSpacer, rightStatus])
171:         statusBar.orientation = .horizontal
172:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
```

Agent note: `NSStackView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L174

```swift
172:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
173: 
174:         let main = NSStackView(views: [controlBar, contentRow, statusBar])
175:         main.orientation = .vertical
176:         main.spacing = 0
```

Agent note: `NSStackView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L124

```swift
122:         let spacer = NSView()
123:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
124:         let controlBar = NSStackView(views: [backButton, filterPopup, flattenCheckbox, refreshButton, spinner, spacer, summaryLabel])
125:         controlBar.orientation = .horizontal
126:         controlBar.spacing = 8
```

Agent note: `NSStackView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L138

```swift
136:         pathLabel.lineBreakMode = .byTruncatingMiddle
137:         pathLabel.stringValue = "\(leftRoot.path)   ⇄   \(rightRoot.path)"
138:         let statusBar = NSStackView(views: [pathLabel])
139:         statusBar.orientation = .horizontal
140:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
```

Agent note: `NSStackView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L142

```swift
140:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
141: 
142:         let main = NSStackView(views: [controlBar, scroll, statusBar])
143:         main.orientation = .vertical
144:         main.spacing = 0
```

Agent note: `NSStackView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L84

```swift
82:             label.textColor = .secondaryLabelColor
83:             label.alignment = .center
84:             let stack = NSStackView(views: [label, scroll])
85:             stack.orientation = .vertical
86:             stack.spacing = 2
```

Agent note: `NSStackView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L98

```swift
96:         rightText = rt
97: 
98:         let sourcesRow = NSStackView(views: [leftPane, basePane, rightPane])
99:         sourcesRow.orientation = .horizontal
100:         sourcesRow.spacing = 1
```

Agent note: `NSStackView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L114

```swift
112:         outputLabel.textColor = .secondaryLabelColor
113:         outputLabel.alignment = .center
114:         let outputPane = NSStackView(views: [outputLabel, outputScroll])
115:         outputPane.orientation = .vertical
116:         outputPane.spacing = 2
```

Agent note: `NSStackView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L137

```swift
135:         let spacer = NSView()
136:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
137:         let controlBar = NSStackView(views: [prevButton, nextButton, counterLabel, spinner, spacer, saveButton])
138:         controlBar.orientation = .horizontal
139:         controlBar.spacing = 8
```

Agent note: `NSStackView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L143

```swift
141: 
142:         split.setContentHuggingPriority(.init(1), for: .vertical)
143:         let main = NSStackView(views: [controlBar, split])
144:         main.orientation = .vertical
145:         main.spacing = 0
```

Agent note: `NSStackView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `NSString` (32 hits)


### `MacGit/Sources/MacGitApp/SocketBridge.swift` L64

```swift
62:     func start() {
63:         guard serverFD < 0 else { return }
64:         let path = (NSTemporaryDirectory() as NSString).appendingPathComponent("macgit-\(ProcessInfo.processInfo.processIdentifier).sock")
65: 
66:         // Validate path length before bind() to avoid silent truncation.
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L167

```swift
165:             let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
166:             let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY
167:             let label = labels[row] as NSString
168:             let size = label.size(withAttributes: attrs)
169:             label.draw(
```

Agent note: `NSString` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L101

```swift
99: 
100:     private func expanded(_ path: String) -> String {
101:         (path.trimmingCharacters(in: .whitespacesAndNewlines) as NSString).expandingTildeInPath
102:     }
103: 
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L132

```swift
130: 
131:     private var name: String {
132:         let left = (item.leftPath as NSString).lastPathComponent
133:         let right = (item.rightPath as NSString).lastPathComponent
134:         return left == right ? left : "\(left) ⇄ \(right)"
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L133

```swift
131:     private var name: String {
132:         let left = (item.leftPath as NSString).lastPathComponent
133:         let right = (item.rightPath as NSString).lastPathComponent
134:         return left == right ? left : "\(left) ⇄ \(right)"
135:     }
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/TextEngine/EncodingDetector.swift` L20

```swift
18: 
19:         let gb18030 = String.Encoding(
20:             rawValue: CFStringConvertEncodingToNSStringEncoding(
21:                 CFStringEncoding(CFStringEncodings.GB_18030_2000.rawValue)))
22: 
```

Agent note: `NSString` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L21

```swift
19: func applyMarkdownFormat(_ format: MarkdownFormat, to tv: NSTextView) {
20:     let sel   = tv.selectedRange()
21:     let text  = tv.string as NSString
22:     let inner = text.substring(with: sel)
23: 
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L57

```swift
55: private func wrapInline(_ sel: String, pre: String, suf: String, placeholder: String,
56:                          at range: NSRange, tv: NSTextView) {
57:     let text   = tv.string as NSString
58:     let preLen = (pre as NSString).length
59:     let sufLen = (suf as NSString).length
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L58

```swift
56:                          at range: NSRange, tv: NSTextView) {
57:     let text   = tv.string as NSString
58:     let preLen = (pre as NSString).length
59:     let sufLen = (suf as NSString).length
60:     let selLen = (sel as NSString).length
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L59

```swift
57:     let text   = tv.string as NSString
58:     let preLen = (pre as NSString).length
59:     let sufLen = (suf as NSString).length
60:     let selLen = (sel as NSString).length
61: 
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L60

```swift
58:     let preLen = (pre as NSString).length
59:     let sufLen = (suf as NSString).length
60:     let selLen = (sel as NSString).length
61: 
62:     // Case A: selection itself includes the markers (e.g. user selected "**text**").
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L65

```swift
63:     if selLen > preLen + sufLen && sel.hasPrefix(pre) && sel.hasSuffix(suf) {
64:         let inner = String(sel.dropFirst(pre.count).dropLast(suf.count))
65:         replaceAndSelect(inner, at: range, tv: tv, offset: 0, len: (inner as NSString).length)
66:         return
67:     }
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L93

```swift
91: 
92: private func toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange) {
93:     let text      = tv.string as NSString
94:     let fullLen   = text.length
95:     let lineRange = text.lineRange(for: NSRange(location: sel.location, length: 0))
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L97

```swift
95:     let lineRange = text.lineRange(for: NSRange(location: sel.location, length: 0))
96:     let lineStr   = text.substring(with: lineRange)
97:     let pLen      = (prefix as NSString).length
98:     if lineStr.hasPrefix(prefix) {
99:         // Remove prefix: cursor shifts left by pLen, clamped to line start.
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L412

```swift
410:         let i = line - 1
411:         let ln = lines[i]
412:         let range = NSRange(location: 0, length: (ln as NSString).length)
413:         guard let match = Self.checkboxRegex?.firstMatch(in: ln, range: range),
414:               let stateRange = Range(match.range(at: 2), in: ln) else { return }
```

Agent note: `NSString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L135

```swift
133: 
134:     private func lineIndex(of charOffset: Int, in string: String) -> Int {
135:         let ns = string as NSString
136:         let clamped = min(charOffset, ns.length)
137:         return (ns.substring(to: clamped) as NSString).components(separatedBy: "\n").count - 1
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L137

```swift
135:         let ns = string as NSString
136:         let clamped = min(charOffset, ns.length)
137:         return (ns.substring(to: clamped) as NSString).components(separatedBy: "\n").count - 1
138:     }
139: 
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L141

```swift
139: 
140:     private func startOffset(of targetLine: Int, in string: String) -> Int {
141:         let lines = (string as NSString).components(separatedBy: "\n")
142:         let line  = max(0, min(targetLine, lines.count - 1))
143:         var pos   = 0
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L144

```swift
142:         let line  = max(0, min(targetLine, lines.count - 1))
143:         var pos   = 0
144:         for i in 0..<line { pos += (lines[i] as NSString).length + 1 }
145:         return min(pos, (string as NSString).length)
146:     }
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L145

```swift
143:         var pos   = 0
144:         for i in 0..<line { pos += (lines[i] as NSString).length + 1 }
145:         return min(pos, (string as NSString).length)
146:     }
147: 
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L191

```swift
189:                 guard let win = tv.window, win.isKeyWindow else { return }
190:                 win.makeFirstResponder(tv)
191:                 let len  = (tv.string as NSString).length
192:                 let loc  = min(coordinator.savedSelectedRange.location, len)
193:                 let rLen = min(coordinator.savedSelectedRange.length, len - loc)
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L236

```swift
234:                 // Preserve caret line so the view doesn't jump to top on reload.
235:                 let caretPos  = tv.selectedRanges.first?.rangeValue.location ?? 0
236:                 let nsOld     = tv.string as NSString
237:                 let caretLine = nsOld.length > 0
238:                     ? (nsOld.substring(to: min(caretPos, nsOld.length)) as NSString)
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L238

```swift
236:                 let nsOld     = tv.string as NSString
237:                 let caretLine = nsOld.length > 0
238:                     ? (nsOld.substring(to: min(caretPos, nsOld.length)) as NSString)
239:                         .components(separatedBy: "\n").count - 1
240:                     : 0
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L250

```swift
248:                 lastText = text
249:                 // Restore caret position (clamped to new length).
250:                 let nsNew = text as NSString
251:                 let lineStart: Int = {
252:                     var pos = 0
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L255

```swift
253:                     let lines = nsNew.components(separatedBy: "\n")
254:                     let line  = max(0, min(caretLine, lines.count - 1))
255:                     for i in 0..<line { pos += (lines[i] as NSString).length + 1 }
256:                     return min(pos, nsNew.length)
257:                 }()
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L288

```swift
286:             }
287: 
288:             let str     = textStorage.string as NSString
289:             let fullLen = str.length
290:             guard fullLen > 0 else { return }
```

Agent note: `NSString` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L77

```swift
75:     ) -> [SyntaxToken] {
76:         guard !text.isEmpty else { return [] }
77:         let ns       = text as NSString
78:         let fullLen  = ns.length
79:         let fullRange = NSRange(location: 0, length: fullLen)
```

Agent note: `NSString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L142

```swift
140:         colors: SyntaxHighlightColors
141:     ) -> [SyntaxToken] {
142:         let ns      = text as NSString
143:         let fullLen = ns.length
144:         guard fullLen > 0 else { return [] }
```

Agent note: `NSString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L254

```swift
252:     }
253: 
254:     // MARK: - Private collect helpers (thread-safe; operate on a pre-bridged NSString)
255: 
256:     private static func collect(
```

Agent note: `NSString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L259

```swift
257:         _ regex: NSRegularExpression?,
258:         _ text: String,
259:         _ ns: NSString,
260:         _ range: NSRange,
261:         attrs: [NSAttributedString.Key: Any],
```

Agent note: `NSString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L273

```swift
271:         _ regex: NSRegularExpression?,
272:         _ text: String,
273:         _ ns: NSString,
274:         _ range: NSRange,
275:         contentAttrs: [NSAttributedString.Key: Any],
```

Agent note: `NSString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L292

```swift
290:         _ regex: NSRegularExpression?,
291:         _ text: String,
292:         _ ns: NSString,
293:         _ range: NSRange,
294:         textAttrs: [NSAttributedString.Key: Any],
```

Agent note: `NSString` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

## `NSTableColumn` (5 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2078

```swift
2076:         let tv = NSTableView()
2077:         tv.headerView = nil
2078:         let col = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("col"))
2079:         col.minWidth = 600
2080:         col.width = 3000
```

Agent note: `NSTableColumn` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2139

```swift
2137:         }
2138: 
2139:         func tableView(_ tv: NSTableView, viewFor col: NSTableColumn?, row: Int) -> NSView? {
2140:             if row >= items.count { return capView(tv) }
2141:             switch items[row] {
```

Agent note: `NSTableColumn` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L159

```swift
157: 
158:     private func configureOutline() {
159:         func column(_ id: NSUserInterfaceItemIdentifier, _ title: String, width: CGFloat) -> NSTableColumn {
160:             let column = NSTableColumn(identifier: id)
161:             column.title = title
```

Agent note: `NSTableColumn` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L160

```swift
158:     private func configureOutline() {
159:         func column(_ id: NSUserInterfaceItemIdentifier, _ title: String, width: CGFloat) -> NSTableColumn {
160:             let column = NSTableColumn(identifier: id)
161:             column.title = title
162:             column.width = width
```

Agent note: `NSTableColumn` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L492

```swift
490:     }
491: 
492:     func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {
493:         guard let entry = item as? FolderEntry, let column = tableColumn else { return nil }
494:         let field: NSTextField
```

Agent note: `NSTableColumn` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

## `NSTableView` (13 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1699

```swift
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
1698:     nonisolated static let visualMaxLines = 50_000
1699:     // Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.
1700:     nonisolated static let swiftUIThreshold = 500
1701: 
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2067

```swift
2065: }
2066: 
2067: // MARK: - Phase 6: Virtualized diff renderer (AppKit NSTableView for large visual diffs)
2068: 
2069: private struct VirtualizedDiffView: NSViewRepresentable {
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2076

```swift
2074: 
2075:     func makeNSView(context: Context) -> NSScrollView {
2076:         let tv = NSTableView()
2077:         tv.headerView = nil
2078:         let col = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("col"))
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2101

```swift
2099: 
2100:     func updateNSView(_ sv: NSScrollView, context: Context) {
2101:         guard let tv = sv.documentView as? NSTableView else { return }
2102:         let coord = context.coordinator
2103:         let changed = coord.items.count != items.count
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2110

```swift
2108: 
2109:     @MainActor
2110:     final class Coordinator: NSObject, NSTableViewDataSource, NSTableViewDelegate {
2111:         var items: [DiffPreviewModel.VisualItem] = []
2112:         var totalLineCount: Int = 0
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2114

```swift
2112:         var totalLineCount: Int = 0
2113: 
2114:         private weak var tableView: NSTableView?
2115:         private var appearanceObservation: NSKeyValueObservation?
2116: 
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2117

```swift
2115:         private var appearanceObservation: NSKeyValueObservation?
2116: 
2117:         func attachAppearanceObserver(to tv: NSTableView) {
2118:             tableView = tv
2119:             appearanceObservation = NSApp.observe(\.effectiveAppearance) { [weak self] _, _ in
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2128

```swift
2126:         }
2127: 
2128:         func numberOfRows(in tv: NSTableView) -> Int { rowCount }
2129: 
2130:         func tableView(_ tv: NSTableView, heightOfRow row: Int) -> CGFloat {
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2130

```swift
2128:         func numberOfRows(in tv: NSTableView) -> Int { rowCount }
2129: 
2130:         func tableView(_ tv: NSTableView, heightOfRow row: Int) -> CGFloat {
2131:             if row >= items.count { return 20 }
2132:             switch items[row] {
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2139

```swift
2137:         }
2138: 
2139:         func tableView(_ tv: NSTableView, viewFor col: NSTableColumn?, row: Int) -> NSView? {
2140:             if row >= items.count { return capView(tv) }
2141:             switch items[row] {
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2148

```swift
2146:         }
2147: 
2148:         private func capView(_ tv: NSTableView) -> NSView {
2149:             let nsId = NSUserInterfaceItemIdentifier("capMsg")
2150:             if let v = tv.makeView(withIdentifier: nsId, owner: nil) as? NSTextField {
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2165

```swift
2163:         }
2164: 
2165:         private func sectionView(_ tv: NSTableView, id: String, text: String, isFile: Bool) -> NSView {
2166:             let nsId = NSUserInterfaceItemIdentifier(id)
2167:             if let v = tv.makeView(withIdentifier: nsId, owner: nil) {
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2201

```swift
2199:         }
2200: 
2201:         private func lineView(_ tv: NSTableView, line: DiffLine) -> NSView {
2202:             let nsId = NSUserInterfaceItemIdentifier("diffLine")
2203:             if let v = tv.makeView(withIdentifier: nsId, owner: nil) {
```

Agent note: `NSTableView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

## `NSTextAttachment` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L679

```swift
677:             let resolved = base.appendingPathComponent(relPath).standardized
678:             if resolved.isFileURL, let nsImage = NSImage(contentsOf: resolved) {
679:                 let attachment = NSTextAttachment()
680:                 attachment.image = nsImage
681:                 let natural = nsImage.size
```

Agent note: `NSTextAttachment` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

## `NSTextContainer` (2 hits)


### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L30

```swift
28:         let textStorage = NSTextStorage()
29:         let layoutMgr   = MarkdownLayoutManager()
30:         let container   = NSTextContainer(size: NSSize(width: 0, height: CGFloat.greatestFiniteMagnitude))
31:         container.widthTracksTextView = true
32:         layoutMgr.addTextContainer(container)
```

Agent note: `NSTextContainer` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L120

```swift
118: 
119:         func layoutManager(_ layoutManager: NSLayoutManager,
120:                            didCompleteLayoutFor textContainer: NSTextContainer?,
121:                            atEnd layoutFinishedFlag: Bool) {
122:             guard layoutFinishedFlag,
```

Agent note: `NSTextContainer` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSTextField` (25 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2150

```swift
2148:         private func capView(_ tv: NSTableView) -> NSView {
2149:             let nsId = NSUserInterfaceItemIdentifier("capMsg")
2150:             if let v = tv.makeView(withIdentifier: nsId, owner: nil) as? NSTextField {
2151:                 v.stringValue = capText()
2152:                 return v
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2154

```swift
2152:                 return v
2153:             }
2154:             let f = NSTextField(labelWithString: capText())
2155:             f.identifier = nsId
2156:             f.font = .monospacedSystemFont(ofSize: 9, weight: .regular)
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2174

```swift
2172:             box.identifier = nsId
2173:             box.wantsLayer = true
2174:             let label = NSTextField(labelWithString: "")
2175:             label.identifier = NSUserInterfaceItemIdentifier("lbl")
2176:             label.isSelectable = true
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2192

```swift
2190:             v.wantsLayer = true
2191:             v.layer?.backgroundColor = NSColor.secondaryLabelColor.withAlphaComponent(alpha).cgColor
2192:             if let label = v.subviews.first(where: { $0.identifier?.rawValue == "lbl" }) as? NSTextField {
2193:                 label.stringValue = text
2194:                 label.font = isFile
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2213

```swift
2211:             let monoCaption: NSFont = .monospacedSystemFont(ofSize: 11, weight: .regular)
2212: 
2213:             func numField(id: String) -> NSTextField {
2214:                 let f = NSTextField(labelWithString: "")
2215:                 f.identifier = NSUserInterfaceItemIdentifier(id)
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2214

```swift
2212: 
2213:             func numField(id: String) -> NSTextField {
2214:                 let f = NSTextField(labelWithString: "")
2215:                 f.identifier = NSUserInterfaceItemIdentifier(id)
2216:                 f.font = monoCaption2
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2225

```swift
2223:             let oldNum = numField(id: "oldNum")
2224:             let newNum = numField(id: "newNum")
2225:             let marker = NSTextField(labelWithString: "")
2226:             marker.identifier = NSUserInterfaceItemIdentifier("marker")
2227:             marker.font = monoCaption
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2230

```swift
2228:             marker.isSelectable = false
2229:             marker.translatesAutoresizingMaskIntoConstraints = false
2230:             let text = NSTextField(labelWithString: "")
2231:             text.identifier = NSUserInterfaceItemIdentifier("text")
2232:             text.font = monoCaption
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2279

```swift
2277:             for sub in v.subviews {
2278:                 switch sub.identifier?.rawValue {
2279:                 case "oldNum": (sub as? NSTextField)?.stringValue = line.oldNumber.map { "\($0)" } ?? ""
2280:                 case "newNum": (sub as? NSTextField)?.stringValue = line.newNumber.map { "\($0)" } ?? ""
2281:                 case "marker":
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2280

```swift
2278:                 switch sub.identifier?.rawValue {
2279:                 case "oldNum": (sub as? NSTextField)?.stringValue = line.oldNumber.map { "\($0)" } ?? ""
2280:                 case "newNum": (sub as? NSTextField)?.stringValue = line.newNumber.map { "\($0)" } ?? ""
2281:                 case "marker":
2282:                     if let f = sub as? NSTextField { f.stringValue = markerStr; f.textColor = markerColor }
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2282

```swift
2280:                 case "newNum": (sub as? NSTextField)?.stringValue = line.newNumber.map { "\($0)" } ?? ""
2281:                 case "marker":
2282:                     if let f = sub as? NSTextField { f.stringValue = markerStr; f.textColor = markerColor }
2283:                 case "text": (sub as? NSTextField)?.stringValue = line.text
2284:                 default: break
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2283

```swift
2281:                 case "marker":
2282:                     if let f = sub as? NSTextField { f.stringValue = markerStr; f.textColor = markerColor }
2283:                 case "text": (sub as? NSTextField)?.stringValue = line.text
2284:                 default: break
2285:                 }
```

Agent note: `NSTextField` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L53

```swift
51:     private var rightRuler: LineNumberRuler!
52:     private let overview = OverviewStripView()
53:     private let counterLabel = NSTextField(labelWithString: "")
54:     private let leftStatus = NSTextField(labelWithString: "")
55:     private let rightStatus = NSTextField(labelWithString: "")
```

Agent note: `NSTextField` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L54

```swift
52:     private let overview = OverviewStripView()
53:     private let counterLabel = NSTextField(labelWithString: "")
54:     private let leftStatus = NSTextField(labelWithString: "")
55:     private let rightStatus = NSTextField(labelWithString: "")
56:     private let fileNavLabel = NSTextField(labelWithString: "")
```

Agent note: `NSTextField` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L55

```swift
53:     private let counterLabel = NSTextField(labelWithString: "")
54:     private let leftStatus = NSTextField(labelWithString: "")
55:     private let rightStatus = NSTextField(labelWithString: "")
56:     private let fileNavLabel = NSTextField(labelWithString: "")
57:     private var backButton: NSButton!
```

Agent note: `NSTextField` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L56

```swift
54:     private let leftStatus = NSTextField(labelWithString: "")
55:     private let rightStatus = NSTextField(labelWithString: "")
56:     private let fileNavLabel = NSTextField(labelWithString: "")
57:     private var backButton: NSButton!
58:     private var prevFileButton: NSButton!
```

Agent note: `NSTextField` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L52

```swift
50:     private let outline = NSOutlineView()
51:     private let scroll = NSScrollView()
52:     private let summaryLabel = NSTextField(labelWithString: "")
53:     private let pathLabel = NSTextField(labelWithString: "")
54:     private let spinner = NSProgressIndicator()
```

Agent note: `NSTextField` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L53

```swift
51:     private let scroll = NSScrollView()
52:     private let summaryLabel = NSTextField(labelWithString: "")
53:     private let pathLabel = NSTextField(labelWithString: "")
54:     private let spinner = NSProgressIndicator()
55:     private var filterPopup: NSPopUpButton!
```

Agent note: `NSTextField` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L494

```swift
492:     func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {
493:         guard let entry = item as? FolderEntry, let column = tableColumn else { return nil }
494:         let field: NSTextField
495:         if let reused = outlineView.makeView(withIdentifier: column.identifier, owner: self) as? NSTextField {
496:             field = reused
```

Agent note: `NSTextField` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L495

```swift
493:         guard let entry = item as? FolderEntry, let column = tableColumn else { return nil }
494:         let field: NSTextField
495:         if let reused = outlineView.makeView(withIdentifier: column.identifier, owner: self) as? NSTextField {
496:             field = reused
497:         } else {
```

Agent note: `NSTextField` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L498

```swift
496:             field = reused
497:         } else {
498:             field = NSTextField(labelWithString: "")
499:             field.identifier = column.identifier
500:             field.lineBreakMode = .byTruncatingMiddle
```

Agent note: `NSTextField` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L507

```swift
505:     }
506: 
507:     private func configure(_ field: NSTextField, column: NSUserInterfaceItemIdentifier, entry: FolderEntry) {
508:         let leftPresent = entry.left != nil || (entry.isDirectory && entry.status != .rightOnly)
509:         let rightPresent = entry.right != nil || (entry.isDirectory && entry.status != .leftOnly)
```

Agent note: `NSTextField` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L32

```swift
30:     private var outputText: DiffTextView!
31:     private var outputRuler: LineNumberRuler!
32:     private let counterLabel = NSTextField(labelWithString: "")
33:     private let spinner = NSProgressIndicator()
34: 
```

Agent note: `NSTextField` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L80

```swift
78:         func sourcePane(_ header: String) -> (NSView, DiffTextView) {
79:             let (scroll, text) = DiffTextView.makePane(editable: false)
80:             let label = NSTextField(labelWithString: header)
81:             label.font = .systemFont(ofSize: 11, weight: .semibold)
82:             label.textColor = .secondaryLabelColor
```

Agent note: `NSTextField` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L110

```swift
108:         outputScroll.hasVerticalRuler = true
109:         outputScroll.rulersVisible = true
110:         let outputLabel = NSTextField(labelWithString: "Output")
111:         outputLabel.font = .systemFont(ofSize: 11, weight: .semibold)
112:         outputLabel.textColor = .secondaryLabelColor
```

Agent note: `NSTextField` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `NSTextStorage` (16 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L47

```swift
45:         benchLog("[BENCH] makeNSView frameW=\(Int(scrollView.frame.width)) containerW=\(initCW)")
46: 
47:         // isInitialLoad suppresses the synchronous NSTextStorageDelegate highlight callback
48:         // so the text appears immediately; deferred async applyFull runs on the next pass.
49:         if !initialText.isEmpty {
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150

```swift
148:     // MARK: - Coordinator
149: 
150:     final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {
151:         var parent: MarkdownEditorView
152:         var lastSyntaxHighlighting: Bool = true
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L161

```swift
159:         /// True while a toolbar format action is being applied; suppresses savedSelectedRange updates.
160:         var isApplyingFormat: Bool = false
161:         /// Location and delta captured from NSTextStorageDelegate during undo/redo.
162:         var undoEditLoc: Int = NSNotFound
163:         var undoDelta: Int = 0
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L177

```swift
175:         private var highlightDebounceTimer: DispatchWorkItem?
176:         // Cached text updated on main thread in textDidChange; used in deinit instead of
177:         // tv.string to avoid a potential NSTextStorage read off the main thread (R-0050-03).
178:         fileprivate var lastText: String = ""
179: 
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L219

```swift
217:             // Push the live text to AppState so save works when the editor pane disappears
218:             // (e.g. user switches to preview-only mode).
219:             // Use lastText rather than tv.string — the NSTextStorage may be on a layout pass
220:             // and tv.string is unsafe to read off the main thread (R-0050-03).
221:             parent.onViewDisappear(lastText)
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L241

```swift
239:                         .components(separatedBy: "\n").count - 1
240:                     : 0
241:                 // isInitialLoad suppresses the NSTextStorageDelegate sync highlight so
242:                 // text appears immediately; deferred async applyFull handles coloring.
243:                 isInitialLoad = true
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L271

```swift
269:         }
270: 
271:         // MARK: NSTextStorageDelegate
272: 
273:         func textStorage(
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L274

```swift
272: 
273:         func textStorage(
274:             _ textStorage: NSTextStorage,
275:             didProcessEditing editedMask: NSTextStorageEditActions,
276:             range editedRange: NSRange,
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L275

```swift
273:         func textStorage(
274:             _ textStorage: NSTextStorage,
275:             didProcessEditing editedMask: NSTextStorageEditActions,
276:             range editedRange: NSRange,
277:             changeInLength delta: Int
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L319

```swift
317: 
318:             // Debounced background full-document highlight: fires 300 ms after typing settles.
319:             // String(…) forces an independent copy of the NSTextStorage backing buffer so the
320:             // background thread never aliases live storage memory (R-0049-01).
321:             let snapshot = String(textStorage.string)
```

Agent note: `NSTextStorage` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L28

```swift
26:     func makeNSView(context: Context) -> NSScrollView {
27:         // Manual construction so we can inject MarkdownLayoutManager.
28:         let textStorage = NSTextStorage()
29:         let layoutMgr   = MarkdownLayoutManager()
30:         let container   = NSTextContainer(size: NSSize(width: 0, height: CGFloat.greatestFiniteMagnitude))
```

Agent note: `NSTextStorage` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L197

```swift
195:     // Apply a pre-computed token array to storage.
196:     // Must be called on the main thread; caller wraps in beginEditing/endEditing.
197:     static func applyTokens(_ tokens: [SyntaxToken], to storage: NSTextStorage) {
198:         for token in tokens {
199:             storage.addAttributes(token.attributes, range: token.range)
```

Agent note: `NSTextStorage` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L206

```swift
204: 
205:     static func applyFull(
206:         _ storage: NSTextStorage,
207:         fontSize: Double = 13,
208:         family: String = "",
```

Agent note: `NSTextStorage` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L220

```swift
218: 
219:     static func applyInline(
220:         _ storage: NSTextStorage,
221:         fontSize: Double = 13,
222:         family: String = "",
```

Agent note: `NSTextStorage` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L236

```swift
234:     // MARK: - Public highlight wrappers (with begin/endEditing — for external callers)
235: 
236:     static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {
237:         let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
238:         let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
```

Agent note: `NSTextStorage` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L243

```swift
241: 
242:     static func highlight(
243:         _ storage: NSTextStorage,
244:         fontSize: Double,
245:         family: String = "",
```

Agent note: `NSTextStorage` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

## `NSTextStorageDelegate` (5 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L47

```swift
45:         benchLog("[BENCH] makeNSView frameW=\(Int(scrollView.frame.width)) containerW=\(initCW)")
46: 
47:         // isInitialLoad suppresses the synchronous NSTextStorageDelegate highlight callback
48:         // so the text appears immediately; deferred async applyFull runs on the next pass.
49:         if !initialText.isEmpty {
```

Agent note: `NSTextStorageDelegate` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150

```swift
148:     // MARK: - Coordinator
149: 
150:     final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {
151:         var parent: MarkdownEditorView
152:         var lastSyntaxHighlighting: Bool = true
```

Agent note: `NSTextStorageDelegate` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L161

```swift
159:         /// True while a toolbar format action is being applied; suppresses savedSelectedRange updates.
160:         var isApplyingFormat: Bool = false
161:         /// Location and delta captured from NSTextStorageDelegate during undo/redo.
162:         var undoEditLoc: Int = NSNotFound
163:         var undoDelta: Int = 0
```

Agent note: `NSTextStorageDelegate` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L241

```swift
239:                         .components(separatedBy: "\n").count - 1
240:                     : 0
241:                 // isInitialLoad suppresses the NSTextStorageDelegate sync highlight so
242:                 // text appears immediately; deferred async applyFull handles coloring.
243:                 isInitialLoad = true
```

Agent note: `NSTextStorageDelegate` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L271

```swift
269:         }
270: 
271:         // MARK: NSTextStorageDelegate
272: 
273:         func textStorage(
```

Agent note: `NSTextStorageDelegate` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `NSTextView` (33 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L3

```swift
1: import AppKit
2: 
3: /// NSTextView (TextKit 1) with full-width row background painting and a
4: /// row-aware line number ruler. Attribute-based backgrounds only cover
5: /// glyphs; diff row tints must span the full line width, so they are drawn
```

Agent note: `NSTextView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L7

```swift
5: /// glyphs; diff row tints must span the full line width, so they are drawn
6: /// in `drawBackground(in:)` from the display-row table. (SPEC §11.4)
7: final class DiffTextView: NSTextView {
8: 
9:     /// Display row index → row background color.
```

Agent note: `NSTextView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L81

```swift
79:     }
80: 
81:     /// Esc in read-only comparison panes navigates Back (NSTextView would
82:     /// otherwise swallow it for completion). The editable merge-output
83:     /// pane keeps Esc for normal text editing.
```

Agent note: `NSTextView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L372

```swift
370: }
371: 
372: extension MergeViewController: NSTextViewDelegate {
373:     func textDidChange(_ notification: Notification) {
374:         // After a manual edit, recompute row offsets so backgrounds and line
```

Agent note: `NSTextView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L17

```swift
15: }
16: 
17: // MARK: - Apply format to NSTextView (free function; called from coordinator)
18: 
19: func applyMarkdownFormat(_ format: MarkdownFormat, to tv: NSTextView) {
```

Agent note: `NSTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L19

```swift
17: // MARK: - Apply format to NSTextView (free function; called from coordinator)
18: 
19: func applyMarkdownFormat(_ format: MarkdownFormat, to tv: NSTextView) {
20:     let sel   = tv.selectedRange()
21:     let text  = tv.string as NSString
```

Agent note: `NSTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L56

```swift
54: 
55: private func wrapInline(_ sel: String, pre: String, suf: String, placeholder: String,
56:                          at range: NSRange, tv: NSTextView) {
57:     let text   = tv.string as NSString
58:     let preLen = (pre as NSString).length
```

Agent note: `NSTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L92

```swift
90: }
91: 
92: private func toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange) {
93:     let text      = tv.string as NSString
94:     let fullLen   = text.length
```

Agent note: `NSTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L117

```swift
115: }
116: 
117: private func replaceAndSelect(_ rep: String, at range: NSRange, tv: NSTextView,
118:                                offset: Int, len: Int) {
119:     guard tv.shouldChangeText(in: range, replacementString: rep) else { return }
```

Agent note: `NSTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L354

```swift
352:     func saveCurrentFile() -> Bool {
353:         guard let url = currentURL, isDirty else { return true }
354:         // Pull live text from NSTextView; fall back to liveText (set by debounce/deinit).
355:         let text = editorCoordinator?.textViewRef?.string ?? liveText
356:         fileWatcher?.stop()
```

Agent note: `NSTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L383

```swift
381:                                         baseURL: currentURL?.deletingLastPathComponent())
382: 
383:         let tv = NSTextView(frame: NSRect(x: 0, y: 0, width: pageWidth, height: 100))
384:         tv.textContainer?.widthTracksTextView = true
385:         tv.textContainer?.containerSize = NSSize(width: pageWidth, height: .greatestFiniteMagnitude)
```

Agent note: `NSTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L6

```swift
4: 
5: struct MarkdownEditorView: NSViewRepresentable {
6:     // Editor owns its live text in NSTextView; AppState never receives the full string on
7:     // every keystroke. These three params replace the old @Binding var text (R-0048-02).
8:     let initialText: String
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L15

```swift
13: 
14:     func makeNSView(context: Context) -> NSScrollView {
15:         let scrollView = NSTextView.scrollableTextView()
16:         guard let textView = scrollView.documentView as? NSTextView else { return scrollView }
17:         context.coordinator.textViewRef = textView
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L16

```swift
14:     func makeNSView(context: Context) -> NSScrollView {
15:         let scrollView = NSTextView.scrollableTextView()
16:         guard let textView = scrollView.documentView as? NSTextView else { return scrollView }
17:         context.coordinator.textViewRef = textView
18:         textView.delegate = context.coordinator
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L62

```swift
60: 
61:         // Register coordinator with AppState so save/print can pull live text directly
62:         // from NSTextView without a SwiftUI binding round-trip (R-0048-02).
63:         AppState.shared.editorCoordinator = context.coordinator
64: 
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L81

```swift
79: 
80:     func updateNSView(_ scrollView: NSScrollView, context: Context) {
81:         guard let textView = scrollView.documentView as? NSTextView else { return }
82:         let cW = Int(textView.textContainer?.containerSize.width ?? -1)
83:         benchLog("[BENCH] updateNSView \(benchT()) textLen=\(textView.string.count) cW=\(cW)")
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150

```swift
148:     // MARK: - Coordinator
149: 
150:     final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {
151:         var parent: MarkdownEditorView
152:         var lastSyntaxHighlighting: Bool = true
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L164

```swift
162:         var undoEditLoc: Int = NSNotFound
163:         var undoDelta: Int = 0
164:         weak var textViewRef: NSTextView?
165:         private var floatingPanel: FloatingSelectionPanel?
166:         private var formatObserver: NSObjectProtocol?
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L227

```swift
225: 
226:         // Sets up the Combine subscription that receives text pushed by AppState
227:         // (load/reload/toggle/clear) and applies it to NSTextView.
228:         func subscribeToExternalText(
229:             _ publisher: PassthroughSubject<String, Never>,
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L326

```swift
324:         }
325: 
326:         // MARK: NSTextViewDelegate
327: 
328:         func textDidChange(_ notification: Notification) {
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L329

```swift
327: 
328:         func textDidChange(_ notification: Notification) {
329:             guard let tv = notification.object as? NSTextView else { return }
330:             // Cache current text on main thread for safe use in deinit (R-0050-03).
331:             lastText = tv.string
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L355

```swift
353: 
354:         func textViewDidChangeSelection(_ notification: Notification) {
355:             guard let tv = notification.object as? NSTextView,
356:                   tv === textViewRef else { return }
357:             // Lazily set up first-responder KVO once the text view has a window.
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L415

```swift
413:         }
414: 
415:         private func showFloatingPanel(for tv: NSTextView, selectionRange: NSRange) {
416:             guard let lm = tv.layoutManager, let tc = tv.textContainer else { return }
417:             let glyphRange = lm.glyphRange(forCharacterRange: selectionRange, actualCharacterRange: nil)
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L439

```swift
437:     // MARK: - Tab stops
438: 
439:     private func applyTabStops(to textView: NSTextView, tabSize: Int, fontSize: Double, family: String = "") {
440:         let font = MarkdownSyntaxHighlighter.baseFont(size: fontSize, family: family)
441:         let charWidth = font.maximumAdvancement.width
```

Agent note: `NSTextView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L4

```swift
2: import SwiftUI
3: 
4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
5: 
6: struct MarkdownPreviewTextView: NSViewRepresentable {
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L38

```swift
36:         layoutMgr.delegate = context.coordinator
37: 
38:         let textView = NSTextView(frame: .zero, textContainer: container)
39:         textView.minSize                = NSSize(width: 0, height: 0)
40:         textView.maxSize                = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L89

```swift
87:         if context.coordinator.lastOutlineJumpID != outlineJump?.id,
88:            let outlineJump,
89:            let textView = scrollView.documentView as? NSTextView {
90:             context.coordinator.lastOutlineJumpID = outlineJump.id
91:             context.coordinator.scrollToHeading(outlineJump.entry, in: textView)
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L95

```swift
93:         // Skip if the attributed string object hasn't changed (e.g. isDirty re-renders).
94:         guard context.coordinator.lastAttributedString !== attributedString,
95:               let textView = scrollView.documentView as? NSTextView else { return }
96:         context.coordinator.lastAttributedString    = attributedString
97:         context.coordinator.pendingScrollOrigin     = scrollView.contentView.bounds.origin
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105

```swift
103:     // MARK: - Coordinator
104: 
105:     final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {
106:         var onToggle:       (Int) -> Void
107:         var onRelativeLink: ((URL) -> Void)?
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L108

```swift
106:         var onToggle:       (Int) -> Void
107:         var onRelativeLink: ((URL) -> Void)?
108:         weak var textViewRef:         NSTextView?
109:         weak var scrollViewRef:       NSScrollView?
110:         weak var lastAttributedString: NSAttributedString?
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L134

```swift
132:         }
133: 
134:         func textView(_ textView: NSTextView, clickedOnLink link: Any, at charIndex: Int) -> Bool {
135:             guard let url = link as? URL else { return false }
136: 
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L153

```swift
151:             }
152: 
153:             // Web/scheme URLs — let NSTextView handle via NSWorkspace
154:             guard url.scheme == nil else { return false }
155: 
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L161

```swift
159:         }
160: 
161:         func scrollToHeading(_ entry: MarkdownOutlineEntry, in textView: NSTextView) {
162:             guard let storage = textView.textStorage,
163:                   let layoutManager = textView.layoutManager,
```

Agent note: `NSTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSTextViewDelegate` (4 hits)


### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L372

```swift
370: }
371: 
372: extension MergeViewController: NSTextViewDelegate {
373:     func textDidChange(_ notification: Notification) {
374:         // After a manual edit, recompute row offsets so backgrounds and line
```

Agent note: `NSTextViewDelegate` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150

```swift
148:     // MARK: - Coordinator
149: 
150:     final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {
151:         var parent: MarkdownEditorView
152:         var lastSyntaxHighlighting: Bool = true
```

Agent note: `NSTextViewDelegate` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L326

```swift
324:         }
325: 
326:         // MARK: NSTextViewDelegate
327: 
328:         func textDidChange(_ notification: Notification) {
```

Agent note: `NSTextViewDelegate` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105

```swift
103:     // MARK: - Coordinator
104: 
105:     final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {
106:         var onToggle:       (Int) -> Void
107:         var onRelativeLink: ((URL) -> Void)?
```

Agent note: `NSTextViewDelegate` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NSView` (44 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2069

```swift
2067: // MARK: - Phase 6: Virtualized diff renderer (AppKit NSTableView for large visual diffs)
2068: 
2069: private struct VirtualizedDiffView: NSViewRepresentable {
2070:     let items: [DiffPreviewModel.VisualItem]
2071:     let totalLineCount: Int
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2075

```swift
2073:     func makeCoordinator() -> Coordinator { Coordinator() }
2074: 
2075:     func makeNSView(context: Context) -> NSScrollView {
2076:         let tv = NSTableView()
2077:         tv.headerView = nil
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2100

```swift
2098:     }
2099: 
2100:     func updateNSView(_ sv: NSScrollView, context: Context) {
2101:         guard let tv = sv.documentView as? NSTableView else { return }
2102:         let coord = context.coordinator
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2139

```swift
2137:         }
2138: 
2139:         func tableView(_ tv: NSTableView, viewFor col: NSTableColumn?, row: Int) -> NSView? {
2140:             if row >= items.count { return capView(tv) }
2141:             switch items[row] {
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2148

```swift
2146:         }
2147: 
2148:         private func capView(_ tv: NSTableView) -> NSView {
2149:             let nsId = NSUserInterfaceItemIdentifier("capMsg")
2150:             if let v = tv.makeView(withIdentifier: nsId, owner: nil) as? NSTextField {
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2165

```swift
2163:         }
2164: 
2165:         private func sectionView(_ tv: NSTableView, id: String, text: String, isFile: Bool) -> NSView {
2166:             let nsId = NSUserInterfaceItemIdentifier(id)
2167:             if let v = tv.makeView(withIdentifier: nsId, owner: nil) {
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2171

```swift
2169:                 return v
2170:             }
2171:             let box = NSView()
2172:             box.identifier = nsId
2173:             box.wantsLayer = true
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2188

```swift
2186:         }
2187: 
2188:         private func configureSection(_ v: NSView, text: String, isFile: Bool) {
2189:             let alpha: CGFloat = isFile ? 0.12 : 0.06
2190:             v.wantsLayer = true
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2201

```swift
2199:         }
2200: 
2201:         private func lineView(_ tv: NSTableView, line: DiffLine) -> NSView {
2202:             let nsId = NSUserInterfaceItemIdentifier("diffLine")
2203:             if let v = tv.makeView(withIdentifier: nsId, owner: nil) {
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2207

```swift
2205:                 return v
2206:             }
2207:             let box = NSView()
2208:             box.identifier = nsId
2209:             box.wantsLayer = true
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2259

```swift
2257:         }
2258: 
2259:         private func configureLine(_ v: NSView, line: DiffLine) {
2260:             let bg: NSColor
2261:             switch line.kind {
```

Agent note: `NSView` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L18

```swift
16: /// Panes are read-only in 0.1.x; in-place editing and per-hunk merge
17: /// gestures follow in M2.
18: final class FileDiffViewController: NSViewController {
19: 
20:     private(set) var leftURL: URL
```

Agent note: `NSView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L144

```swift
142:         spinner.isDisplayedWhenStopped = false
143: 
144:         let spacer = NSView()
145:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
146:         let controlBar = NSStackView(views: [
```

Agent note: `NSView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L168

```swift
166:             label.lineBreakMode = .byTruncatingMiddle
167:         }
168:         let statusSpacer = NSView()
169:         statusSpacer.setContentHuggingPriority(.init(1), for: .horizontal)
170:         let statusBar = NSStackView(views: [leftStatus, statusSpacer, rightStatus])
```

Agent note: `NSView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L179

```swift
177:         main.translatesAutoresizingMaskIntoConstraints = false
178: 
179:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))
180:         container.addSubview(main)
181:         NSLayoutConstraint.activate([
```

Agent note: `NSView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L204

```swift
202:             NotificationCenter.default.addObserver(
203:                 self, selector: #selector(boundsChanged(_:)),
204:                 name: NSView.boundsDidChangeNotification, object: scroll.contentView
205:             )
206:         }
```

Agent note: `NSView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L5

```swift
3: /// Whole-document map of change positions on the trailing edge (SPEC §5.3).
4: /// Click or drag to jump.
5: final class OverviewStripView: NSView {
6: 
7:     struct Mark {
```

Agent note: `NSView` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L20

```swift
18:     override var isFlipped: Bool { true }
19: 
20:     override var intrinsicContentSize: NSSize { NSSize(width: 14, height: NSView.noIntrinsicMetric) }
21: 
22:     override func draw(_ dirtyRect: NSRect) {
```

Agent note: `NSView` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L8

```swift
6: /// a flattened file list, the ignore-line-endings comparison option, and
7: /// the cross-file navigation context handed to drill-down diffs.
8: final class FolderCompareViewController: NSViewController {
9: 
10:     let leftRoot: URL
```

Agent note: `NSView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L122

```swift
120:         summaryLabel.textColor = .secondaryLabelColor
121: 
122:         let spacer = NSView()
123:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
124:         let controlBar = NSStackView(views: [backButton, filterPopup, flattenCheckbox, refreshButton, spinner, spacer, summaryLabel])
```

Agent note: `NSView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L147

```swift
145:         main.translatesAutoresizingMaskIntoConstraints = false
146: 
147:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))
148:         container.addSubview(main)
149:         NSLayoutConstraint.activate([
```

Agent note: `NSView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L492

```swift
490:     }
491: 
492:     func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {
493:         guard let entry = item as? FolderEntry, let column = tableColumn else { return nil }
494:         let field: NSTextField
```

Agent note: `NSView` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L12

```swift
10: /// background. v0.1 resolves conflicts by editing the output directly;
11: /// per-hunk take-left/take-right gestures land in M4.
12: final class MergeViewController: NSViewController {
13: 
14:     let baseURL: URL
```

Agent note: `NSView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L78

```swift
76: 
77:     override func loadView() {
78:         func sourcePane(_ header: String) -> (NSView, DiffTextView) {
79:             let (scroll, text) = DiffTextView.makePane(editable: false)
80:             let label = NSTextField(labelWithString: header)
```

Agent note: `NSView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L135

```swift
133:         spinner.isDisplayedWhenStopped = false
134: 
135:         let spacer = NSView()
136:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
137:         let controlBar = NSStackView(views: [prevButton, nextButton, counterLabel, spinner, spacer, saveButton])
```

Agent note: `NSView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L148

```swift
146:         main.translatesAutoresizingMaskIntoConstraints = false
147: 
148:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1280, height: 800))
149:         container.addSubview(main)
150:         NSLayoutConstraint.activate([
```

Agent note: `NSView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L202

```swift
200:     // MARK: - Presentation
201: 
202:     private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {
203:         let window = NSWindow(contentViewController: viewController)
204:         window.title = viewController.title ?? "MacMerge"
```

Agent note: `NSView` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L178

```swift
176: 
177:     // Pushes text into the editor view without a SwiftUI round-trip (R-0048-02).
178:     // Coordinator subscribes in makeNSView; fires on load/reload/toggle/clear.
179:     let externalTextPublisher = PassthroughSubject<String, Never>()
180:     // Weak back-reference set by the editor coordinator; used for save/print/toggle (R-0048-02).
```

Agent note: `NSView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L665

```swift
663:             result.addAttribute(.link, value: url, range: all)
664:         }
665:         // Always set theme link color; makeNSView clears the foreground override in linkTextAttributes.
666:         result.addAttribute(.foregroundColor, value: theme.linkColor, range: all)
667:         return result
```

Agent note: `NSView` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L5

```swift
3: import SwiftUI
4: 
5: struct MarkdownEditorView: NSViewRepresentable {
6:     // Editor owns its live text in NSTextView; AppState never receives the full string on
7:     // every keystroke. These three params replace the old @Binding var text (R-0048-02).
```

Agent note: `NSView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L14

```swift
12:     @EnvironmentObject var appearance: AppearanceSettings
13: 
14:     func makeNSView(context: Context) -> NSScrollView {
15:         let scrollView = NSTextView.scrollableTextView()
16:         guard let textView = scrollView.documentView as? NSTextView else { return scrollView }
```

Agent note: `NSView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L45

```swift
43:         scrollView.setFrameSize(NSSize(width: 800, height: 600))
44:         let initCW = Int(textView.textContainer?.containerSize.width ?? -1)
45:         benchLog("[BENCH] makeNSView frameW=\(Int(scrollView.frame.width)) containerW=\(initCW)")
46: 
47:         // isInitialLoad suppresses the synchronous NSTextStorageDelegate highlight callback
```

Agent note: `NSView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L58

```swift
56:             context.coordinator.lastText = initialText
57:             context.coordinator.isInitialLoad = false
58:             benchLog("[BENCH] makeNSView string-set done")
59:         }
60: 
```

Agent note: `NSView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L80

```swift
78:     }
79: 
80:     func updateNSView(_ scrollView: NSScrollView, context: Context) {
81:         guard let textView = scrollView.documentView as? NSTextView else { return }
82:         let cW = Int(textView.textContainer?.containerSize.width ?? -1)
```

Agent note: `NSView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L83

```swift
81:         guard let textView = scrollView.documentView as? NSTextView else { return }
82:         let cW = Int(textView.textContainer?.containerSize.width ?? -1)
83:         benchLog("[BENCH] updateNSView \(benchT()) textLen=\(textView.string.count) cW=\(cW)")
84:         context.coordinator.parent = self
85: 
```

Agent note: `NSView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L103

```swift
101: 
102:         // External text changes (load/reload/toggle) arrive via externalTextPublisher, not here.
103:         // updateNSView is now called only for appearance changes, not for every keystroke.
104: 
105:         // Settings change: re-highlight the whole document on background thread (R-0049-01).
```

Agent note: `NSView` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L4

```swift
2: import SwiftUI
3: 
4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
5: 
6: struct MarkdownPreviewTextView: NSViewRepresentable {
```

Agent note: `NSView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L6

```swift
4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
5: 
6: struct MarkdownPreviewTextView: NSViewRepresentable {
7:     let attributedString:  NSAttributedString
8:     let onToggleCheckbox:  (Int) -> Void
```

Agent note: `NSView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L26

```swift
24:     }
25: 
26:     func makeNSView(context: Context) -> NSScrollView {
27:         // Manual construction so we can inject MarkdownLayoutManager.
28:         let textStorage = NSTextStorage()
```

Agent note: `NSView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L84

```swift
82:     }
83: 
84:     func updateNSView(_ scrollView: NSScrollView, context: Context) {
85:         context.coordinator.onToggle       = onToggleCheckbox
86:         context.coordinator.onRelativeLink = onRelativeLink
```

Agent note: `NSView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L6

```swift
4: // MARK: - Esc key interceptor (closes the Settings window)
5: 
6: private struct EscapeKeyInterceptor: NSViewRepresentable {
7:     func makeNSView(context: Context) -> NSView {
8:         let view = EscView()
```

Agent note: `NSView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L7

```swift
5: 
6: private struct EscapeKeyInterceptor: NSViewRepresentable {
7:     func makeNSView(context: Context) -> NSView {
8:         let view = EscView()
9:         return view
```

Agent note: `NSView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L11

```swift
9:         return view
10:     }
11:     func updateNSView(_ nsView: NSView, context: Context) {}
12: 
13:     private class EscView: NSView {
```

Agent note: `NSView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L13

```swift
11:     func updateNSView(_ nsView: NSView, context: Context) {}
12: 
13:     private class EscView: NSView {
14:         private var monitor: Any?
15:         override func viewDidMoveToWindow() {
```

Agent note: `NSView` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSViewController` (4 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L18

```swift
16: /// Panes are read-only in 0.1.x; in-place editing and per-hunk merge
17: /// gestures follow in M2.
18: final class FileDiffViewController: NSViewController {
19: 
20:     private(set) var leftURL: URL
```

Agent note: `NSViewController` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L8

```swift
6: /// a flattened file list, the ignore-line-endings comparison option, and
7: /// the cross-file navigation context handed to drill-down diffs.
8: final class FolderCompareViewController: NSViewController {
9: 
10:     let leftRoot: URL
```

Agent note: `NSViewController` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L12

```swift
10: /// background. v0.1 resolves conflicts by editing the output directly;
11: /// per-hunk take-left/take-right gestures land in M4.
12: final class MergeViewController: NSViewController {
13: 
14:     let baseURL: URL
```

Agent note: `NSViewController` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L202

```swift
200:     // MARK: - Presentation
201: 
202:     private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {
203:         let window = NSWindow(contentViewController: viewController)
204:         window.title = viewController.title ?? "MacMerge"
```

Agent note: `NSViewController` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

## `NSViewRepresentable` (5 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2069

```swift
2067: // MARK: - Phase 6: Virtualized diff renderer (AppKit NSTableView for large visual diffs)
2068: 
2069: private struct VirtualizedDiffView: NSViewRepresentable {
2070:     let items: [DiffPreviewModel.VisualItem]
2071:     let totalLineCount: Int
```

Agent note: `NSViewRepresentable` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L5

```swift
3: import SwiftUI
4: 
5: struct MarkdownEditorView: NSViewRepresentable {
6:     // Editor owns its live text in NSTextView; AppState never receives the full string on
7:     // every keystroke. These three params replace the old @Binding var text (R-0048-02).
```

Agent note: `NSViewRepresentable` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L4

```swift
2: import SwiftUI
3: 
4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
5: 
6: struct MarkdownPreviewTextView: NSViewRepresentable {
```

Agent note: `NSViewRepresentable` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L6

```swift
4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
5: 
6: struct MarkdownPreviewTextView: NSViewRepresentable {
7:     let attributedString:  NSAttributedString
8:     let onToggleCheckbox:  (Int) -> Void
```

Agent note: `NSViewRepresentable` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L6

```swift
4: // MARK: - Esc key interceptor (closes the Settings window)
5: 
6: private struct EscapeKeyInterceptor: NSViewRepresentable {
7:     func makeNSView(context: Context) -> NSView {
8:         let view = EscView()
```

Agent note: `NSViewRepresentable` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSWindow` (28 hits)


### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L47

```swift
45: @MainActor
46: enum SessionWriter {
47:     static func save(_ session: ComparisonSession, suggestedName: String, in window: NSWindow?) {
48:         let panel = NSSavePanel()
49:         panel.nameFieldStringValue = "\(suggestedName).\(ComparisonSession.fileExtension)"
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L60

```swift
58:         menu.addItem(withTitle: "Generate Patch…", action: NSSelectorFromString("generatePatch:"), keyEquivalent: "")
59:         menu.addItem(.separator())
60:         menu.addItem(withTitle: "Close", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
61:         return item
62:     }
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L91

```swift
89:         menu.addItem(.separator())
90:         let fullScreen = menu.addItem(withTitle: "Enter Full Screen",
91:                                       action: #selector(NSWindow.toggleFullScreen(_:)), keyEquivalent: "f")
92:         fullScreen.keyEquivalentModifierMask = [.command, .control]
93:         return item
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L134

```swift
132:     private static func makeWindowMenu() -> NSMenuItem {
133:         let (item, menu) = submenu("Window")
134:         menu.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
135:         menu.addItem(withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")
136:         menu.addItem(.separator())
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L135

```swift
133:         let (item, menu) = submenu("Window")
134:         menu.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
135:         menu.addItem(withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")
136:         menu.addItem(.separator())
137:         menu.addItem(withTitle: "Show Welcome Window",
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L21

```swift
19:     static let shared = WindowManager()
20: 
21:     private var controllers: [NSWindowController] = []
22:     private var welcomeController: NSWindowController?
23:     private var newComparisonController: NSWindowController?
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L22

```swift
20: 
21:     private var controllers: [NSWindowController] = []
22:     private var welcomeController: NSWindowController?
23:     private var newComparisonController: NSWindowController?
24:     private var newComparisonModel: NewComparisonModel?
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L23

```swift
21:     private var controllers: [NSWindowController] = []
22:     private var welcomeController: NSWindowController?
23:     private var newComparisonController: NSWindowController?
24:     private var newComparisonModel: NewComparisonModel?
25: 
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L31

```swift
29:         if welcomeController == nil {
30:             let hosting = PanelHostingController(rootView: WelcomeView())
31:             let window = NSWindow(contentViewController: hosting)
32:             window.title = "Welcome to MacMerge"
33:             window.styleMask = [.titled, .closable, .fullSizeContentView]
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L39

```swift
37:             window.delegate = self
38:             window.center()
39:             welcomeController = NSWindowController(window: window)
40:         }
41:         welcomeController?.showWindow(nil)
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L68

```swift
66:         newComparisonModel = model
67:         let hosting = PanelHostingController(rootView: NewComparisonView(model: model))
68:         let window = NSWindow(contentViewController: hosting)
69:         window.title = "New Comparison"
70:         window.styleMask = [.titled, .closable]
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L75

```swift
73:         window.center()
74:         window.delegate = self
75:         newComparisonController = NSWindowController(window: window)
76:         newComparisonController?.showWindow(nil)
77:         window.makeKeyAndOrderFront(nil)
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L118

```swift
116:     }
117: 
118:     func openFileDiff(left: URL, right: URL, tabIn host: NSWindow? = nil,
119:                       nav: FolderNavContext? = nil, origin: (left: URL, right: URL)? = nil) {
120:         present(FileDiffViewController(left: left, right: right, nav: nav, origin: origin), tabIn: host)
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L126

```swift
124:     /// Back-navigation target: activates an existing folder-comparison tab
125:     /// for these roots, or recreates one if the user closed it.
126:     func returnToFolderCompare(left: URL, right: URL, near window: NSWindow?) {
127:         for controller in controllers {
128:             if let vc = controller.window?.contentViewController as? FolderCompareViewController,
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L137

```swift
135:     }
136: 
137:     func openFolderCompare(left: URL, right: URL, tabIn host: NSWindow? = nil) {
138:         present(FolderCompareViewController(left: left, right: right), tabIn: host)
139:         RecentsStore.shared.add(RecentComparison(mode: .folderCompare, leftPath: left.path, rightPath: right.path))
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L142

```swift
140:     }
141: 
142:     func openMerge(base: URL, left: URL, right: URL, output: URL? = nil, tabIn host: NSWindow? = nil) {
143:         present(MergeViewController(base: base, left: left, right: right, output: output), tabIn: host)
144:         RecentsStore.shared.add(RecentComparison(
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L202

```swift
200:     // MARK: - Presentation
201: 
202:     private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {
203:         let window = NSWindow(contentViewController: viewController)
204:         window.title = viewController.title ?? "MacMerge"
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L203

```swift
201: 
202:     private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {
203:         let window = NSWindow(contentViewController: viewController)
204:         window.title = viewController.title ?? "MacMerge"
205:         window.tabbingMode = .preferred
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L210

```swift
208:         window.delegate = self
209: 
210:         let controller = NSWindowController(window: window)
211:         controllers.append(controller)
212: 
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L237

```swift
235: }
236: 
237: extension WindowManager: NSWindowDelegate {
238:     func windowWillClose(_ notification: Notification) {
239:         guard let window = notification.object as? NSWindow else { return }
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L239

```swift
237: extension WindowManager: NSWindowDelegate {
238:     func windowWillClose(_ notification: Notification) {
239:         guard let window = notification.object as? NSWindow else { return }
240:         if window === welcomeController?.window {
241:             welcomeController = nil
```

Agent note: `NSWindow` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L605

```swift
603:         .environmentObject(newState)
604:         .environmentObject(AppearanceSettings.shared)
605:     let win = NSWindow(
606:         contentRect: NSRect(x: 0, y: 0, width: 900, height: 640),
607:         styleMask:   [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView],
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L613

```swift
611:     win.contentView = NSHostingView(rootView: content)
612:     win.center()
613:     win.delegate   = NSApp.delegate as? NSWindowDelegate
614:     win.makeKeyAndOrderFront(nil)
615:     (NSApp.delegate as? AppDelegate)?.register(win, state: newState)
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L621

```swift
619: // MARK: - App delegate
620: 
621: final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
622:     /// Tracks extra document windows opened via link navigation.
623:     var extraWindows: [NSWindow: AppState] = [:]
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L623

```swift
621: final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
622:     /// Tracks extra document windows opened via link navigation.
623:     var extraWindows: [NSWindow: AppState] = [:]
624: 
625:     func register(_ window: NSWindow, state: AppState) {
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L625

```swift
623:     var extraWindows: [NSWindow: AppState] = [:]
624: 
625:     func register(_ window: NSWindow, state: AppState) {
626:         extraWindows[window] = state
627:     }
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L645

```swift
643:     }
644: 
645:     func windowShouldClose(_ sender: NSWindow) -> Bool {
646:         // Extra document windows opened via link navigation.
647:         if let state = extraWindows[sender] {
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L667

```swift
665: 
666:     func windowWillClose(_ notification: Notification) {
667:         guard let window = notification.object as? NSWindow else { return }
668:         extraWindows.removeValue(forKey: window)
669:     }
```

Agent note: `NSWindow` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `NSWorkspace` (14 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L260

```swift
258:                         .contextMenu {
259:                             Button("Reveal in Finder") {
260:                                 NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: wt.path)])
261:                             }
262:                         }
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2595

```swift
2593:         if !node.isDirectory {
2594:             Button {
2595:                 NSWorkspace.shared.open(fileURL)
2596:             } label: {
2597:                 Label("Open File", systemImage: "arrow.up.right.square")
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2601

```swift
2599:         }
2600:         Button {
2601:             NSWorkspace.shared.activateFileViewerSelecting([fileURL])
2602:         } label: {
2603:             Label("Reveal in Finder", systemImage: "finder")
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3208

```swift
3206:     func revealRepositoryInFinder() {
3207:         guard let repositoryURL else { return }
3208:         NSWorkspace.shared.activateFileViewerSelecting([repositoryURL])
3209:     }
3210: 
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3216

```swift
3214:         }
3215:         let fileURL = repositoryURL.appendingPathComponent(change.path)
3216:         NSWorkspace.shared.activateFileViewerSelecting([fileURL])
3217:     }
3218: 
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3221

```swift
3219:     func openFile(_ change: FileChange) {
3220:         guard let repositoryURL else { return }
3221:         NSWorkspace.shared.open(repositoryURL.appendingPathComponent(change.path))
3222:     }
3223: 
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3266

```swift
3264:             try? "".write(to: url, atomically: true, encoding: .utf8)
3265:         }
3266:         NSWorkspace.shared.open(url)
3267:     }
3268: 
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3568

```swift
3566:         guard let repositoryURL else { return }
3567:         let url = repositoryURL.appendingPathComponent(path)
3568:         NSWorkspace.shared.open(url)
3569:     }
3570: 
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4260

```swift
4258:             do {
4259:                 try text.write(to: tempURL, atomically: true, encoding: .utf8)
4260:                 _ = await MainActor.run { NSWorkspace.shared.open(tempURL) }
4261:             } catch {}
4262:         }
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4461

```swift
4459:                 .contextMenu {
4460:                     Button {
4461:                         NSWorkspace.shared.open(repositoryURL.appendingPathComponent(stat.path))
4462:                     } label: {
4463:                         Label("Open File", systemImage: "arrow.up.right.square")
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4466

```swift
4464:                     }
4465:                     Button {
4466:                         NSWorkspace.shared.activateFileViewerSelecting([repositoryURL.appendingPathComponent(stat.path)])
4467:                     } label: {
4468:                         Label("Reveal in Finder", systemImage: "finder")
```

Agent note: `NSWorkspace` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L453

```swift
451:     @objc func revealLeft(_ sender: Any?) {
452:         guard let entry = targetEntry() else { return }
453:         NSWorkspace.shared.activateFileViewerSelecting([leftRoot.appendingPathComponent(entry.relativePath)])
454:     }
455: 
```

Agent note: `NSWorkspace` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L458

```swift
456:     @objc func revealRight(_ sender: Any?) {
457:         guard let entry = targetEntry() else { return }
458:         NSWorkspace.shared.activateFileViewerSelecting([rightRoot.appendingPathComponent(entry.relativePath)])
459:     }
460: 
```

Agent note: `NSWorkspace` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L153

```swift
151:             }
152: 
153:             // Web/scheme URLs — let NSTextView handle via NSWorkspace
154:             guard url.scheme == nil else { return false }
155: 
```

Agent note: `NSWorkspace` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `NotificationCenter` (7 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L65

```swift
63:             .modifier(RepositoryPresentations(store: store, selectedView: $selectedView))
64:             .modifier(SocketBridgePresentations(bridge: store.bridge))
65:             .onReceive(NotificationCenter.default.publisher(for: NSApplication.willTerminateNotification)) { _ in
66:                 store.stopBridge()
67:             }
```

Agent note: `NotificationCenter` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L202

```swift
200:         for scroll in [leftScroll!, rightScroll!] {
201:             scroll.contentView.postsBoundsChangedNotifications = true
202:             NotificationCenter.default.addObserver(
203:                 self, selector: #selector(boundsChanged(_:)),
204:                 name: NSView.boundsDidChangeNotification, object: scroll.contentView
```

Agent note: `NotificationCenter` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L225

```swift
223:     deinit {
224:         reloadTask?.cancel()
225:         NotificationCenter.default.removeObserver(self)
226:     }
227: 
```

Agent note: `NotificationCenter` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L163

```swift
161:                          icon: String? = nil) -> some View {
162:         Button {
163:             NotificationCenter.default.post(name: .applyMarkdownFormat, object: format)
164:         } label: {
165:             if let label {
```

Agent note: `NotificationCenter` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L218

```swift
216:     private func selBtn(_ format: MarkdownFormat, _ icon: String) -> some View {
217:         Button {
218:             NotificationCenter.default.post(name: .applyMarkdownFormat, object: format)
219:         } label: {
220:             Image(systemName: icon)
```

Agent note: `NotificationCenter` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L183

```swift
181:             self.parent = parent
182:             super.init()
183:             formatObserver = NotificationCenter.default.addObserver(
184:                 forName: .applyMarkdownFormat, object: nil, queue: .main
185:             ) { [weak self] note in
```

Agent note: `NotificationCenter` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L222

```swift
220:             // and tv.string is unsafe to read off the main thread (R-0050-03).
221:             parent.onViewDisappear(lastText)
222:             if let obs = formatObserver { NotificationCenter.default.removeObserver(obs) }
223:             floatingPanel?.orderOut(nil)
224:         }
```

Agent note: `NotificationCenter` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `ObservableObject` (10 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L23

```swift
21: /// Manages the console state: lines buffer, history, running process (SPEC §3.1).
22: @MainActor
23: final class ConsoleStore: ObservableObject {
24:     @Published private(set) var lines: [ConsoleLine] = []
25:     @Published private(set) var isRunning = false
```

Agent note: `ObservableObject` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1694

```swift
1692: 
1693: @MainActor
1694: private final class DiffPreviewModel: ObservableObject {
1695:     // R-0038-04 / R-0039-01: cap for SwiftUI path; AppKit path uses visualMaxLines.
1696:     nonisolated static let maxLines = 2000
```

Agent note: `ObservableObject` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2330

```swift
2328: 
2329: @MainActor
2330: private final class FolderViewModel: ObservableObject {
2331:     @Published private(set) var rootNodes: [FileNode] = []
2332:     @Published private(set) var isLoading = false
```

Agent note: `ObservableObject` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2822

```swift
2820: 
2821: @MainActor
2822: private final class RepositoryStore: ObservableObject {
2823:     struct RecentRepository: Identifiable, Equatable {
2824:         let id: String
```

Agent note: `ObservableObject` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4116

```swift
4114: 
4115: @MainActor
4116: private final class HistoryViewModel: ObservableObject {
4117:     struct HistoryRow: Identifiable {
4118:         let commit: Commit
```

Agent note: `ObservableObject` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L27

```swift
25: /// The socket path is written to the environment so child processes can find it.
26: @MainActor
27: final class SocketBridge: ObservableObject {
28:     /// Single-item enum so only one bridge sheet is presented at a time.
29:     enum PendingRequest: Identifiable {
```

Agent note: `ObservableObject` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L7

```swift
5: /// WindowManager holds a reference so drops on any screen fill slots sequentially (L→R→Base).
6: @MainActor
7: final class NewComparisonModel: ObservableObject {
8:     @Published var leftPath: String
9:     @Published var rightPath: String
```

Agent note: `ObservableObject` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/SessionKit/SessionKit.swift` L75

```swift
73: 
74: @MainActor
75: public final class RecentsStore: ObservableObject {
76: 
77:     public static let shared = RecentsStore()
```

Agent note: `ObservableObject` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L43

```swift
41: // MARK: - Appearance settings
42: 
43: final class AppearanceSettings: ObservableObject {
44:     static let shared = AppearanceSettings()
45: 
```

Agent note: `ObservableObject` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L125

```swift
123: // MARK: - App state
124: 
125: final class AppState: ObservableObject {
126:     static let shared = AppState()
127: 
```

Agent note: `ObservableObject` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `PassthroughSubject` (3 hits)


### `MackDown/Sources/MackDownApp/MackDownApp.swift` L179

```swift
177:     // Pushes text into the editor view without a SwiftUI round-trip (R-0048-02).
178:     // Coordinator subscribes in makeNSView; fires on load/reload/toggle/clear.
179:     let externalTextPublisher = PassthroughSubject<String, Never>()
180:     // Weak back-reference set by the editor coordinator; used for save/print/toggle (R-0048-02).
181:     weak var editorCoordinator: MarkdownEditorView.Coordinator?
```

Agent note: `PassthroughSubject` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L11

```swift
9:     let onTextChanged: (String) -> Void       // called by coordinator's 200 ms debounce
10:     let onViewDisappear: (String) -> Void     // called in coordinator deinit for preview-mode save
11:     let externalTextPublisher: PassthroughSubject<String, Never>
12:     @EnvironmentObject var appearance: AppearanceSettings
13: 
```

Agent note: `PassthroughSubject` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L229

```swift
227:         // (load/reload/toggle/clear) and applies it to NSTextView.
228:         func subscribeToExternalText(
229:             _ publisher: PassthroughSubject<String, Never>,
230:             appearance: AppearanceSettings
231:         ) {
```

Agent note: `PassthroughSubject` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `SwiftUI` (20 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L2

```swift
1: import AppKit
2: import SwiftUI
3: import MacGitCore
4: 
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2

```swift
1: import AppKit
2: import SwiftUI
3: import UniformTypeIdentifiers
4: 
```

Agent note: `SwiftUI` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L25

```swift
23:                 .frame(minWidth: 900, minHeight: 560)
24:         }
25:         // Prevent SwiftUI from opening a new window for every file-open URL event;
26:         // MacGit manages its own single-window repository routing.
27:         .handlesExternalEvents(matching: [])
```

Agent note: `SwiftUI` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1695

```swift
1693: @MainActor
1694: private final class DiffPreviewModel: ObservableObject {
1695:     // R-0038-04 / R-0039-01: cap for SwiftUI path; AppKit path uses visualMaxLines.
1696:     nonisolated static let maxLines = 2000
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
```

Agent note: `SwiftUI` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1699

```swift
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
1698:     nonisolated static let visualMaxLines = 50_000
1699:     // Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.
1700:     nonisolated static let swiftUIThreshold = 500
1701: 
```

Agent note: `SwiftUI` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L2

```swift
1: import Foundation
2: import SwiftUI
3: 
4: // MARK: - Wire protocol
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L2

```swift
1: import AppKit
2: import SwiftUI
3: import SessionKit
4: 
```

Agent note: `SwiftUI` appears here in a `Window/menu/AppKit shell` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L1

```swift
1: import SwiftUI
2: import UniformTypeIdentifiers
3: 
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L1

```swift
1: import SwiftUI
2: import SessionKit
3: import UniformTypeIdentifiers
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L2

```swift
1: import AppKit
2: import SwiftUI
3: 
4: // MARK: - Syntax highlight color set
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/ContentView.swift` L1

```swift
1: import SwiftUI
2: import UniformTypeIdentifiers
3: 
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L2

```swift
1: import AppKit
2: import SwiftUI
3: 
4: // MARK: - Format actions
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L199

```swift
197: }
198: 
199: // MARK: - Floating selection toolbar (SwiftUI content embedded in NSPanel)
200: 
201: struct SelectionToolbarView: View {
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L3

```swift
1: import AppKit
2: import Combine
3: import SwiftUI
4: 
5: // MARK: - Bench logging (writes to /tmp/mackdown-bench.log when --bench is active)
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L177

```swift
175:     private var willChangeSink: AnyCancellable?
176: 
177:     // Pushes text into the editor view without a SwiftUI round-trip (R-0048-02).
178:     // Coordinator subscribes in makeNSView; fires on load/reload/toggle/clear.
179:     let externalTextPublisher = PassthroughSubject<String, Never>()
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L3

```swift
1: import AppKit
2: import Combine
3: import SwiftUI
4: 
5: struct MarkdownEditorView: NSViewRepresentable {
```

Agent note: `SwiftUI` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L53

```swift
51:             textView.string = initialText
52:             // lastText must be set here so that deinit has correct content if the user
53:             // switches modes before typing (SwiftUI recreates MarkdownEditorView on every
54:             // structural-position change; the new coordinator starts with lastText = "")
55:             // (R-0052-01 residual fix for R-0050-03).
```

Agent note: `SwiftUI` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L62

```swift
60: 
61:         // Register coordinator with AppState so save/print can pull live text directly
62:         // from NSTextView without a SwiftUI binding round-trip (R-0048-02).
63:         AppState.shared.editorCoordinator = context.coordinator
64: 
```

Agent note: `SwiftUI` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L2

```swift
1: import AppKit
2: import SwiftUI
3: 
4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
```

Agent note: `SwiftUI` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L2

```swift
1: import AppKit
2: import SwiftUI
3: 
4: // MARK: - Esc key interceptor (closes the Settings window)
```

Agent note: `SwiftUI` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `Task` (133 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L87

```swift
85:     func interrupt() {
86:         let r = runner
87:         Task { await r?.interrupt() }
88:     }
89: 
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L120

```swift
118:         runner = r
119: 
120:         Task {
121:             await r.run(command) { [weak self] event in
122:                 guard let self else { return }
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L232

```swift
230:         // Move blocking Foundation.read off the actor executor so interrupt() can
231:         // preempt the loop and deliver SIGINT without waiting for a read to return.
232:         await Task.detached(priority: .userInitiated) { [self, master] in
233:             var hasCursorSeqs = false
234:             let bufSize = 4096
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L425

```swift
423:                         openExternalDiffAction: store.primarySelectedChangePath.flatMap { path in
424:                             store.repositoryURL.map { url in
425:                                 { Task { try? await store.client.openDiffTool(path: path, in: url) } }
426:                             }
427:                         },
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L904

```swift
902:             fileDiffGeneration &+= 1
903:             let myGen = fileDiffGeneration
904:             Task { await loadFileDiff(path: path, generation: myGen) }
905:         }
906:     }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1726

```swift
1724:         let gen = parseGeneration
1725:         isParsing = true
1726:         Task.detached(priority: .userInitiated) { [weak self] in
1727:             let files = parseDiff(raw)
1728:             let (vis, visTotal) = DiffPreviewModel.buildVisual(files)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2337

```swift
2335:     @Published private(set) var isLoadingDiff = false
2336: 
2337:     private var diffTask: Task<Void, Never>?
2338:     private var loadTask: Task<Void, Never>?
2339:     private var cachedRepoURL: URL?
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2338

```swift
2336: 
2337:     private var diffTask: Task<Void, Never>?
2338:     private var loadTask: Task<Void, Never>?
2339:     private var cachedRepoURL: URL?
2340:     private var cachedNodePaths: Set<String> = []
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2343

```swift
2341: 
2342:     func load(repositoryURL: URL, status: RepositoryStatus?) {
2343:         loadTask?.cancel()
2344:         let changeList = status?.changes ?? []
2345:         let changes = Dictionary(uniqueKeysWithValues: changeList.map { ($0.path, $0) })
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2364

```swift
2362:         let gitPath = repositoryURL.appendingPathComponent(".git").path
2363:         isLoading = true
2364:         loadTask = Task {
2365:             let nodes = await Task.detached(priority: .userInitiated) {
2366:                 Self.buildNodes(
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2365

```swift
2363:         isLoading = true
2364:         loadTask = Task {
2365:             let nodes = await Task.detached(priority: .userInitiated) {
2366:                 Self.buildNodes(
2367:                     at: repositoryURL,
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2376

```swift
2374:                 )
2375:             }.value
2376:             guard !Task.isCancelled else { return }
2377:             rootNodes = nodes
2378:             cachedRepoURL = repositoryURL
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2385

```swift
2383: 
2384:     func selectFile(_ path: String, repositoryURL: URL, client: GitClient) {
2385:         diffTask?.cancel()
2386:         diffText = nil
2387:         diffTask = Task {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2387

```swift
2385:         diffTask?.cancel()
2386:         diffText = nil
2387:         diffTask = Task {
2388:             isLoadingDiff = true
2389:             defer { isLoadingDiff = false }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2392

```swift
2390:             do {
2391:                 let text = try await client.diff(path: path, in: repositoryURL)
2392:                 guard !Task.isCancelled else { return }
2393:                 diffText = text.isEmpty ? nil : text
2394:             } catch {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2395

```swift
2393:                 diffText = text.isEmpty ? nil : text
2394:             } catch {
2395:                 guard !Task.isCancelled else { return }
2396:                 diffText = nil
2397:             }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2556

```swift
2554:                 openExternalDiffAction: vm.selectedPath.flatMap { path in
2555:                     path.hasSuffix("/") ? nil : {
2556:                         Task { try? await client.openDiffTool(path: path, in: repositoryURL) }
2557:                     }
2558:                 },
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2744

```swift
2742:                 guard fileSize > 0, fileSize < 20 * 1024 * 1024 else { return }
2743:                 // Load raw bytes on background thread; NSImage (non-Sendable) created on main actor.
2744:                 if let data = await Task.detached(priority: .userInitiated, operation: { try? Data(contentsOf: fileURL) }).value,
2745:                    let img = NSImage(data: data) {
2746:                     previewContent = .image(img)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2749

```swift
2747:                 }
2748:             } else if fileSize > 0, fileSize < 524_288 {
2749:                 if let content = await Task.detached(priority: .userInitiated, operation: { try? String(contentsOf: fileURL, encoding: .utf8) }).value {
2750:                     previewContent = .text(content)
2751:                 }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2894

```swift
2892:     private var undoLog = UndoLog()
2893:     private let repoWatcher = RepoWatcher()
2894:     private var watcherTask: Task<Void, Never>?
2895: 
2896:     init() {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2909

```swift
2907: 
2908:     private func stopWatching() {
2909:         watcherTask?.cancel()
2910:         watcherTask = nil
2911:         Task { await repoWatcher.stop() }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2910

```swift
2908:     private func stopWatching() {
2909:         watcherTask?.cancel()
2910:         watcherTask = nil
2911:         Task { await repoWatcher.stop() }
2912:     }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2911

```swift
2909:         watcherTask?.cancel()
2910:         watcherTask = nil
2911:         Task { await repoWatcher.stop() }
2912:     }
2913: 
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2915

```swift
2913: 
2914:     deinit {
2915:         watcherTask?.cancel()
2916:     }
2917: 
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2936

```swift
2934:         }
2935: 
2936:         Task {
2937:             await openRepository(at: url)
2938:         }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2953

```swift
2951:             let location = try await client.repositoryRoot(containing: url)
2952:             let repoURL = location.rootURL
2953:             async let statusTask = client.status(in: repoURL)
2954:             async let refsTask = client.refs(in: repoURL)
2955:             async let pushedTask = client.isHeadPushed(in: repoURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2954

```swift
2952:             let repoURL = location.rootURL
2953:             async let statusTask = client.status(in: repoURL)
2954:             async let refsTask = client.refs(in: repoURL)
2955:             async let pushedTask = client.isHeadPushed(in: repoURL)
2956:             let (repositoryStatus, loadedRefs, pushed) = try await (statusTask, refsTask, pushedTask)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2955

```swift
2953:             async let statusTask = client.status(in: repoURL)
2954:             async let refsTask = client.refs(in: repoURL)
2955:             async let pushedTask = client.isHeadPushed(in: repoURL)
2956:             let (repositoryStatus, loadedRefs, pushed) = try await (statusTask, refsTask, pushedTask)
2957:             let loadedWorktrees = (try? await client.listWorktrees(in: repoURL)) ?? []
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2956

```swift
2954:             async let refsTask = client.refs(in: repoURL)
2955:             async let pushedTask = client.isHeadPushed(in: repoURL)
2956:             let (repositoryStatus, loadedRefs, pushed) = try await (statusTask, refsTask, pushedTask)
2957:             let loadedWorktrees = (try? await client.listWorktrees(in: repoURL)) ?? []
2958:             repositoryURL = repoURL
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2998

```swift
2996:             securityScopedURL = recent.url
2997:         }
2998:         Task {
2999:             await openRepository(at: recent.url)
3000:         }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3022

```swift
3020:             }
3021: 
3022:             Task { @MainActor in
3023:                 await self.openRepository(at: url)
3024:             }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3039

```swift
3037:         errorMessage = nil
3038: 
3039:         Task {
3040:             do {
3041:                 let location = try await client.initializeRepository(at: request.url)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3049

```swift
3047:                 }
3048:                 let repoURL = location.rootURL
3049:                 async let statusTask = client.status(in: repoURL)
3050:                 async let refsTask = client.refs(in: repoURL)
3051:                 async let pushedTask = client.isHeadPushed(in: repoURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3050

```swift
3048:                 let repoURL = location.rootURL
3049:                 async let statusTask = client.status(in: repoURL)
3050:                 async let refsTask = client.refs(in: repoURL)
3051:                 async let pushedTask = client.isHeadPushed(in: repoURL)
3052:                 let (newStatus, newRefs, pushed) = try await (statusTask, refsTask, pushedTask)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3051

```swift
3049:                 async let statusTask = client.status(in: repoURL)
3050:                 async let refsTask = client.refs(in: repoURL)
3051:                 async let pushedTask = client.isHeadPushed(in: repoURL)
3052:                 let (newStatus, newRefs, pushed) = try await (statusTask, refsTask, pushedTask)
3053:                 repositoryURL = repoURL
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3052

```swift
3050:                 async let refsTask = client.refs(in: repoURL)
3051:                 async let pushedTask = client.isHeadPushed(in: repoURL)
3052:                 let (newStatus, newRefs, pushed) = try await (statusTask, refsTask, pushedTask)
3053:                 repositoryURL = repoURL
3054:                 remoteURL = try? await client.remoteURL(in: repoURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3091

```swift
3089:         let expectedGen = refreshGeneration
3090:         let repoPath = repositoryURL.path
3091:         Task {
3092:             defer {
3093:                 // Always release the in-flight lock regardless of how the Task exits (return, throw,
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3093

```swift
3091:         Task {
3092:             defer {
3093:                 // Always release the in-flight lock regardless of how the Task exits (return, throw,
3094:                 // or normal completion), then start a trailing refresh if one was requested.
3095:                 refreshInFlight = false
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3105

```swift
3103:             }
3104:             do {
3105:                 async let statusTask = client.status(in: repositoryURL)
3106:                 async let refsTask = client.refs(in: repositoryURL)
3107:                 async let pushedTask = client.isHeadPushed(in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3106

```swift
3104:             do {
3105:                 async let statusTask = client.status(in: repositoryURL)
3106:                 async let refsTask = client.refs(in: repositoryURL)
3107:                 async let pushedTask = client.isHeadPushed(in: repositoryURL)
3108:                 let (newStatus, newRefs, pushed) = try await (statusTask, refsTask, pushedTask)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3107

```swift
3105:                 async let statusTask = client.status(in: repositoryURL)
3106:                 async let refsTask = client.refs(in: repositoryURL)
3107:                 async let pushedTask = client.isHeadPushed(in: repositoryURL)
3108:                 let (newStatus, newRefs, pushed) = try await (statusTask, refsTask, pushedTask)
3109:                 // Discard stale results if repo switched or a newer refresh superseded this one.
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3108

```swift
3106:                 async let refsTask = client.refs(in: repositoryURL)
3107:                 async let pushedTask = client.isHeadPushed(in: repositoryURL)
3108:                 let (newStatus, newRefs, pushed) = try await (statusTask, refsTask, pushedTask)
3109:                 // Discard stale results if repo switched or a newer refresh superseded this one.
3110:                 guard self.repositoryURL?.path == repoPath, self.refreshGeneration == expectedGen else { return }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3130

```swift
3128:         isAmend = value
3129:         if value, let repositoryURL {
3130:             Task {
3131:                 if let headCommit = try? await client.log(in: repositoryURL, maxCount: 1).first {
3132:                     commitMessage = headCommit.subject
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3146

```swift
3144:         operationErrorMessage = nil
3145: 
3146:         Task {
3147:             do {
3148:                 // Capture HEAD before commit so it can be restored by undo.
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3184

```swift
3182:         operationErrorMessage = nil
3183: 
3184:         Task {
3185:             do {
3186:                 if staged {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3245

```swift
3243:         pendingIgnoreChange = nil
3244:         operationErrorMessage = nil
3245:         Task {
3246:             do {
3247:                 try await client.appendToGitIgnore(pattern: pattern, in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3288

```swift
3286:         operationErrorMessage = nil
3287: 
3288:         Task {
3289:             do {
3290:                 consoleStore.echo(gitCommand: "git checkout -- \(path)")
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3304

```swift
3302:         guard let repositoryURL else { return }
3303:         operationErrorMessage = nil
3304:         Task {
3305:             if (try? await client.isOperationInProgress(in: repositoryURL)) == true {
3306:                 operationErrorMessage = "Finish or abort the in-progress merge/rebase first."
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3326

```swift
3324:         operationErrorMessage = nil
3325:         if remember { saveSwitchPreference(option, for: repositoryURL) }
3326:         Task {
3327:             do {
3328:                 switch option {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3377

```swift
3375:         operationErrorMessage = nil
3376:         showNewBranchSheet = false
3377:         Task {
3378:             do {
3379:                 let isUnborn = status?.branch.oid == nil
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3402

```swift
3400:         operationErrorMessage = nil
3401:         showRenameBranchSheet = false
3402:         Task {
3403:             do {
3404:                 guard let sha = try await client.revParse(ref: "refs/heads/\(old)", in: repositoryURL) else { return }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3433

```swift
3431:         isConfirmingDeleteBranch = false
3432:         operationErrorMessage = nil
3433:         Task {
3434:             do {
3435:                 if let sha = try await client.revParse(ref: "refs/heads/\(name)", in: repositoryURL) {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3454

```swift
3452:         undoDescription = undoLog.nextDescription
3453:         operationErrorMessage = nil
3454:         Task {
3455:             do {
3456:                 try await client.updateRef(ref: entry.branchRef, to: entry.sha, in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3475

```swift
3473:         hasBringAlongConflict = false
3474:         conflictedFiles = []
3475:         Task {
3476:             _ = try? await client.stashDrop(in: repositoryURL)
3477:             await refreshAfterOp(in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3490

```swift
3488:         snapshotDetected = false
3489:         operationErrorMessage = nil
3490:         Task {
3491:             do {
3492:                 try await SnapshotEngine.restoreSnapshot(branch: branch, in: client, repositoryURL: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3505

```swift
3503:         guard let repositoryURL else { return }
3504:         operationErrorMessage = nil
3505:         Task {
3506:             do {
3507:                 switch inProgressOperation {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3526

```swift
3524:         guard let repositoryURL else { return }
3525:         operationErrorMessage = nil
3526:         Task {
3527:             do {
3528:                 switch inProgressOperation {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3546

```swift
3544:         guard let repositoryURL else { return }
3545:         operationErrorMessage = nil
3546:         Task {
3547:             do {
3548:                 try await client.takeOurs(path: path, in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3557

```swift
3555:         guard let repositoryURL else { return }
3556:         operationErrorMessage = nil
3557:         Task {
3558:             do {
3559:                 try await client.takeTheirs(path: path, in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3573

```swift
3571:     func openInMergeTool(path: String) {
3572:         guard let repositoryURL else { return }
3573:         Task {
3574:             // Fire-and-forget: if no merge tool is configured the external process exits
3575:             // non-zero but the error is not actionable from the UI (user can see the tool
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3587

```swift
3585:         guard let repositoryURL else { return }
3586:         operationErrorMessage = nil
3587:         Task {
3588:             do {
3589:                 let headSHA = try await client.revParse(ref: "HEAD", in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3611

```swift
3609:         guard let repositoryURL else { return }
3610:         operationErrorMessage = nil
3611:         Task {
3612:             do {
3613:                 let headSHA = try await client.revParse(ref: "HEAD", in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3636

```swift
3634:         guard let repositoryURL else { return }
3635:         operationErrorMessage = nil
3636:         Task {
3637:             do {
3638:                 let headSHA = try await client.revParse(ref: "HEAD", in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3678

```swift
3676:         showCreateTagSheet = false
3677:         operationErrorMessage = nil
3678:         Task {
3679:             do {
3680:                 consoleStore.echo(gitCommand: "git tag\(message.map { " -a -m \"\($0)\"" } ?? "") \(name) \(sha)")
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3706

```swift
3704:         showSquashSheet = false
3705:         operationErrorMessage = nil
3706:         Task {
3707:             do {
3708:                 guard let headSHA = try await client.revParse(ref: "HEAD", in: repositoryURL) else { return }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3736

```swift
3734:     private func reloadAfterSwitch(in repositoryURL: URL, to branch: String) async {
3735:         do {
3736:             async let statusTask = client.status(in: repositoryURL)
3737:             async let refsTask = client.refs(in: repositoryURL)
3738:             let (newStatus, newRefs) = try await (statusTask, refsTask)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3737

```swift
3735:         do {
3736:             async let statusTask = client.status(in: repositoryURL)
3737:             async let refsTask = client.refs(in: repositoryURL)
3738:             let (newStatus, newRefs) = try await (statusTask, refsTask)
3739:             updateStatus(newStatus)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3738

```swift
3736:             async let statusTask = client.status(in: repositoryURL)
3737:             async let refsTask = client.refs(in: repositoryURL)
3738:             let (newStatus, newRefs) = try await (statusTask, refsTask)
3739:             updateStatus(newStatus)
3740:             refList = newRefs
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3814

```swift
3812: 
3813:     private func startWatching(_ url: URL) {
3814:         watcherTask?.cancel()
3815:         watcherTask = Task {
3816:             let events = await repoWatcher.events(for: url)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3815

```swift
3813:     private func startWatching(_ url: URL) {
3814:         watcherTask?.cancel()
3815:         watcherTask = Task {
3816:             let events = await repoWatcher.events(for: url)
3817:             for await _ in events {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3818

```swift
3816:             let events = await repoWatcher.events(for: url)
3817:             for await _ in events {
3818:                 guard !Task.isCancelled else { break }
3819:                 // Use single-flight coordinator; operationErrorMessage is not cleared for watcher events.
3820:                 scheduleRefresh(for: url)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3852

```swift
3850:         let myGen = diffLoadGeneration
3851: 
3852:         Task {
3853:             do {
3854:                 let text = try await client.diff(path: path, in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L3913

```swift
3911:         isChangingStage = true
3912:         operationErrorMessage = nil
3913:         Task {
3914:             do {
3915:                 if staged {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4166

```swift
4164: 
4165:         do {
4166:             async let commitsTask = client.log(in: repositoryURL, maxCount: pageSize)
4167:             async let refsTask = client.refs(in: repositoryURL)
4168:             let (loadedCommits, loadedRefs) = try await (commitsTask, refsTask)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4167

```swift
4165:         do {
4166:             async let commitsTask = client.log(in: repositoryURL, maxCount: pageSize)
4167:             async let refsTask = client.refs(in: repositoryURL)
4168:             let (loadedCommits, loadedRefs) = try await (commitsTask, refsTask)
4169:             commits = loadedCommits
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4168

```swift
4166:             async let commitsTask = client.log(in: repositoryURL, maxCount: pageSize)
4167:             async let refsTask = client.refs(in: repositoryURL)
4168:             let (loadedCommits, loadedRefs) = try await (commitsTask, refsTask)
4169:             commits = loadedCommits
4170:             rows = GraphLayout.compute(commits)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4203

```swift
4201:         guard let sha else { return }
4202:         isDiffStatsLoading = true
4203:         Task {
4204:             do {
4205:                 commitDiffStats = try await client.diffStat(forCommit: sha, in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4220

```swift
4218:         diffPathGeneration &+= 1
4219:         let myGen = diffPathGeneration
4220:         Task {
4221:             do {
4222:                 let text = try await client.diff(commit: sha, path: path, in: repositoryURL)
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4241

```swift
4239:     // R-0038-08: opens the external diff tool for a single file at a given commit.
4240:     func openCommitFileDiffTool(sha: String, path: String) {
4241:         Task {
4242:             _ = try? await client.run(
4243:                 ["difftool", "-y", "--no-prompt", "\(sha)^!", "--", path],
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4251

```swift
4249:     // R-0038-07: extracts a file at a commit to a temp path and opens it.
4250:     func openFileAtCommitSnapshot(sha: String, path: String) {
4251:         Task {
4252:             guard let text = try? await client.showFileText(atCommit: sha, path: path, in: repositoryURL) else { return }
4253:             let ext = URL(fileURLWithPath: path).pathExtension
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4350

```swift
4348:                     .onAppear {
4349:                         if historyRow.id == vm.historyRows.last?.id {
4350:                             Task { await vm.loadMore() }
4351:                         }
4352:                     }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4569

```swift
4567:     // R-0038-05: hover popup state
4568:     @State private var showHoverPopover = false
4569:     @State private var hoverTask: Task<Void, Never>?
4570: 
4571:     var body: some View {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4602

```swift
4600:         }
4601:         .onHover { hovering in
4602:             hoverTask?.cancel()
4603:             if hovering {
4604:                 hoverTask = Task {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4604

```swift
4602:             hoverTask?.cancel()
4603:             if hovering {
4604:                 hoverTask = Task {
4605:                     try? await Task.sleep(nanoseconds: 400_000_000)
4606:                     if !Task.isCancelled { showHoverPopover = true }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4605

```swift
4603:             if hovering {
4604:                 hoverTask = Task {
4605:                     try? await Task.sleep(nanoseconds: 400_000_000)
4606:                     if !Task.isCancelled { showHoverPopover = true }
4607:                 }
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L4606

```swift
4604:                 hoverTask = Task {
4605:                     try? await Task.sleep(nanoseconds: 400_000_000)
4606:                     if !Task.isCancelled { showHoverPopover = true }
4607:                 }
4608:             } else {
```

Agent note: `Task` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L56

```swift
54: 
55:     private var serverFD: Int32 = -1
56:     private var acceptTask: Task<Void, Never>?
57:     private(set) var socketPath: String?
58: 
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L95

```swift
93:         serverFD = fd
94: 
95:         acceptTask = Task.detached(priority: .background) { [weak self] in
96:             while true {
97:                 let clientFD = Darwin.accept(fd, nil, nil)
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L99

```swift
97:                 let clientFD = Darwin.accept(fd, nil, nil)
98:                 guard clientFD >= 0 else { break }
99:                 Task { [weak self] in await self?.handleClient(clientFD) }
100:             }
101:         }
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L105

```swift
103: 
104:     func stop() {
105:         acceptTask?.cancel()
106:         acceptTask = nil
107:         if serverFD >= 0 {
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L106

```swift
104:     func stop() {
105:         acceptTask?.cancel()
106:         acceptTask = nil
107:         if serverFD >= 0 {
108:             Darwin.close(serverFD)
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L123

```swift
121: 
122:         // Receive request off main actor — blocking recv must not block the UI thread.
123:         let maybeRequest: BridgeRequest? = await Task.detached { () -> BridgeRequest? in
124:             Self.recvFrameIO(fd)
125:         }.value
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L147

```swift
145:         let response = BridgeResponse(ok: ok, value: value)
146:         if let data = try? JSONEncoder().encode(response) {
147:             await Task.detached { Self.sendFrameIO(fd, data) }.value
148:         }
149:     }
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/GitClient.swift` L104

```swift
102:         let timedOut = TimeoutBox()
103:         let pid = process.processIdentifier
104:         let timeoutTask = Task {
105:             try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
106:             guard process.isRunning else { return }
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/GitClient.swift` L105

```swift
103:         let pid = process.processIdentifier
104:         let timeoutTask = Task {
105:             try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
106:             guard process.isRunning else { return }
107:             await timedOut.markTimedOut()
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/GitClient.swift` L110

```swift
108:             process.terminate()  // SIGTERM
109:             // Grace period: if still running after 3 s, SIGKILL.
110:             try? await Task.sleep(nanoseconds: 3_000_000_000)
111:             if process.isRunning { kill(pid, SIGKILL) }
112:         }
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/GitClient.swift` L121

```swift
119:             if !process.isRunning { box.resume() }
120:         }
121:         timeoutTask.cancel()
122:         await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
123:             drainGroup.notify(queue: drainQueue) { continuation.resume() }
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L13

```swift
11:     private var stream: FSEventStreamRef?
12:     private var continuation: AsyncStream<Void>.Continuation?
13:     private var debounceTask: Task<Void, Never>?
14: 
15:     public init() {}
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L27

```swift
25: 
26:     public func stop() {
27:         debounceTask?.cancel()
28:         debounceTask = nil
29:         if let s = stream {
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L28

```swift
26:     public func stop() {
27:         debounceTask?.cancel()
28:         debounceTask = nil
29:         if let s = stream {
30:             FSEventStreamStop(s)
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L80

```swift
78:                 }
79:                 if relevant {
80:                     Task { await watcher.fire() }
81:                 }
82:             },
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L99

```swift
97: 
98:     private func fire() {
99:         debounceTask?.cancel()
100:         debounceTask = Task {
101:             try? await Task.sleep(nanoseconds: 300_000_000)
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L100

```swift
98:     private func fire() {
99:         debounceTask?.cancel()
100:         debounceTask = Task {
101:             try? await Task.sleep(nanoseconds: 300_000_000)
102:             guard !Task.isCancelled else { return }
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L101

```swift
99:         debounceTask?.cancel()
100:         debounceTask = Task {
101:             try? await Task.sleep(nanoseconds: 300_000_000)
102:             guard !Task.isCancelled else { return }
103:             continuation?.yield()
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitCore/RepoWatcher.swift` L102

```swift
100:         debounceTask = Task {
101:             try? await Task.sleep(nanoseconds: 300_000_000)
102:             guard !Task.isCancelled else { return }
103:             continuation?.yield()
104:         }
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/FolderCompareKit/FolderScanner.swift` L3

```swift
1: import Foundation
2: 
3: /// Recursive two-root scanner. Synchronous; run it inside a Task and it
4: /// honors cooperative cancellation. v0.1 returns the complete tree;
5: /// streaming row delivery (SPEC §3.4) comes with the virtualized UI.
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/FolderCompareKit/FolderScanner.swift` L51

```swift
49:         options: ScanOptions, depth: Int, visited: inout Set<NSObject>
50:     ) throws -> FolderEntry {
51:         try Task.checkCancellation()
52:         guard depth < maxScanDepth else {
53:             return FolderEntry(name: name, relativePath: relativePath, isDirectory: true,
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/FolderCompareKit/FolderScanner.swift` L129

```swift
127: 
128:         for childName in fileNames.sorted() where !typeConflicts.contains(childName) {
129:             try Task.checkCancellation()
130:             let lMeta = leftListing.files[childName]
131:             let rMeta = rightListing.files[childName]
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/FolderCompareKit/FolderScanner.swift` L255

```swift
253:         let chunkSize = 1 << 20
254:         while true {
255:             try Task.checkCancellation()
256:             let ca = try fa.read(upToCount: chunkSize) ?? Data()
257:             let cb = try fb.read(upToCount: chunkSize) ?? Data()
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/FolderCompareKit/FolderScanner.swift` L270

```swift
268:         while true {
269:             iterations += 1
270:             if iterations & 0xFFFF == 0 { try Task.checkCancellation() }
271:             let ba = try ra.next()
272:             let bb = try rb.next()
```

Agent note: `Task` appears here in a `Core diff/text/git/model logic` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L38

```swift
36:     private var contextLines: Int? = 10
37:     private var generation = 0
38:     private var reloadTask: Task<Void, Never>?
39:     private var watcher: FileWatcher?
40: 
```

Agent note: `Task` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L224

```swift
222: 
223:     deinit {
224:         reloadTask?.cancel()
225:         NotificationCenter.default.removeObserver(self)
226:     }
```

Agent note: `Task` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L253

```swift
251: 
252:     private func reload() {
253:         reloadTask?.cancel()
254:         generation += 1
255:         let gen = generation
```

Agent note: `Task` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L262

```swift
260:         counterLabel.stringValue = "Comparing…"
261: 
262:         let bg = Task.detached(priority: .userInitiated) { () -> ReloadPayload in
263:             if try Self.isBinaryFile(l) || Self.isBinaryFile(r) {
264:                 return try Self.hexPayload(left: l, right: r, context: context)
```

Agent note: `Task` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L268

```swift
266:             return try Self.textPayload(left: l, right: r, ignore: ignore, context: context)
267:         }
268:         reloadTask = Task { @MainActor [weak self, bg] in
269:             defer { bg.cancel() }
270:             do {
```

Agent note: `Task` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L15

```swift
13:     private var rootEntry: FolderEntry?
14:     private var scanOptions = ScanOptions()
15:     private var scanTask: Task<Void, Never>?
16:     private var fileOpInProgress = false
17: 
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L88

```swift
86: 
87:     deinit {
88:         scanTask?.cancel()
89:     }
90: 
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L207

```swift
205: 
206:     private func rescan() {
207:         scanTask?.cancel()
208:         spinner.startAnimation(nil)
209:         summaryLabel.stringValue = "Scanning…"
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L212

```swift
210:         let l = leftRoot, r = rightRoot
211:         let options = scanOptions
212:         scanTask = Task { @MainActor [weak self] in
213:             do {
214:                 let root = try await Task.detached(priority: .userInitiated) {
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L214

```swift
212:         scanTask = Task { @MainActor [weak self] in
213:             do {
214:                 let root = try await Task.detached(priority: .userInitiated) {
215:                     try FolderScanner.scan(left: l, right: r, options: options)
216:                 }.value
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L217

```swift
215:                     try FolderScanner.scan(left: l, right: r, options: options)
216:                 }.value
217:                 guard let self, !Task.isCancelled else { return }
218:                 self.rootEntry = root
219:                 self.applyViewOptions()
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L410

```swift
408:         spinner.startAnimation(nil)
409:         summaryLabel.stringValue = "Working…"
410:         Task { @MainActor [weak self] in
411:             let result: Result<Void, Error> = await Task.detached(priority: .userInitiated) {
412:                 do { try operation(); return .success(()) }
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L411

```swift
409:         summaryLabel.stringValue = "Working…"
410:         Task { @MainActor [weak self] in
411:             let result: Result<Void, Error> = await Task.detached(priority: .userInitiated) {
412:                 do { try operation(); return .success(()) }
413:                 catch { return .failure(error) }
```

Agent note: `Task` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L23

```swift
21:     private var currentConflict = -1
22:     private var generation = 0
23:     private var reloadTask: Task<Void, Never>?
24:     private var isOutputDirty = false
25:     private var watcher: FileWatcher?
```

Agent note: `Task` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L58

```swift
56: 
57:     deinit {
58:         reloadTask?.cancel()
59:     }
60: 
```

Agent note: `Task` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L176

```swift
174: 
175:     private func reload() {
176:         reloadTask?.cancel()
177:         generation += 1
178:         let gen = generation
```

Agent note: `Task` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L183

```swift
181:         counterLabel.stringValue = "Merging…"
182: 
183:         let bg = Task.detached(priority: .userInitiated) { () -> MergePayload in
184:             let baseDoc = try TextDocument.load(from: b)
185:             let leftDoc = try TextDocument.load(from: l)
```

Agent note: `Task` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L233

```swift
231:             )
232:         }
233:         reloadTask = Task { @MainActor [weak self, bg] in
234:             defer { bg.cancel() }
235:             do {
```

Agent note: `Task` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L77

```swift
75:         .frame(width: 560)
76:         .onDrop(of: [.fileURL], isTargeted: $dropTargeted) { providers in
77:             Task { @MainActor in
78:                 for provider in providers {
79:                     if let url = await loadURL(from: provider) {
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L186

```swift
184:             _ = provider.loadObject(ofClass: URL.self) { url, _ in
185:                 guard let url else { return }
186:                 Task { @MainActor in
187:                     path = url.path
188:                 }
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L102

```swift
100:     private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
101:         guard !providers.isEmpty else { return false }
102:         Task { @MainActor in
103:             for provider in providers {
104:                 guard let url = await loadURL(from: provider) else { continue }
```

Agent note: `Task` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L388

```swift
386:             guard let item = child as? ListItem else { continue }
387:             result.append(hasCheckboxes
388:                 ? renderTaskItem(item)
389:                 : renderBulletItem(item, depth: depth))
390:         }
```

Agent note: `Task` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L460

```swift
458:     }
459: 
460:     private func renderTaskItem(_ item: ListItem) -> NSAttributedString {
461:         let isChecked = item.checkbox == .checked
462:         let lineNum   = item.range?.lowerBound.line ?? 0
```

Agent note: `Task` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

## `allowsNonContiguousLayout` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L29

```swift
27:         // Non-contiguous layout: layout manager only typesets visible glyphs, making
28:         // initial display of large documents near-instant instead of blocking on full layout.
29:         textView.layoutManager?.allowsNonContiguousLayout = true
30:         textView.isEditable = true
31:         textView.isSelectable = true
```

Agent note: `allowsNonContiguousLayout` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `autoresizingMask` (2 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L107

```swift
105:         textView.font = Theme.editorFont
106:         textView.textContainerInset = NSSize(width: 4, height: 4)
107:         textView.autoresizingMask = [.width]
108: 
109:         // Disable wrapping: one display row per line fragment.
```

Agent note: `autoresizingMask` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L43

```swift
41:         textView.isVerticallyResizable  = true
42:         textView.isHorizontallyResizable = false
43:         textView.autoresizingMask       = .width
44:         textView.isEditable            = false
45:         textView.isSelectable          = true
```

Agent note: `autoresizingMask` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `beginEditing` (4 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L401

```swift
399:                     guard let self, self.highlightGeneration == gen else { return }
400:                     guard let storage = self.textViewRef?.textStorage else { return }
401:                     storage.beginEditing()
402:                     MarkdownSyntaxHighlighter.applyTokens(tokens, to: storage)
403:                     storage.endEditing()
```

Agent note: `beginEditing` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L196

```swift
194: 
195:     // Apply a pre-computed token array to storage.
196:     // Must be called on the main thread; caller wraps in beginEditing/endEditing.
197:     static func applyTokens(_ tokens: [SyntaxToken], to storage: NSTextStorage) {
198:         for token in tokens {
```

Agent note: `beginEditing` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L229

```swift
227:         let tokens = collectTokensInline(text: storage.string, paragraphRange: paragraphRange,
228:                                          fontSize: fontSize, family: family, enabled: enabled, colors: colors)
229:         storage.beginEditing()
230:         applyTokens(tokens, to: storage)
231:         storage.endEditing()
```

Agent note: `beginEditing` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L249

```swift
247:         colors: SyntaxHighlightColors
248:     ) {
249:         storage.beginEditing()
250:         applyFull(storage, fontSize: fontSize, family: family, enabled: enabled, colors: colors)
251:         storage.endEditing()
```

Agent note: `beginEditing` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

## `bestMatch` (9 hits)


### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L12

```swift
10:     static func dynamic(light: NSColor, dark: NSColor) -> NSColor {
11:         NSColor(name: nil) { appearance in
12:             appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua ? dark : light
13:         }
14:     }
```

Agent note: `bestMatch` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L200

```swift
198:             // White in light mode; system window background (dark-gray) in dark mode.
199:             case .adaptive: return Color(nsColor: NSColor(name: nil) { t in
200:                 t.bestMatch(from: [.darkAqua, .vibrantDark]) != nil ? .windowBackgroundColor : .white
201:             })
202:             case .light:    return Color.white
```

Agent note: `bestMatch` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L233

```swift
231:             case .dark, .ink: return true
232:             case .adaptive:
233:                 return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
234:             default: return false
235:             }
```

Agent note: `bestMatch` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L124

```swift
122:     static var editorBackground: NSColor {
123:         NSColor(name: nil) { appearance in
124:             if appearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil {
125:                 return NSColor(white: 0.18, alpha: 1.0)
126:             } else {
```

Agent note: `bestMatch` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L292

```swift
290:             guard fullLen > 0 else { return }
291: 
292:             let isDark   = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
293:             let colors   = AppearanceSettings.shared.syntaxColors(dark: isDark)
294:             let fontSize = parent.appearance.editorFontSize
```

Agent note: `bestMatch` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L391

```swift
389:             highlightGeneration = gen
390:             // Capture colors now on main thread (appearance-dependent).
391:             let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
392:             let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
393: 
```

Agent note: `bestMatch` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L35

```swift
33: 
34:     private static let codeBackground = NSColor(name: nil) { app in
35:         app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
36:             ? NSColor(white: 1.0, alpha: 0.09)
37:             : NSColor(white: 0.0, alpha: 0.06)
```

Agent note: `bestMatch` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L237

```swift
235: 
236:     static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {
237:         let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
238:         let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
239:         highlight(storage, fontSize: fontSize, family: family, enabled: enabled, colors: colors)
```

Agent note: `bestMatch` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L34

```swift
32:     @EnvironmentObject private var appearance: AppearanceSettings
33:     @State private var colorsDark: Bool = {
34:         NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
35:     }()
36: 
```

Agent note: `bestMatch` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `bottomAnchor` (3 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L183

```swift
181:         NSLayoutConstraint.activate([
182:             main.topAnchor.constraint(equalTo: container.topAnchor),
183:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
184:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
185:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
```

Agent note: `bottomAnchor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L151

```swift
149:         NSLayoutConstraint.activate([
150:             main.topAnchor.constraint(equalTo: container.topAnchor),
151:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
152:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
153:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
```

Agent note: `bottomAnchor` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L152

```swift
150:         NSLayoutConstraint.activate([
151:             main.topAnchor.constraint(equalTo: container.topAnchor),
152:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
153:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
154:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
```

Agent note: `bottomAnchor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `boundingRect` (3 hits)


### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L116

```swift
114:                 let iEnd   = min(NSMaxRange(gr), NSMaxRange(lineGlyphRange))
115:                 guard iEnd > iStart else { return }
116:                 let codeRect = self.boundingRect(
117:                     forGlyphRange: NSRange(location: iStart, length: iEnd - iStart),
118:                     in: container)
```

Agent note: `boundingRect` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L418

```swift
416:             guard let lm = tv.layoutManager, let tc = tv.textContainer else { return }
417:             let glyphRange = lm.glyphRange(forCharacterRange: selectionRange, actualCharacterRange: nil)
418:             var rect = lm.boundingRect(forGlyphRange: glyphRange, in: tc)
419:             let inset = tv.textContainerInset
420:             rect.origin.x += inset.width
```

Agent note: `boundingRect` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L181

```swift
179:             layoutManager.ensureLayout(for: container)
180:             let glyphRange = layoutManager.glyphRange(forCharacterRange: target, actualCharacterRange: nil)
181:             let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)
182:                 .offsetBy(dx: textView.textContainerInset.width, dy: textView.textContainerInset.height)
183:             let y = max(rect.minY - 12, 0)
```

Agent note: `boundingRect` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `boundsDidChangeNotification` (1 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L204

```swift
202:             NotificationCenter.default.addObserver(
203:                 self, selector: #selector(boundsChanged(_:)),
204:                 name: NSView.boundsDidChangeNotification, object: scroll.contentView
205:             )
206:         }
```

Agent note: `boundsDidChangeNotification` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

## `centerYAnchor` (5 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2181

```swift
2179:             NSLayoutConstraint.activate([
2180:                 label.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 8),
2181:                 label.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2182:                 label.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -4)
2183:             ])
```

Agent note: `centerYAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2240

```swift
2238:             NSLayoutConstraint.activate([
2239:                 oldNum.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 4),
2240:                 oldNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2241:                 oldNum.widthAnchor.constraint(equalToConstant: 36),
2242: 
```

Agent note: `centerYAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2244

```swift
2242: 
2243:                 newNum.leadingAnchor.constraint(equalTo: oldNum.trailingAnchor, constant: 4),
2244:                 newNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2245:                 newNum.widthAnchor.constraint(equalToConstant: 36),
2246: 
```

Agent note: `centerYAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2248

```swift
2246: 
2247:                 marker.leadingAnchor.constraint(equalTo: newNum.trailingAnchor, constant: 6),
2248:                 marker.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2249:                 marker.widthAnchor.constraint(equalToConstant: 12),
2250: 
```

Agent note: `centerYAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2252

```swift
2250: 
2251:                 text.leadingAnchor.constraint(equalTo: marker.trailingAnchor, constant: 4),
2252:                 text.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2253:                 text.trailingAnchor.constraint(equalTo: box.trailingAnchor)
2254:             ])
```

Agent note: `centerYAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

## `characterRange` (4 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L38

```swift
36:         if !rowBackgrounds.isEmpty {
37:             let glyphRange = lm.glyphRange(forBoundingRect: rect, in: tc)
38:             let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
39:             var row = Self.rowIndex(in: lineStartOffsets, for: charRange.location)
40: 
```

Agent note: `characterRange` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L151

```swift
149:         let visibleRect = tv.visibleRect
150:         let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)
151:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
152:         let starts = tv.lineStartOffsets
153: 
```

Agent note: `characterRange` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L552

```swift
550:               !leftText.lineStartOffsets.isEmpty else { return }
551:         let glyphRange = lm.glyphRange(forBoundingRect: leftText.visibleRect, in: tc)
552:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
553:         let starts = leftText.lineStartOffsets
554:         let first = DiffTextView.rowIndex(in: starts, for: charRange.location)
```

Agent note: `characterRange` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L47

```swift
45:             return
46:         }
47:         let charRange = characterRange(forGlyphRange: glyphsToShow, actualGlyphRange: nil)
48:         var prev: (MarkdownBlockBackground, NSRange)? = nil
49: 
```

Agent note: `characterRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

## `clickedOnLink` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L134

```swift
132:         }
133: 
134:         func textView(_ textView: NSTextView, clickedOnLink link: Any, at charIndex: Int) -> Bool {
135:             guard let url = link as? URL else { return false }
136: 
```

Agent note: `clickedOnLink` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `containerSize` (5 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L116

```swift
114:         if let container = textView.textContainer {
115:             container.widthTracksTextView = false
116:             container.containerSize = NSSize(width: CGFloat.greatestFiniteMagnitude,
117:                                              height: CGFloat.greatestFiniteMagnitude)
118:         }
```

Agent note: `containerSize` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L385

```swift
383:         let tv = NSTextView(frame: NSRect(x: 0, y: 0, width: pageWidth, height: 100))
384:         tv.textContainer?.widthTracksTextView = true
385:         tv.textContainer?.containerSize = NSSize(width: pageWidth, height: .greatestFiniteMagnitude)
386:         tv.isVerticallyResizable   = true
387:         tv.isHorizontallyResizable = false
```

Agent note: `containerSize` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L58

```swift
56:             let pad = container.lineFragmentPadding
57:             bounding.origin.x    = pad
58:             bounding.size.width  = container.containerSize.width - pad * 2
59:             var rect = bounding.offsetBy(dx: origin.x, dy: origin.y)
60:             rect.origin.y    += bg.topInset
```

Agent note: `containerSize` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L44

```swift
42:         // (258K frags for 258 KB), causing a 400 ms+ display stall.
43:         scrollView.setFrameSize(NSSize(width: 800, height: 600))
44:         let initCW = Int(textView.textContainer?.containerSize.width ?? -1)
45:         benchLog("[BENCH] makeNSView frameW=\(Int(scrollView.frame.width)) containerW=\(initCW)")
46: 
```

Agent note: `containerSize` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L82

```swift
80:     func updateNSView(_ scrollView: NSScrollView, context: Context) {
81:         guard let textView = scrollView.documentView as? NSTextView else { return }
82:         let cW = Int(textView.textContainer?.containerSize.width ?? -1)
83:         benchLog("[BENCH] updateNSView \(benchT()) textLen=\(textView.string.count) cW=\(cW)")
84:         context.coordinator.parent = self
```

Agent note: `containerSize` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `contentView.scroll` (5 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L530

```swift
528:         let targetY = max(0, frag.midY - leftScroll.contentView.bounds.height / 2)
529:         let origin = NSPoint(x: leftScroll.contentView.bounds.origin.x, y: targetY)
530:         leftScroll.contentView.scroll(to: origin)
531:         leftScroll.reflectScrolledClipView(leftScroll.contentView)
532:     }
```

Agent note: `contentView.scroll` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L539

```swift
537:             syncing = true
538:             let other: NSScrollView = (clipView === leftScroll.contentView) ? rightScroll : leftScroll
539:             other.contentView.scroll(to: clipView.bounds.origin)
540:             other.reflectScrolledClipView(other.contentView)
541:             syncing = false
```

Agent note: `contentView.scroll` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L300

```swift
298:         let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
299:         let targetY = max(0, frag.midY - scroll.contentView.bounds.height / 2)
300:         scroll.contentView.scroll(to: NSPoint(x: scroll.contentView.bounds.origin.x, y: targetY))
301:         scroll.reflectScrolledClipView(scroll.contentView)
302:     }
```

Agent note: `contentView.scroll` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L130

```swift
128:             let maxY    = max(0, docH - clipH)
129:             let clamped = NSPoint(x: origin.x, y: min(origin.y, maxY))
130:             sv.contentView.scroll(to: clamped)
131:             sv.reflectScrolledClipView(sv.contentView)
132:         }
```

Agent note: `contentView.scroll` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L184

```swift
182:                 .offsetBy(dx: textView.textContainerInset.width, dy: textView.textContainerInset.height)
183:             let y = max(rect.minY - 12, 0)
184:             scrollView.contentView.scroll(to: NSPoint(x: 0, y: y))
185:             scrollView.reflectScrolledClipView(scrollView.contentView)
186:         }
```

Agent note: `contentView.scroll` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `darkAqua` (9 hits)


### `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L12

```swift
10:     static func dynamic(light: NSColor, dark: NSColor) -> NSColor {
11:         NSColor(name: nil) { appearance in
12:             appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua ? dark : light
13:         }
14:     }
```

Agent note: `darkAqua` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L200

```swift
198:             // White in light mode; system window background (dark-gray) in dark mode.
199:             case .adaptive: return Color(nsColor: NSColor(name: nil) { t in
200:                 t.bestMatch(from: [.darkAqua, .vibrantDark]) != nil ? .windowBackgroundColor : .white
201:             })
202:             case .light:    return Color.white
```

Agent note: `darkAqua` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L233

```swift
231:             case .dark, .ink: return true
232:             case .adaptive:
233:                 return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
234:             default: return false
235:             }
```

Agent note: `darkAqua` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L124

```swift
122:     static var editorBackground: NSColor {
123:         NSColor(name: nil) { appearance in
124:             if appearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil {
125:                 return NSColor(white: 0.18, alpha: 1.0)
126:             } else {
```

Agent note: `darkAqua` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L292

```swift
290:             guard fullLen > 0 else { return }
291: 
292:             let isDark   = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
293:             let colors   = AppearanceSettings.shared.syntaxColors(dark: isDark)
294:             let fontSize = parent.appearance.editorFontSize
```

Agent note: `darkAqua` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L391

```swift
389:             highlightGeneration = gen
390:             // Capture colors now on main thread (appearance-dependent).
391:             let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
392:             let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
393: 
```

Agent note: `darkAqua` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L35

```swift
33: 
34:     private static let codeBackground = NSColor(name: nil) { app in
35:         app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
36:             ? NSColor(white: 1.0, alpha: 0.09)
37:             : NSColor(white: 0.0, alpha: 0.06)
```

Agent note: `darkAqua` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L237

```swift
235: 
236:     static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {
237:         let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
238:         let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
239:         highlight(storage, fontSize: fontSize, family: family, enabled: enabled, colors: colors)
```

Agent note: `darkAqua` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L34

```swift
32:     @EnvironmentObject private var appearance: AppearanceSettings
33:     @State private var colorsDark: Bool = {
34:         NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
35:     }()
36: 
```

Agent note: `darkAqua` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `defaultParagraphStyle` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L446

```swift
444:         style.defaultTabInterval = tabInterval
445:         style.tabStops = []
446:         textView.defaultParagraphStyle = style
447:         textView.typingAttributes[.paragraphStyle] = style
448:     }
```

Agent note: `defaultParagraphStyle` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `didCompleteLayoutFor` (3 hits)


### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L35

```swift
33:         textStorage.addLayoutManager(layoutMgr)
34:         // Single-pass layout required so documentRect.height is accurate when
35:         // didCompleteLayoutFor fires and we restore the scroll position.
36:         layoutMgr.delegate = context.coordinator
37: 
```

Agent note: `didCompleteLayoutFor` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L99

```swift
97:         context.coordinator.pendingScrollOrigin     = scrollView.contentView.bounds.origin
98:         textView.textStorage?.setAttributedString(attributedString)
99:         // Scroll position is restored in layoutManager(_:didCompleteLayoutFor:atEnd:)
100:         // after NSLayoutManager finishes laying out the new content.
101:     }
```

Agent note: `didCompleteLayoutFor` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L120

```swift
118: 
119:         func layoutManager(_ layoutManager: NSLayoutManager,
120:                            didCompleteLayoutFor textContainer: NSTextContainer?,
121:                            atEnd layoutFinishedFlag: Bool) {
122:             guard layoutFinishedFlag,
```

Agent note: `didCompleteLayoutFor` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `didProcessEditing` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L275

```swift
273:         func textStorage(
274:             _ textStorage: NSTextStorage,
275:             didProcessEditing editedMask: NSTextStorageEditActions,
276:             range editedRange: NSRange,
277:             changeInLength delta: Int
```

Agent note: `didProcessEditing` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `distribution` (2 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L158

```swift
156:         contentRow.orientation = .horizontal
157:         contentRow.spacing = 1
158:         contentRow.distribution = .fill
159:         leftScroll.widthAnchor.constraint(equalTo: rightScroll.widthAnchor).isActive = true
160:         overview.widthAnchor.constraint(equalToConstant: 14).isActive = true
```

Agent note: `distribution` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L101

```swift
99:         sourcesRow.orientation = .horizontal
100:         sourcesRow.spacing = 1
101:         sourcesRow.distribution = .fillEqually
102: 
103:         let (outputScroll, ot) = DiffTextView.makePane(editable: true)
```

Agent note: `distribution` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `documentRect` (2 hits)


### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L34

```swift
32:         layoutMgr.addTextContainer(container)
33:         textStorage.addLayoutManager(layoutMgr)
34:         // Single-pass layout required so documentRect.height is accurate when
35:         // didCompleteLayoutFor fires and we restore the scroll position.
36:         layoutMgr.delegate = context.coordinator
```

Agent note: `documentRect` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L126

```swift
124:                   let sv     = scrollViewRef else { return }
125:             pendingScrollOrigin = nil
126:             let docH    = sv.contentView.documentRect.height
127:             let clipH   = sv.contentView.bounds.height
128:             let maxY    = max(0, docH - clipH)
```

Agent note: `documentRect` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `draw(_` (1 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L22

```swift
20:     override var intrinsicContentSize: NSSize { NSSize(width: 14, height: NSView.noIntrinsicMetric) }
21: 
22:     override func draw(_ dirtyRect: NSRect) {
23:         NSColor.windowBackgroundColor.setFill()
24:         bounds.fill()
```

Agent note: `draw(_` appears here in a `Overview strip custom NSView` context. Check surrounding module before changing behavior.

## `drawBackground` (6 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L6

```swift
4: /// row-aware line number ruler. Attribute-based backgrounds only cover
5: /// glyphs; diff row tints must span the full line width, so they are drawn
6: /// in `drawBackground(in:)` from the display-row table. (SPEC §11.4)
7: final class DiffTextView: NSTextView {
8: 
```

Agent note: `drawBackground` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L30

```swift
28:     }
29: 
30:     override func drawBackground(in rect: NSRect) {
31:         super.drawBackground(in: rect)
32:         guard !lineStartOffsets.isEmpty,
```

Agent note: `drawBackground` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L31

```swift
29: 
30:     override func drawBackground(in rect: NSRect) {
31:         super.drawBackground(in: rect)
32:         guard !lineStartOffsets.isEmpty,
33:               let lm = layoutManager, let tc = textContainer,
```

Agent note: `drawBackground` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L42

```swift
40: 
41: final class MarkdownLayoutManager: NSLayoutManager {
42:     override func drawBackground(forGlyphRange glyphsToShow: NSRange, at origin: NSPoint) {
43:         guard let storage = textStorage, let container = textContainers.first else {
44:             super.drawBackground(forGlyphRange: glyphsToShow, at: origin)
```

Agent note: `drawBackground` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L44

```swift
42:     override func drawBackground(forGlyphRange glyphsToShow: NSRange, at origin: NSPoint) {
43:         guard let storage = textStorage, let container = textContainers.first else {
44:             super.drawBackground(forGlyphRange: glyphsToShow, at: origin)
45:             return
46:         }
```

Agent note: `drawBackground` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L134

```swift
132: 
133:         // 4. Super draws selection highlights and NSTextTable cell backgrounds on top.
134:         super.drawBackground(forGlyphRange: glyphsToShow, at: origin)
135:     }
136: }
```

Agent note: `drawBackground` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

## `drawHashMarksAndLabels` (1 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L144

```swift
142:     }
143: 
144:     override func drawHashMarksAndLabels(in rect: NSRect) {
145:         guard let tv = diffTextView, let lm = tv.layoutManager, let tc = tv.textContainer,
146:               let storage = tv.textStorage, storage.length > 0,
```

Agent note: `drawHashMarksAndLabels` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

## `drawsBackground` (4 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L36

```swift
34:         let bg = Self.editorBackground
35:         scrollView.backgroundColor = bg
36:         scrollView.drawsBackground = true
37:         textView.backgroundColor   = bg
38:         textView.drawsBackground   = true
```

Agent note: `drawsBackground` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L38

```swift
36:         scrollView.drawsBackground = true
37:         textView.backgroundColor   = bg
38:         textView.drawsBackground   = true
39:         applyTabStops(to: textView, tabSize: appearance.editorTabSize, fontSize: appearance.editorFontSize, family: appearance.editorFontFamily)
40:         // Pre-size so NSLayoutManager gets a real container width before the first string
```

Agent note: `drawsBackground` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L47

```swift
45:         textView.isSelectable          = true
46:         textView.isRichText            = true
47:         textView.drawsBackground       = false
48:         textView.textContainerInset    = NSSize(width: 32, height: 32)
49: 
```

Agent note: `drawsBackground` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L79

```swift
77:         scrollView.hasHorizontalScroller = false
78:         scrollView.autohidesScrollers   = true
79:         scrollView.drawsBackground      = false
80:         context.coordinator.scrollViewRef = scrollView
81:         return scrollView
```

Agent note: `drawsBackground` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `edgeInsets` (5 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L153

```swift
151:         controlBar.orientation = .horizontal
152:         controlBar.spacing = 8
153:         controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
154: 
155:         let contentRow = NSStackView(views: [leftScroll, rightScroll, overview])
```

Agent note: `edgeInsets` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L172

```swift
170:         let statusBar = NSStackView(views: [leftStatus, statusSpacer, rightStatus])
171:         statusBar.orientation = .horizontal
172:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
173: 
174:         let main = NSStackView(views: [controlBar, contentRow, statusBar])
```

Agent note: `edgeInsets` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L127

```swift
125:         controlBar.orientation = .horizontal
126:         controlBar.spacing = 8
127:         controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
128: 
129:         configureOutline()
```

Agent note: `edgeInsets` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L140

```swift
138:         let statusBar = NSStackView(views: [pathLabel])
139:         statusBar.orientation = .horizontal
140:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
141: 
142:         let main = NSStackView(views: [controlBar, scroll, statusBar])
```

Agent note: `edgeInsets` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L140

```swift
138:         controlBar.orientation = .horizontal
139:         controlBar.spacing = 8
140:         controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
141: 
142:         split.setContentHuggingPriority(.init(1), for: .vertical)
```

Agent note: `edgeInsets` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `effectiveAppearance` (6 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2119

```swift
2117:         func attachAppearanceObserver(to tv: NSTableView) {
2118:             tableView = tv
2119:             appearanceObservation = NSApp.observe(\.effectiveAppearance) { [weak self] _, _ in
2120:                 DispatchQueue.main.async { self?.tableView?.reloadData() }
2121:             }
```

Agent note: `effectiveAppearance` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L233

```swift
231:             case .dark, .ink: return true
232:             case .adaptive:
233:                 return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
234:             default: return false
235:             }
```

Agent note: `effectiveAppearance` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L292

```swift
290:             guard fullLen > 0 else { return }
291: 
292:             let isDark   = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
293:             let colors   = AppearanceSettings.shared.syntaxColors(dark: isDark)
294:             let fontSize = parent.appearance.editorFontSize
```

Agent note: `effectiveAppearance` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L391

```swift
389:             highlightGeneration = gen
390:             // Capture colors now on main thread (appearance-dependent).
391:             let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
392:             let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
393: 
```

Agent note: `effectiveAppearance` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L237

```swift
235: 
236:     static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {
237:         let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
238:         let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
239:         highlight(storage, fontSize: fontSize, family: family, enabled: enabled, colors: colors)
```

Agent note: `effectiveAppearance` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L34

```swift
32:     @EnvironmentObject private var appearance: AppearanceSettings
33:     @State private var colorsDark: Bool = {
34:         NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
35:     }()
36: 
```

Agent note: `effectiveAppearance` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `endEditing` (5 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L403

```swift
401:                     storage.beginEditing()
402:                     MarkdownSyntaxHighlighter.applyTokens(tokens, to: storage)
403:                     storage.endEditing()
404:                 }
405:             }
```

Agent note: `endEditing` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L196

```swift
194: 
195:     // Apply a pre-computed token array to storage.
196:     // Must be called on the main thread; caller wraps in beginEditing/endEditing.
197:     static func applyTokens(_ tokens: [SyntaxToken], to storage: NSTextStorage) {
198:         for token in tokens {
```

Agent note: `endEditing` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L231

```swift
229:         storage.beginEditing()
230:         applyTokens(tokens, to: storage)
231:         storage.endEditing()
232:     }
233: 
```

Agent note: `endEditing` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L234

```swift
232:     }
233: 
234:     // MARK: - Public highlight wrappers (with begin/endEditing — for external callers)
235: 
236:     static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {
```

Agent note: `endEditing` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L251

```swift
249:         storage.beginEditing()
250:         applyFull(storage, fontSize: fontSize, family: family, enabled: enabled, colors: colors)
251:         storage.endEditing()
252:     }
253: 
```

Agent note: `endEditing` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

## `ensureLayout` (2 hits)


### `MackDown/Sources/MackDownApp/MackDownApp.swift` L391

```swift
389:         tv.textStorage?.setAttributedString(attr)
390:         if let lm = tv.layoutManager, let tc = tv.textContainer {
391:             lm.ensureLayout(for: tc)
392:             tv.frame.size.height = lm.usedRect(for: tc).height + 20
393:         }
```

Agent note: `ensureLayout` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L179

```swift
177:             }
178:             guard let target else { return }
179:             layoutManager.ensureLayout(for: container)
180:             let glyphRange = layoutManager.glyphRange(forCharacterRange: target, actualCharacterRange: nil)
181:             let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)
```

Agent note: `ensureLayout` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `glyphRange` (13 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L37

```swift
35: 
36:         if !rowBackgrounds.isEmpty {
37:             let glyphRange = lm.glyphRange(forBoundingRect: rect, in: tc)
38:             let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
39:             var row = Self.rowIndex(in: lineStartOffsets, for: charRange.location)
```

Agent note: `glyphRange` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L38

```swift
36:         if !rowBackgrounds.isEmpty {
37:             let glyphRange = lm.glyphRange(forBoundingRect: rect, in: tc)
38:             let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
39:             var row = Self.rowIndex(in: lineStartOffsets, for: charRange.location)
40: 
```

Agent note: `glyphRange` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L150

```swift
148: 
149:         let visibleRect = tv.visibleRect
150:         let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)
151:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
152:         let starts = tv.lineStartOffsets
```

Agent note: `glyphRange` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L151

```swift
149:         let visibleRect = tv.visibleRect
150:         let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)
151:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
152:         let starts = tv.lineStartOffsets
153: 
```

Agent note: `glyphRange` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L551

```swift
549:         guard let lm = leftText.layoutManager, let tc = leftText.textContainer,
550:               !leftText.lineStartOffsets.isEmpty else { return }
551:         let glyphRange = lm.glyphRange(forBoundingRect: leftText.visibleRect, in: tc)
552:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
553:         let starts = leftText.lineStartOffsets
```

Agent note: `glyphRange` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L552

```swift
550:               !leftText.lineStartOffsets.isEmpty else { return }
551:         let glyphRange = lm.glyphRange(forBoundingRect: leftText.visibleRect, in: tc)
552:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
553:         let starts = leftText.lineStartOffsets
554:         let first = DiffTextView.rowIndex(in: starts, for: charRange.location)
```

Agent note: `glyphRange` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L51

```swift
49: 
50:         func flush(_ range: NSRange, _ bg: MarkdownBlockBackground) {
51:             let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)
52:             var rects: [NSRect] = []
53:             enumerateLineFragments(forGlyphRange: gr) { r, _, _, _, _ in rects.append(r) }
```

Agent note: `glyphRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L90

```swift
88:         storage.enumerateAttribute(.markdownBlockLeftBorders, in: charRange, options: []) { val, range, _ in
89:             guard let v = val as? MarkdownBlockLeftBorders, !v.list.isEmpty else { return }
90:             let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)
91:             var rects: [NSRect] = []
92:             enumerateLineFragments(forGlyphRange: gr) { r, _, _, _, _ in rects.append(r) }
```

Agent note: `glyphRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L111

```swift
109:         storage.enumerateAttribute(.markdownInlineCode, in: charRange, options: []) { val, range, _ in
110:             guard let color = val as? NSColor else { return }
111:             let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)
112:             enumerateLineFragments(forGlyphRange: gr) { lineFragRect, _, _, lineGlyphRange, _ in
113:                 let iStart = max(gr.location, lineGlyphRange.location)
```

Agent note: `glyphRange` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L417

```swift
415:         private func showFloatingPanel(for tv: NSTextView, selectionRange: NSRange) {
416:             guard let lm = tv.layoutManager, let tc = tv.textContainer else { return }
417:             let glyphRange = lm.glyphRange(forCharacterRange: selectionRange, actualCharacterRange: nil)
418:             var rect = lm.boundingRect(forGlyphRange: glyphRange, in: tc)
419:             let inset = tv.textContainerInset
```

Agent note: `glyphRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L418

```swift
416:             guard let lm = tv.layoutManager, let tc = tv.textContainer else { return }
417:             let glyphRange = lm.glyphRange(forCharacterRange: selectionRange, actualCharacterRange: nil)
418:             var rect = lm.boundingRect(forGlyphRange: glyphRange, in: tc)
419:             let inset = tv.textContainerInset
420:             rect.origin.x += inset.width
```

Agent note: `glyphRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L180

```swift
178:             guard let target else { return }
179:             layoutManager.ensureLayout(for: container)
180:             let glyphRange = layoutManager.glyphRange(forCharacterRange: target, actualCharacterRange: nil)
181:             let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)
182:                 .offsetBy(dx: textView.textContainerInset.width, dy: textView.textContainerInset.height)
```

Agent note: `glyphRange` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L181

```swift
179:             layoutManager.ensureLayout(for: container)
180:             let glyphRange = layoutManager.glyphRange(forCharacterRange: target, actualCharacterRange: nil)
181:             let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)
182:                 .offsetBy(dx: textView.textContainerInset.width, dy: textView.textContainerInset.height)
183:             let y = max(rect.minY - 12, 0)
```

Agent note: `glyphRange` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `isHorizontallyResizable` (3 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L110

```swift
108: 
109:         // Disable wrapping: one display row per line fragment.
110:         textView.isHorizontallyResizable = true
111:         textView.isVerticallyResizable = true
112:         textView.maxSize = NSSize(width: CGFloat.greatestFiniteMagnitude,
```

Agent note: `isHorizontallyResizable` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L387

```swift
385:         tv.textContainer?.containerSize = NSSize(width: pageWidth, height: .greatestFiniteMagnitude)
386:         tv.isVerticallyResizable   = true
387:         tv.isHorizontallyResizable = false
388:         tv.isEditable = false
389:         tv.textStorage?.setAttributedString(attr)
```

Agent note: `isHorizontallyResizable` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L42

```swift
40:         textView.maxSize                = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
41:         textView.isVerticallyResizable  = true
42:         textView.isHorizontallyResizable = false
43:         textView.autoresizingMask       = .width
44:         textView.isEditable            = false
```

Agent note: `isHorizontallyResizable` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `isVerticallyResizable` (3 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L111

```swift
109:         // Disable wrapping: one display row per line fragment.
110:         textView.isHorizontallyResizable = true
111:         textView.isVerticallyResizable = true
112:         textView.maxSize = NSSize(width: CGFloat.greatestFiniteMagnitude,
113:                                   height: CGFloat.greatestFiniteMagnitude)
```

Agent note: `isVerticallyResizable` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L386

```swift
384:         tv.textContainer?.widthTracksTextView = true
385:         tv.textContainer?.containerSize = NSSize(width: pageWidth, height: .greatestFiniteMagnitude)
386:         tv.isVerticallyResizable   = true
387:         tv.isHorizontallyResizable = false
388:         tv.isEditable = false
```

Agent note: `isVerticallyResizable` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L41

```swift
39:         textView.minSize                = NSSize(width: 0, height: 0)
40:         textView.maxSize                = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
41:         textView.isVerticallyResizable  = true
42:         textView.isHorizontallyResizable = false
43:         textView.autoresizingMask       = .width
```

Agent note: `isVerticallyResizable` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `leadingAnchor` (8 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2180

```swift
2178:             box.addSubview(label)
2179:             NSLayoutConstraint.activate([
2180:                 label.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 8),
2181:                 label.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2182:                 label.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -4)
```

Agent note: `leadingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2239

```swift
2237:             [oldNum, newNum, marker, text].forEach { box.addSubview($0) }
2238:             NSLayoutConstraint.activate([
2239:                 oldNum.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 4),
2240:                 oldNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2241:                 oldNum.widthAnchor.constraint(equalToConstant: 36),
```

Agent note: `leadingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2243

```swift
2241:                 oldNum.widthAnchor.constraint(equalToConstant: 36),
2242: 
2243:                 newNum.leadingAnchor.constraint(equalTo: oldNum.trailingAnchor, constant: 4),
2244:                 newNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2245:                 newNum.widthAnchor.constraint(equalToConstant: 36),
```

Agent note: `leadingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2247

```swift
2245:                 newNum.widthAnchor.constraint(equalToConstant: 36),
2246: 
2247:                 marker.leadingAnchor.constraint(equalTo: newNum.trailingAnchor, constant: 6),
2248:                 marker.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2249:                 marker.widthAnchor.constraint(equalToConstant: 12),
```

Agent note: `leadingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2251

```swift
2249:                 marker.widthAnchor.constraint(equalToConstant: 12),
2250: 
2251:                 text.leadingAnchor.constraint(equalTo: marker.trailingAnchor, constant: 4),
2252:                 text.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2253:                 text.trailingAnchor.constraint(equalTo: box.trailingAnchor)
```

Agent note: `leadingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L184

```swift
182:             main.topAnchor.constraint(equalTo: container.topAnchor),
183:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
184:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
185:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
186:         ])
```

Agent note: `leadingAnchor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L152

```swift
150:             main.topAnchor.constraint(equalTo: container.topAnchor),
151:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
152:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
153:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
154:         ])
```

Agent note: `leadingAnchor` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L153

```swift
151:             main.topAnchor.constraint(equalTo: container.topAnchor),
152:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
153:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
154:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
155:         ])
```

Agent note: `leadingAnchor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `lineFragmentPadding` (3 hits)


### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L29

```swift
27: struct MarkdownBlockLeftBorderEntry {
28:     let color:   NSColor
29:     let xOffset: CGFloat  // distance from container lineFragmentPadding
30:     let width:   CGFloat  // typically 4pt
31: }
```

Agent note: `lineFragmentPadding` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L56

```swift
54:             guard !rects.isEmpty else { return }
55:             var bounding = rects.reduce(rects[0]) { $0.union($1) }
56:             let pad = container.lineFragmentPadding
57:             bounding.origin.x    = pad
58:             bounding.size.width  = container.containerSize.width - pad * 2
```

Agent note: `lineFragmentPadding` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L87

```swift
85: 
86:         // 2. Draw blockquote left-border bars.
87:         let pad2 = container.lineFragmentPadding
88:         storage.enumerateAttribute(.markdownBlockLeftBorders, in: charRange, options: []) { val, range, _ in
89:             guard let v = val as? MarkdownBlockLeftBorders, !v.list.isEmpty else { return }
```

Agent note: `lineFragmentPadding` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

## `lineFragmentRect` (4 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L76

```swift
74:         let charIdx = min(lineStartOffsets[row], storage.length - 1)
75:         let glyphIdx = lm.glyphIndexForCharacter(at: charIdx)
76:         var frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
77:         frag.origin.y += textContainerOrigin.y
78:         return frag
```

Agent note: `lineFragmentRect` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L165

```swift
163:             let charIdx = min(starts[row], storage.length - 1)
164:             let glyphIdx = lm.glyphIndexForCharacter(at: charIdx)
165:             let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
166:             let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY
167:             let label = labels[row] as NSString
```

Agent note: `lineFragmentRect` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L527

```swift
525:         let charIdx = min(starts[clampedRow], storageLength - 1)
526:         let glyphIdx = lm.glyphIndexForCharacter(at: charIdx)
527:         let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
528:         let targetY = max(0, frag.midY - leftScroll.contentView.bounds.height / 2)
529:         let origin = NSPoint(x: leftScroll.contentView.bounds.origin.x, y: targetY)
```

Agent note: `lineFragmentRect` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L298

```swift
296:         let charIdx = min(starts[clampedRow], length - 1)
297:         let glyphIdx = lm.glyphIndexForCharacter(at: charIdx)
298:         let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
299:         let targetY = max(0, frag.midY - scroll.contentView.bounds.height / 2)
300:         scroll.contentView.scroll(to: NSPoint(x: scroll.contentView.bounds.origin.x, y: targetY))
```

Agent note: `lineFragmentRect` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `linkTextAttributes` (2 hits)


### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L665

```swift
663:             result.addAttribute(.link, value: url, range: all)
664:         }
665:         // Always set theme link color; makeNSView clears the foreground override in linkTextAttributes.
666:         result.addAttribute(.foregroundColor, value: theme.linkColor, range: all)
667:         return result
```

Agent note: `linkTextAttributes` appears here in a `Markdown attributed renderer/custom layout manager` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L63

```swift
61: 
62:         // Theme-consistent link appearance; foreground color is set by the renderer.
63:         textView.linkTextAttributes = [
64:             .underlineStyle: NSUnderlineStyle.single.rawValue,
65:             .cursor:         NSCursor.pointingHand
```

Agent note: `linkTextAttributes` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `nonisolated` (22 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L277

```swift
275:     }
276: 
277:     // MARK: - Helpers (nonisolated: pure computation, safe to call from detached tasks)
278: 
279:     private nonisolated func shellSplit(_ s: String) -> [String] {
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L279

```swift
277:     // MARK: - Helpers (nonisolated: pure computation, safe to call from detached tasks)
278: 
279:     private nonisolated func shellSplit(_ s: String) -> [String] {
280:         // Handles single- and double-quoted tokens so paths with spaces work correctly.
281:         var tokens: [String] = []
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L304

```swift
302:     }
303: 
304:     private nonisolated func shellQuote(_ s: String) -> String {
305:         "'" + s.replacingOccurrences(of: "'", with: "'\\''") + "'"
306:     }
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L308

```swift
306:     }
307: 
308:     private nonisolated func containsCursorMovement(_ s: String) -> Bool {
309:         // Cursor movement: ESC [ <n> A/B/C/D/H/f or ESC [ 2J etc. Exclude SGR (m).
310:         guard s.contains("\u{1B}[") else { return false }
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L316

```swift
314: 
315:     /// Strips SGR escape sequences and returns (clean text, color if any).
316:     private nonisolated func parseSGR(_ s: String) -> (String, Color?) {
317:         var result = ""
318:         var color: Color?
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/ConsoleView.swift` L344

```swift
342:     }
343: 
344:     private nonisolated func sgrColor(_ params: String) -> Color? {
345:         let codes = params.split(separator: ";").compactMap { Int($0) }
346:         for code in codes {
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1488

```swift
1486:     let discardAction: (FileChange) -> Void
1487: 
1488:     nonisolated static func == (lhs: ChangeRowView, rhs: ChangeRowView) -> Bool {
1489:         lhs.change == rhs.change && lhs.isChangingStage == rhs.isChangingStage
1490:     }
```

Agent note: `nonisolated` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1696

```swift
1694: private final class DiffPreviewModel: ObservableObject {
1695:     // R-0038-04 / R-0039-01: cap for SwiftUI path; AppKit path uses visualMaxLines.
1696:     nonisolated static let maxLines = 2000
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
1698:     nonisolated static let visualMaxLines = 50_000
```

Agent note: `nonisolated` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1698

```swift
1696:     nonisolated static let maxLines = 2000
1697:     // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
1698:     nonisolated static let visualMaxLines = 50_000
1699:     // Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.
1700:     nonisolated static let swiftUIThreshold = 500
```

Agent note: `nonisolated` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1700

```swift
1698:     nonisolated static let visualMaxLines = 50_000
1699:     // Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.
1700:     nonisolated static let swiftUIThreshold = 500
1701: 
1702:     enum VisualItem: Sendable {
```

Agent note: `nonisolated` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1741

```swift
1739:     }
1740: 
1741:     nonisolated private static func buildVisual(_ files: [DiffFile]) -> ([VisualItem], Int) {
1742:         var items: [VisualItem] = []
1743:         var lineCount = 0
```

Agent note: `nonisolated` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L1761

```swift
1759:     }
1760: 
1761:     nonisolated private static func buildSplit(_ files: [DiffFile]) -> ([SplitRow], Int) {
1762:         if files.isEmpty { return ([], 0) }
1763:         var result: [SplitRow] = []
```

Agent note: `nonisolated` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2401

```swift
2399:     }
2400: 
2401:     private nonisolated static func buildNodes(
2402:         at dirURL: URL,
2403:         repoPath: String,
```

Agent note: `nonisolated` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L151

```swift
149:     }
150: 
151:     // MARK: - Frame I/O (nonisolated static — safe to call from any executor)
152: 
153:     private nonisolated static func recvFrameIO<T: Decodable>(_ fd: Int32) -> T? {
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L153

```swift
151:     // MARK: - Frame I/O (nonisolated static — safe to call from any executor)
152: 
153:     private nonisolated static func recvFrameIO<T: Decodable>(_ fd: Int32) -> T? {
154:         var lenBuf = [UInt8](repeating: 0, count: 4)
155:         guard recvAllBytes(fd, &lenBuf, 4) == 4 else { return nil }
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L163

```swift
161:     }
162: 
163:     private nonisolated static func sendFrameIO(_ fd: Int32, _ data: Data) {
164:         var len = UInt32(data.count).bigEndian
165:         withUnsafeBytes(of: &len) { sendAllBytes(fd, $0.baseAddress!, 4) }
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L169

```swift
167:     }
168: 
169:     private nonisolated static func recvAllBytes(_ fd: Int32, _ buf: inout [UInt8], _ n: Int) -> Int {
170:         var received = 0
171:         while received < n {
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/SocketBridge.swift` L179

```swift
177:     }
178: 
179:     private nonisolated static func sendAllBytes(_ fd: Int32, _ buf: UnsafeRawPointer, _ n: Int) {
180:         var sent = 0
181:         while sent < n {
```

Agent note: `nonisolated` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L64

```swift
62:     private var syncing = false
63: 
64:     private nonisolated static let hexByteCap = 4 * 1024 * 1024
65: 
66:     private struct ReloadPayload {
```

Agent note: `nonisolated` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L290

```swift
288:     }
289: 
290:     private nonisolated static func isBinaryFile(_ url: URL) throws -> Bool {
291:         let handle = try FileHandle(forReadingFrom: url)
292:         defer { try? handle.close() }
```

Agent note: `nonisolated` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L296

```swift
294:     }
295: 
296:     private nonisolated static func textPayload(
297:         left: URL, right: URL, ignore: IgnoreOptions, context: Int?
298:     ) throws -> ReloadPayload {
```

Agent note: `nonisolated` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L316

```swift
314:     }
315: 
316:     private nonisolated static func hexPayload(left: URL, right: URL, context: Int?) throws -> ReloadPayload {
317:         func hexDocument(_ url: URL) throws -> (doc: TextDocument, status: String) {
318:             // Read only up to the render cap (+1 to detect truncation) instead
```

Agent note: `nonisolated` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

## `orientation` (13 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L134

```swift
132: 
133:     init(scrollView: NSScrollView, textView: DiffTextView) {
134:         super.init(scrollView: scrollView, orientation: .verticalRuler)
135:         clientView = textView
136:         diffTextView = textView
```

Agent note: `orientation` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L151

```swift
149:             contextPopup, swapButton, patchButton,
150:         ])
151:         controlBar.orientation = .horizontal
152:         controlBar.spacing = 8
153:         controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
```

Agent note: `orientation` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L156

```swift
154: 
155:         let contentRow = NSStackView(views: [leftScroll, rightScroll, overview])
156:         contentRow.orientation = .horizontal
157:         contentRow.spacing = 1
158:         contentRow.distribution = .fill
```

Agent note: `orientation` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L171

```swift
169:         statusSpacer.setContentHuggingPriority(.init(1), for: .horizontal)
170:         let statusBar = NSStackView(views: [leftStatus, statusSpacer, rightStatus])
171:         statusBar.orientation = .horizontal
172:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
173: 
```

Agent note: `orientation` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L175

```swift
173: 
174:         let main = NSStackView(views: [controlBar, contentRow, statusBar])
175:         main.orientation = .vertical
176:         main.spacing = 0
177:         main.translatesAutoresizingMaskIntoConstraints = false
```

Agent note: `orientation` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L125

```swift
123:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
124:         let controlBar = NSStackView(views: [backButton, filterPopup, flattenCheckbox, refreshButton, spinner, spacer, summaryLabel])
125:         controlBar.orientation = .horizontal
126:         controlBar.spacing = 8
127:         controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
```

Agent note: `orientation` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L139

```swift
137:         pathLabel.stringValue = "\(leftRoot.path)   ⇄   \(rightRoot.path)"
138:         let statusBar = NSStackView(views: [pathLabel])
139:         statusBar.orientation = .horizontal
140:         statusBar.edgeInsets = NSEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
141: 
```

Agent note: `orientation` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L143

```swift
141: 
142:         let main = NSStackView(views: [controlBar, scroll, statusBar])
143:         main.orientation = .vertical
144:         main.spacing = 0
145:         main.translatesAutoresizingMaskIntoConstraints = false
```

Agent note: `orientation` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L85

```swift
83:             label.alignment = .center
84:             let stack = NSStackView(views: [label, scroll])
85:             stack.orientation = .vertical
86:             stack.spacing = 2
87:             scroll.setContentHuggingPriority(.init(1), for: .vertical)
```

Agent note: `orientation` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L99

```swift
97: 
98:         let sourcesRow = NSStackView(views: [leftPane, basePane, rightPane])
99:         sourcesRow.orientation = .horizontal
100:         sourcesRow.spacing = 1
101:         sourcesRow.distribution = .fillEqually
```

Agent note: `orientation` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L115

```swift
113:         outputLabel.alignment = .center
114:         let outputPane = NSStackView(views: [outputLabel, outputScroll])
115:         outputPane.orientation = .vertical
116:         outputPane.spacing = 2
117:         outputScroll.setContentHuggingPriority(.init(1), for: .vertical)
```

Agent note: `orientation` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L138

```swift
136:         spacer.setContentHuggingPriority(.init(1), for: .horizontal)
137:         let controlBar = NSStackView(views: [prevButton, nextButton, counterLabel, spinner, spacer, saveButton])
138:         controlBar.orientation = .horizontal
139:         controlBar.spacing = 8
140:         controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
```

Agent note: `orientation` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L144

```swift
142:         split.setContentHuggingPriority(.init(1), for: .vertical)
143:         let main = NSStackView(views: [controlBar, split])
144:         main.orientation = .vertical
145:         main.spacing = 0
146:         main.translatesAutoresizingMaskIntoConstraints = false
```

Agent note: `orientation` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `postsBoundsChangedNotifications` (1 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L201

```swift
199:         super.viewDidLoad()
200:         for scroll in [leftScroll!, rightScroll!] {
201:             scroll.contentView.postsBoundsChangedNotifications = true
202:             NotificationCenter.default.addObserver(
203:                 self, selector: #selector(boundsChanged(_:)),
```

Agent note: `postsBoundsChangedNotifications` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

## `reflectScrolledClipView` (5 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L531

```swift
529:         let origin = NSPoint(x: leftScroll.contentView.bounds.origin.x, y: targetY)
530:         leftScroll.contentView.scroll(to: origin)
531:         leftScroll.reflectScrolledClipView(leftScroll.contentView)
532:     }
533: 
```

Agent note: `reflectScrolledClipView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L540

```swift
538:             let other: NSScrollView = (clipView === leftScroll.contentView) ? rightScroll : leftScroll
539:             other.contentView.scroll(to: clipView.bounds.origin)
540:             other.reflectScrolledClipView(other.contentView)
541:             syncing = false
542:         }
```

Agent note: `reflectScrolledClipView` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L301

```swift
299:         let targetY = max(0, frag.midY - scroll.contentView.bounds.height / 2)
300:         scroll.contentView.scroll(to: NSPoint(x: scroll.contentView.bounds.origin.x, y: targetY))
301:         scroll.reflectScrolledClipView(scroll.contentView)
302:     }
303: 
```

Agent note: `reflectScrolledClipView` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L131

```swift
129:             let clamped = NSPoint(x: origin.x, y: min(origin.y, maxY))
130:             sv.contentView.scroll(to: clamped)
131:             sv.reflectScrolledClipView(sv.contentView)
132:         }
133: 
```

Agent note: `reflectScrolledClipView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L185

```swift
183:             let y = max(rect.minY - 12, 0)
184:             scrollView.contentView.scroll(to: NSPoint(x: 0, y: y))
185:             scrollView.reflectScrolledClipView(scrollView.contentView)
186:         }
187:     }
```

Agent note: `reflectScrolledClipView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `scrollTo` (6 hits)


### `MacGit/Sources/MacGitApp/ConsoleView.swift` L404

```swift
402:                     }
403:                     .onChange(of: store.lines.count) {
404:                         withAnimation(.none) { proxy.scrollTo("bottom", anchor: .bottom) }
405:                     }
406:                 }
```

Agent note: `scrollTo` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L207

```swift
205:             )
206:         }
207:         overview.onJump = { [weak self] row in self?.scrollToRow(row) }
208:         updateFileNavUI()
209:         updateBackButton()
```

Agent note: `scrollTo` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L482

```swift
480:         leftText.highlightedRows = rows
481:         rightText.highlightedRows = rows
482:         scrollToRow(rows.lowerBound)
483:         var text = "Difference \(clamped + 1) of \(count)"
484:         if model.rows[rows.lowerBound].isWhitespaceOnly { text += " · whitespace-only" }
```

Agent note: `scrollTo` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L519

```swift
517:     // MARK: - Scrolling
518: 
519:     private func scrollToRow(_ row: Int) {
520:         let starts = leftText.lineStartOffsets
521:         guard !starts.isEmpty, let lm = leftText.layoutManager else { return }
```

Agent note: `scrollTo` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L91

```swift
89:            let textView = scrollView.documentView as? NSTextView {
90:             context.coordinator.lastOutlineJumpID = outlineJump.id
91:             context.coordinator.scrollToHeading(outlineJump.entry, in: textView)
92:         }
93:         // Skip if the attributed string object hasn't changed (e.g. isDirty re-renders).
```

Agent note: `scrollTo` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L161

```swift
159:         }
160: 
161:         func scrollToHeading(_ entry: MarkdownOutlineEntry, in textView: NSTextView) {
162:             guard let storage = textView.textStorage,
163:                   let layoutManager = textView.layoutManager,
```

Agent note: `scrollTo` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `selectedRange` (4 hits)


### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L20

```swift
18: 
19: func applyMarkdownFormat(_ format: MarkdownFormat, to tv: NSTextView) {
20:     let sel   = tv.selectedRange()
21:     let text  = tv.string as NSString
22:     let inner = text.substring(with: sel)
```

Agent note: `selectedRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L201

```swift
199:                 // reads the stale pre-format savedSelectedRange and wraps again, producing
200:                 // e.g. ****an app**le** (R-0051-04).
201:                 let newRange = tv.selectedRange()
202:                 coordinator.savedSelectedRange = newRange
203:                 if newRange.length > 0 {
```

Agent note: `selectedRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L235

```swift
233:                 guard let self, let tv = textViewRef else { return }
234:                 // Preserve caret line so the view doesn't jump to top on reload.
235:                 let caretPos  = tv.selectedRanges.first?.rangeValue.location ?? 0
236:                 let nsOld     = tv.string as NSString
237:                 let caretLine = nsOld.length > 0
```

Agent note: `selectedRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L366

```swift
364:                 }
365:             }
366:             let range = tv.selectedRange()
367:             if let um = tv.undoManager, um.isUndoing || um.isRedoing { return }
368:             if isApplyingFormat { return }
```

Agent note: `selectedRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `setAttributedString` (7 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L358

```swift
356:         leftText.highlightedRows = nil
357:         rightText.highlightedRows = nil
358:         leftText.textStorage?.setAttributedString(payload.leftPane.attributed)
359:         leftText.lineStartOffsets = payload.leftPane.lineStartOffsets
360:         leftText.rowBackgrounds = payload.leftPane.rowBackgrounds
```

Agent note: `setAttributedString` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L363

```swift
361:         leftRuler.labels = payload.leftPane.labels
362: 
363:         rightText.textStorage?.setAttributedString(payload.rightPane.attributed)
364:         rightText.lineStartOffsets = payload.rightPane.lineStartOffsets
365:         rightText.rowBackgrounds = payload.rightPane.rowBackgrounds
```

Agent note: `setAttributedString` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L7

```swift
5: 
6: /// Pre-rendered content for one editor pane. Built off the main thread;
7: /// only `textStorage.setAttributedString` happens on main. (SPEC §9)
8: struct PaneContent {
9:     var attributed: NSAttributedString
```

Agent note: `setAttributedString` appears here in a `Diff pane attributed-string builder` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L256

```swift
254:         for (textView, pane) in [(leftText!, payload.leftPane), (baseText!, payload.basePane),
255:                                  (rightText!, payload.rightPane), (outputText!, payload.outputPane)] {
256:             textView.textStorage?.setAttributedString(pane.attributed)
257:             textView.lineStartOffsets = pane.lineStartOffsets
258:             textView.rowBackgrounds = pane.rowBackgrounds
```

Agent note: `setAttributedString` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L389

```swift
387:         tv.isHorizontallyResizable = false
388:         tv.isEditable = false
389:         tv.textStorage?.setAttributedString(attr)
390:         if let lm = tv.layoutManager, let tc = tv.textContainer {
391:             lm.ensureLayout(for: tc)
```

Agent note: `setAttributedString` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L71

```swift
69:         context.coordinator.textViewRef = textView
70: 
71:         textStorage.setAttributedString(attributedString)
72:         context.coordinator.lastAttributedString = attributedString
73: 
```

Agent note: `setAttributedString` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L98

```swift
96:         context.coordinator.lastAttributedString    = attributedString
97:         context.coordinator.pendingScrollOrigin     = scrollView.contentView.bounds.origin
98:         textView.textStorage?.setAttributedString(attributedString)
99:         // Scroll position is restored in layoutManager(_:didCompleteLayoutFor:atEnd:)
100:         // after NSLayoutManager finishes laying out the new content.
```

Agent note: `setAttributedString` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `setSelectedRange` (5 hits)


### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L105

```swift
103:         let newLoc = max(lineRange.location, originalSel.location - pLen)
104:         let newLen = max(0, min(originalSel.length, fullLen - pLen - newLoc))
105:         tv.setSelectedRange(NSRange(location: newLoc, length: newLen))
106:     } else {
107:         // Add prefix: cursor shifts right by pLen.
```

Agent note: `setSelectedRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L113

```swift
111:         let newLoc = originalSel.location + pLen
112:         let newLen = min(originalSel.length, max(0, fullLen + pLen - newLoc))
113:         tv.setSelectedRange(NSRange(location: newLoc, length: newLen))
114:     }
115: }
```

Agent note: `setSelectedRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/EditorToolbar.swift` L122

```swift
120:     tv.replaceCharacters(in: range, with: rep)
121:     tv.didChangeText()
122:     tv.setSelectedRange(NSRange(location: range.location + offset, length: len))
123: }
124: 
```

Agent note: `setSelectedRange` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L195

```swift
193:                 let rLen = min(coordinator.savedSelectedRange.length, len - loc)
194:                 coordinator.isApplyingFormat = true
195:                 tv.setSelectedRange(NSRange(location: loc, length: rLen))
196:                 applyMarkdownFormat(format, to: tv)
197:                 coordinator.isApplyingFormat = false
```

Agent note: `setSelectedRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L258

```swift
256:                     return min(pos, nsNew.length)
257:                 }()
258:                 tv.setSelectedRange(NSRange(location: lineStart, length: 0))
259:                 // Background highlight: text is visible first, coloring follows on background
260:                 // thread so large files don't block the main thread (R-0049-01).
```

Agent note: `setSelectedRange` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `textContainerInset` (5 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L106

```swift
104:         textView.allowsUndo = editable
105:         textView.font = Theme.editorFont
106:         textView.textContainerInset = NSSize(width: 4, height: 4)
107:         textView.autoresizingMask = [.width]
108: 
```

Agent note: `textContainerInset` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L33

```swift
31:         textView.isSelectable = true
32:         textView.font = MarkdownSyntaxHighlighter.baseFont(size: appearance.editorFontSize, family: appearance.editorFontFamily)
33:         textView.textContainerInset = NSSize(width: 16, height: 16)
34:         let bg = Self.editorBackground
35:         scrollView.backgroundColor = bg
```

Agent note: `textContainerInset` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L419

```swift
417:             let glyphRange = lm.glyphRange(forCharacterRange: selectionRange, actualCharacterRange: nil)
418:             var rect = lm.boundingRect(forGlyphRange: glyphRange, in: tc)
419:             let inset = tv.textContainerInset
420:             rect.origin.x += inset.width
421:             rect.origin.y += inset.height
```

Agent note: `textContainerInset` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L48

```swift
46:         textView.isRichText            = true
47:         textView.drawsBackground       = false
48:         textView.textContainerInset    = NSSize(width: 32, height: 32)
49: 
50:         // Read-only preview — disable all text-editing assistance.
```

Agent note: `textContainerInset` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L182

```swift
180:             let glyphRange = layoutManager.glyphRange(forCharacterRange: target, actualCharacterRange: nil)
181:             let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)
182:                 .offsetBy(dx: textView.textContainerInset.width, dy: textView.textContainerInset.height)
183:             let y = max(rect.minY - 12, 0)
184:             scrollView.contentView.scroll(to: NSPoint(x: 0, y: y))
```

Agent note: `textContainerInset` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.

## `textContainerOrigin` (2 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L77

```swift
75:         let glyphIdx = lm.glyphIndexForCharacter(at: charIdx)
76:         var frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
77:         frag.origin.y += textContainerOrigin.y
78:         return frag
79:     }
```

Agent note: `textContainerOrigin` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L166

```swift
164:             let glyphIdx = lm.glyphIndexForCharacter(at: charIdx)
165:             let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
166:             let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY
167:             let label = labels[row] as NSString
168:             let size = label.size(withAttributes: attrs)
```

Agent note: `textContainerOrigin` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

## `topAnchor` (3 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L182

```swift
180:         container.addSubview(main)
181:         NSLayoutConstraint.activate([
182:             main.topAnchor.constraint(equalTo: container.topAnchor),
183:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
184:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
```

Agent note: `topAnchor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L150

```swift
148:         container.addSubview(main)
149:         NSLayoutConstraint.activate([
150:             main.topAnchor.constraint(equalTo: container.topAnchor),
151:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
152:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
```

Agent note: `topAnchor` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L151

```swift
149:         container.addSubview(main)
150:         NSLayoutConstraint.activate([
151:             main.topAnchor.constraint(equalTo: container.topAnchor),
152:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
153:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
```

Agent note: `topAnchor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `trailingAnchor` (8 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2182

```swift
2180:                 label.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 8),
2181:                 label.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2182:                 label.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -4)
2183:             ])
2184:             configureSection(box, text: text, isFile: isFile)
```

Agent note: `trailingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2243

```swift
2241:                 oldNum.widthAnchor.constraint(equalToConstant: 36),
2242: 
2243:                 newNum.leadingAnchor.constraint(equalTo: oldNum.trailingAnchor, constant: 4),
2244:                 newNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2245:                 newNum.widthAnchor.constraint(equalToConstant: 36),
```

Agent note: `trailingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2247

```swift
2245:                 newNum.widthAnchor.constraint(equalToConstant: 36),
2246: 
2247:                 marker.leadingAnchor.constraint(equalTo: newNum.trailingAnchor, constant: 6),
2248:                 marker.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2249:                 marker.widthAnchor.constraint(equalToConstant: 12),
```

Agent note: `trailingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2251

```swift
2249:                 marker.widthAnchor.constraint(equalToConstant: 12),
2250: 
2251:                 text.leadingAnchor.constraint(equalTo: marker.trailingAnchor, constant: 4),
2252:                 text.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2253:                 text.trailingAnchor.constraint(equalTo: box.trailingAnchor)
```

Agent note: `trailingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2253

```swift
2251:                 text.leadingAnchor.constraint(equalTo: marker.trailingAnchor, constant: 4),
2252:                 text.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2253:                 text.trailingAnchor.constraint(equalTo: box.trailingAnchor)
2254:             ])
2255:             configureLine(box, line: line)
```

Agent note: `trailingAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L185

```swift
183:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
184:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
185:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
186:         ])
187:         view = container
```

Agent note: `trailingAnchor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L153

```swift
151:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
152:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
153:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
154:         ])
155:         view = container
```

Agent note: `trailingAnchor` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L154

```swift
152:             main.bottomAnchor.constraint(equalTo: container.bottomAnchor),
153:             main.leadingAnchor.constraint(equalTo: container.leadingAnchor),
154:             main.trailingAnchor.constraint(equalTo: container.trailingAnchor),
155:         ])
156:         view = container
```

Agent note: `trailingAnchor` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `translatesAutoresizingMaskIntoConstraints` (7 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2177

```swift
2175:             label.identifier = NSUserInterfaceItemIdentifier("lbl")
2176:             label.isSelectable = true
2177:             label.translatesAutoresizingMaskIntoConstraints = false
2178:             box.addSubview(label)
2179:             NSLayoutConstraint.activate([
```

Agent note: `translatesAutoresizingMaskIntoConstraints` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2220

```swift
2218:                 f.alignment = .right
2219:                 f.isSelectable = false
2220:                 f.translatesAutoresizingMaskIntoConstraints = false
2221:                 return f
2222:             }
```

Agent note: `translatesAutoresizingMaskIntoConstraints` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2229

```swift
2227:             marker.font = monoCaption
2228:             marker.isSelectable = false
2229:             marker.translatesAutoresizingMaskIntoConstraints = false
2230:             let text = NSTextField(labelWithString: "")
2231:             text.identifier = NSUserInterfaceItemIdentifier("text")
```

Agent note: `translatesAutoresizingMaskIntoConstraints` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2235

```swift
2233:             text.isSelectable = true
2234:             text.lineBreakMode = .byClipping
2235:             text.translatesAutoresizingMaskIntoConstraints = false
2236: 
2237:             [oldNum, newNum, marker, text].forEach { box.addSubview($0) }
```

Agent note: `translatesAutoresizingMaskIntoConstraints` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L177

```swift
175:         main.orientation = .vertical
176:         main.spacing = 0
177:         main.translatesAutoresizingMaskIntoConstraints = false
178: 
179:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))
```

Agent note: `translatesAutoresizingMaskIntoConstraints` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L145

```swift
143:         main.orientation = .vertical
144:         main.spacing = 0
145:         main.translatesAutoresizingMaskIntoConstraints = false
146: 
147:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))
```

Agent note: `translatesAutoresizingMaskIntoConstraints` appears here in a `Folder compare outline controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L146

```swift
144:         main.orientation = .vertical
145:         main.spacing = 0
146:         main.translatesAutoresizingMaskIntoConstraints = false
147: 
148:         let container = NSView(frame: NSRect(x: 0, y: 0, width: 1280, height: 800))
```

Agent note: `translatesAutoresizingMaskIntoConstraints` appears here in a `Merge AppKit controller` context. Check surrounding module before changing behavior.

## `typingAttributes` (1 hits)


### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L447

```swift
445:         style.tabStops = []
446:         textView.defaultParagraphStyle = style
447:         textView.typingAttributes[.paragraphStyle] = style
448:     }
449: }
```

Agent note: `typingAttributes` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

## `vibrantDark` (8 hits)


### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L200

```swift
198:             // White in light mode; system window background (dark-gray) in dark mode.
199:             case .adaptive: return Color(nsColor: NSColor(name: nil) { t in
200:                 t.bestMatch(from: [.darkAqua, .vibrantDark]) != nil ? .windowBackgroundColor : .white
201:             })
202:             case .light:    return Color.white
```

Agent note: `vibrantDark` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L233

```swift
231:             case .dark, .ink: return true
232:             case .adaptive:
233:                 return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
234:             default: return false
235:             }
```

Agent note: `vibrantDark` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L124

```swift
122:     static var editorBackground: NSColor {
123:         NSColor(name: nil) { appearance in
124:             if appearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil {
125:                 return NSColor(white: 0.18, alpha: 1.0)
126:             } else {
```

Agent note: `vibrantDark` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L292

```swift
290:             guard fullLen > 0 else { return }
291: 
292:             let isDark   = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
293:             let colors   = AppearanceSettings.shared.syntaxColors(dark: isDark)
294:             let fontSize = parent.appearance.editorFontSize
```

Agent note: `vibrantDark` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L391

```swift
389:             highlightGeneration = gen
390:             // Capture colors now on main thread (appearance-dependent).
391:             let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
392:             let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
393: 
```

Agent note: `vibrantDark` appears here in a `Markdown editor bridge` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L35

```swift
33: 
34:     private static let codeBackground = NSColor(name: nil) { app in
35:         app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
36:             ? NSColor(white: 1.0, alpha: 0.09)
37:             : NSColor(white: 0.0, alpha: 0.06)
```

Agent note: `vibrantDark` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L237

```swift
235: 
236:     static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {
237:         let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
238:         let colors = AppearanceSettings.shared.syntaxColors(dark: isDark)
239:         highlight(storage, fontSize: fontSize, family: family, enabled: enabled, colors: colors)
```

Agent note: `vibrantDark` appears here in a `Markdown syntax highlighter` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/SettingsView.swift` L34

```swift
32:     @EnvironmentObject private var appearance: AppearanceSettings
33:     @State private var colorsDark: Bool = {
34:         NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil
35:     }()
36: 
```

Agent note: `vibrantDark` appears here in a `Support code` context. Check surrounding module before changing behavior.

## `visibleRect` (4 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L149

```swift
147:               !tv.lineStartOffsets.isEmpty else { return }
148: 
149:         let visibleRect = tv.visibleRect
150:         let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)
151:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
```

Agent note: `visibleRect` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L150

```swift
148: 
149:         let visibleRect = tv.visibleRect
150:         let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)
151:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
152:         let starts = tv.lineStartOffsets
```

Agent note: `visibleRect` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L166

```swift
164:             let glyphIdx = lm.glyphIndexForCharacter(at: charIdx)
165:             let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)
166:             let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY
167:             let label = labels[row] as NSString
168:             let size = label.size(withAttributes: attrs)
```

Agent note: `visibleRect` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L551

```swift
549:         guard let lm = leftText.layoutManager, let tc = leftText.textContainer,
550:               !leftText.lineStartOffsets.isEmpty else { return }
551:         let glyphRange = lm.glyphRange(forBoundingRect: leftText.visibleRect, in: tc)
552:         let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
553:         let starts = leftText.lineStartOffsets
```

Agent note: `visibleRect` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

## `wantsLayer` (4 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2173

```swift
2171:             let box = NSView()
2172:             box.identifier = nsId
2173:             box.wantsLayer = true
2174:             let label = NSTextField(labelWithString: "")
2175:             label.identifier = NSUserInterfaceItemIdentifier("lbl")
```

Agent note: `wantsLayer` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2190

```swift
2188:         private func configureSection(_ v: NSView, text: String, isFile: Bool) {
2189:             let alpha: CGFloat = isFile ? 0.12 : 0.06
2190:             v.wantsLayer = true
2191:             v.layer?.backgroundColor = NSColor.secondaryLabelColor.withAlphaComponent(alpha).cgColor
2192:             if let label = v.subviews.first(where: { $0.identifier?.rawValue == "lbl" }) as? NSTextField {
```

Agent note: `wantsLayer` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2209

```swift
2207:             let box = NSView()
2208:             box.identifier = nsId
2209:             box.wantsLayer = true
2210:             let monoCaption2: NSFont = .monospacedSystemFont(ofSize: 9, weight: .regular)
2211:             let monoCaption: NSFont = .monospacedSystemFont(ofSize: 11, weight: .regular)
```

Agent note: `wantsLayer` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2266

```swift
2264:             default:       bg = .clear
2265:             }
2266:             v.wantsLayer = true
2267:             v.layer?.backgroundColor = bg.cgColor
2268: 
```

Agent note: `wantsLayer` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

## `widthAnchor` (5 hits)


### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2241

```swift
2239:                 oldNum.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 4),
2240:                 oldNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2241:                 oldNum.widthAnchor.constraint(equalToConstant: 36),
2242: 
2243:                 newNum.leadingAnchor.constraint(equalTo: oldNum.trailingAnchor, constant: 4),
```

Agent note: `widthAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2245

```swift
2243:                 newNum.leadingAnchor.constraint(equalTo: oldNum.trailingAnchor, constant: 4),
2244:                 newNum.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2245:                 newNum.widthAnchor.constraint(equalToConstant: 36),
2246: 
2247:                 marker.leadingAnchor.constraint(equalTo: newNum.trailingAnchor, constant: 6),
```

Agent note: `widthAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacGit/Sources/MacGitApp/MacGitApp.swift` L2249

```swift
2247:                 marker.leadingAnchor.constraint(equalTo: newNum.trailingAnchor, constant: 6),
2248:                 marker.centerYAnchor.constraint(equalTo: box.centerYAnchor),
2249:                 marker.widthAnchor.constraint(equalToConstant: 12),
2250: 
2251:                 text.leadingAnchor.constraint(equalTo: marker.trailingAnchor, constant: 4),
```

Agent note: `widthAnchor` appears here in a `MacGit NSTableView virtualized diff preview` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L159

```swift
157:         contentRow.spacing = 1
158:         contentRow.distribution = .fill
159:         leftScroll.widthAnchor.constraint(equalTo: rightScroll.widthAnchor).isActive = true
160:         overview.widthAnchor.constraint(equalToConstant: 14).isActive = true
161:         contentRow.setContentHuggingPriority(.init(1), for: .vertical)
```

Agent note: `widthAnchor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L160

```swift
158:         contentRow.distribution = .fill
159:         leftScroll.widthAnchor.constraint(equalTo: rightScroll.widthAnchor).isActive = true
160:         overview.widthAnchor.constraint(equalToConstant: 14).isActive = true
161:         contentRow.setContentHuggingPriority(.init(1), for: .vertical)
162: 
```

Agent note: `widthAnchor` appears here in a `File diff AppKit controller` context. Check surrounding module before changing behavior.

## `widthTracksTextView` (3 hits)


### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L115

```swift
113:                                   height: CGFloat.greatestFiniteMagnitude)
114:         if let container = textView.textContainer {
115:             container.widthTracksTextView = false
116:             container.containerSize = NSSize(width: CGFloat.greatestFiniteMagnitude,
117:                                              height: CGFloat.greatestFiniteMagnitude)
```

Agent note: `widthTracksTextView` appears here in a `Diff NSTextView and ruler` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MackDownApp.swift` L384

```swift
382: 
383:         let tv = NSTextView(frame: NSRect(x: 0, y: 0, width: pageWidth, height: 100))
384:         tv.textContainer?.widthTracksTextView = true
385:         tv.textContainer?.containerSize = NSSize(width: pageWidth, height: .greatestFiniteMagnitude)
386:         tv.isVerticallyResizable   = true
```

Agent note: `widthTracksTextView` appears here in a `Support code` context. Check surrounding module before changing behavior.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L31

```swift
29:         let layoutMgr   = MarkdownLayoutManager()
30:         let container   = NSTextContainer(size: NSSize(width: 0, height: CGFloat.greatestFiniteMagnitude))
31:         container.widthTracksTextView = true
32:         layoutMgr.addTextContainer(container)
33:         textStorage.addLayoutManager(layoutMgr)
```

Agent note: `widthTracksTextView` appears here in a `Markdown preview TextKit stack` context. Check surrounding module before changing behavior.
