# Source Chunk: MacGit/Sources/MacGitApp/ConsoleView.swift

Roles: Support code

Lines: 447; bytes: 16002; imports: AppKit, SwiftUI, MacGitCore

## Declarations
- struct `ConsoleLine` inherits Identifiable, Sendable
- class `ConsoleStore` inherits ObservableObject
- struct `ConsoleDrawer` inherits View
- extension `View` 

## Functions
- `configure(repositoryURL: URL, branchName: String?, socketPath: String? = nil)`
- `updateSocketPath(_ path: String?)`
- `updateBranch(_ name: String?)`
- `rebuildPrompt()`
- `submit()`
- `interrupt()`
- `historyUp()`
- `historyDown()`
- `echo(gitCommand: String)`
- `runCommand(_ command: String)`
- `appendLine(_ text: String, kind: ConsoleLine.Kind = .output, color: Color? = nil)`
- `run(_ command: String, handler: @escaping @Sendable (Event)`
- `interrupt()`
- `shellSplit(_ s: String)`
- `shellQuote(_ s: String)`
- `containsCursorMovement(_ s: String)`
- `parseSGR(_ s: String)`
- `sgrColor(_ params: String)`
- `lineColor(_ line: ConsoleLine)`
- `cursor(_ cursor: NSCursor)`

## Terms
- `nonisolated` × 6
- `Task` × 3
- `MainActor` × 2
- `NSCursor` × 2
- `AppKit` × 1
- `ObservableObject` × 1
- `SwiftUI` × 1
- `scrollTo` × 1

## Design comments
- L5: // MARK: - Console model
- L21: /// Manages the console state: lines buffer, history, running process (SPEC §3.1).
- L71: // Git-scope fence: bare first token → prepend "git ".
- L107: /// Appends a GUI-action echo line (SPEC §3.2 GUI→Console).
- L112: // MARK: - Private
- L142: // MARK: - PTY Runner (SPEC §3.1)
- L144: /// Runs a git command on a pseudo-TTY. Parses SGR color sequences; flags cursor movement.
- L161: // Build the argv: ["git", "subcommand", ...]
- L168: // Open PTY via POSIX (openpty is deprecated in macOS 14).
- L199: // Find macgit-cli next to the running executable (works for both .app bundle and
- L200: // plain-executable dev builds produced by make build).
- L204: // Shell-quote the path so spaces in the bundle location don't split the command.
- L230: // Move blocking Foundation.read off the actor executor so interrupt() can
- L231: // preempt the loop and deliver SIGINT without waiting for a read to return.
- L244: // Check for cursor-movement sequences (non-SGR).
- L250: // Emit lines as they become available.
- L261: // Flush remaining.
- L277: // MARK: - Helpers (nonisolated: pure computation, safe to call from detached tasks)
- L280: // Handles single- and double-quoted tokens so paths with spaces work correctly.
- L309: // Cursor movement: ESC [ <n> A/B/C/D/H/f or ESC [ 2J etc. Exclude SGR (m).
- L315: /// Strips SGR escape sequences and returns (clean text, color if any).
- L322: // Skip to end of escape sequence (terminated by a letter).
- L329: // SGR: parse color.
- L363: // MARK: - Console Drawer View
- L372: // Drag handle.
- L387: // Scrollable output area.
- L408: // Input bar.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L2 `SwiftUI`: `import SwiftUI`
- L22 `MainActor`: `@MainActor`
- L23 `ObservableObject`: `final class ConsoleStore: ObservableObject {`
- L87 `Task`: `Task { await r?.interrupt() }`
- L120 `Task`: `Task {`
- L123 `MainActor`: `await MainActor.run {`
- L232 `Task`: `await Task.detached(priority: .userInitiated) { [self, master] in`
- L277 `nonisolated`: `// MARK: - Helpers (nonisolated: pure computation, safe to call from detached tasks)`
- L279 `nonisolated`: `private nonisolated func shellSplit(_ s: String) -> [String] {`
- L304 `nonisolated`: `private nonisolated func shellQuote(_ s: String) -> String {`
- L308 `nonisolated`: `private nonisolated func containsCursorMovement(_ s: String) -> Bool {`
- L316 `nonisolated`: `private nonisolated func parseSGR(_ s: String) -> (String, Color?) {`
- L344 `nonisolated`: `private nonisolated func sgrColor(_ params: String) -> Color? {`
- L404 `scrollTo`: `withAnimation(.none) { proxy.scrollTo("bottom", anchor: .bottom) }`
- L442 `NSCursor`: `func cursor(_ cursor: NSCursor) -> some View {`
- L444 `NSCursor`: `if inside { cursor.push() } else { NSCursor.pop() }`
