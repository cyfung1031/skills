# Source Chunk: MacGit/Sources/MacGitCore/RepoWatcher.swift

Roles: Core diff/text/git/model logic

Lines: 119; bytes: 4422; imports: Foundation, CoreServices

## Declarations

## Functions
- `events(for repositoryURL: URL)`
- `stop()`
- `startFSEvents(at repositoryURL: URL)`
- `fire()`
- `events(for repositoryURL: URL)`
- `stop()`

## Terms
- `Task` × 10
- `DispatchQueue` × 2

## Design comments
- L6: /// Watches a repository directory for file-system changes using FSEvents (SPEC §6.3).
- L7: /// Fires an `AsyncStream<Void>` event on change, debounced (trailing-edge, 300 ms).
- L8: /// Ignores changes inside `.git/objects` (pack operations) and `.git/refs` writes
- L9: /// that MacGit itself just made (not filtered — cheap refresh is fine).
- L17: /// Returns an `AsyncStream` that fires once per debounce window when the repo changes.
- L39: // MARK: - Private
- L62: // eventPaths is CFArray of CFString when kFSEventStreamCreateFlagUseCFTypes is set.
- L65: // Ignore git-internal write noise that does not reflect worktree changes:
- L66: // .git/objects/ (pack ops), transient lock files, reflog entries (always
- L67: // accompany a .git/HEAD or .git/refs/ write that will also be in the batch).
- L107: // FSEventStream cleanup is handled by stop() — call it before releasing the watcher.
- L108: // deinit cannot access actor-isolated state; release is managed via stop().
- L111: // Non-macOS stub (for compilation on Linux CI if ever needed).

## Important AppKit/TextKit lines
- L13 `Task`: `private var debounceTask: Task<Void, Never>?`
- L27 `Task`: `debounceTask?.cancel()`
- L28 `Task`: `debounceTask = nil`
- L80 `Task`: `Task { await watcher.fire() }`
- L93 `DispatchQueue`: `FSEventStreamSetDispatchQueue(fsStream, DispatchQueue.global(qos: .background))`
- L99 `Task`: `debounceTask?.cancel()`
- L100 `Task`: `debounceTask = Task {`
- L101 `Task`: `try? await Task.sleep(nanoseconds: 300_000_000)`
- L102 `Task`: `guard !Task.isCancelled else { return }`
