# Source Chunk: MacMerge/Sources/MacMergeApp/MacMergeApp.swift

Roles: Window/menu/AppKit shell

Lines: 16; bytes: 447; imports: AppKit

## Declarations
- struct `MacMergeApp` 

## Functions
- `main()`

## Terms
- `AppKit` × 1
- `MainActor` × 1

## Design comments
- L3: // SwiftPM executable entry point — no nib, no storyboard, no Xcode project.
- L4: // `build-app.sh` wraps this executable into MacMerge.app; running the bare
- L5: // binary also works for development.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L7 `MainActor`: `@MainActor`
