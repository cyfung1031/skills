# Source Chunk: MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift

Roles: Diff pane attributed-string builder

Lines: 186; bytes: 7846; imports: AppKit, DiffCore, TextEngine, SyntaxKit

## Declarations
- struct `PaneContent` 
- enum `PaneBuilder` 
- enum `Side` 
- struct `Accumulator` 

## Functions
- `buildPanes(
        model: DiffDisplayModel,
        left: TextDocument, right: TextDocument,
        languageOverride: Language? =)`
- `buildPlain(
        lines: [String], fileExtension: String,
        lineBackgrounds: [Int: NSColor]
    )`
- `background(
        for row: DiffDisplayModel.Row, hasLine: Bool, isRewrite: Bool, side: Side
    )`
- `appendMarkerRow(_ marker: String)`
- `appendRow(
            line: String?, lineNumber: Int?,
            background: NSColor?,
            emphasis: [Range<Int>], emph)`
- `clamp(_ range: Range<Int>, to length: Int)`

## Terms
- `NSColor` × 8
- `NSAttributedString` × 3
- `NSMutableAttributedString` × 2
- `NSRange` × 2
- `AppKit` × 1
- `NSAttributedString.Key` × 1
- `setAttributedString` × 1

## Design comments
- L6: /// Pre-rendered content for one editor pane. Built off the main thread;
- L7: /// only `textStorage.setAttributedString` happens on main. (SPEC §9)
- L17: /// Builds both panes of a 2-way diff together so intra-line refinement
- L18: /// runs once per changed line pair. `languageOverride` forces a language
- L19: /// (e.g. `.plain` for hex rows) instead of detecting from the extension.
- L44: // Replace rows pairing lines that aren't versions of each other
- L45: // (the pairing is positional) render as removed+added code:
- L46: // emphasis on shared confetti would mislead.
- L58: // Whitespace-only rows whisper: faint row tint, soft emphasis on
- L59: // the whitespace delta itself — content edits keep the strong
- L60: // red/green treatment so they stand out inside re-indented blocks.
- L79: /// One-pane builder for merge views: rows map 1:1 to lines.
- L111: // Rewritten pairs and the unpaired tail of an uneven replace
- L112: // are removed/added code, not edits of a surviving line.
- L121: // MARK: - Accumulator
- L140: /// Collapsed-context marker: dimmed text, phantom background, no number.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L7 `setAttributedString`: `/// only `textStorage.setAttributedString` happens on main. (SPEC §9)`
- L9 `NSAttributedString`: `var attributed: NSAttributedString`
- L11 `NSColor`: `var rowBackgrounds: [Int: NSColor]`
- L82 `NSColor`: `lineBackgrounds: [Int: NSColor]`
- L100 `NSColor`: `) -> NSColor? {`
- L125 `NSAttributedString`: `let baseAttributes: [NSAttributedString.Key: Any] = [`
- L125 `NSAttributedString.Key`: `let baseAttributes: [NSAttributedString.Key: Any] = [`
- L127 `NSColor`: `.foregroundColor: NSColor.textColor,`
- L129 `NSMutableAttributedString`: `var text = NSMutableAttributedString()`
- L131 `NSColor`: `var backgrounds: [Int: NSColor] = [:]`
- L145 `NSAttributedString`: `let attr = NSAttributedString(string: marker + "\n", attributes: [`
- L147 `NSColor`: `.foregroundColor: NSColor.tertiaryLabelColor,`
- L155 `NSColor`: `background: NSColor?,`
- L156 `NSColor`: `emphasis: [Range<Int>], emphasisColor: NSColor`
- L163 `NSMutableAttributedString`: `let attr = NSMutableAttributedString(string: (line ?? "") + "\n", attributes: baseAttributes)`
- L179 `NSRange`: `private func clamp(_ range: Range<Int>, to length: Int) -> NSRange? {`
- L183 `NSRange`: `return NSRange(location: lower, length: upper - lower)`
