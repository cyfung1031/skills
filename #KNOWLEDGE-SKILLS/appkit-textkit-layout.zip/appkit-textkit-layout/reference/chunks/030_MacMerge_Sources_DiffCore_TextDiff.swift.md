# Source Chunk: MacMerge/Sources/DiffCore/TextDiff.swift

Roles: Core diff/text/git/model logic

Lines: 560; bytes: 26585; imports: (none)

## Declarations
- enum `TextDiff` 
- struct `PairLine` 

## Functions
- `diff(
        leftLines: [String], rightLines: [String],
        leftContentKeys: [String]? = nil, rightContentKeys: [String])`
- `mergeSameKind(_ hunks: [Hunk])`
- `trimmed(_ s: String)`
- `alignKey(_ content: String)`
- `reanchor(
        _ hunks: [Hunk], alignLeft: [String], alignRight: [String],
        options: DiffOptions, approximate: inout Bo)`
- `resplit(
        _ hunks: [Hunk], leftContent: [String], rightContent: [String],
        rawLeft: [String], rawRight: [String]
 )`
- `pair(
        _ hunks: [Hunk], leftContent: [String], rightContent: [String]
    )`
- `pairRegion(
        left: Range<Int>, right: Range<Int>,
        leftContent: [String], rightContent: [String]
    )`
- `emitGap(_ gl: Range<Int>, _ gr: Range<Int>)`
- `score(against other: PairLine)`
- `markWhitespaceOnlyReplaces(
        _ hunks: [Hunk], rawLeft: [String], rawRight: [String]
    )`
- `slide(
        _ hunks: [Hunk],
        alignLeft: [String], alignRight: [String],
        rawLeft: [String], rawRight: [Strin)`
- `shifted(_ r: Range<Int>, _ d: Int)`
- `boundaryScore(start: Int, raw: [String])`
- `indentWidth(_ line: String)`

## Terms

## Design comments
- L1: /// Text-aware line diff (SPEC §3.2). Improves on raw line equality for the
- L2: /// patterns that dominate real source trees:
- L3: ///
- L4: /// 1. **Alignment on whitespace-trimmed keys** — lint/indent churn pairs up
- L5: ///    as changed lines instead of disjoint delete/insert blocks. Lines that
- L6: ///    are *only* structural delimiters (`}`, `});`, …) additionally carry
- L7: ///    their indent width in the key: trimmed equality would let a closing
- L8: ///    bracket anchor to a same-shaped bracket at a different nesting depth,
- L9: ///    crossing the pairing a human reads from the brackets.
- L10: /// 2. **Local re-anchoring** — the differ's patience skeleton picks anchors
- L11: ///    by uniqueness over the whole region, so a small moved block that is
- L12: ///    unique file-wide can out-anchor a bigger surviving block that occurs
- L13: ///    twice (the duplicate disqualifies it). Small equal runs flanked by
- L14: ///    changes are re-diffed together with their flanks; within that window
- L15: ///    uniqueness is local, and the bigger match wins. Accepted only when
- L16: ///    strictly more non-blank lines end up matched.
- L17: /// 3. **Hunk-boundary sliding** — insert/delete hunks with ambiguous
- L18: ///    placement shift to structurally better boundaries (after blank
- L19: ///    lines; never starting at a closing bracket, which would steal it
- L20: ///    from its block). Compact version of git's indent heuristic.
- L21: /// 4. **Re-splitting** — key-equal runs whose content still differs (e.g.
- L22: ///    indent-only changes) come back as replace hunks so they remain
- L23: ///    visible and navigable, unless the caller's content keys say to
- L24: ///    ignore them.
- L25: /// 5. **Similarity pairing** — inside a changed region the display pairs
- L26: ///    rows positionally, so one inserted blank line shifts every following
- L27: ///    pair off by one. A monotonic max-similarity matching re-segments the
- L28: ///    region: edited lines pair up as replaces, the rest become inserts/
- L29: ///    deletes. Delimiter-only lines pair only on exact depth-qualified key
- L30: ///    equality — an added `{` keeps its added `}` instead of the `}`
- L31: ///    pairing with an unrelated bracket.
- L34: /// - Parameters:
- L35: ///   - leftContentKeys/rightContentKeys: per-line comparison keys after
- L36: ///     the user's ignore options (nil = compare raw content). Lines
- L37: ///     whose content keys match are reported equal.
- L58: // Merge same-kind neighbors only. Differ.normalized would fold a
- L59: // one-sided insert/delete into an adjacent replace, which shifts
- L60: // the replace's row pairing off by one — exactly the misalignment
- L61: // this type exists to prevent.
- L70: // Whitespace-only and content replaces never merge: a real edit
- L71: // inside a re-indented block must stay its own navigation stop.
- L72: // Replaces merge only when both are 1:1 — folding an uneven
- L73: // block into a paired run would shift its row pairing.
- L100: /// Alignment key for one content key. Normally the trimmed content;
- L101: /// delimiter-only lines append their indent width. Such lines carry no
- L102: /// content of their own — their identity is their nesting position, and
- L103: /// indentation is the depth signal available without parsing. Often this
- L104: /// makes the matching delimiter unique in its region, so the patience
- L105: /// skeleton anchors it instead of the rare-line fallback guessing among
- L106: /// look-alikes. Derived from the *content key* (not the raw line) so
- L107: /// ignore-whitespace options neutralize the qualifier along with the
- L108: /// indentation itself.
- L112: // U+0001 cannot occur in `t` (delimiter characters only).
- L116: // MARK: - Local re-anchoring
- L118: /// Equal runs longer than this are trusted as anchors. Spurious anchors
- L119: /// are small moved blocks; the cap also bounds how many windows get a
- L120: /// second diff.
- L122: /// Window (both sides combined) above which re-diffing is skipped.
- L125: /// A patience anchor is unique over the whole region, so a small moved
- L126: /// block that is unique file-wide (a relocated 4-line `setTimeout`) can
- L127: /// out-anchor a bigger surviving block that occurs twice in the file —
- L128: /// the duplicate disqualifies the bigger block from the skeleton, and
- L129: /// the gaps around the small anchor then bury it as delete + insert
- L130: /// walls. Re-diff each small equal run together with its flanking
- L131: /// change hunks: within the window, occurrence counts are local, so the
- L132: /// bigger block anchors and the moved one drops out. Accept only when
- L133: /// strictly more non-blank lines match — a legitimate anchor re-matches
- L134: /// itself and the result is discarded.
- L151: // The flanks are single change hunks (zero internal matches), so
- L152: // the run is the window's whole matched mass. A run bigger than
- L153: // either flank can't be a buried move — skip the re-diff.
- L177: // Rescan from before the splice: the new alignment can expose a
- L178: // further buried anchor. Terminates — every acceptance strictly
- L179: // increases total matched mass.
- L185: // MARK: - Re-splitting key-equal runs
- L187: /// Splits equal hunks at lines whose content keys differ (alignment was
- L188: /// on trimmed keys, so e.g. indent-only changes land here) into 1:1
- L189: /// replace hunks. Each replace run is classified `isWhitespaceOnly`
- L190: /// when its *raw* line pairs all match after trimming — the flag
- L191: /// describes what the user will see, not the comparison keys.
- L227: // MARK: - Similarity pairing inside changed regions
- L229: /// Regions with more cells than this keep positional pairing (the DP
- L230: /// table is left.count × right.count).
- L233: /// Pair score below which two lines are not versions of each other.
- L234: /// Matches `IntraLineDiff.rewriteThreshold`: pairing below it would
- L235: /// still render as removed + added, so it buys nothing.
- L238: /// Re-segments each contiguous changed region by a monotonic maximum-
- L239: /// similarity matching of its two sides. The differ aligns only
- L240: /// key-equal lines, so inside a replace hunk rows pair positionally and
- L241: /// a single inserted blank line shifts every following pair off by one
- L242: /// (`if (!value) {` ends up beside the blank, its real partner
- L243: /// `if (!path) {` one row below, and both render as removed + added).
- L244: ///
- L245: /// Matched runs become replace hunks; gap lines on one side become
- L246: /// insert/delete. A gap with lines on both sides stays one positional
- L247: /// replace — unrelated rewrites keep the compact side-by-side rendering.
- L248: /// Whitespace-only hunks (1:1 by construction) pass through untouched.
- L262: // Maximal run of contiguous changed hunks = one region. Pairs
- L263: // may cross hunk borders (a true partner often sits in the
- L264: // adjacent insert), never an equal or whisper anchor.
- L285: /// nil = region not worth re-segmenting (one-sided, 1:1, too big, or no
- L286: /// pair found) — caller keeps the original hunks.
- L297: // dp[(li+1) stride + (ri+1)]: best total score aligning prefixes.
- L309: // Traceback (prefer pairing on ties for determinism).
- L326: // Edge rescue. Delimiter-only lines refuse cross-depth pairing in
- L327: // the DP, but when a block is re-indented its closing brackets sit
- L328: // at a gap edge directly against their paired block — there the
- L329: // bracket demonstrably follows its block, so extend pairing through
- L330: // trim-equal rows from both edges of every gap. Mid-gap brackets
- L331: // stay unpaired: an added `{` keeps its `}` added.
- L366: // Split runs where trim-equality flips so a re-indented stretch
- L367: // can whisper independently of the edited rows beside it.
- L387: /// Per-line pairing features, computed once per region line.
- L413: /// 1 for key-equal lines, token-bag Dice similarity otherwise.
- L414: /// Blank and delimiter-only lines carry no content identity: they
- L415: /// pair only with their exact key match (for delimiters that
- L416: /// includes nesting depth — an added `{` keeps its `}` added).
- L433: /// Depth-qualified delimiter keys (see `alignKey`) keep a re-indented
- L434: /// `}` out of equal hunks, so resplit never sees it — it surfaces as a
- L435: /// 1:1 replace straight from the differ. Classify those replaces
- L436: /// whitespace-only by the same raw-line rule as resplit, or a
- L437: /// re-indented block fragments into whisper runs with loud `}` rows
- L438: /// between them.
- L453: // MARK: - Hunk sliding
- L455: /// Pure insert/delete hunks bounded by equal regions can often be
- L456: /// shifted up/down without changing diff validity. Pick the
- L457: /// structurally best placement.
- L474: // Shift bounds come from the neighboring equal hunks.
- L497: // Ties slide down, matching git's default placement.
- L531: /// Lower is better. Captures the two rules that matter most in source
- L532: /// code: hunks should start after blank lines, and must not start at a
- L533: /// closing bracket (which visually steals it from the block above).

## Important AppKit/TextKit lines
