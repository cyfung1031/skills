# Source Chunk: MacGit/Sources/MacGitCore/GitRepository.swift

Roles: Core diff/text/git/model logic

Lines: 55; bytes: 1938; imports: Foundation

## Declarations
- struct `RepositoryLocation` inherits Equatable, Sendable
- extension `GitClient` 

## Functions
- `repositoryRoot(containing url: URL)`
- `initializeRepository(at url: URL, initialBranch: String = "main")`
- `writeDefaultGitIgnore(at repositoryURL: URL)`

## Terms

## Design comments

## Important AppKit/TextKit lines
