# Source Chunk: MacGit/Sources/MacGitCore/PorcelainV2StatusParser.swift

Roles: Core diff/text/git/model logic

Lines: 124; bytes: 4901; imports: (none)

## Declarations
- enum `PorcelainV2StatusParser` 

## Functions
- `parse(_ output: String)`
- `parseOrdinary(_ record: String)`
- `parseRename(_ record: String, originalPath: String?)`
- `parseUnmerged(_ record: String)`
- `parseXY(_ field: Substring)`

## Terms

## Design comments
- L98: // Porcelain v2 unmerged record: "u <xy> <sub> <m1> <m2> <m3> <mW> <h1> <h2> <h3> <path>"

## Important AppKit/TextKit lines
