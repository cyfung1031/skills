# Source Chunk: MacMerge/Sources/MacMergeApp/Support/FileWatcher.swift

Roles: Support code

Lines: 60; bytes: 2099; imports: Foundation

## Declarations
- class `FileWatcher` 

## Functions
- `arm()`
- `handleEvent()`

## Terms
- `MainActor` × 3
- `DispatchQueue` × 1

## Design comments
- L3: /// Watches a set of files for on-disk changes and invokes a handler on the
- L4: /// main actor. Used to detect external edits to open comparison/merge inputs
- L5: /// (SPEC §3.6 external-change handling).
- L6: ///
- L7: /// Each watched path gets a DispatchSource file-system-object source on an
- L8: /// open descriptor. On a `.write`/`.extend`/`.delete`/`.rename`, the handler
- L9: /// fires. Editors that replace files (write-to-temp + rename) invalidate the
- L10: /// descriptor; we re-arm by re-opening the path after a short debounce.
- L49: // Debounce bursts (editors emit several events per save) and re-arm
- L50: // afterward so atomic-rename saves keep being watched.

## Important AppKit/TextKit lines
- L11 `MainActor`: `@MainActor`
- L14 `MainActor`: `private let onChange: @MainActor () -> Void`
- L18 `MainActor`: `init(urls: [URL], onChange: @escaping @MainActor () -> Void) {`
- L58 `DispatchQueue`: `DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: work)`
