# Source Chunk: MacGit/Sources/MacGitCore/GitVersion.swift

Roles: Core diff/text/git/model logic

Lines: 46; bytes: 1684; imports: (none)

## Declarations
- struct `GitVersion` inherits Comparable, Equatable, Sendable
- extension `GitClient` 

## Functions
- `parse(_ output: String)`
- `version()`

## Terms

## Design comments
- L38: // Probes the binary directly so it doubles as the version-gate primitive without recursing
- L39: // through ``run(_:in:kind:timeout:)``.

## Important AppKit/TextKit lines
