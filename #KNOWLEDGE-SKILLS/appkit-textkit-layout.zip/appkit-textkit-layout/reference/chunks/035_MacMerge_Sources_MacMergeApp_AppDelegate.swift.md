# Source Chunk: MacMerge/Sources/MacMergeApp/AppDelegate.swift

Roles: Window/menu/AppKit shell

Lines: 50; bytes: 1378; imports: AppKit, SessionKit

## Declarations
- class `AppDelegate` inherits NSObject, NSApplicationDelegate

## Functions
- `applicationDidFinishLaunching(_ notification: Notification)`
- `applicationSupportsSecureRestorableState(_ app: NSApplication)`
- `applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication)`
- `applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool)`
- `application(_ application: NSApplication, open urls: [URL])`
- `newComparison(_ sender: Any?)`
- `threeWayMergeAction(_ sender: Any?)`
- `openSessionAction(_ sender: Any?)`
- `showWelcomeWindow(_ sender: Any?)`

## Terms
- `AppKit` × 1
- `MainActor` × 1

## Design comments
- L28: /// Finder "Open With", Dock drops, and `open -a MacMerge a b`.
- L33: // MARK: - Menu actions (File menu, explicit target via responder chain)

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L4 `MainActor`: `@MainActor`
