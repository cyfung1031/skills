# Source Chunk: MackDown/Sources/MackDownApp/FrontMatterParser.swift

Roles: Support code

Lines: 43; bytes: 1610; imports: Foundation

## Declarations
- struct `FrontMatter` 
- struct `ParsedMarkdownInput` 

## Functions
- `parseFrontMatter(from source: String)`

## Terms

## Design comments

## Important AppKit/TextKit lines
