# Source Chunk: MacGit/Sources/MacGitCore/GitClient.swift

Roles: Core diff/text/git/model logic

Lines: 323; bytes: 12370; imports: Foundation

## Declarations
- extension `GitClient` 
- enum `OpKind` inherits Sendable
- struct `GitResult` inherits Equatable, Sendable
- enum `GitError` inherits Error, Equatable, CustomStringConvertible, Sendable
- class `PipeDrain` inherits @unchecked Sendable
- class `ResumeOnceBox` inherits @unchecked Sendable

## Functions
- `run(
        _ arguments: [String],
        in workingDirectory: URL? = nil,
        kind: OpKind = .read,
        timeout: )`
- `requireSuccess(
        _ arguments: [String],
        in workingDirectory: URL? = nil,
        kind: OpKind = .read,
        timeout: )`
- `validateInstallation()`
- `execute(
        _ arguments: [String],
        in workingDirectory: URL?,
        timeout: TimeInterval
    )`
- `ensureSupportedGit()`
- `acquireMutationLock()`
- `releaseMutationLock()`
- `read()`
- `markTimedOut()`
- `resume()`

## Terms
- `Task` × 5
- `DispatchQueue` × 1

## Design comments
- L9: /// Incremented on every mutation; callers can snapshot before and compare after
- L10: /// to detect whether a concurrent mutation has occurred and discard stale results.
- L12: /// Cache of empty-untracked-directory scan results: repoPath → (dirs, systemUptime at cache time).
- L57: /// Resolves and validates the git installation (≥ ``minimumGitVersion``), returning the
- L58: /// discovered version. Cached after the first success; throws a friendly install-guidance
- L59: /// error when git is missing or too old (SPEC §6.2 / A1).
- L66: // MARK: - Internal execution
- L68: /// Spawns git once, draining both pipes concurrently. Bypasses the version gate and the
- L69: /// mutation queue — callers go through ``run(_:in:kind:timeout:)``.
- L77: // Stateless w.r.t. CWD: explicit `-C <path>` on every call (SPEC §6.2), never the
- L78: // per-process working directory.
- L94: // Drain both pipes concurrently. Caps: stdout 32 MB, stderr 256 KB.
- L109: // Grace period: if still running after 3 s, SIGKILL.
- L114: // Non-blocking wait via termination handler so the actor executor is not blocked.
- L115: // Use a lock-protected flag to prevent double-resume if the process already exited.
- L193: /// Reads run concurrently (status, log, diff…).
- L195: /// Mutations are serialized so two GUI actions can never interleave (SPEC §6.2).
- L202: /// Raw stdout bytes — preserves binary fidelity for image diffs, `cat-file`, and
- L203: /// NUL-delimited output (SPEC §6.2 `GitOutput.stdout: Data`).
- L207: /// UTF-8 decoded stdout for text commands.
- L226: /// Switching would overwrite local changes that can't be carried forward cleanly.
- L228: /// Target branch is already checked out in another worktree.
- L230: /// Attempted a branch-level op while a merge/rebase/cherry-pick is in progress.
- L232: /// Git command output exceeded the hard byte cap and was truncated.
- L265: /// Concurrent pipe reader with a hard byte cap. `@unchecked Sendable` because the wrapped
- L266: /// `FileHandle` is confined to a single drain queue and results are read only after the
- L267: /// `DispatchGroup` completes.
- L290: // Drain remaining bytes to prevent pipe-buffer deadlock.
- L306: /// Thread-safe wrapper that resumes a `CheckedContinuation` at most once.

## Important AppKit/TextKit lines
- L98 `DispatchQueue`: `let drainQueue = DispatchQueue(label: "local.macgit.git.pipe-drain", attributes: .concurrent)`
- L104 `Task`: `let timeoutTask = Task {`
- L105 `Task`: `try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))`
- L110 `Task`: `try? await Task.sleep(nanoseconds: 3_000_000_000)`
- L121 `Task`: `timeoutTask.cancel()`
