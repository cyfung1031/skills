# Source Chunk: MacMerge/Sources/macmerge-cli/main.swift

Roles: Core diff/text/git/model logic

Lines: 93; bytes: 2856; imports: Foundation, DiffCore, TextEngine, PatchKit

## Declarations

## Functions
- `fail(_ message: String)`

## Terms

## Design comments
- L6: // macmerge — headless CLI (SPEC §3.10).
- L7: // v0.1 prints a unified diff; GUI hand-off (`--wait`, opening the app)
- L8: // arrives with the app-bundle install flow.
- L9: //
- L10: // Exit codes follow diff(1): 0 = identical, 1 = different, 2 = error.

## Important AppKit/TextKit lines
