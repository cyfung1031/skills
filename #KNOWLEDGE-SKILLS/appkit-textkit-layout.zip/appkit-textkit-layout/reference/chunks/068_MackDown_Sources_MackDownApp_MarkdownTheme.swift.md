# Source Chunk: MackDown/Sources/MackDownApp/MarkdownTheme.swift

Roles: Support code

Lines: 135; bytes: 6851; imports: AppKit

## Declarations
- struct `MarkdownTheme` 
- extension `MarkdownTheme` 

## Functions
- `headingFont(level: Int)`
- `githubLight(bodySize: CGFloat, codeSize: CGFloat, fontFamily: String, lineSpacing: CGFloat)`
- `githubDark(bodySize: CGFloat, codeSize: CGFloat, fontFamily: String, lineSpacing: CGFloat)`
- `current(appearance: AppearanceSettings)`
- `c(_ hex: String)`
- `makeBodyFont(size: CGFloat, family: String)`

## Terms
- `NSColor` × 42
- `NSFont` × 11
- `AppKit` × 1

## Design comments
- L3: // MARK: - Theme
- L6: // Colors
- L24: // Fonts
- L28: // Spacing
- L43: // MARK: - GitHub presets
- L109: // Paper-adaptive code block and inline-code backgrounds.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L7 `NSColor`: `var textColor:             NSColor`
- L8 `NSColor`: `var secondaryTextColor:    NSColor`
- L9 `NSColor`: `var linkColor:             NSColor`
- L10 `NSColor`: `var codeTextColor:         NSColor`
- L11 `NSColor`: `var inlineCodeBackground:  NSColor`
- L12 `NSColor`: `var codeBlockBackground:   NSColor`
- L13 `NSColor`: `var codeBlockBorderColor:  NSColor`
- L14 `NSColor`: `var quoteBorderColor:      NSColor`
- L15 `NSColor`: `var quoteTextColor:        NSColor`
- L16 `NSColor`: `var tableHeaderBackground: NSColor`
- L17 `NSColor`: `var tableBorderColor:      NSColor`
- L18 `NSColor`: `var tableAltRowBackground: NSColor`
- L19 `NSColor`: `var hrColor:               NSColor`
- L20 `NSColor`: `var frontMatterBackground: NSColor`
- L21 `NSColor`: `var frontMatterTextColor:  NSColor`
- L22 `NSColor`: `var frontMatterKeyColor:   NSColor`
- L25 `NSFont`: `var bodyFont: NSFont`
- L26 `NSFont`: `var codeFont: NSFont`
- L34 `NSFont`: `func headingFont(level: Int) -> NSFont {`
- L38 `NSFont`: `return NSFont(descriptor: bodyFont.fontDescriptor.withSymbolicTraits(.bold), size: sz)`
- L39 `NSFont`: `?? NSFont.boldSystemFont(ofSize: sz)`
- L52 `NSColor`: `inlineCodeBackground:  c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),`
- L53 `NSColor`: `codeBlockBackground:   c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),`
- L54 `NSColor`: `codeBlockBorderColor:  c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),`
- L55 `NSColor`: `quoteBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),`
- L57 `NSColor`: `tableHeaderBackground: c("#eaeef2") ?? NSColor(white: 0.92, alpha: 1),`
- L58 `NSColor`: `tableBorderColor:      c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),`
- L59 `NSColor`: `tableAltRowBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),`
- L60 `NSColor`: `hrColor:               c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),`
- L61 `NSColor`: `frontMatterBackground: c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),`
- L65 `NSFont`: `codeFont:              NSFont.monospacedSystemFont(ofSize: codeSize, weight: .regular),`
- L79 `NSColor`: `inlineCodeBackground:  c("#161b22") ?? NSColor(white: 0.10, alpha: 1),`
- L80 `NSColor`: `codeBlockBackground:   c("#161b22") ?? NSColor(white: 0.10, alpha: 1),`
- L81 `NSColor`: `codeBlockBorderColor:  c("#30363d") ?? NSColor(white: 0.25, alpha: 1),`
- L82 `NSColor`: `quoteBorderColor:      c("#3d444d") ?? NSColor(white: 0.25, alpha: 1),`
- L84 `NSColor`: `tableHeaderBackground: c("#21262d") ?? NSColor(white: 0.14, alpha: 1),`
- L85 `NSColor`: `tableBorderColor:      c("#30363d") ?? NSColor(white: 0.25, alpha: 1),`
- L86 `NSColor`: `tableAltRowBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),`
- L87 `NSColor`: `hrColor:               c("#30363d") ?? NSColor(white: 0.25, alpha: 1),`
- L88 `NSColor`: `frontMatterBackground: c("#161b22") ?? NSColor(white: 0.10, alpha: 1),`
- L92 `NSFont`: `codeFont:              NSFont.monospacedSystemFont(ofSize: codeSize, weight: .regular),`
- L112 `NSColor`: `let bg = NSColor(red: 0.91, green: 0.88, blue: 0.80, alpha: 1)`
- L113 `NSColor`: `let br = NSColor(red: 0.75, green: 0.72, blue: 0.64, alpha: 1)`
- L116 `NSColor`: `let bg = NSColor(red: 0.14, green: 0.14, blue: 0.17, alpha: 1)`
- L117 `NSColor`: `let br = NSColor(red: 0.22, green: 0.22, blue: 0.26, alpha: 1)`
- L120 `NSColor`: `let bg = NSColor(red: 0.09, green: 0.09, blue: 0.11, alpha: 1)`
- L121 `NSColor`: `let br = NSColor(red: 0.15, green: 0.15, blue: 0.18, alpha: 1)`
- L129 `NSColor`: `private static func c(_ hex: String) -> NSColor? { NSColor(hex: hex) }`
- L131 `NSFont`: `private static func makeBodyFont(size: CGFloat, family: String) -> NSFont {`
- L132 `NSFont`: `guard !family.isEmpty else { return NSFont.systemFont(ofSize: size) }`
- L133 `NSFont`: `return NSFont(name: family, size: size) ?? NSFont.systemFont(ofSize: size)`
