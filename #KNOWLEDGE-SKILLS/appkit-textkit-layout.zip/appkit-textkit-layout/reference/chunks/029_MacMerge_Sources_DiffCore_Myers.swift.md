# Source Chunk: MacMerge/Sources/DiffCore/Myers.swift

Roles: Core diff/text/git/model logic

Lines: 73; bytes: 2436; imports: (none)

## Declarations
- enum `Myers` 

## Functions

## Terms

## Design comments
- L1: /// Classic Myers O(ND) greedy diff with full trace backtracking.
- L2: /// Used for small regions (histogram fallback) and when explicitly selected.
- L3: /// Memory is O(D²), so callers cap `maxD`; exceeding the cap returns nil.
- L7: /// Returns covering hunks in absolute (slice) indices, or nil if `maxD` was exceeded.
- L47: // Backtrack, collecting matched pairs (absolute indices).

## Important AppKit/TextKit lines
