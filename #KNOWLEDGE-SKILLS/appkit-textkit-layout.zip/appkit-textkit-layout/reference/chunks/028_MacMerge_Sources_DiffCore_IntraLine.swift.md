# Source Chunk: MacMerge/Sources/DiffCore/IntraLine.swift

Roles: Core diff/text/git/model logic

Lines: 134; bytes: 5472; imports: (none)

## Declarations
- struct `IntraLineDiff` inherits Sendable, Equatable
- enum `IntraLine` 

## Functions
- `refine(left: String, right: String)`
- `appendCoalescing(_ range: Range<Int>, to ranges: inout [Range<Int>])`
- `tokenize(_ s: String)`
- `flushWord(endIdx: String.Index, endU16: Int)`

## Terms
- `NSRange` × 1

## Design comments
- L1: /// Word-level refinement of a changed line pair. Returns changed character
- L2: /// ranges as UTF-16 offsets (directly convertible to NSRange by UI layers).
- L7: /// How much non-whitespace text the pair shares, length-weighted, 0…1.
- L8: /// Low values mean the two lines are not versions of each other — the
- L9: /// pairing is positional, and emphasis ranges would be confetti.
- L12: /// Below this the pair reads as removed+added code, not an edited line.
- L13: /// Calibrated on the scriptcat 1.3.2→1.4.0 corpus: genuine edits
- L14: /// (renames, argument changes) score ≥ 0.5; positionally-paired
- L15: /// unrelated lines cluster under 0.25.
- L18: /// True when the pair should render as a rewrite (delete + insert),
- L19: /// suppressing intra-line emphasis.
- L32: /// Lines longer than this (UTF-16 units) are not refined — whole line marked changed.
- L42: // Refinement skipped: similarity stays 1 so the pair keeps the
- L43: // edited treatment rather than being misreported as a rewrite.
- L55: // Whitespace tokens carry no identity (deep indents would make any
- L56: // two lines look related), so similarity weighs only visible text.
- L94: // MARK: - Tokenization
- L101: /// Words (alphanumerics + underscore) as single tokens; everything else char-by-char.

## Important AppKit/TextKit lines
- L2 `NSRange`: `/// ranges as UTF-16 offsets (directly convertible to NSRange by UI layers).`
