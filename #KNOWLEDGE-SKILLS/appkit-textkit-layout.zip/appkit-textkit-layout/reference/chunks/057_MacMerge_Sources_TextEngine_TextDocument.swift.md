# Source Chunk: MacMerge/Sources/TextEngine/TextDocument.swift

Roles: Core diff/text/git/model logic

Lines: 171; bytes: 6128; imports: Foundation

## Declarations
- enum `LineEnding` inherits String, Sendable
- enum `TextLoadError` inherits Error, LocalizedError
- struct `TextDocument` inherits Sendable
- extension `LineEnding` 

## Functions
- `load(from url: URL)`
- `make(
        content: String, url: URL? = nil,
        encoding: String.Encoding = .utf8, confidence: Double = 1.0
    )`
- `analyze(_ content: String)`

## Terms

## Design comments
- L3: /// TextEngine — file loading, encoding/EOL detection, line model. (SPEC §11.2)
- L4: ///
- L5: /// v0.1 loads via `Data(mappedIfSafe:)` and materializes decoded lines.
- L6: /// The piece-table / chunked-line-index design from SPEC §10 lands when
- L7: /// editing and >100 MB virtualization are implemented.
- L42: /// Logical lines without terminators.
- L57: /// Hard ceiling for full in-memory text load. Above this, `load` throws
- L58: /// `.fileTooLarge` rather than risk exhausting memory. Chunked streaming
- L59: /// for larger files is tracked in SPEC §10.
- L109: // MARK: - Line / EOL analysis

## Important AppKit/TextKit lines
