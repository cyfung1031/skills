# Source Chunk: MacGit/Sources/MacGitCore/DiffStatParser.swift

Roles: Core diff/text/git/model logic

Lines: 60; bytes: 2206; imports: Foundation

## Declarations
- enum `DiffStatParser` 

## Functions
- `parse(_ output: String)`
- `count(_ field: Substring)`

## Terms

## Design comments
- L3: /// Pure `String -> [DiffStat]` parser for `git diff --numstat -z` (SPEC §6.2).
- L4: ///
- L5: /// Record shape (R-0005-02): `added<TAB>deleted<TAB>` then either `path` (normal) or an empty slot
- L6: /// followed by two NUL tokens `oldpath` `newpath` (rename/copy). Binary files report `-` for both
- L7: /// counts. Splitting the whole stream on NUL yields, per normal file, one token
- L8: /// `added\tdeleted\tpath`; per rename, the token `added\tdeleted\t` plus two path tokens.
- L36: // Rename/copy: next two tokens are original then new path.
- L56: /// `-` marks a binary file (no line counts).

## Important AppKit/TextKit lines
