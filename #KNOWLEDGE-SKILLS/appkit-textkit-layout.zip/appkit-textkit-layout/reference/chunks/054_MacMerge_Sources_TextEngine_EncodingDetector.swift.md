# Source Chunk: MacMerge/Sources/TextEngine/EncodingDetector.swift

Roles: Core diff/text/git/model logic

Lines: 57; bytes: 2081; imports: Foundation

## Declarations
- enum `EncodingDetector` 
- enum `BinarySniffer` 

## Functions
- `detect(_ data: Data)`
- `detectBOM(_ data: Data)`
- `isBinary(_ data: Data)`

## Terms
- `NSString` × 1

## Design comments
- L3: /// Encoding detection per SPEC §3.2: BOM → UTF-8 validation → legacy
- L4: /// candidates → Latin-1 last resort. Statistical charset sniffing (full
- L5: /// ICU-style) is a later-release refinement; candidate order is fixed here.
- L52: /// Binary detection: NUL byte in the first 64 KB. (SPEC §3.2)

## Important AppKit/TextKit lines
- L20 `NSString`: `rawValue: CFStringConvertEncodingToNSStringEncoding(`
