# Source Chunk: MacGit/Sources/MacGitCore/GitStatus.swift

Roles: Core diff/text/git/model logic

Lines: 205; bytes: 6747; imports: Foundation

## Declarations
- enum `RepositoryHeadState` inherits Equatable, Sendable
- enum `InProgressOperation` inherits Equatable, Sendable
- struct `RepositoryStatus` inherits Equatable, Sendable
- extension `RepositoryStatus` 
- struct `BranchStatus` inherits Equatable, Sendable
- struct `FileChange` inherits Equatable, Sendable
- extension `FileChange` 
- enum `GitFileStatus` inherits Character, Equatable, Sendable
- extension `GitClient` 

## Functions
- `status(in repositoryURL: URL)`
- `cachedEmptyUntrackedDirectories(in repositoryURL: URL)`
- `emptyUntrackedDirectoriesScan(in repositoryURL: URL)`
- `scan(_ url: URL, depth: Int)`

## Terms

## Design comments
- L3: /// Explicit model of the HEAD state derived from porcelain v2 branch fields.
- L5: /// Freshly initialized repo with no commits; `branchName` is the configured initial branch.
- L7: /// Normal branch with at least one commit.
- L9: /// Detached HEAD (no branch name).
- L51: /// The specific git operation currently in progress (merge/cherry-pick/rebase/revert).
- L157: // Returns cached empty-dir results if within the 10s TTL; otherwise re-scans with a 50ms budget.
- L169: // Scans the working tree (up to 5 levels deep) for directories that are completely
- L170: // empty (no files, no non-empty subdirectories). Git ignores such directories entirely,
- L171: // so they would otherwise be invisible in the changes list. Stops early if the 50ms
- L172: // budget is exceeded, returning whatever was found so far.

## Important AppKit/TextKit lines
