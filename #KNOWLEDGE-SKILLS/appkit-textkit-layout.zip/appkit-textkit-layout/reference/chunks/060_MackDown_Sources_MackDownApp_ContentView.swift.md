# Source Chunk: MackDown/Sources/MackDownApp/ContentView.swift

Roles: Support code

Lines: 396; bytes: 13531; imports: SwiftUI, UniformTypeIdentifiers

## Declarations
- struct `ContentView` inherits View
- struct `WelcomeRecentRow` inherits View
- struct `NavigationDocumentModifier` inherits ViewModifier
- struct `GearSettingsButton` inherits View
- struct `GearSettingsButtonMacOS14` inherits View
- extension `View` 

## Functions
- `loadRecentURLs()`
- `outlineFontSize(for level: Int)`
- `isMarkdownURL(_ url: URL)`
- `body(content: Content)`
- `hideScrollBackground()`

## Terms
- `DispatchQueue` × 1
- `SwiftUI` × 1

## Design comments
- L42: // MARK: - Main content
- L63: // MARK: - Welcome view (no file open)
- L138: // MARK: - Editor pane
- L219: // Re-render when appearance properties that affect the theme change.
- L226: // MARK: - Toolbar
- L248: // MARK: - Sub-views
- L306: // MARK: - Helpers
- L322: // MARK: - Recent file row for welcome screen
- L346: // MARK: - navigationDocument shim (macOS 13+ proxy icon popup)
- L359: // MARK: - Gear / Settings button (uses openSettings env action on macOS 14+)
- L385: // MARK: - macOS 12-compatible List background shim

## Important AppKit/TextKit lines
- L1 `SwiftUI`: `import SwiftUI`
- L36 `DispatchQueue`: `DispatchQueue.main.async { appState.load(url: url) }`
