# Source Chunk: MacMerge/Sources/MergeKit/MergeBuilder.swift

Roles: Core diff/text/git/model logic

Lines: 46; bytes: 1803; imports: DiffCore

## Declarations
- enum `MergeBuilder` 
- struct `Output` inherits Sendable

## Functions
- `autoMerge(
        base: [String], left: [String], right: [String],
        segments: [Merge3Segment],
        leftLabel: String =)`

## Terms

## Design comments
- L3: /// Builds the auto-merged output for a 3-way merge (SPEC §3.3): non-conflict
- L4: /// segments are pre-applied; true conflicts are emitted with diff3-style
- L5: /// markers for manual resolution in the output pane.
- L11: /// Ranges in `lines` spanning each conflict block, markers included.

## Important AppKit/TextKit lines
