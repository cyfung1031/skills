# Source Chunk: MacGit/Sources/MacGitCore/RenameGrouper.swift

Roles: Core diff/text/git/model logic

Lines: 123; bytes: 5616; imports: Foundation

## Declarations
- enum `RenameGrouper` 

## Functions
- `group(_ changes: [FileChange])`
- `parentDir(_ path: String)`
- `basename(_ path: String)`

## Terms

## Design comments
- L3: /// Detects OS-level renames (not staged via `git mv`) by pairing worktree-deleted
- L4: /// tracked entries with untracked entries. Two strategies:
- L5: ///
- L6: /// 1. **Directory rename**: If all deleted entries inside an old directory correspond
- L7: ///    (same basenames) to untracked entries in a different directory, with ≥2 matching
- L8: ///    files, emit one synthetic directory-rename entry and suppress the individual pairs.
- L9: ///
- L10: /// 2. **File rename**: For any remaining deleted/untracked pair sharing an identical
- L11: ///    basename with exactly one match on each side, emit a synthetic file-rename entry.
- L12: ///
- L13: /// Staged rename entries (produced by `git mv`) already arrive as a single `FileChange`
- L14: /// with `stagedStatus == .renamed` from `PorcelainV2StatusParser` and are untouched.
- L17: // Only worktree-deleted tracked files are candidates for OS-level rename source.
- L21: // Only plain untracked files (not directory entries with trailing /).
- L29: // Preserve all other changes; pairs will be added back below.
- L38: // MARK: Step 1 — Directory rename detection
- L45: // Compare every (oldDir, newDir) pair for matching basename sets.
- L46: // Process larger groups first so a bigger rename wins over subsets.
- L59: // All basenames must match exactly, with at least 2 files.
- L64: // Emit one directory-rename entry (trailing / on both sides).
- L77: // MARK: Step 2 — File rename detection (1:1 basename match)
- L82: // Build basename → [untracked] lookup.
- L106: // Add back unmatched entries unchanged.
- L113: // MARK: - Helpers

## Important AppKit/TextKit lines
