# Source Chunk: MackDown/Sources/mackdown-cli/main.swift

Roles: Core diff/text/git/model logic

Lines: 39; bytes: 1006; imports: Foundation

## Declarations

## Functions

## Terms

## Design comments
- L19: // Resolve and validate each path
- L33: // Open all files in MackDown.app via /usr/bin/open

## Important AppKit/TextKit lines
