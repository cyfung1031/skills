# Source Chunk: MacGit/Sources/MacGitCore/GitWorkingTree.swift

Roles: Core diff/text/git/model logic

Lines: 70; bytes: 2679; imports: Foundation

## Declarations
- struct `BackupRef` inherits Equatable, Sendable
- extension `GitClient` 

## Functions
- `createBackupRef(in repositoryURL: URL, date: Date = Date()`
- `discard(path: String, in repositoryURL: URL)`
- `appendToGitIgnore(pattern: String, in repositoryURL: URL)`
- `isTracked(path: String, in repositoryURL: URL)`
- `backupRefTimestamp(for date: Date)`

## Terms

## Design comments

## Important AppKit/TextKit lines
