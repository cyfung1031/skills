# Source Chunk: MacMerge/Sources/SyntaxKit/SyntaxKit.swift

Roles: Core diff/text/git/model logic

Lines: 290; bytes: 13230; imports: Foundation

## Declarations
- enum `Language` inherits String, CaseIterable, Sendable
- enum `TokenKind` inherits Sendable, Equatable
- struct `Token` inherits Sendable, Equatable
- enum `LanguageDetector` 
- struct `LanguageProfile` 
- enum `Profiles` 
- enum `LineTokenizer` 

## Functions
- `language(forFileExtension ext: String)`
- `profile(for language: Language)`
- `tokenize(_ line: String, language: Language)`
- `u16len(_ c: Character)`
- `matches(_ chars: [Character], at i: Int, prefix: String)`

## Terms
- `NSRange` × 1

## Design comments
- L3: /// SyntaxKit — v0.1 placeholder implementation (SPEC §11.5).
- L4: ///
- L5: /// This is a per-line keyword/string/comment/number tokenizer, deliberately
- L6: /// stateless across lines (no block comments, no multi-line strings). The
- L7: /// module boundary is the contract: it will be replaced by tree-sitter
- L8: /// incremental parsing without touching callers.
- L21: /// UTF-16 offsets within the line (convertible directly to NSRange).
- L212: // Line comment → rest of line.
- L220: // String literal (single line; unterminated runs to end of line).
- L241: // Number.
- L259: // Identifier / keyword.

## Important AppKit/TextKit lines
- L21 `NSRange`: `/// UTF-16 offsets within the line (convertible directly to NSRange).`
