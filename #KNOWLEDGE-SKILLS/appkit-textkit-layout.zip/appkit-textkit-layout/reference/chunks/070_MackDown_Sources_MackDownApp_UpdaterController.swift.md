# Source Chunk: MackDown/Sources/MackDownApp/UpdaterController.swift

Roles: Support code

Lines: 15; bytes: 467; imports: Sparkle

## Declarations
- class `UpdaterController` 

## Functions
- `checkForUpdates()`

## Terms

## Design comments
- L1: // Sparkle auto-updater controller — compiled only when Sparkle is vendored.
- L2: // Enable: WITH_SPARKLE=1 ./scripts/vendor.sh && make build

## Important AppKit/TextKit lines
