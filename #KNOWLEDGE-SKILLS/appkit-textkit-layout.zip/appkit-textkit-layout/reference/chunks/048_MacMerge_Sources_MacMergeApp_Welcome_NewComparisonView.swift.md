# Source Chunk: MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift

Roles: Support code

Lines: 204; bytes: 7326; imports: SwiftUI, UniformTypeIdentifiers

## Declarations
- class `NewComparisonModel` inherits ObservableObject
- struct `NewComparisonView` inherits View
- struct `PathWell` inherits View

## Functions
- `fillNextPath(_ path: String)`
- `expanded(_ path: String)`
- `loadURL(from provider: NSItemProvider)`
- `start()`
- `validated(_ path: String, _ label: String)`
- `browse()`

## Terms
- `MainActor` × 5
- `Task` × 2
- `NSOpenPanel` × 1
- `NSString` × 1
- `ObservableObject` × 1
- `SwiftUI` × 1

## Design comments
- L4: /// Shared state for the "New Comparison" chooser.
- L5: /// WindowManager holds a reference so drops on any screen fill slots sequentially (L→R→Base).
- L20: /// Fills the next empty slot: left → right → base (auto-enables threeWay on base fill).
- L33: /// "New Comparison" window (SPEC §5.1 chooser): independent Left/Right
- L34: /// path wells — each accepts drag & drop, Browse…, or a typed path — plus
- L35: /// an optional Base well for three-way merges. The comparison mode
- L36: /// (file/folder) is inferred from what was chosen, WinMerge-style.
- L155: /// One side's path input: editable text field + Browse… + drop target.

## Important AppKit/TextKit lines
- L1 `SwiftUI`: `import SwiftUI`
- L6 `MainActor`: `@MainActor`
- L7 `ObservableObject`: `final class NewComparisonModel: ObservableObject {`
- L37 `MainActor`: `@MainActor`
- L77 `MainActor`: `Task { @MainActor in`
- L77 `Task`: `Task { @MainActor in`
- L101 `NSString`: `(path.trimmingCharacters(in: .whitespacesAndNewlines) as NSString).expandingTildeInPath`
- L156 `MainActor`: `@MainActor`
- L186 `MainActor`: `Task { @MainActor in`
- L186 `Task`: `Task { @MainActor in`
- L195 `NSOpenPanel`: `let panel = NSOpenPanel()`
