# Source Chunk: MacMerge/Sources/PatchKit/UnifiedDiff.swift

Roles: Core diff/text/git/model logic

Lines: 95; bytes: 3722; imports: DiffCore

## Declarations
- enum `UnifiedDiff` 

## Functions
- `generate(
        leftLines: [String], rightLines: [String],
        leftLabel: String, rightLabel: String,
        context: Int )`
- `render(
        hunks: [Hunk],
        leftLines: [String], rightLines: [String],
        leftLabel: String, rightLabel: String)`
- `emitContext(upTo lTarget: Int)`

## Terms

## Design comments
- L3: /// Unified diff generation (SPEC §3.7). Patch parsing/application is a
- L4: /// later-release feature; generation covers the patch-export commands.
- L36: // Group changes whose equal-line gap is ≤ 2 × context.
- L59: // Unified convention: with count 0, the displayed number is the line *before*.

## Important AppKit/TextKit lines
