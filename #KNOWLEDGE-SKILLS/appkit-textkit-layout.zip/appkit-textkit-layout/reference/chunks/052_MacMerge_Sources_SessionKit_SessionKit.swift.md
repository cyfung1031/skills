# Source Chunk: MacMerge/Sources/SessionKit/SessionKit.swift

Roles: Core diff/text/git/model logic

Lines: 136; bytes: 4175; imports: Foundation, Combine

## Declarations
- struct `ComparisonSession` inherits Codable, Sendable, Equatable
- enum `Mode` inherits String, Codable, Sendable
- struct `RecentComparison` inherits Codable, Sendable, Equatable, Identifiable
- class `RecentsStore` inherits ObservableObject

## Functions
- `load(from url: URL)`
- `write(to url: URL)`
- `add(_ item: RecentComparison)`
- `clear()`
- `load()`
- `save()`

## Terms
- `MainActor` × 1
- `ObservableObject` × 1

## Design comments
- L4: /// Sessions & recents (SPEC §11.6).
- L5: ///
- L6: /// v0.1: sessions are plain Codable JSON documents with absolute paths;
- L7: /// NSDocument integration and security-scoped bookmarks (for the sandboxed
- L8: /// SKU) are layered on in later releases — the schema already reserves the
- L9: /// fields via `schemaVersion`.
- L85: /// Designated initializer is injectable for tests.
- L132: // Recents are best-effort; losing them must never break the app.

## Important AppKit/TextKit lines
- L74 `MainActor`: `@MainActor`
- L75 `ObservableObject`: `public final class RecentsStore: ObservableObject {`
