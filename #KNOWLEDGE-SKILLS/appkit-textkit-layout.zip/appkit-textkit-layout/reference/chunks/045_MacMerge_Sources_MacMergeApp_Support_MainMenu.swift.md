# Source Chunk: MacMerge/Sources/MacMergeApp/Support/MainMenu.swift

Roles: Window/menu/AppKit shell

Lines: 152; bytes: 8722; imports: AppKit

## Declarations
- enum `MainMenu` 

## Functions
- `install()`
- `submenu(_ title: String)`
- `functionKey(_ code: Int)`
- `makeAppMenu()`
- `makeFileMenu()`
- `makeEditMenu()`
- `makeViewMenu()`
- `makeNavigateMenu()`
- `makeWindowMenu()`
- `makeHelpMenu()`

## Terms
- `NSMenu` × 12
- `NSWindow` × 4
- `AppKit` × 1
- `MainActor` × 1

## Design comments
- L3: /// Programmatic menu bar (SPEC §6). Every command lives here; comparison
- L4: /// commands use nil-target actions resolved through the responder chain to
- L5: /// the front tab's view controller.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L6 `MainActor`: `@MainActor`
- L10 `NSMenu`: `let main = NSMenu()`
- L21 `NSMenu`: `private static func submenu(_ title: String) -> (NSMenuItem, NSMenu) {`
- L22 `NSMenu`: `let item = NSMenuItem()`
- L23 `NSMenu`: `let menu = NSMenu(title: title)`
- L32 `NSMenu`: `private static func makeAppMenu() -> NSMenuItem {`
- L47 `NSMenu`: `private static func makeFileMenu() -> NSMenuItem {`
- L60 `NSWindow`: `menu.addItem(withTitle: "Close", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")`
- L64 `NSMenu`: `private static func makeEditMenu() -> NSMenuItem {`
- L78 `NSMenu`: `private static func makeViewMenu() -> NSMenuItem {`
- L91 `NSWindow`: `action: #selector(NSWindow.toggleFullScreen(_:)), keyEquivalent: "f")`
- L96 `NSMenu`: `private static func makeNavigateMenu() -> NSMenuItem {`
- L132 `NSMenu`: `private static func makeWindowMenu() -> NSMenuItem {`
- L134 `NSWindow`: `menu.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")`
- L135 `NSWindow`: `menu.addItem(withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")`
- L146 `NSMenu`: `private static func makeHelpMenu() -> NSMenuItem {`
