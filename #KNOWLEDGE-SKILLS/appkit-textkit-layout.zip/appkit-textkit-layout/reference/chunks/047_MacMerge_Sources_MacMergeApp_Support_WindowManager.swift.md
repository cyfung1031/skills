# Source Chunk: MacMerge/Sources/MacMergeApp/Support/WindowManager.swift

Roles: Window/menu/AppKit shell

Lines: 253; bytes: 10226; imports: AppKit, SwiftUI, SessionKit

## Declarations
- class `PanelHostingController` 
- class `WindowManager` inherits NSObject
- extension `WindowManager` inherits NSWindowDelegate

## Functions
- `cancelOperation(_ sender: Any?)`
- `showWelcome()`
- `dropPath(_ path: String)`
- `showNewComparison(leftPath: String = "", rightPath: String = "", threeWay: Bool = false)`
- `closeNewComparison()`
- `openComparison(urls: [URL])`
- `openFileDiff(left: URL, right: URL, tabIn host: NSWindow? = nil,
                      nav: FolderNavContext? = nil, origin: (left: U)`
- `returnToFolderCompare(left: URL, right: URL, near window: NSWindow?)`
- `openFolderCompare(left: URL, right: URL, tabIn host: NSWindow? = nil)`
- `openMerge(base: URL, left: URL, right: URL, output: URL? = nil, tabIn host: NSWindow? = nil)`
- `openSession(_ url: URL)`
- `openRecent(_ item: RecentComparison)`
- `present(_ viewController: NSViewController, tabIn host: NSWindow?)`
- `isDirectory(_ url: URL)`
- `presentMessage(_ message: String)`
- `windowWillClose(_ notification: Notification)`

## Terms
- `NSWindow` × 16
- `NSAlert` × 2
- `AppKit` × 1
- `MainActor` × 1
- `NSView` × 1
- `NSViewController` × 1
- `SwiftUI` × 1

## Design comments
- L5: /// Owns all windows and routes comparisons to the right view controller.
- L6: /// Windows use native tabbing (SPEC §5.5); folder drill-down opens file
- L7: /// diffs as tabs of the same window.
- L8: /// Hosting controller for panel-style windows (Welcome, New Comparison):
- L9: /// Esc closes them, like native dialogs.
- L26: // MARK: - Welcome
- L49: // MARK: - New Comparison chooser
- L51: /// Fills the next empty slot (L→R→Base) in an open NewComparison window,
- L52: /// or opens a new one with the path pre-filled in the left slot.
- L62: /// Recreated each show so the threeWay preset and stale paths reset.
- L86: // MARK: - Routing
- L88: /// Routes dropped/opened URLs: one session file, two items for diff/folder, or three files for merge.
- L124: /// Back-navigation target: activates an existing folder-comparison tab
- L125: /// for these roots, or recreates one if the user closed it.
- L200: // MARK: - Presentation

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L2 `SwiftUI`: `import SwiftUI`
- L16 `MainActor`: `@MainActor`
- L21 `NSWindow`: `private var controllers: [NSWindowController] = []`
- L22 `NSWindow`: `private var welcomeController: NSWindowController?`
- L23 `NSWindow`: `private var newComparisonController: NSWindowController?`
- L31 `NSWindow`: `let window = NSWindow(contentViewController: hosting)`
- L39 `NSWindow`: `welcomeController = NSWindowController(window: window)`
- L68 `NSWindow`: `let window = NSWindow(contentViewController: hosting)`
- L75 `NSWindow`: `newComparisonController = NSWindowController(window: window)`
- L118 `NSWindow`: `func openFileDiff(left: URL, right: URL, tabIn host: NSWindow? = nil,`
- L126 `NSWindow`: `func returnToFolderCompare(left: URL, right: URL, near window: NSWindow?) {`
- L137 `NSWindow`: `func openFolderCompare(left: URL, right: URL, tabIn host: NSWindow? = nil) {`
- L142 `NSWindow`: `func openMerge(base: URL, left: URL, right: URL, output: URL? = nil, tabIn host: NSWindow? = nil) {`
- L171 `NSAlert`: `NSAlert(error: error).runModal()`
- L202 `NSView`: `private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {`
- L202 `NSViewController`: `private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {`
- L202 `NSWindow`: `private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {`
- L203 `NSWindow`: `let window = NSWindow(contentViewController: viewController)`
- L210 `NSWindow`: `let controller = NSWindowController(window: window)`
- L230 `NSAlert`: `let alert = NSAlert()`
- L237 `NSWindow`: `extension WindowManager: NSWindowDelegate {`
- L239 `NSWindow`: `guard let window = notification.object as? NSWindow else { return }`
