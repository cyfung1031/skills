# Source Chunk: MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift

Roles: Markdown preview TextKit stack

Lines: 188; bytes: 8985; imports: AppKit, SwiftUI

## Declarations
- struct `MarkdownPreviewTextView` inherits NSViewRepresentable
- class `Coordinator` inherits NSObject, NSTextViewDelegate, NSLayoutManagerDelegate

## Functions
- `makeCoordinator()`
- `makeNSView(context: Context)`
- `updateNSView(_ scrollView: NSScrollView, context: Context)`
- `layoutManager(_ layoutManager: NSLayoutManager,
                           didCompleteLayoutFor textContainer: NSTextContainer?,
     )`
- `textView(_ textView: NSTextView, clickedOnLink link: Any, at charIndex: Int)`
- `scrollToHeading(_ entry: MarkdownOutlineEntry, in textView: NSTextView)`

## Terms
- `NSTextView` × 9
- `NSScrollView` × 4
- `NSView` × 4
- `NSAttributedString` × 3
- `NSLayoutManager` × 3
- `didCompleteLayoutFor` × 3
- `glyphRange` × 3
- `textContainerInset` × 3
- `NSPasteboard` × 2
- `NSRange` × 2
- `NSTextContainer` × 2
- `NSViewRepresentable` × 2
- `contentView.scroll` × 2
- `documentRect` × 2
- `drawsBackground` × 2
- `reflectScrolledClipView` × 2
- `scrollTo` × 2
- `setAttributedString` × 2
- `AppKit` × 1
- `NSCursor` × 1
- `NSLayoutManagerDelegate` × 1
- `NSTextStorage` × 1
- `NSTextViewDelegate` × 1
- `NSWorkspace` × 1
- `SwiftUI` × 1
- `autoresizingMask` × 1
- `boundingRect` × 1
- `clickedOnLink` × 1
- `ensureLayout` × 1
- `isHorizontallyResizable` × 1
- `isVerticallyResizable` × 1
- `linkTextAttributes` × 1
- `widthTracksTextView` × 1

## Design comments
- L4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
- L27: // Manual construction so we can inject MarkdownLayoutManager.
- L34: // Single-pass layout required so documentRect.height is accurate when
- L35: // didCompleteLayoutFor fires and we restore the scroll position.
- L50: // Read-only preview — disable all text-editing assistance.
- L62: // Theme-consistent link appearance; foreground color is set by the renderer.
- L93: // Skip if the attributed string object hasn't changed (e.g. isDirty re-renders).
- L99: // Scroll position is restored in layoutManager(_:didCompleteLayoutFor:atEnd:)
- L100: // after NSLayoutManager finishes laying out the new content.
- L103: // MARK: - Coordinator
- L137: // Copy-code links on language labels / copy hint
- L147: // Checkbox toggle links
- L153: // Web/scheme URLs — let NSTextView handle via NSWorkspace
- L156: // Relative (nil-scheme) links — delegate to caller for markdown navigation

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L2 `SwiftUI`: `import SwiftUI`
- L4 `NSTextView`: `// MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview`
- L4 `NSViewRepresentable`: `// MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview`
- L4 `NSView`: `// MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview`
- L6 `NSViewRepresentable`: `struct MarkdownPreviewTextView: NSViewRepresentable {`
- L6 `NSView`: `struct MarkdownPreviewTextView: NSViewRepresentable {`
- L7 `NSAttributedString`: `let attributedString:  NSAttributedString`
- L12 `NSAttributedString`: `init(attributedString: NSAttributedString,`
- L26 `NSScrollView`: `func makeNSView(context: Context) -> NSScrollView {`
- L26 `NSView`: `func makeNSView(context: Context) -> NSScrollView {`
- L28 `NSTextStorage`: `let textStorage = NSTextStorage()`
- L30 `NSTextContainer`: `let container   = NSTextContainer(size: NSSize(width: 0, height: CGFloat.greatestFiniteMagnitude))`
- L31 `widthTracksTextView`: `container.widthTracksTextView = true`
- L34 `documentRect`: `// Single-pass layout required so documentRect.height is accurate when`
- L35 `didCompleteLayoutFor`: `// didCompleteLayoutFor fires and we restore the scroll position.`
- L38 `NSTextView`: `let textView = NSTextView(frame: .zero, textContainer: container)`
- L41 `isVerticallyResizable`: `textView.isVerticallyResizable  = true`
- L42 `isHorizontallyResizable`: `textView.isHorizontallyResizable = false`
- L43 `autoresizingMask`: `textView.autoresizingMask       = .width`
- L47 `drawsBackground`: `textView.drawsBackground       = false`
- L48 `textContainerInset`: `textView.textContainerInset    = NSSize(width: 32, height: 32)`
- L63 `linkTextAttributes`: `textView.linkTextAttributes = [`
- L65 `NSCursor`: `.cursor:         NSCursor.pointingHand`
- L71 `setAttributedString`: `textStorage.setAttributedString(attributedString)`
- L74 `NSScrollView`: `let scrollView = NSScrollView()`
- L79 `drawsBackground`: `scrollView.drawsBackground      = false`
- L84 `NSScrollView`: `func updateNSView(_ scrollView: NSScrollView, context: Context) {`
- L84 `NSView`: `func updateNSView(_ scrollView: NSScrollView, context: Context) {`
- L89 `NSTextView`: `let textView = scrollView.documentView as? NSTextView {`
- L91 `scrollTo`: `context.coordinator.scrollToHeading(outlineJump.entry, in: textView)`
- L95 `NSTextView`: `let textView = scrollView.documentView as? NSTextView else { return }`
- L98 `setAttributedString`: `textView.textStorage?.setAttributedString(attributedString)`
- L99 `didCompleteLayoutFor`: `// Scroll position is restored in layoutManager(_:didCompleteLayoutFor:atEnd:)`
- L100 `NSLayoutManager`: `// after NSLayoutManager finishes laying out the new content.`
- L105 `NSLayoutManager`: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`
- L105 `NSTextView`: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`
- L105 `NSTextViewDelegate`: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`
- L105 `NSLayoutManagerDelegate`: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`
- L108 `NSTextView`: `weak var textViewRef:         NSTextView?`
- L109 `NSScrollView`: `weak var scrollViewRef:       NSScrollView?`
- L110 `NSAttributedString`: `weak var lastAttributedString: NSAttributedString?`
- L119 `NSLayoutManager`: `func layoutManager(_ layoutManager: NSLayoutManager,`
- L120 `NSTextContainer`: `didCompleteLayoutFor textContainer: NSTextContainer?,`
- L120 `didCompleteLayoutFor`: `didCompleteLayoutFor textContainer: NSTextContainer?,`
- L126 `documentRect`: `let docH    = sv.contentView.documentRect.height`
- L130 `contentView.scroll`: `sv.contentView.scroll(to: clamped)`
- L131 `reflectScrolledClipView`: `sv.reflectScrolledClipView(sv.contentView)`
- L134 `NSTextView`: `func textView(_ textView: NSTextView, clickedOnLink link: Any, at charIndex: Int) -> Bool {`
- L134 `clickedOnLink`: `func textView(_ textView: NSTextView, clickedOnLink link: Any, at charIndex: Int) -> Bool {`
- L142 `NSPasteboard`: `NSPasteboard.general.clearContents()`
- L143 `NSPasteboard`: `NSPasteboard.general.setString(code, forType: .string)`
- L153 `NSTextView`: `// Web/scheme URLs — let NSTextView handle via NSWorkspace`
- L153 `NSWorkspace`: `// Web/scheme URLs — let NSTextView handle via NSWorkspace`
- L161 `NSTextView`: `func scrollToHeading(_ entry: MarkdownOutlineEntry, in textView: NSTextView) {`
- L161 `scrollTo`: `func scrollToHeading(_ entry: MarkdownOutlineEntry, in textView: NSTextView) {`
- L167 `NSRange`: `var target: NSRange?`
- L168 `NSRange`: `let fullRange = NSRange(location: 0, length: storage.length)`
- L179 `ensureLayout`: `layoutManager.ensureLayout(for: container)`
- L180 `glyphRange`: `let glyphRange = layoutManager.glyphRange(forCharacterRange: target, actualCharacterRange: nil)`
- L181 `glyphRange`: `let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)`
- L181 `boundingRect`: `let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)`
- L182 `textContainerInset`: `.offsetBy(dx: textView.textContainerInset.width, dy: textView.textContainerInset.height)`
- L184 `contentView.scroll`: `scrollView.contentView.scroll(to: NSPoint(x: 0, y: y))`
- L185 `reflectScrolledClipView`: `scrollView.reflectScrolledClipView(scrollView.contentView)`
