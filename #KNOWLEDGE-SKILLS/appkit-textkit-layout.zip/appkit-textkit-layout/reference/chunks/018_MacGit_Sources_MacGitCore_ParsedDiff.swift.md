# Source Chunk: MacGit/Sources/MacGitCore/ParsedDiff.swift

Roles: Core diff/text/git/model logic

Lines: 108; bytes: 3989; imports: Foundation

## Declarations
- struct `DiffFile` inherits Sendable
- struct `DiffHunk` inherits Sendable
- enum `DiffLineKind` inherits Sendable
- struct `DiffLine` inherits Sendable

## Functions
- `parseDiff(_ raw: String)`
- `hunkLineNumbers(_ header: String)`
- `leadingInt(_ s: Substring)`

## Terms

## Design comments
- L3: /// A single file section within a unified diff.
- L11: /// A `@@` hunk within a diff file section.
- L30: /// Parses a unified diff string (output of `git diff` / `git show`) into structured `DiffFile` values.
- L43: // Consume file header lines (---, +++, index, mode, similarity, etc.)
- L56: // Consume hunks
- L75: // "No newline at end of file" — skip
- L80: // empty or inter-hunk meta lines are skipped
- L95: /// Extracts (oldStart, newStart) from a hunk header like `@@ -1,5 +1,6 @@ ctx`.

## Important AppKit/TextKit lines
