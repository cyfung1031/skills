# Source Chunk: MacMerge/Sources/DiffCore/DisplayModel.swift

Roles: Core diff/text/git/model logic

Lines: 90; bytes: 4094; imports: (none)

## Declarations
- struct `DiffDisplayModel` inherits Sendable
- struct `Row` inherits Sendable

## Functions
- `build(from hunks: [Hunk], context: Int? = nil)`
- `emitEqualRows(_ offsets: Range<Int>)`

## Terms

## Design comments
- L1: /// Maps hunks to aligned display rows: matched lines stay level, one-sided
- L2: /// regions render as phantom rows on the other side (SPEC §5.3).
- L3: ///
- L4: /// With a `context` limit, long identical runs collapse into a single marker
- L5: /// row (`collapsedCount > 0`) so the view shows only the lines around each
- L6: /// change — callers must label the view as partial when `hiddenLineCount > 0`.
- L14: /// > 0 → marker row standing in for this many hidden identical lines.
- L16: /// Mirrors `Hunk.isWhitespaceOnly` for the row's hunk.
- L32: /// Display-row range of each non-equal hunk, in order (navigation targets).
- L34: /// Total identical lines hidden behind marker rows (0 = full view).
- L39: /// - Parameter context: identical lines to keep around each change;
- L40: ///   nil shows the full file.
- L60: // No context needed before the first change or after the last.

## Important AppKit/TextKit lines
