# Source Chunk: MackDown/Sources/MackDownApp/SettingsView.swift

Roles: Support code

Lines: 365; bytes: 13197; imports: AppKit, SwiftUI

## Declarations
- struct `EscapeKeyInterceptor` inherits NSViewRepresentable
- class `EscView` inherits NSView
- struct `SettingsView` inherits View

## Functions
- `makeNSView(context: Context)`
- `updateNSView(_ nsView: NSView, context: Context)`
- `viewDidMoveToWindow()`
- `settingsSectionHeader(_ title: String)`
- `colorRow(_ label: String, light: Binding<String>, dark: Binding<String>)`
- `colorBinding(hex: Binding<String>)`

## Terms
- `NSView` × 6
- `NSEvent` × 3
- `AppKit` × 1
- `NSViewRepresentable` × 1
- `SwiftUI` × 1
- `bestMatch` × 1
- `darkAqua` × 1
- `effectiveAppearance` × 1
- `vibrantDark` × 1

## Design comments
- L4: // MARK: - Esc key interceptor (closes the Settings window)
- L29: // MARK: - Settings view
- L56: // MARK: - General
- L86: // MARK: - Editor
- L161: // MARK: - Preview
- L269: // MARK: - Colors
- L320: // MARK: - Shared row components (matching Colors pane style)

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L2 `SwiftUI`: `import SwiftUI`
- L6 `NSViewRepresentable`: `private struct EscapeKeyInterceptor: NSViewRepresentable {`
- L6 `NSView`: `private struct EscapeKeyInterceptor: NSViewRepresentable {`
- L7 `NSView`: `func makeNSView(context: Context) -> NSView {`
- L11 `NSView`: `func updateNSView(_ nsView: NSView, context: Context) {}`
- L13 `NSView`: `private class EscView: NSView {`
- L17 `NSEvent`: `monitor.map { NSEvent.removeMonitor($0) }`
- L19 `NSEvent`: `monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak win] event in`
- L25 `NSEvent`: `deinit { monitor.map { NSEvent.removeMonitor($0) } }`
- L34 `effectiveAppearance`: `NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L34 `bestMatch`: `NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L34 `darkAqua`: `NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L34 `vibrantDark`: `NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
