# Source Chunk: MacMerge/Sources/DiffCore/Diff3.swift

Roles: Core diff/text/git/model logic

Lines: 111; bytes: 4339; imports: (none)

## Declarations
- struct `Merge3Segment` inherits Sendable, Equatable
- enum `Kind` inherits Sendable, Equatable
- enum `Diff3` 

## Functions
- `emitUnchanged(upTo lo: Int)`

## Terms

## Design comments
- L1: /// Three-way merge segmentation (SPEC §3.3). Segments cover base, left, and
- L2: /// right completely and in order. Adjacent change regions (no unchanged line
- L3: /// between them) merge into one region — same behavior as git's diff3.
- L33: // Change records against base: (base range, replacement range on that side).
- L64: // Expand the region while changes from either side touch or overlap it.
- L81: // Side lengths: unchanged-in-side portions stay 1:1; changed portions
- L82: // contribute their replacement lengths.

## Important AppKit/TextKit lines
