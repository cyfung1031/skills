# Source Chunk: MacGit/Sources/MacGitCore/GitDiff.swift

Roles: Core diff/text/git/model logic

Lines: 44; bytes: 2157; imports: Foundation

## Declarations
- extension `GitClient` 

## Functions
- `diff(path: String, in repositoryURL: URL)`
- `diff(commit sha: String, path: String, in repositoryURL: URL)`
- `diff(from base: String, to target: String, path: String, in repositoryURL: URL)`
- `openDiffTool(path: String, in repositoryURL: URL)`
- `showFileText(atCommit sha: String, path: String, in repositoryURL: URL)`

## Terms

## Design comments
- L14: /// Returns the diff for a specific file as introduced by `sha` (SPEC §2.4 inspector).
- L15: /// Uses `git show <sha> -- <path>` which includes the commit header and the unified diff.
- L21: /// Returns the diff of `path` between two revisions (e.g. `HEAD...branchName` for branch preview).
- L30: /// Opens the configured external diff tool (`git difftool`) for a working-tree file.
- L31: /// Respects the user's `git config diff.tool`; falls back to `opendiff` (FileMerge) on macOS.
- L36: /// Returns the text content of a file at a given commit (using `git show SHA:path`).
- L37: /// Returns nil for binary files, files larger than 512 KB, or errors.

## Important AppKit/TextKit lines
