# Source Chunk: MackDown/Sources/MackDownApp/EditorToolbar.swift

Roles: Support code

Lines: 249; bytes: 10424; imports: AppKit, SwiftUI

## Declarations
- enum `MarkdownFormat` inherits Hashable
- extension `Notification.Name` 
- struct `EditorToolbarView` inherits View
- struct `SelectionToolbarView` inherits View
- class `FloatingSelectionPanel` inherits NSPanel

## Functions
- `applyMarkdownFormat(_ format: MarkdownFormat, to tv: NSTextView)`
- `wrapInline(_ sel: String, pre: String, suf: String, placeholder: String,
                         at range: NSRange, tv: NSTextView)`
- `toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange)`
- `replaceAndSelect(_ rep: String, at range: NSRange, tv: NSTextView,
                               offset: Int, len: Int)`
- `fmtBtn(_ format: MarkdownFormat, label: String? = nil,
                         icon: String? = nil)`
- `help(_ f: MarkdownFormat)`
- `selBtn(_ format: MarkdownFormat, _ icon: String)`

## Terms
- `NSRange` × 15
- `NSString` × 8
- `NSTextView` × 5
- `setSelectedRange` × 3
- `NotificationCenter` × 2
- `SwiftUI` × 2
- `AppKit` × 1
- `NSHostingView` × 1
- `selectedRange` × 1

## Design comments
- L4: // MARK: - Format actions
- L17: // MARK: - Apply format to NSTextView (free function; called from coordinator)
- L62: // Case A: selection itself includes the markers (e.g. user selected "**text**").
- L69: // Case B: selection is the inner text with markers immediately outside in the document.
- L84: // Default: wrap.
- L99: // Remove prefix: cursor shifts left by pLen, clamped to line start.
- L107: // Add prefix: cursor shifts right by pLen.
- L125: // MARK: - Fixed editor toolbar strip
- L199: // MARK: - Floating selection toolbar (SwiftUI content embedded in NSPanel)
- L230: // MARK: - Borderless floating NSPanel hosting SelectionToolbarView

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L2 `SwiftUI`: `import SwiftUI`
- L17 `NSTextView`: `// MARK: - Apply format to NSTextView (free function; called from coordinator)`
- L19 `NSTextView`: `func applyMarkdownFormat(_ format: MarkdownFormat, to tv: NSTextView) {`
- L20 `selectedRange`: `let sel   = tv.selectedRange()`
- L21 `NSString`: `let text  = tv.string as NSString`
- L56 `NSTextView`: `at range: NSRange, tv: NSTextView) {`
- L56 `NSRange`: `at range: NSRange, tv: NSTextView) {`
- L57 `NSString`: `let text   = tv.string as NSString`
- L58 `NSString`: `let preLen = (pre as NSString).length`
- L59 `NSString`: `let sufLen = (suf as NSString).length`
- L60 `NSString`: `let selLen = (sel as NSString).length`
- L65 `NSString`: `replaceAndSelect(inner, at: range, tv: tv, offset: 0, len: (inner as NSString).length)`
- L74 `NSRange`: `let preStr = text.substring(with: NSRange(location: preStart, length: preLen))`
- L75 `NSRange`: `let sufStr = text.substring(with: NSRange(location: sufStart, length: sufLen))`
- L77 `NSRange`: `let outerRange = NSRange(location: preStart, length: preLen + selLen + sufLen)`
- L92 `NSTextView`: `private func toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange) {`
- L92 `NSRange`: `private func toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange) {`
- L93 `NSString`: `let text      = tv.string as NSString`
- L95 `NSRange`: `let lineRange = text.lineRange(for: NSRange(location: sel.location, length: 0))`
- L97 `NSString`: `let pLen      = (prefix as NSString).length`
- L100 `NSRange`: `guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: pLen), replacementString: "") else { return }`
- L101 `NSRange`: `tv.replaceCharacters(in: NSRange(location: lineRange.location, length: pLen), with: "")`
- L105 `NSRange`: `tv.setSelectedRange(NSRange(location: newLoc, length: newLen))`
- L105 `setSelectedRange`: `tv.setSelectedRange(NSRange(location: newLoc, length: newLen))`
- L108 `NSRange`: `guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: 0), replacementString: prefix) else { return }`
- L109 `NSRange`: `tv.replaceCharacters(in: NSRange(location: lineRange.location, length: 0), with: prefix)`
- L113 `NSRange`: `tv.setSelectedRange(NSRange(location: newLoc, length: newLen))`
- L113 `setSelectedRange`: `tv.setSelectedRange(NSRange(location: newLoc, length: newLen))`
- L117 `NSTextView`: `private func replaceAndSelect(_ rep: String, at range: NSRange, tv: NSTextView,`
- L117 `NSRange`: `private func replaceAndSelect(_ rep: String, at range: NSRange, tv: NSTextView,`
- L122 `NSRange`: `tv.setSelectedRange(NSRange(location: range.location + offset, length: len))`
- L122 `setSelectedRange`: `tv.setSelectedRange(NSRange(location: range.location + offset, length: len))`
- L163 `NotificationCenter`: `NotificationCenter.default.post(name: .applyMarkdownFormat, object: format)`
- L199 `SwiftUI`: `// MARK: - Floating selection toolbar (SwiftUI content embedded in NSPanel)`
- L218 `NotificationCenter`: `NotificationCenter.default.post(name: .applyMarkdownFormat, object: format)`
- L247 `NSHostingView`: `contentView        = NSHostingView(rootView: SelectionToolbarView())`
