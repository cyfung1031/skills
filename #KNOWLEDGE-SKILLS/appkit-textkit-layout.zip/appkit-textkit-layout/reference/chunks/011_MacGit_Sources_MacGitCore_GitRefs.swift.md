# Source Chunk: MacGit/Sources/MacGitCore/GitRefs.swift

Roles: Core diff/text/git/model logic

Lines: 389; bytes: 17687; imports: Foundation

## Declarations
- struct `Branch` inherits Equatable, Sendable, Identifiable
- struct `Tag` inherits Equatable, Sendable, Identifiable
- struct `RefList` inherits Equatable, Sendable
- struct `WorktreeInfo` inherits Equatable, Sendable, Identifiable
- extension `GitClient` 

## Functions
- `refs(in repositoryURL: URL)`
- `isHeadPushed(in repositoryURL: URL)`
- `switchBranch(to branch: String, in repositoryURL: URL)`
- `createBranch(name: String, from startPoint: String? = nil, in repositoryURL: URL)`
- `renameBranch(old: String, new: String, in repositoryURL: URL)`
- `deleteBranch(name: String, force: Bool = false, in repositoryURL: URL)`
- `isBranchMerged(name: String, in repositoryURL: URL)`
- `resetHard(to sha: String, in repositoryURL: URL)`
- `resetMixed(to sha: String, in repositoryURL: URL)`
- `resetSoft(to sha: String, in repositoryURL: URL)`
- `updateRef(ref: String, to sha: String, in repositoryURL: URL)`
- `revParse(ref: String = "HEAD", in repositoryURL: URL)`
- `isOperationInProgress(in repositoryURL: URL)`
- `stashPushIncludingUntracked(in repositoryURL: URL)`
- `stashPop(in repositoryURL: URL)`
- `stashDrop(ref: String = "stash@{0}", in repositoryURL: URL)`
- `addWorktree(branch: String, at path: String, createBranch: Bool = false, in repositoryURL: URL)`
- `removeWorktree(path: String, force: Bool = false, in repositoryURL: URL)`
- `listWorktrees(in repositoryURL: URL)`
- `parseWorktreePorcelain(_ output: String)`
- `cherryPick(sha: String, in repositoryURL: URL)`
- `cherryPickContinue(in repositoryURL: URL)`
- `cherryPickAbort(in repositoryURL: URL)`
- `revert(sha: String, in repositoryURL: URL)`
- `revertContinue(in repositoryURL: URL)`
- `revertAbort(in repositoryURL: URL)`
- `rebaseContinue(in repositoryURL: URL)`
- `rebaseAbort(in repositoryURL: URL)`
- `mergeContinue(in repositoryURL: URL)`
- `mergeAbort(in repositoryURL: URL)`
- `takeOurs(path: String, in repositoryURL: URL)`
- `takeTheirs(path: String, in repositoryURL: URL)`
- `createTag(name: String, at sha: String, message: String? = nil, in repositoryURL: URL)`
- `deleteTag(name: String, in repositoryURL: URL)`
- `detectOperationInProgress(in repositoryURL: URL)`
- `mergeTool(in repositoryURL: URL)`
- `launchMergeTool(path: String, in repositoryURL: URL)`
- `remoteURL(name: String = "origin", in repositoryURL: URL)`

## Terms

## Design comments
- L3: /// A local branch (SPEC §2.4 chips, §M3.2 sidebar). `ahead`/`behind` are relative to the configured
- L4: /// upstream; both are 0 when there is no upstream.
- L32: /// A tag. `targetOID` is the *commit* it points at — annotated tags are dereferenced so chips land
- L33: /// on the right history row (R-0003-03).
- L56: /// A git worktree listing entry.
- L65: /// Lists local branches and tags via `for-each-ref` (SPEC §6.2). A repository with no refs
- L66: /// (freshly initialized) returns empty lists, not an error.
- L77: /// Returns `true` when HEAD is reachable from any remote-tracking ref — i.e., the current
- L78: /// commit has been pushed. Returns `false` for unborn branches, repos with no remotes, or when
- L79: /// HEAD is not reachable from any remote ref.
- L86: /// Switches to `branch`. Throws `GitError.wouldOverwrite` when the tree is dirty and git
- L87: /// refuses, `GitError.operationInProgress` when a merge/rebase is active.
- L105: /// Creates a new branch at `startPoint` (default: HEAD), then switches to it.
- L106: /// On an unborn repo (no commits) pass `startPoint: nil` — `git switch -c` works without HEAD.
- L116: /// Renames `oldName` to `newName`.
- L121: /// Deletes `name`. Pass `force: true` to delete unmerged branches (`-D`).
- L130: /// Returns `true` if `branchName` is merged into the current HEAD (safe to delete).
- L139: /// Hard-resets the current branch to `sha` (dangerous — callers must snapshot first).
- L144: /// Mixed-reset HEAD to `sha` (drops commit; index ← tree at sha; worktree unchanged).
- L149: /// Soft-reset HEAD to `sha` (drops commit; index keeps staged changes; worktree unchanged).
- L154: /// Updates a ref to point at `sha` (used by UndoLog to restore branch tips).
- L159: /// Returns the SHA of `ref` (or HEAD when `ref` is nil). Returns `nil` for unborn branches.
- L166: /// Returns true when a merge/rebase/cherry-pick is currently in progress.
- L178: // MARK: - Stash (used only as silent fallback for Option B bring-along; SPEC §5.2)
- L180: /// Stashes all changes including untracked (`-u`). Returns the stash ref (e.g. `stash@{0}`).
- L190: /// Applies and removes the top stash. Returns conflicted file paths if the pop conflicted.
- L194: // Pop failed: collect conflicted files from the index.
- L200: /// Drops the stash entry at `ref` (e.g. `stash@{0}`).
- L205: // MARK: - Worktrees
- L207: /// Adds a linked worktree for `branch` at `path`. If `createBranch` is true, creates the
- L208: /// branch first (equivalent to `git worktree add -b <branch> <path>`).
- L222: /// Removes a linked worktree. Pass `force: true` if the worktree has uncommitted changes.
- L229: /// Lists all linked worktrees (including the main one).
- L265: // MARK: - Cherry-pick (SPEC §2.4)
- L285: // MARK: - Revert (SPEC §2.4)
- L305: // MARK: - Rebase continue / abort (interactive rebase via console; SPEC §6.4)
- L315: // MARK: - Merge continue / abort
- L325: // MARK: - Conflict resolution helpers (SPEC §2.6)
- L327: /// Checks out our version of a conflicted file and stages it.
- L333: /// Checks out their version of a conflicted file and stages it.
- L339: // MARK: - Tags (SPEC §2.4)
- L341: /// Creates a lightweight tag (when message is nil) or an annotated tag.
- L356: // MARK: - Operation detection (replaces Bool isOperationInProgress)
- L358: /// Returns the specific in-progress operation, if any.
- L372: /// Returns the merge.tool config value (empty string when unconfigured).
- L378: /// Launches mergetool for a specific file (fire-and-forget; opens external tool).
- L383: /// Returns the fetch URL for the named remote, or nil when no such remote exists.

## Important AppKit/TextKit lines
