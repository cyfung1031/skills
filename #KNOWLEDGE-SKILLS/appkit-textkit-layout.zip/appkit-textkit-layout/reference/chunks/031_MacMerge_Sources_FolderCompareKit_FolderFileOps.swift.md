# Source Chunk: MacMerge/Sources/FolderCompareKit/FolderFileOps.swift

Roles: Core diff/text/git/model logic

Lines: 46; bytes: 2036; imports: Foundation

## Declarations
- enum `FolderFileOps` 
- enum `Side` inherits Sendable
- enum `Direction` inherits Sendable

## Functions
- `copy(
        relativePath: String, direction: Direction,
        leftRoot: URL, rightRoot: URL
    )`
- `trash(relativePath: String, side: Side, leftRoot: URL, rightRoot: URL)`

## Terms

## Design comments
- L3: /// File operations on comparison entries (SPEC §3.4). Deletes go to the
- L4: /// Trash. Queued/progress-reported bulk operations come with sync execution
- L5: /// in a later release; v0.1 operations are single-entry and synchronous.
- L12: /// Copies the entry (file or whole subtree) across, replacing any
- L13: /// existing destination.
- L31: // Stage into a temp sibling so the destination is never removed before
- L32: // the replacement is ready.
- L40: /// Moves the entry on the given side to the Trash.

## Important AppKit/TextKit lines
