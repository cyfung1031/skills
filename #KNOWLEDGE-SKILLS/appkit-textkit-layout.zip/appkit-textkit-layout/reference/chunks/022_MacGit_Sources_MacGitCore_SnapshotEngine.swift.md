# Source Chunk: MacGit/Sources/MacGitCore/SnapshotEngine.swift

Roles: Core diff/text/git/model logic

Lines: 150; bytes: 7198; imports: Foundation

## Declarations
- enum `SnapshotEngine` 
- struct `FileTimestamp` inherits Codable

## Functions
- `isSnapshotCommit(subject: String)`
- `detectSnapshot(in client: GitClient, repositoryURL: URL)`
- `realTip(branch: String, in client: GitClient, repositoryURL: URL)`
- `createSnapshot(branch: String, in client: GitClient, repositoryURL: URL)`
- `restoreSnapshot(branch: String, in client: GitClient, repositoryURL: URL)`
- `timestampsURL(for repositoryURL: URL)`
- `saveTimestamps(for changes: [FileChange], branch: String, repositoryURL: URL)`
- `restoreTimestamps(for branch: String, repositoryURL: URL)`
- `loadAllTimestamps(repositoryURL: URL)`
- `subject(of sha: String, in client: GitClient, repositoryURL: URL)`

## Terms

## Design comments
- L3: /// Implements the stashless WIP snapshot protocol from SPEC §5.1.
- L4: ///
- L5: /// Snapshot shape: two WIP commits on the branch tip —
- L6: ///   parent~1  «macgit-wip» index    (staged state, --allow-empty)
- L7: ///   parent    «macgit-wip» worktree (everything else incl. untracked)
- L8: ///
- L9: /// Restore: two-reset dance —
- L10: ///   git reset --mixed HEAD~1   (drop worktree commit; index ← index-commit tree)
- L11: ///   git reset --soft  HEAD~1   (drop index commit;    HEAD ← real parent)
- L12: ///
- L13: /// The sentinel prefix is checked by exact prefix match; do NOT change it (reflog stores it).
- L21: /// Returns true when the current HEAD is the worktree-layer of a snapshot.
- L32: /// Returns the real (pre-snapshot) tip SHA for the given branch, walking back past any
- L33: /// snapshot commits. Used for push guard, History filtering, and branch-from-here.
- L49: /// Creates a snapshot of the current dirty state on `branch`.
- L50: /// Saves file modification/creation timestamps beforehand so `restoreSnapshot`
- L51: /// can reapply them after git rewrites the files.
- L52: /// Precondition: not in a merge/rebase/cherry-pick in-progress state.
- L54: // Require at least one commit on the branch (unborn HEAD cannot be snapshot-committed).
- L61: // 1. Commit whatever is staged (--allow-empty for clean index case).
- L67: // 2. Stage everything remaining (untracked, unstaged).
- L69: // 3. Commit the worktree state.
- L77: /// Restores a snapshot on `branch`. The branch tip must be a `«macgit-wip» worktree`
- L78: /// commit (i.e., `detectSnapshot` returns true).
- L80: // Drop worktree commit; index ← index-commit tree.
- L82: // Drop index commit; HEAD ← real parent; index retains staged set.
- L84: // Reapply saved file timestamps so Finder shows the original modification times.
- L88: // MARK: - Timestamp persistence
- L144: // MARK: - Private helpers

## Important AppKit/TextKit lines
