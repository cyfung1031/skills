# Source Chunk: MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift

Roles: Merge AppKit controller

Lines: 404; bytes: 16558; imports: AppKit, DiffCore, TextEngine, MergeKit, SessionKit

## Declarations
- class `MergeViewController` inherits NSViewController
- struct `MergePayload` 
- extension `MergeViewController` inherits NSTextViewDelegate
- extension `MergeViewController` inherits NSMenuItemValidation

## Functions
- `armWatcher()`
- `loadView()`
- `sourcePane(_ header: String)`
- `symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector)`
- `viewDidLoad()`
- `reload()`
- `apply(_ payload: MergePayload)`
- `nextConflict(_ sender: Any?)`
- `previousConflict(_ sender: Any?)`
- `goToConflict(_ index: Int)`
- `scrollOutputToRow(_ row: Int)`
- `saveOutput(_ sender: Any?)`
- `write(to url: URL)`
- `refresh(_ sender: Any?)`
- `saveSession(_ sender: Any?)`
- `goBack(_ sender: Any?)`
- `cancelOperation(_ sender: Any?)`
- `textDidChange(_ notification: Notification)`
- `validateMenuItem(_ menuItem: NSMenuItem)`

## Terms
- `Task` × 7
- `NSStackView` × 5
- `orientation` × 5
- `NSColor` × 4
- `NSView` × 4
- `NSAlert` × 3
- `NSButton` × 3
- `NSTextField` × 3
- `NSMenu` × 2
- `bottomAnchor` × 2
- `leadingAnchor` × 2
- `topAnchor` × 2
- `trailingAnchor` × 2
- `AppKit` × 1
- `MainActor` × 1
- `NSLayoutConstraint` × 1
- `NSMenuItemValidation` × 1
- `NSSavePanel` × 1
- `NSTextView` × 1
- `NSTextViewDelegate` × 1
- `NSViewController` × 1
- `contentView.scroll` × 1
- `distribution` × 1
- `edgeInsets` × 1
- `lineFragmentRect` × 1
- `reflectScrolledClipView` × 1
- `setAttributedString` × 1
- `translatesAutoresizingMaskIntoConstraints` × 1

## Design comments
- L7: /// Three-way merge (SPEC §3.3). Layout: left / base / right source panes
- L8: /// over an editable output pane. Auto-resolvable segments are pre-applied;
- L9: /// true conflicts appear in the output with diff3 markers and a tinted
- L10: /// background. v0.1 resolves conflicts by editing the output directly;
- L11: /// per-hunk take-left/take-right gestures land in M4.
- L61: /// Watches the three merge inputs. Auto-reloads only when the output has
- L62: /// no unsaved edits; otherwise surfaces a non-destructive notice so the
- L63: /// user's in-progress merge is never discarded silently.
- L75: // MARK: - View construction
- L173: // MARK: - Loading
- L271: // MARK: - Navigation
- L304: // MARK: - Saving
- L361: /// Back from a merge goes to the Welcome window (Esc outside the
- L362: /// editable output pane, ⌘[). ⌘W still closes.
- L374: // After a manual edit, recompute row offsets so backgrounds and line
- L375: // numbers stay truthful. Conflict tints are cleared lazily: ranges no
- L376: // longer match reality once lines shift, so drop them.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L12 `NSView`: `final class MergeViewController: NSViewController {`
- L12 `NSViewController`: `final class MergeViewController: NSViewController {`
- L23 `Task`: `private var reloadTask: Task<Void, Never>?`
- L32 `NSTextField`: `private let counterLabel = NSTextField(labelWithString: "")`
- L58 `Task`: `reloadTask?.cancel()`
- L78 `NSView`: `func sourcePane(_ header: String) -> (NSView, DiffTextView) {`
- L80 `NSTextField`: `let label = NSTextField(labelWithString: header)`
- L84 `NSStackView`: `let stack = NSStackView(views: [label, scroll])`
- L85 `orientation`: `stack.orientation = .vertical`
- L98 `NSStackView`: `let sourcesRow = NSStackView(views: [leftPane, basePane, rightPane])`
- L99 `orientation`: `sourcesRow.orientation = .horizontal`
- L101 `distribution`: `sourcesRow.distribution = .fillEqually`
- L110 `NSTextField`: `let outputLabel = NSTextField(labelWithString: "Output")`
- L114 `NSStackView`: `let outputPane = NSStackView(views: [outputLabel, outputScroll])`
- L115 `orientation`: `outputPane.orientation = .vertical`
- L127 `NSButton`: `let saveButton = NSButton(title: "Save Output", target: self, action: #selector(saveOutput(_:)))`
- L135 `NSView`: `let spacer = NSView()`
- L137 `NSStackView`: `let controlBar = NSStackView(views: [prevButton, nextButton, counterLabel, spinner, spacer, saveButton])`
- L138 `orientation`: `controlBar.orientation = .horizontal`
- L140 `edgeInsets`: `controlBar.edgeInsets = NSEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)`
- L143 `NSStackView`: `let main = NSStackView(views: [controlBar, split])`
- L144 `orientation`: `main.orientation = .vertical`
- L146 `translatesAutoresizingMaskIntoConstraints`: `main.translatesAutoresizingMaskIntoConstraints = false`
- L148 `NSView`: `let container = NSView(frame: NSRect(x: 0, y: 0, width: 1280, height: 800))`
- L150 `NSLayoutConstraint`: `NSLayoutConstraint.activate([`
- L151 `topAnchor`: `main.topAnchor.constraint(equalTo: container.topAnchor),`
- L152 `bottomAnchor`: `main.bottomAnchor.constraint(equalTo: container.bottomAnchor),`
- L153 `leadingAnchor`: `main.leadingAnchor.constraint(equalTo: container.leadingAnchor),`
- L154 `trailingAnchor`: `main.trailingAnchor.constraint(equalTo: container.trailingAnchor),`
- L159 `NSButton`: `private func symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector) -> NSButton {`
- L161 `NSButton`: `let button = NSButton(image: image, target: self, action: action)`
- L176 `Task`: `reloadTask?.cancel()`
- L183 `Task`: `let bg = Task.detached(priority: .userInitiated) { () -> MergePayload in`
- L196 `NSColor`: `var leftBG: [Int: NSColor] = [:]`
- L197 `NSColor`: `var baseBG: [Int: NSColor] = [:]`
- L198 `NSColor`: `var rightBG: [Int: NSColor] = [:]`
- L218 `NSColor`: `var outputBG: [Int: NSColor] = [:]`
- L233 `MainActor`: `reloadTask = Task { @MainActor [weak self, bg] in`
- L233 `Task`: `reloadTask = Task { @MainActor [weak self, bg] in`
- L244 `NSAlert`: `NSAlert(error: error).runModal()`
- L256 `setAttributedString`: `textView.textStorage?.setAttributedString(pane.attributed)`
- L298 `lineFragmentRect`: `let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)`
- L300 `contentView.scroll`: `scroll.contentView.scroll(to: NSPoint(x: scroll.contentView.bounds.origin.x, y: targetY))`
- L301 `reflectScrolledClipView`: `scroll.reflectScrolledClipView(scroll.contentView)`
- L310 `NSSavePanel`: `let panel = NSSavePanel()`
- L337 `NSAlert`: `NSAlert(error: error).runModal()`
- L343 `NSAlert`: `let alert = NSAlert()`
- L372 `NSTextView`: `extension MergeViewController: NSTextViewDelegate {`
- L372 `NSTextViewDelegate`: `extension MergeViewController: NSTextViewDelegate {`
- L395 `NSMenu`: `extension MergeViewController: NSMenuItemValidation {`
- L395 `NSMenuItemValidation`: `extension MergeViewController: NSMenuItemValidation {`
- L396 `NSMenu`: `func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {`
