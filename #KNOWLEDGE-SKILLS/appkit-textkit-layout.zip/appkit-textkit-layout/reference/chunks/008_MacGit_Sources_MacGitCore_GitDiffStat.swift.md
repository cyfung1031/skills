# Source Chunk: MacGit/Sources/MacGitCore/GitDiffStat.swift

Roles: Core diff/text/git/model logic

Lines: 53; bytes: 2216; imports: Foundation

## Declarations
- struct `DiffStat` inherits Equatable, Sendable, Identifiable
- extension `GitClient` 

## Functions
- `diffStat(in repositoryURL: URL, staged: Bool = false)`
- `diffStat(forCommit sha: String, in repositoryURL: URL)`
- `diffStat(from base: String, to target: String, in repositoryURL: URL)`

## Terms

## Design comments
- L3: /// Per-file line-change summary for the inspector file list (SPEC §2.4). `added`/`deleted` are
- L4: /// `nil` for binary files (git reports `-`). `originalPath` is set for renames/copies.
- L24: /// Working-tree numstat: unstaged by default, staged when `staged` is true (SPEC §6.2).
- L34: /// Numstat for the change introduced by a single commit. `<sha>^!` diffs the commit against its
- L35: /// parents (the empty tree for a root commit, i.e. everything added). Reused by M3 history.
- L44: /// Numstat between two revisions — used by branch preview to show files that differ.
- L45: /// Typical usage: `diffStat(from: "HEAD", to: branchName, in: url)`.

## Important AppKit/TextKit lines
