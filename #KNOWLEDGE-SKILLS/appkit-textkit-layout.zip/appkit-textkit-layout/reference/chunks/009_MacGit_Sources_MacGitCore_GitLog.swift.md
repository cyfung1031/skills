# Source Chunk: MacGit/Sources/MacGitCore/GitLog.swift

Roles: Core diff/text/git/model logic

Lines: 66; bytes: 2126; imports: Foundation

## Declarations
- struct `Commit` inherits Equatable, Sendable, Identifiable
- extension `GitClient` 

## Functions
- `log(
        in repositoryURL: URL,
        maxCount: Int = 500,
        skip: Int = 0,
        revision: String? = nil
    )`

## Terms

## Design comments
- L3: /// A single commit as needed by the History view (SPEC §2.4) and GraphLayout (M1.4).
- L4: /// `parents` carries the full parent list so lane assignment and merge detection work without
- L5: /// a second query.
- L36: /// Reads a page of history as `[Commit]` (SPEC §2.4, §7: 500/page, infinite scroll).
- L37: /// A repository with no commits yet returns `[]` rather than erroring — that is a normal,
- L38: /// expected state for a freshly initialized repo, not a failure.
- L58: // Unborn branch / empty repo: `git log` exits non-zero with this message.

## Important AppKit/TextKit lines
