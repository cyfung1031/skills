# Source Chunk: MacGit/Sources/MacGitCore/ForEachRefParser.swift

Roles: Core diff/text/git/model logic

Lines: 71; bytes: 2923; imports: Foundation

## Declarations
- enum `ForEachRefParser` 

## Functions
- `parse(_ output: String)`
- `suffix(of refname: String, after prefix: String)`
- `parseTrack(_ track: String)`
- `leadingInt(_ text: String, after marker: String)`

## Terms

## Design comments
- L3: /// Pure `String -> RefList` parser for `git for-each-ref` (SPEC §6.2).
- L4: ///
- L5: /// Ref names cannot contain newline or NUL, so records are newline-separated and fields are
- L6: /// `%00`-separated — unambiguous without `-z`. ahead/behind come from `%(upstream:track)` rather
- L7: /// than `%(ahead-behind:)`, which is git 2.41+ and above the 2.39 floor (R-0003-02).
- L9: /// `refname \0 objectname \0 HEAD \0 upstreamShort \0 upstreamTrack \0 derefObjectname`
- L60: /// `%(upstream:track)` is `[ahead N, behind M]`, `[ahead N]`, `[behind M]`, `[gone]`, or empty.

## Important AppKit/TextKit lines
