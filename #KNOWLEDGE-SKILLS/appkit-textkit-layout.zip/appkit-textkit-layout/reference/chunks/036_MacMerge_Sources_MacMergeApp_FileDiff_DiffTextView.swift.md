# Source Chunk: MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift

Roles: Diff NSTextView and ruler

Lines: 175; bytes: 7519; imports: AppKit

## Declarations
- class `DiffTextView` inherits NSTextView
- class `LineNumberRuler` inherits NSRulerView

## Functions
- `rowIndex(in starts: [Int], for charOffset: Int)`
- `drawBackground(in rect: NSRect)`
- `fragmentRect(forRow row: Int)`
- `keyDown(with event: NSEvent)`
- `makePane(editable: Bool)`
- `drawHashMarksAndLabels(in rect: NSRect)`

## Terms
- `glyphRange` × 6
- `visibleRect` × 4
- `NSColor` × 3
- `NSScrollView` × 3
- `NSTextView` × 3
- `drawBackground` × 3
- `characterRange` × 2
- `lineFragmentRect` × 2
- `textContainerOrigin` × 2
- `AppKit` × 1
- `NSAttributedString` × 1
- `NSAttributedString.Key` × 1
- `NSBezierPath` × 1
- `NSEvent` × 1
- `NSRulerView` × 1
- `NSString` × 1
- `autoresizingMask` × 1
- `containerSize` × 1
- `drawHashMarksAndLabels` × 1
- `isHorizontallyResizable` × 1
- `isVerticallyResizable` × 1
- `orientation` × 1
- `textContainerInset` × 1
- `widthTracksTextView` × 1

## Design comments
- L3: /// NSTextView (TextKit 1) with full-width row background painting and a
- L4: /// row-aware line number ruler. Attribute-based backgrounds only cover
- L5: /// glyphs; diff row tints must span the full line width, so they are drawn
- L6: /// in `drawBackground(in:)` from the display-row table. (SPEC §11.4)
- L9: /// Display row index → row background color.
- L11: /// UTF-16 character offset of each display row's start, ascending.
- L13: /// Rows of the *current* difference (⌘↑/⌘↓ target) — drawn with an
- L14: /// accent outline so the user can see where navigation is pointing.
- L51: // Current-difference indicator: accent outline around its rows.
- L70: /// View-coordinate rect of one display row's line fragment.
- L81: /// Esc in read-only comparison panes navigates Back (NSTextView would
- L82: /// otherwise swallow it for completion). The editable merge-output
- L83: /// pane keeps Esc for normal text editing.
- L92: /// Standard no-wrap diff editor configuration.
- L109: // Disable wrapping: one display row per line fragment.
- L125: /// Line numbers per display row; phantom rows show no number.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L3 `NSTextView`: `/// NSTextView (TextKit 1) with full-width row background painting and a`
- L6 `drawBackground`: `/// in `drawBackground(in:)` from the display-row table. (SPEC §11.4)`
- L7 `NSTextView`: `final class DiffTextView: NSTextView {`
- L10 `NSColor`: `var rowBackgrounds: [Int: NSColor] = [:]`
- L30 `drawBackground`: `override func drawBackground(in rect: NSRect) {`
- L31 `drawBackground`: `super.drawBackground(in: rect)`
- L37 `glyphRange`: `let glyphRange = lm.glyphRange(forBoundingRect: rect, in: tc)`
- L38 `glyphRange`: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- L38 `characterRange`: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- L62 `NSBezierPath`: `let path = NSBezierPath(roundedRect: outline, xRadius: 3, yRadius: 3)`
- L64 `NSColor`: `NSColor.controlAccentColor.setStroke()`
- L76 `lineFragmentRect`: `var frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)`
- L77 `textContainerOrigin`: `frag.origin.y += textContainerOrigin.y`
- L81 `NSTextView`: `/// Esc in read-only comparison panes navigates Back (NSTextView would`
- L84 `NSEvent`: `override func keyDown(with event: NSEvent) {`
- L93 `NSScrollView`: `static func makePane(editable: Bool) -> (scrollView: NSScrollView, textView: DiffTextView) {`
- L94 `NSScrollView`: `let scrollView = NSScrollView()`
- L106 `textContainerInset`: `textView.textContainerInset = NSSize(width: 4, height: 4)`
- L107 `autoresizingMask`: `textView.autoresizingMask = [.width]`
- L110 `isHorizontallyResizable`: `textView.isHorizontallyResizable = true`
- L111 `isVerticallyResizable`: `textView.isVerticallyResizable = true`
- L115 `widthTracksTextView`: `container.widthTracksTextView = false`
- L116 `containerSize`: `container.containerSize = NSSize(width: CGFloat.greatestFiniteMagnitude,`
- L126 `NSRulerView`: `final class LineNumberRuler: NSRulerView {`
- L133 `NSScrollView`: `init(scrollView: NSScrollView, textView: DiffTextView) {`
- L134 `orientation`: `super.init(scrollView: scrollView, orientation: .verticalRuler)`
- L144 `drawHashMarksAndLabels`: `override func drawHashMarksAndLabels(in rect: NSRect) {`
- L149 `visibleRect`: `let visibleRect = tv.visibleRect`
- L150 `glyphRange`: `let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)`
- L150 `visibleRect`: `let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)`
- L151 `glyphRange`: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- L151 `characterRange`: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- L154 `NSAttributedString`: `let attrs: [NSAttributedString.Key: Any] = [`
- L154 `NSAttributedString.Key`: `let attrs: [NSAttributedString.Key: Any] = [`
- L156 `NSColor`: `.foregroundColor: NSColor.secondaryLabelColor,`
- L165 `lineFragmentRect`: `let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)`
- L166 `textContainerOrigin`: `let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY`
- L166 `visibleRect`: `let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY`
- L167 `NSString`: `let label = labels[row] as NSString`
