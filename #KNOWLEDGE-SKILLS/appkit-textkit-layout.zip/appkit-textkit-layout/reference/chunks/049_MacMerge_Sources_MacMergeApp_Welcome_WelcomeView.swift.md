# Source Chunk: MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift

Roles: Support code

Lines: 158; bytes: 5260; imports: SwiftUI, SessionKit, UniformTypeIdentifiers

## Declarations
- struct `WelcomeView` inherits View
- struct `RecentRow` inherits View

## Functions
- `actionButton(_ title: String, symbol: String, action: @escaping ()`
- `handleDrop(_ providers: [NSItemProvider])`
- `loadURL(from provider: NSItemProvider)`

## Terms
- `MainActor` × 2
- `NSString` × 2
- `SwiftUI` × 1
- `Task` × 1

## Design comments
- L5: /// Welcome window (SPEC §5.1): actions, recents, and whole-window drop target.
- L6: /// Single drops fill slot A then B; two or three drops open immediately.

## Important AppKit/TextKit lines
- L1 `SwiftUI`: `import SwiftUI`
- L7 `MainActor`: `@MainActor`
- L102 `MainActor`: `Task { @MainActor in`
- L102 `Task`: `Task { @MainActor in`
- L132 `NSString`: `let left = (item.leftPath as NSString).lastPathComponent`
- L133 `NSString`: `let right = (item.rightPath as NSString).lastPathComponent`
