# Source Chunk: MacGit/Sources/MacGitApp/SocketBridge.swift

Roles: Support code

Lines: 273; bytes: 9175; imports: Foundation, SwiftUI

## Declarations
- struct `BridgeRequest` inherits Codable
- struct `BridgeResponse` inherits Codable
- class `SocketBridge` inherits ObservableObject
- struct `CommitMessageEditorSheet` inherits View
- struct `AskpassSheet` inherits View
- struct `SocketBridgePresentations` inherits ViewModifier

## Functions
- `start()`
- `stop()`
- `handleClient(_ fd: Int32)`
- `sendFrameIO(_ fd: Int32, _ data: Data)`
- `recvAllBytes(_ fd: Int32, _ buf: inout [UInt8], _ n: Int)`
- `sendAllBytes(_ fd: Int32, _ buf: UnsafeRawPointer, _ n: Int)`
- `body(content: Content)`

## Terms
- `Task` × 9
- `nonisolated` × 5
- `MainActor` × 1
- `NSString` × 1
- `ObservableObject` × 1
- `SwiftUI` × 1

## Design comments
- L4: // MARK: - Wire protocol
- L6: /// Simple length-prefixed framing over a UNIX domain socket.
- L7: /// Frame: 4-byte big-endian uint32 length + UTF-8 JSON payload.
- L8: /// Request JSON: {"type": "edit"|"askpass", "path": "...", "prompt": "..."}
- L9: /// Response JSON: {"ok": true|false, "value": "..."}
- L22: // MARK: - SocketBridge actor (app side)
- L24: /// Listens on a UNIX domain socket in TMPDIR and dispatches edit/askpass sheets.
- L25: /// The socket path is written to the environment so child processes can find it.
- L28: /// Single-item enum so only one bridge sheet is presented at a time.
- L59: // Maximum length of sun_path on Darwin is 104 bytes (including NUL terminator).
- L66: // Validate path length before bind() to avoid silent truncation.
- L117: // MARK: - Client handling
- L122: // Receive request off main actor — blocking recv must not block the UI thread.
- L128: // Present UI on main actor (we're already here).
- L144: // Send response off main actor.
- L151: // MARK: - Frame I/O (nonisolated static — safe to call from any executor)
- L189: // MARK: - Editor sheet
- L209: // Write the edited text back to disk; cli reads it.
- L224: // MARK: - Askpass sheet
- L251: // MARK: - SocketBridgePresentations ViewModifier

## Important AppKit/TextKit lines
- L2 `SwiftUI`: `import SwiftUI`
- L26 `MainActor`: `@MainActor`
- L27 `ObservableObject`: `final class SocketBridge: ObservableObject {`
- L56 `Task`: `private var acceptTask: Task<Void, Never>?`
- L64 `NSString`: `let path = (NSTemporaryDirectory() as NSString).appendingPathComponent("macgit-\(ProcessInfo.processInfo.processIdentifier).sock")`
- L95 `Task`: `acceptTask = Task.detached(priority: .background) { [weak self] in`
- L99 `Task`: `Task { [weak self] in await self?.handleClient(clientFD) }`
- L105 `Task`: `acceptTask?.cancel()`
- L106 `Task`: `acceptTask = nil`
- L123 `Task`: `let maybeRequest: BridgeRequest? = await Task.detached { () -> BridgeRequest? in`
- L147 `Task`: `await Task.detached { Self.sendFrameIO(fd, data) }.value`
- L151 `nonisolated`: `// MARK: - Frame I/O (nonisolated static — safe to call from any executor)`
- L153 `nonisolated`: `private nonisolated static func recvFrameIO<T: Decodable>(_ fd: Int32) -> T? {`
- L163 `nonisolated`: `private nonisolated static func sendFrameIO(_ fd: Int32, _ data: Data) {`
- L169 `nonisolated`: `private nonisolated static func recvAllBytes(_ fd: Int32, _ buf: inout [UInt8], _ n: Int) -> Int {`
- L179 `nonisolated`: `private nonisolated static func sendAllBytes(_ fd: Int32, _ buf: UnsafeRawPointer, _ n: Int) {`
