# Source Chunk: MacGit/Sources/MacGitCore/GraphLayout.swift

Roles: Core diff/text/git/model logic

Lines: 89; bytes: 3723; imports: Foundation

## Declarations
- enum `GraphLayout` 
- struct `Row` inherits Equatable, Sendable, Identifiable

## Functions
- `compute(_ commits: [Commit])`
- `firstFreeLane(_ active: [String?])`

## Terms

## Design comments
- L3: /// Incremental commit-graph lane assignment (SPEC §2.4, plan M1.4).
- L4: ///
- L5: /// Pure function `[Commit] -> [Row]`. Commits arrive newest-first (as `git log` emits them) and are
- L6: /// processed strictly top-to-bottom; each row's result depends only on the rows above it, never
- L7: /// below. That is the stability contract (R-0007-02): pages extend history *downward* (older commits
- L8: /// appended), so `compute(prefix + suffix)`'s first `prefix.count` rows are identical to
- L9: /// `compute(prefix)`. A commit that is a tip in an earlier page stays a tip.
- L10: ///
- L11: /// Lane assignment tracks, for each column, the SHA that column is "waiting to draw" (a child's
- L12: /// parent pointer). A commit takes the column waiting for it (the leftmost, if several children
- L13: /// converge), its first parent inherits that column, and additional parents fan out into free
- L14: /// columns — reusing an existing column when another commit already tracks that parent (merge
- L15: /// convergence). Color is a render concern (`lane % 8`, M3) and is intentionally absent here.
- L19: /// Column of the commit dot.
- L21: /// Column each parent occupies going down; drives merge fan-out lines.
- L23: /// Lane occupancy at the bottom edge of this row (index = column, nil = free). With the next
- L24: /// row's `lane`, this fully determines the edge segments crossing the gap.
- L46: // Converging children: free the other columns waiting for this commit.

## Important AppKit/TextKit lines
