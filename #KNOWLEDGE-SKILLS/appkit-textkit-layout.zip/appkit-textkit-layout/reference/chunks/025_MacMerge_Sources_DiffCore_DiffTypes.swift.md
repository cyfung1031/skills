# Source Chunk: MacMerge/Sources/DiffCore/DiffTypes.swift

Roles: Core diff/text/git/model logic

Lines: 84; bytes: 3309; imports: (none)

## Declarations
- enum `DiffAlgorithm` inherits String, Sendable, Codable, CaseIterable
- struct `DiffOptions` inherits Sendable
- enum `HunkKind` inherits Sendable, Equatable
- struct `Hunk` inherits Sendable, Equatable
- struct `DiffResult` inherits Sendable, Equatable

## Functions
- `change(left: Range<Int>, right: Range<Int>)`

## Terms
- `AppKit` × 1

## Design comments
- L1: /// DiffCore — pure diff engine. No AppKit, no I/O. (SPEC §11.1)
- L4: /// JGit-style histogram diff: anchor on low-occurrence common elements. Default.
- L6: /// Patience diff: anchor on unique common elements only.
- L8: /// Classic Myers O(ND). Exact, but capped by `myersMaxD`.
- L14: /// Histogram: max occurrences of an element before it is rejected as an anchor.
- L16: /// Myers: max edit distance explored before falling back to an approximate result.
- L18: /// Regions up to this combined size may fall back from histogram to Myers.
- L41: /// One contiguous region of the comparison. Hunks cover both inputs completely
- L42: /// and in order: concatenating all `left` ranges yields `0..<a.count`, and all
- L43: /// `right` ranges yields `0..<b.count`.
- L48: /// Replace hunks whose paired lines differ only in whitespace (e.g. a
- L49: /// re-indented block after extracting a function). Real but minor:
- L50: /// display layers demote these so content changes stand out.
- L61: /// Kind derived from range emptiness (insert/delete/replace) for non-equal hunks.
- L70: /// True when an algorithm cap was hit and part of the result is a coarse block replace.
- L80: /// How many of the changes are whitespace-only (subset of `changeCount`).

## Important AppKit/TextKit lines
- L1 `AppKit`: `/// DiffCore — pure diff engine. No AppKit, no I/O. (SPEC §11.1)`
