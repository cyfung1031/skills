# Source Chunk: MacMerge/Sources/GitSupport/Git.swift

Roles: Core diff/text/git/model logic

Lines: 99; bytes: 3918; imports: Foundation

## Declarations
- enum `GitError` inherits Error, LocalizedError
- enum `Git` 

## Functions
- `repositoryRoot(for url: URL)`
- `status(in root: URL)`
- `run(_ args: [String], cwd: URL?)`

## Terms
- `DispatchQueue` × 2

## Design comments
- L3: /// Git integration by shelling out to the user's git binary (SPEC §3.8,
- L4: /// decision log §17.3). Plumbing commands only, parsed defensively.
- L5: /// v0.1 surface: repository detection + porcelain status. Compare-against-
- L6: /// commit and mergetool installation build on this in later releases.
- L24: /// Returns the work-tree root containing `url`, or nil if not in a repo
- L25: /// (or git is unavailable).
- L38: /// `git status --porcelain -z` parsed into relativePath → XY status code.
- L53: // Rename/copy entries are followed by the original path as a separate record.
- L59: // MARK: - Subprocess plumbing
- L81: // Drain stdout and stderr concurrently to prevent pipe-buffer deadlock
- L82: // when either stream writes more than the kernel pipe buffer (~64 KB).

## Important AppKit/TextKit lines
- L86 `DispatchQueue`: `DispatchQueue.global().async {`
- L91 `DispatchQueue`: `DispatchQueue.global().async {`
