# Source Chunk: MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift

Roles: Markdown syntax highlighter

Lines: 307; bytes: 16133; imports: AppKit

## Declarations
- struct `SyntaxToken` 
- enum `MarkdownSyntaxHighlighter` 

## Functions
- `baseFont(size: Double = 13, family: String = "")`
- `boldFont(size: Double = 13, family: String = "")`
- `italicFont(size: Double = 13, family: String = "")`
- `collectTokensFull(
        text: String,
        fontSize: Double = 13,
        family: String = "",
        enabled: Bool = true,
       )`
- `collectTokensInline(
        text: String,
        paragraphRange: NSRange,
        fontSize: Double = 13,
        family: String = "",
    )`
- `applyTokens(_ tokens: [SyntaxToken], to storage: NSTextStorage)`
- `applyFull(
        _ storage: NSTextStorage,
        fontSize: Double = 13,
        family: String = "",
        enabled: Bool = t)`
- `applyInline(
        _ storage: NSTextStorage,
        fontSize: Double = 13,
        family: String = "",
        enabled: Bool = t)`
- `highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true)`
- `highlight(
        _ storage: NSTextStorage,
        fontSize: Double,
        family: String = "",
        enabled: Bool,
       )`
- `collect(
        _ regex: NSRegularExpression?,
        _ text: String,
        _ ns: NSString,
        _ range: NSRange,
      )`
- `collectDelimDim(
        _ regex: NSRegularExpression?,
        _ text: String,
        _ ns: NSString,
        _ range: NSRange,
      )`
- `collectHeadingWithDim(
        _ regex: NSRegularExpression?,
        _ text: String,
        _ ns: NSString,
        _ range: NSRange,
      )`

## Terms
- `NSColor` × 11
- `NSFont` × 11
- `NSRange` × 10
- `NSAttributedString` × 6
- `NSAttributedString.Key` × 6
- `NSString` × 6
- `NSTextStorage` × 5
- `endEditing` × 4
- `beginEditing` × 3
- `bestMatch` × 2
- `darkAqua` × 2
- `vibrantDark` × 2
- `AppKit` × 1
- `effectiveAppearance` × 1

## Design comments
- L3: // MARK: - Token type (produced by background thread, consumed on main thread)
- L12: // MARK: - Fonts
- L32: // MARK: - Dynamic code background (evaluates appearance at draw time, safe to store in tokens)
- L40: // MARK: - Pre-compiled patterns
- L64: // MARK: - Token collection (pure, thread-safe — operates on a String snapshot)
- L65: //
- L66: // Call these from any thread. Pre-create font and color objects on the main thread
- L67: // and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.
- L85: // Pre-size: 20 patterns × average 10 matches for a medium file → ~200 tokens typical
- L88: // Reset token covers the full document.
- L157: // Paragraph-level reset: foreground/font/strike only — do not touch .backgroundColor.
- L195: // Apply a pre-computed token array to storage.
- L196: // Must be called on the main thread; caller wraps in beginEditing/endEditing.
- L203: // MARK: - Full-document apply (convenience — still runs on caller's thread)
- L217: // MARK: - Paragraph-level apply (convenience — still runs on caller's thread)
- L234: // MARK: - Public highlight wrappers (with begin/endEditing — for external callers)
- L254: // MARK: - Private collect helpers (thread-safe; operate on a pre-bridged NSString)

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L6 `NSRange`: `let range: NSRange`
- L7 `NSAttributedString`: `let attributes: [NSAttributedString.Key: Any]`
- L7 `NSAttributedString.Key`: `let attributes: [NSAttributedString.Key: Any]`
- L14 `NSFont`: `static func baseFont(size: Double = 13, family: String = "") -> NSFont {`
- L15 `NSFont`: `if !family.isEmpty, let f = NSFont(name: family, size: size) { return f }`
- L16 `NSFont`: `return NSFont.monospacedSystemFont(ofSize: size, weight: .regular)`
- L19 `NSFont`: `private static func boldFont(size: Double = 13, family: String = "") -> NSFont {`
- L21 `NSFont`: `let base = NSFont(name: family, size: size) ?? NSFont.monospacedSystemFont(ofSize: size, weight: .regular)`
- L22 `NSFont`: `return NSFontManager.shared.convert(base, toHaveTrait: .boldFontMask)`
- L24 `NSFont`: `return NSFont.monospacedSystemFont(ofSize: size, weight: .bold)`
- L27 `NSFont`: `private static func italicFont(size: Double = 13, family: String = "") -> NSFont {`
- L29 `NSFont`: `return NSFontManager.shared.convert(base, toHaveTrait: .italicFontMask)`
- L34 `NSColor`: `private static let codeBackground = NSColor(name: nil) { app in`
- L35 `bestMatch`: `app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L35 `darkAqua`: `app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L35 `vibrantDark`: `app.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L36 `NSColor`: `? NSColor(white: 1.0, alpha: 0.09)`
- L37 `NSColor`: `: NSColor(white: 0.0, alpha: 0.06)`
- L67 `NSColor`: `// and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.`
- L67 `NSFont`: `// and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.`
- L77 `NSString`: `let ns       = text as NSString`
- L79 `NSRange`: `let fullRange = NSRange(location: 0, length: fullLen)`
- L91 `NSColor`: `.foregroundColor: NSColor.labelColor,`
- L93 `NSColor`: `.backgroundColor: NSColor.clear`
- L103 `NSColor`: `collect(reHRule,         text, ns, fullRange, attrs: [.foregroundColor: NSColor.tertiaryLabelColor], into: &tokens)`
- L136 `NSRange`: `paragraphRange: NSRange,`
- L142 `NSString`: `let ns      = text as NSString`
- L148 `NSRange`: `let safe = NSRange(location: loc, length: len)`
- L160 `NSColor`: `.foregroundColor: NSColor.labelColor,`
- L166 `NSColor`: `collect(reHRule, text, ns, safe, attrs: [.foregroundColor: NSColor.tertiaryLabelColor], into: &tokens)`
- L196 `beginEditing`: `// Must be called on the main thread; caller wraps in beginEditing/endEditing.`
- L196 `endEditing`: `// Must be called on the main thread; caller wraps in beginEditing/endEditing.`
- L197 `NSTextStorage`: `static func applyTokens(_ tokens: [SyntaxToken], to storage: NSTextStorage) {`
- L206 `NSTextStorage`: `_ storage: NSTextStorage,`
- L220 `NSTextStorage`: `_ storage: NSTextStorage,`
- L225 `NSRange`: `paragraphRange: NSRange`
- L229 `beginEditing`: `storage.beginEditing()`
- L231 `endEditing`: `storage.endEditing()`
- L234 `endEditing`: `// MARK: - Public highlight wrappers (with begin/endEditing — for external callers)`
- L236 `NSTextStorage`: `static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {`
- L237 `effectiveAppearance`: `let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L237 `bestMatch`: `let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L237 `darkAqua`: `let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L237 `vibrantDark`: `let isDark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L243 `NSTextStorage`: `_ storage: NSTextStorage,`
- L249 `beginEditing`: `storage.beginEditing()`
- L251 `endEditing`: `storage.endEditing()`
- L254 `NSString`: `// MARK: - Private collect helpers (thread-safe; operate on a pre-bridged NSString)`
- L259 `NSString`: `_ ns: NSString,`
- L260 `NSRange`: `_ range: NSRange,`
- L261 `NSAttributedString`: `attrs: [NSAttributedString.Key: Any],`
- L261 `NSAttributedString.Key`: `attrs: [NSAttributedString.Key: Any],`
- L273 `NSString`: `_ ns: NSString,`
- L274 `NSRange`: `_ range: NSRange,`
- L275 `NSAttributedString`: `contentAttrs: [NSAttributedString.Key: Any],`
- L275 `NSAttributedString.Key`: `contentAttrs: [NSAttributedString.Key: Any],`
- L280 `NSAttributedString`: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- L280 `NSAttributedString.Key`: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- L280 `NSColor`: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- L284 `NSRange`: `tokens.append(SyntaxToken(range: NSRange(location: r.location, length: delimLen), attributes: dim))`
- L285 `NSRange`: `tokens.append(SyntaxToken(range: NSRange(location: NSMaxRange(r) - delimLen, length: delimLen), attributes: dim))`
- L292 `NSString`: `_ ns: NSString,`
- L293 `NSRange`: `_ range: NSRange,`
- L294 `NSAttributedString`: `textAttrs: [NSAttributedString.Key: Any],`
- L294 `NSAttributedString.Key`: `textAttrs: [NSAttributedString.Key: Any],`
- L298 `NSAttributedString`: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- L298 `NSAttributedString.Key`: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- L298 `NSColor`: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
