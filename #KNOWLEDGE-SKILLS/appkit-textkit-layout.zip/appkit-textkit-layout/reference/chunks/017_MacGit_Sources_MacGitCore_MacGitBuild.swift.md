# Source Chunk: MacGit/Sources/MacGitCore/MacGitBuild.swift

Roles: Core diff/text/git/model logic

Lines: 6; bytes: 227; imports: (none)

## Declarations
- enum `MacGitBuild` 

## Functions

## Terms

## Design comments

## Important AppKit/TextKit lines
