# Source Chunk: MacMerge/Sources/TextEngine/HexDump.swift

Roles: Core diff/text/git/model logic

Lines: 53; bytes: 1892; imports: Foundation

## Declarations
- enum `HexDump` 

## Functions
- `lines(_ data: Data)`

## Terms

## Design comments
- L3: /// Hex-dump row rendering for the binary comparison view (SPEC §3.5).
- L4: /// Rows are plain strings so the standard line-diff pipeline aligns and
- L5: /// highlights them; byte-insertion re-alignment (rolling-hash anchors) is a
- L6: /// later-release refinement.
- L11: /// `00000010  48 65 6C 6C 6F 20 57 6F  72 6C 64 21 0A 00 00 00  |Hello World!....|`

## Important AppKit/TextKit lines
