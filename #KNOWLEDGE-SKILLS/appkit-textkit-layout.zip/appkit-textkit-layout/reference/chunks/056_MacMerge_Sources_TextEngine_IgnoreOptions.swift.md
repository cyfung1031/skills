# Source Chunk: MacMerge/Sources/TextEngine/IgnoreOptions.swift

Roles: Core diff/text/git/model logic

Lines: 42; bytes: 1367; imports: Foundation

## Declarations
- struct `IgnoreOptions` inherits Sendable, Codable, Equatable
- enum `Whitespace` inherits String, Sendable, Codable

## Functions
- `key(for line: String)`
- `keys(for lines: [String])`

## Terms

## Design comments
- L3: /// Comparison-time normalization (SPEC §3.2 "ignore options"). Diffing runs
- L4: /// on normalized keys; display always shows raw content. Blank-line ignoring
- L5: /// and regex line rules are later-release additions.
- L24: /// Normalized comparison key for one line.

## Important AppKit/TextKit lines
