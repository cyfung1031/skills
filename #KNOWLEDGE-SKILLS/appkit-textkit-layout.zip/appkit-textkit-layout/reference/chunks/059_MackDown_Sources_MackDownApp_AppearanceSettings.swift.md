# Source Chunk: MackDown/Sources/MackDownApp/AppearanceSettings.swift

Roles: Support code

Lines: 262; bytes: 10158; imports: AppKit, SwiftUI

## Declarations
- struct `SyntaxHighlightColors` 
- extension `NSColor` 
- extension `Color` 
- class `AppearanceSettings` inherits ObservableObject

## Functions
- `resetSyntaxColors(dark: Bool)`
- `syntaxColors(dark isDark: Bool)`
- `c(_ light: String, _ dark: String)`

## Terms
- `NSColor` × 7
- `bestMatch` × 2
- `darkAqua` × 2
- `vibrantDark` × 2
- `AppKit` × 1
- `ObservableObject` × 1
- `SwiftUI` × 1
- `effectiveAppearance` × 1

## Design comments
- L4: // MARK: - Syntax highlight color set
- L10: // MARK: - Color hex helpers
- L41: // MARK: - Appearance settings
- L46: // MARK: General
- L49: // MARK: Paper / Preview
- L58: // MARK: Editor
- L64: // MARK: Syntax highlight colors — light mode (muted, eye-friendly for light backgrounds)
- L75: // MARK: Syntax highlight colors — dark mode (VS Code One Dark inspired)
- L86: // MARK: Curated font lists for pickers
- L105: // MARK: Default hex values (for "Reset to defaults")
- L149: // MARK: - App theme
- L177: // MARK: - Paper color
- L198: // White in light mode; system window background (dark-gray) in dark mode.
- L243: // MARK: - Outline display

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L2 `SwiftUI`: `import SwiftUI`
- L7 `NSColor`: `var heading, code, italic, link, blockquote, listMarker, strikethrough, frontMatter, image: NSColor`
- L12 `NSColor`: `extension NSColor {`
- L35 `NSColor`: `guard let ns = NSColor(hex: hex) else { return nil }`
- L38 `NSColor`: `var hexString: String { NSColor(self).hexString }`
- L43 `ObservableObject`: `final class AppearanceSettings: ObservableObject {`
- L133 `NSColor`: `func c(_ light: String, _ dark: String) -> NSColor {`
- L134 `NSColor`: `NSColor(hex: isDark ? dark : light) ?? .labelColor`
- L199 `NSColor`: `case .adaptive: return Color(nsColor: NSColor(name: nil) { t in`
- L200 `bestMatch`: `t.bestMatch(from: [.darkAqua, .vibrantDark]) != nil ? .windowBackgroundColor : .white`
- L200 `darkAqua`: `t.bestMatch(from: [.darkAqua, .vibrantDark]) != nil ? .windowBackgroundColor : .white`
- L200 `vibrantDark`: `t.bestMatch(from: [.darkAqua, .vibrantDark]) != nil ? .windowBackgroundColor : .white`
- L233 `effectiveAppearance`: `return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L233 `bestMatch`: `return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L233 `darkAqua`: `return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
- L233 `vibrantDark`: `return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .vibrantDark]) != nil`
