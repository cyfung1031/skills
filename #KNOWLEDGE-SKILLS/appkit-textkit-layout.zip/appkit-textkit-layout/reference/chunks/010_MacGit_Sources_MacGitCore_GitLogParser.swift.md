# Source Chunk: MacGit/Sources/MacGitCore/GitLogParser.swift

Roles: Core diff/text/git/model logic

Lines: 68; bytes: 2500; imports: Foundation

## Declarations
- enum `GitLogParser` 

## Functions
- `parse(_ output: String)`

## Terms

## Design comments
- L3: /// Pure `String -> [Commit]` parser for `git log` output (SPEC §6.2: machine-readable format only).
- L4: ///
- L5: /// Format (R-0001-02): each field is `%x00`-separated and `-z` terminates each commit record with a
- L6: /// trailing NUL, so the whole stream is NUL-separated tokens grouped `fieldCount` at a time. The
- L7: /// scheme is unambiguous because none of the fields can contain a NUL: `%s` is the single-line
- L8: /// subject, `%P` is a space-separated SHA list, and `%aI` is strict ISO-8601.
- L10: /// `sha \0 parents \0 authorName \0 authorEmail \0 authorDateISO \0 subject`
- L21: // `-z` terminates the final record too, leaving a trailing empty token.

## Important AppKit/TextKit lines
