# Source Chunk: MacGit/Sources/macgit-cli/main.swift

Roles: Core diff/text/git/model logic

Lines: 498; bytes: 18161; imports: Foundation, MacGitCore

## Declarations
- struct `BridgeCLIRequest` inherits Codable
- struct `BridgeCLIResponse` inherits Codable

## Functions
- `writeStderr(_ message: String)`
- `bridgeRoundtrip(socketPath: String, request: BridgeCLIRequest)`
- `recvAllBytes(_ fd: Int32, _ buf: inout [UInt8], _ n: Int)`
- `sendAllBytes(_ fd: Int32, _ buf: UnsafeRawPointer, _ n: Int)`

## Terms

## Design comments
- L10: // MARK: - Bridge IPC helpers (used by _edit and _askpass)
- L23: /// Synchronous round-trip: send request frame, receive response frame.
- L48: // Read response.
- L77: // MARK: - Commands
- L434: // Called by git as GIT_EDITOR: open a native editor sheet in MacGitApp.
- L435: // Usage: macgit-cli _edit <file>
- L449: // Called by git as GIT_ASKPASS: prompt for a credential.
- L450: // Usage: macgit-cli _askpass <prompt>

## Important AppKit/TextKit lines
