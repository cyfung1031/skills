# Source Chunk: MacMerge/Sources/DiffCore/Differ.swift

Roles: Core diff/text/git/model logic

Lines: 287; bytes: 11963; imports: (none)

## Declarations
- enum `Differ` 

## Functions
- `longestIncreasingChain(_ pairs: [(i: Int, j: Int)`
- `normalized(_ hunks: [Hunk])`
- `hunks(
        fromMatches matches: [(Int, Int)`

## Terms

## Design comments
- L1: /// Entry point for sequence diffs. Operates on any Hashable element type
- L2: /// (lines, words, tokens, bytes). Ignore rules are applied by the caller via
- L3: /// normalization — pass pre-normalized keys and display the raw content.
- L30: // MARK: - Histogram (default; patience = occurrence cap 1)
- L41: // Common prefix.
- L48: // Common suffix (emitted after the middle).
- L72: // Occurrence counts on BOTH sides. A single greedy anchor chosen
- L73: // from one side's counts can pair an element with an unrelated
- L74: // occurrence far away on the other side; one such crossing match
- L75: // folds everything between into one-sided blocks (seen in practice:
- L76: // a field unique in A anchored to an early duplicate in B, hiding
- L77: // 500+ surviving lines).
- L97: // Patience skeleton: elements unique on both sides, restricted to
- L98: // a longest non-crossing chain — moved lines drop out of the
- L99: // skeleton instead of forcing a crossing alignment.
- L111: // Free the indexes before recursing: gap regions rebuild
- L112: // their own, and holding these across recursion makes peak
- L113: // memory quadratic in pathological inputs.
- L128: // No unique-unique element: histogram fallback — anchor on the
- L129: // element rarest across both sides (a one-sided count invites the
- L130: // crossing failure above).
- L143: // No shared element at all: a block replace is exact, not approximate.
- L155: // Extend the anchor to its maximal equal run.
- L172: /// Longest chain of pairs ascending in both coordinates. Input is
- L173: /// ascending in `.i` with distinct `.j` values, so this is the classic
- L174: /// O(n log n) LIS over `.j` with parent links.
- L203: // MARK: - Myers (top level)
- L229: // MARK: - Normalization
- L231: /// Merges adjacent mergeable hunks, recomputes canonical kinds, drops empties.
- L258: /// Builds covering hunks from an ascending list of matched index pairs.

## Important AppKit/TextKit lines
