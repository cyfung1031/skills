# Source Chunk: MacMerge/Sources/FolderCompareKit/FolderScanner.swift

Roles: Core diff/text/git/model logic

Lines: 324; bytes: 13102; imports: Foundation

## Declarations
- enum `FolderScanner` 
- struct `Listing` 
- class `NormalizedByteReader` 

## Functions
- `scan(left: URL, right: URL, options: ScanOptions = ScanOptions()`
- `fileResourceID(_ url: URL)`
- `summary(of root: FolderEntry)`
- `walk(_ entry: FolderEntry)`
- `scanDirectory(
        name: String, relativePath: String,
        left: URL?, right: URL?,
        leftExists: Bool, rightExists: Boo)`
- `directoryStatus(leftExists: Bool, rightExists: Bool, children: [FolderEntry])`
- `list(_ url: URL, options: ScanOptions)`
- `globMatches(_ pattern: String, _ name: String)`
- `fileStatus(
        leftURL: URL, leftMeta: FileMeta,
        rightURL: URL, rightMeta: FileMeta,
        options: ScanOptions
    )`
- `byteCompare(_ a: URL, _ b: URL)`
- `normalizedCompare(_ a: URL, _ b: URL)`
- `nextRaw()`
- `next()`

## Terms
- `Task` × 5

## Design comments
- L3: /// Recursive two-root scanner. Synchronous; run it inside a Task and it
- L4: /// honors cooperative cancellation. v0.1 returns the complete tree;
- L5: /// streaming row delivery (SPEC §3.4) comes with the virtualized UI.
- L36: // MARK: - Directory recursion
- L76: // Names that are a dir on one side and a file on the other are type
- L77: // conflicts — emit one error entry and exclude from both loops.
- L94: // Symlink cycle detection: track visited file-resource IDs.
- L119: // Patch in this directory's own meta/one-sidedness.
- L215: // MARK: - File comparison
- L222: // Symlinks compare by target path; EOL normalization doesn't apply.
- L232: // Normalized-equal: only byte equality distinguishes identical
- L233: // from equivalent, and only same-size pairs can be byte-equal.
- L263: /// Streamed comparison with CRLF/CR → LF normalization on both sides.
- L279: /// Buffered byte stream that yields CRLF and lone CR as a single LF.

## Important AppKit/TextKit lines
- L3 `Task`: `/// Recursive two-root scanner. Synchronous; run it inside a Task and it`
- L51 `Task`: `try Task.checkCancellation()`
- L129 `Task`: `try Task.checkCancellation()`
- L255 `Task`: `try Task.checkCancellation()`
- L270 `Task`: `if iterations & 0xFFFF == 0 { try Task.checkCancellation() }`
