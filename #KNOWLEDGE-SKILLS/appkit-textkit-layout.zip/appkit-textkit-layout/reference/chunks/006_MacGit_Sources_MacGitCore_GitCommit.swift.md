# Source Chunk: MacGit/Sources/MacGitCore/GitCommit.swift

Roles: Core diff/text/git/model logic

Lines: 62; bytes: 2443; imports: Foundation

## Declarations
- extension `GitClient` 

## Functions
- `stageAll(in repositoryURL: URL)`
- `stage(paths: [String], in repositoryURL: URL)`
- `unstage(paths: [String], in repositoryURL: URL)`
- `commit(message: String, in repositoryURL: URL)`
- `commitAll(message: String, in repositoryURL: URL)`
- `commitAmend(message: String, in repositoryURL: URL)`
- `hasHead(in repositoryURL: URL)`

## Terms

## Design comments

## Important AppKit/TextKit lines
