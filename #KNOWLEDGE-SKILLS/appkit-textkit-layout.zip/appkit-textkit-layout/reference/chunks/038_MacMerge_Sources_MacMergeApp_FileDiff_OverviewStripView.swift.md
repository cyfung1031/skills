# Source Chunk: MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift

Roles: Overview strip custom NSView

Lines: 60; bytes: 2088; imports: AppKit

## Declarations
- class `OverviewStripView` inherits NSView

## Functions
- `draw(_ dirtyRect: NSRect)`
- `mouseDown(with event: NSEvent)`
- `mouseDragged(with event: NSEvent)`
- `jump(to event: NSEvent)`

## Terms
- `NSColor` × 3
- `NSEvent` × 3
- `NSView` × 2
- `AppKit` × 1
- `draw(_` × 1

## Design comments
- L3: /// Whole-document map of change positions on the trailing edge (SPEC §5.3).
- L4: /// Click or drag to jump.
- L14: /// Currently visible display-row span (viewport indicator).
- L29: // Mark colors arrive with their final alpha (demoted marks are
- L30: // pre-dimmed by the caller).

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L5 `NSView`: `final class OverviewStripView: NSView {`
- L9 `NSColor`: `var color: NSColor`
- L20 `NSView`: `override var intrinsicContentSize: NSSize { NSSize(width: 14, height: NSView.noIntrinsicMetric) }`
- L22 `draw(_`: `override func draw(_ dirtyRect: NSRect) {`
- L23 `NSColor`: `NSColor.windowBackgroundColor.setFill()`
- L41 `NSColor`: `NSColor.secondaryLabelColor.withAlphaComponent(0.35).setFill()`
- L46 `NSEvent`: `override func mouseDown(with event: NSEvent) {`
- L50 `NSEvent`: `override func mouseDragged(with event: NSEvent) {`
- L54 `NSEvent`: `private func jump(to event: NSEvent) {`
