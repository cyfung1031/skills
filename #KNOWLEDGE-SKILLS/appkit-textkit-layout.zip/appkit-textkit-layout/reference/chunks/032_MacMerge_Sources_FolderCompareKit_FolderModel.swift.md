# Source Chunk: MacMerge/Sources/FolderCompareKit/FolderModel.swift

Roles: Core diff/text/git/model logic

Lines: 107; bytes: 3374; imports: Foundation

## Declarations
- struct `FileMeta` inherits Sendable, Equatable
- enum `EntryStatus` inherits Sendable, Equatable
- class `FolderEntry` inherits @unchecked Sendable
- struct `ScanSummary` inherits Sendable, Equatable
- struct `ScanOptions` inherits Sendable
- enum `Criteria` inherits String, Sendable

## Functions
- `count(_ entry: FolderEntry)`

## Terms

## Design comments
- L3: /// Folder comparison model (SPEC §11.3).
- L19: /// Equal only under active comparison options (e.g. ignoring line
- L20: /// endings) — the raw bytes differ. (SPEC §3.4 "equivalent")
- L28: /// One aligned row of the comparison tree. Built once on a background task,
- L29: /// then treated as immutable by the UI (hence @unchecked Sendable).
- L79: /// Equal size + equal modification date ⇒ identical.
- L81: /// Equal size + streamed byte-by-byte content comparison.
- L86: /// Glob patterns matched against entry *names* (fnmatch).
- L89: /// Treat CRLF/CR as LF when comparing content. Files equal only after
- L90: /// normalization are classified `.equivalent`. Forces content
- L91: /// comparison even under `.quick` criteria.

## Important AppKit/TextKit lines
