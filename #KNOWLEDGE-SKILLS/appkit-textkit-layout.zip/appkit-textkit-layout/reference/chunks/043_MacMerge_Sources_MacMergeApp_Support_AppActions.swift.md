# Source Chunk: MacMerge/Sources/MacMergeApp/Support/AppActions.swift

Roles: Support code

Lines: 67; bytes: 2187; imports: AppKit, SessionKit, UniformTypeIdentifiers

## Declarations
- enum `AppActions` 
- enum `Pickers` 
- enum `SessionWriter` 

## Functions
- `newComparison()`
- `threeWayMerge()`
- `openSession()`
- `pickOne(message: String, allowedExtensions: [String]? = nil)`
- `save(_ session: ComparisonSession, suggestedName: String, in window: NSWindow?)`

## Terms
- `MainActor` × 3
- `AppKit` × 1
- `NSAlert` × 1
- `NSOpenPanel` × 1
- `NSSavePanel` × 1
- `NSWindow` × 1

## Design comments
- L5: /// Shared entry points used by both the menu bar and the Welcome window.
- L44: /// Save-panel helper for `.mmsession` documents.

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L6 `MainActor`: `@MainActor`
- L26 `MainActor`: `@MainActor`
- L30 `NSOpenPanel`: `let panel = NSOpenPanel()`
- L45 `MainActor`: `@MainActor`
- L47 `NSWindow`: `static func save(_ session: ComparisonSession, suggestedName: String, in window: NSWindow?) {`
- L48 `NSSavePanel`: `let panel = NSSavePanel()`
- L58 `NSAlert`: `NSAlert(error: error).runModal()`
