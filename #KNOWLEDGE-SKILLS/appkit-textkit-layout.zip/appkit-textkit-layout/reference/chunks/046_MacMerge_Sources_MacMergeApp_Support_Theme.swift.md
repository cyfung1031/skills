# Source Chunk: MacMerge/Sources/MacMergeApp/Support/Theme.swift

Roles: Support code

Lines: 61; bytes: 3149; imports: AppKit, SyntaxKit

## Declarations
- enum `Theme` 

## Functions
- `dynamic(light: NSColor, dark: NSColor)`
- `rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat)`
- `color(for tokenKind: TokenKind)`

## Terms
- `NSColor` × 11
- `NSFont` × 2
- `darkAqua` × 2
- `AppKit` × 1
- `bestMatch` × 1

## Design comments
- L4: /// Semantic, dark-mode-aware colors (SPEC §5.3). Backgrounds carry diff
- L5: /// state; text color stays free for syntax highlighting. User-overridable
- L6: /// palettes arrive with the Settings window in a later release.
- L20: // Row backgrounds
- L24: /// Whitespace-only changed rows (re-indented blocks): a whisper of the
- L25: /// changed tint so a 100-line extraction doesn't read as 100 edits.
- L30: // Intra-line emphasis
- L34: /// Marks the whitespace delta itself on whitespace-only rows — softer
- L35: /// than the red/green emphasis used for content edits.
- L38: // Overview strip / status glyph accents
- L44: // Syntax (placeholder palette for SyntaxKit's keyword tokenizer)

## Important AppKit/TextKit lines
- L1 `AppKit`: `import AppKit`
- L10 `NSColor`: `static func dynamic(light: NSColor, dark: NSColor) -> NSColor {`
- L11 `NSColor`: `NSColor(name: nil) { appearance in`
- L12 `bestMatch`: `appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua ? dark : light`
- L12 `darkAqua`: `appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua ? dark : light`
- L16 `NSColor`: `private static func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> NSColor {`
- L17 `NSColor`: `NSColor(srgbRed: r, green: g, blue: b, alpha: 1)`
- L39 `NSColor`: `static let addedAccent = NSColor.systemGreen`
- L40 `NSColor`: `static let removedAccent = NSColor.systemRed`
- L41 `NSColor`: `static let changedAccent = NSColor.systemBlue`
- L42 `NSColor`: `static let conflictAccent = NSColor.systemOrange`
- L50 `NSColor`: `static func color(for tokenKind: TokenKind) -> NSColor {`
- L59 `NSFont`: `static let editorFont = NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)`
- L60 `NSFont`: `static let lineNumberFont = NSFont.monospacedDigitSystemFont(ofSize: 10, weight: .regular)`
