# API Glossary and Source Locations (Generated)


## `NSAlert`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L280: `let alert = NSAlert(error: error)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L588: `let alert = NSAlert()`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L617: `NSAlert(error: error).runModal()`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L231: `NSAlert(error: error).runModal()`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L422: `NSAlert(error: error).runModal()`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L244: `NSAlert(error: error).runModal()`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L337: `NSAlert(error: error).runModal()`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L343: `let alert = NSAlert()`
- `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L58: `NSAlert(error: error).runModal()`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L171: `NSAlert(error: error).runModal()`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L230: `let alert = NSAlert()`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L229: `let alert = NSAlert()`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L366: `let alert = NSAlert()`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L430: `let alert = NSAlert()`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSAttributedString`

Carries fonts/colors plus app-specific semantic keys for custom layout manager drawing and link actions.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L154: `let attrs: [NSAttributedString.Key: Any] = [`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L9: `var attributed: NSAttributedString`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L125: `let baseAttributes: [NSAttributedString.Key: Any] = [`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L145: `let attr = NSAttributedString(string: marker + "\n", attributes: [`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L146: `private(set) var parsedAttributed: NSAttributedString = NSAttributedString() {`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L274: `parsedAttributed   = NSAttributedString()`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L315: `parsedAttributed   = NSAttributedString()`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L340: `parsedAttributed   = NSAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L12: `extension NSAttributedString.Key {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L13: `static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L14: `static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L15: `static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L16: `static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L17: `static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L33: `// NSObject wrapper so NSAttributedString can store/copy the array safely.`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L142: `baseURL: URL? = nil) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L165: `func render(from source: String) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L176: `private func renderBlock(_ markup: any Markup) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L204: `private func renderInline(_ markup: any Markup) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L206: `case let t  as MDText:        return NSAttributedString(string: t.string)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L207: `case is SoftBreak:            return NSAttributedString(string: " ")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L208: `case is LineBreak:            return NSAttributedString(string: "\n")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L215: `case let ih as InlineHTML:    return NSAttributedString(string: ih.rawHTML)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L225: `private func renderHeadingRule() -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L232: `return NSAttributedString(string: " \n", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L240: `private func renderHeading(_ heading: Heading) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L255: `result.append(NSAttributedString(string: "\n"))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L265: `private func renderParagraph(_ paragraph: Paragraph) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L268: `result.append(NSAttributedString(string: "\n"))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L278: `private func renderCodeBlock(_ block: CodeBlock) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L283: `private func renderCodeBlock(language: String?, code: String) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L340: `private func renderBlockQuote(_ blockQuote: BlockQuote, depth: Int) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L382: `private func renderUnorderedList(_ list: UnorderedList, depth: Int) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L394: `private func renderOrderedList(_ list: OrderedList, depth: Int) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L404: `private func renderBulletItem(_ item: ListItem, depth: Int) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L407: `let baseAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L415: `str.append(NSAttributedString(string: "•\t",`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L420: `str.append(NSAttributedString(string: "\n"))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L432: `private func renderOrderedItem(_ item: ListItem, number: Int, depth: Int) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L435: `let baseAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L443: `str.append(NSAttributedString(string: "\(number).\t",`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L448: `str.append(NSAttributedString(string: "\n"))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L460: `private func renderTaskItem(_ item: ListItem) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L467: `let baseAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L470: `let cbAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L477: `result.append(NSAttributedString(string: checkChar + "\t", attributes: cbAttrs))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L491: `result.append(NSAttributedString(string: "\n"))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L500: `private func renderTable(_ table: MDTable) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L514: `guard colCount > 0 else { return NSAttributedString() }`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L567: `content.append(NSAttributedString(string: "\n"))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L571: `output.append(NSAttributedString(string: "\n", attributes: [.font: theme.bodyFont]))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L577: `private func renderThematicBreak() -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L584: `return NSAttributedString(string: " \n", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L594: `private func renderFrontMatter(_ fm: FrontMatter) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L610: `line.append(NSAttributedString(string: value + "\n", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L618: `result.append(NSAttributedString(string: "\n", attributes: [.font: theme.bodyFont]))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L624: `private func applyBold(_ str: NSMutableAttributedString) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L633: `private func applyItalic(_ str: NSMutableAttributedString) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L644: `private func applyStrikethrough(_ str: NSMutableAttributedString) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L650: `private func renderInlineCode(_ code: InlineCode) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L651: `NSAttributedString(string: code.code, attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L658: `private func renderLink(_ link: MDLink) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L670: `private func renderImage(_ image: MDImage) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L687: `return NSAttributedString(attachment: attachment)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L691: `return NSAttributedString(string: alt.isEmpty ? "🖼" : "[\(alt)]", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L7: `let attributedString:  NSAttributedString`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L12: `init(attributedString: NSAttributedString,`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L110: `weak var lastAttributedString: NSAttributedString?`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L7: `let attributes: [NSAttributedString.Key: Any]`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L261: `attrs: [NSAttributedString.Key: Any],`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L275: `contentAttrs: [NSAttributedString.Key: Any],`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L280: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L294: `textAttrs: [NSAttributedString.Key: Any],`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L298: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSAttributedString.Key`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L154: `let attrs: [NSAttributedString.Key: Any] = [`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L125: `let baseAttributes: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L12: `extension NSAttributedString.Key {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L13: `static let markdownBlockBackground  = NSAttributedString.Key("com.mackdown.blockBackground")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L14: `static let markdownBlockLeftBorders = NSAttributedString.Key("com.mackdown.blockLeftBorders")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L15: `static let markdownCopyCode         = NSAttributedString.Key("com.mackdown.copyCode")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L16: `static let markdownInlineCode       = NSAttributedString.Key("com.mackdown.inlineCode")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L17: `static let markdownHeadingTitle     = NSAttributedString.Key("com.mackdown.headingTitle")`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L407: `let baseAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L435: `let baseAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L467: `let baseAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L470: `let cbAttrs: [NSAttributedString.Key: Any] = [`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L7: `let attributes: [NSAttributedString.Key: Any]`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L261: `attrs: [NSAttributedString.Key: Any],`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L275: `contentAttrs: [NSAttributedString.Key: Any],`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L280: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L294: `textAttrs: [NSAttributedString.Key: Any],`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L298: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSBezierPath`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L62: `let path = NSBezierPath(roundedRect: outline, xRadius: 3, yRadius: 3)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L62: `let path = NSBezierPath(roundedRect: rect, xRadius: 6, yRadius: 6)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L66: `let bp = NSBezierPath(roundedRect: rect.insetBy(dx: 0.5, dy: 0.5), xRadius: 6, yRadius: 6)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L104: `NSBezierPath(rect: barRect).fill()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L127: `let path = NSBezierPath(roundedRect: r, xRadius: 3, yRadius: 3)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSButton`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L57: `private var backButton: NSButton!`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L58: `private var prevFileButton: NSButton!`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L59: `private var nextFileButton: NSButton!`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L190: `private func symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector) -> NSButton {`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L192: `let button = NSButton(image: image, target: self, action: action)`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L56: `private var flattenCheckbox: NSButton!`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L102: `flattenCheckbox = NSButton(checkboxWithTitle: "Flatten", target: self, action: #selector(flattenChanged(_:)))`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L106: `let backButton = NSButton(image: backImage, target: self, action: #selector(goBack(_:)))`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L111: `let refreshButton = NSButton(image: refreshImage, target: self, action: #selector(refresh(_:)))`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L336: `@objc private func flattenChanged(_ sender: NSButton) {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L127: `let saveButton = NSButton(title: "Save Output", target: self, action: #selector(saveOutput(_:)))`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L159: `private func symbolButton(_ symbol: String, _ tooltip: String, _ action: Selector) -> NSButton {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L161: `let button = NSButton(image: image, target: self, action: action)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSColor`

AppKit color type; use semantic and dynamic colors for appearance correctness.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2191: `v.layer?.backgroundColor = NSColor.secondaryLabelColor.withAlphaComponent(alpha).cgColor`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2260: `let bg: NSColor`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2262: `case .added:   bg = NSColor.systemGreen.withAlphaComponent(0.15)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2263: `case .removed: bg = NSColor.systemRed.withAlphaComponent(0.15)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2270: `let markerColor: NSColor`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L10: `var rowBackgrounds: [Int: NSColor] = [:]`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L64: `NSColor.controlAccentColor.setStroke()`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L156: `.foregroundColor: NSColor.secondaryLabelColor,`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L371: `let color: NSColor`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L9: `var color: NSColor`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L23: `NSColor.windowBackgroundColor.setFill()`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L41: `NSColor.secondaryLabelColor.withAlphaComponent(0.35).setFill()`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L11: `var rowBackgrounds: [Int: NSColor]`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L82: `lineBackgrounds: [Int: NSColor]`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L100: `) -> NSColor? {`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L127: `.foregroundColor: NSColor.textColor,`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L131: `var backgrounds: [Int: NSColor] = [:]`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L147: `.foregroundColor: NSColor.tertiaryLabelColor,`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L155: `background: NSColor?,`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L156: `emphasis: [Range<Int>], emphasisColor: NSColor`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L530: `field.textColor = NSColor.systemTeal`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L196: `var leftBG: [Int: NSColor] = [:]`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L197: `var baseBG: [Int: NSColor] = [:]`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L198: `var rightBG: [Int: NSColor] = [:]`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L218: `var outputBG: [Int: NSColor] = [:]`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L10: `static func dynamic(light: NSColor, dark: NSColor) -> NSColor {`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L11: `NSColor(name: nil) { appearance in`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L16: `private static func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> NSColor {`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L17: `NSColor(srgbRed: r, green: g, blue: b, alpha: 1)`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L39: `static let addedAccent = NSColor.systemGreen`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L40: `static let removedAccent = NSColor.systemRed`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L41: `static let changedAccent = NSColor.systemBlue`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L42: `static let conflictAccent = NSColor.systemOrange`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L50: `static func color(for tokenKind: TokenKind) -> NSColor {`
- `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L7: `var heading, code, italic, link, blockquote, listMarker, strikethrough, frontMatter, image: NSColor`
- `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L12: `extension NSColor {`
- `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L35: `guard let ns = NSColor(hex: hex) else { return nil }`
- `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L38: `var hexString: String { NSColor(self).hexString }`
- `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L133: `func c(_ light: String, _ dark: String) -> NSColor {`
- `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L134: `NSColor(hex: isDark ? dark : light) ?? .labelColor`
- `MackDown/Sources/MackDownApp/AppearanceSettings.swift` L199: `case .adaptive: return Color(nsColor: NSColor(name: nil) { t in`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L21: `let color:       NSColor`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L22: `let borderColor: NSColor?`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L28: `let color:   NSColor`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L110: `guard let color = val as? NSColor else { return }`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L234: `.foregroundColor:         NSColor.clear,`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L586: `.foregroundColor:         NSColor.clear,`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L122: `static var editorBackground: NSColor {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L123: `NSColor(name: nil) { appearance in`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L125: `return NSColor(white: 0.18, alpha: 1.0)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L34: `private static let codeBackground = NSColor(name: nil) { app in`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L36: `? NSColor(white: 1.0, alpha: 0.09)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L37: `: NSColor(white: 0.0, alpha: 0.06)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L67: `// and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L91: `.foregroundColor: NSColor.labelColor,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L93: `.backgroundColor: NSColor.clear`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L103: `collect(reHRule,         text, ns, fullRange, attrs: [.foregroundColor: NSColor.tertiaryLabelColor], into: &tokens)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L160: `.foregroundColor: NSColor.labelColor,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L166: `collect(reHRule, text, ns, safe, attrs: [.foregroundColor: NSColor.tertiaryLabelColor], into: &tokens)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L280: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L298: `let dim: [NSAttributedString.Key: Any] = [.foregroundColor: NSColor.tertiaryLabelColor]`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L7: `var textColor:             NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L8: `var secondaryTextColor:    NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L9: `var linkColor:             NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L10: `var codeTextColor:         NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L11: `var inlineCodeBackground:  NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L12: `var codeBlockBackground:   NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L13: `var codeBlockBorderColor:  NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L14: `var quoteBorderColor:      NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L15: `var quoteTextColor:        NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L16: `var tableHeaderBackground: NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L17: `var tableBorderColor:      NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L18: `var tableAltRowBackground: NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L19: `var hrColor:               NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L20: `var frontMatterBackground: NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L21: `var frontMatterTextColor:  NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L22: `var frontMatterKeyColor:   NSColor`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L52: `inlineCodeBackground:  c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L53: `codeBlockBackground:   c("#f6f8fa") ?? NSColor(white: 0.95, alpha: 1),`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L54: `codeBlockBorderColor:  c("#d0d7de") ?? NSColor(white: 0.80, alpha: 1),`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSCursor`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/ConsoleView.swift` L442: `func cursor(_ cursor: NSCursor) -> some View {`
- `MacGit/Sources/MacGitApp/ConsoleView.swift` L444: `if inside { cursor.push() } else { NSCursor.pop() }`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L65: `.cursor:         NSCursor.pointingHand`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSEvent`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L84: `override func keyDown(with event: NSEvent) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L46: `override func mouseDown(with event: NSEvent) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L50: `override func mouseDragged(with event: NSEvent) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L54: `private func jump(to event: NSEvent) {`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L17: `monitor.map { NSEvent.removeMonitor($0) }`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L19: `monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak win] event in`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L25: `deinit { monitor.map { NSEvent.removeMonitor($0) } }`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSFont`

AppKit font type; monospaced fonts keep code/diff alignment stable.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2210: `let monoCaption2: NSFont = .monospacedSystemFont(ofSize: 9, weight: .regular)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2211: `let monoCaption: NSFont = .monospacedSystemFont(ofSize: 11, weight: .regular)`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L59: `static let editorFont = NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)`
- `MacMerge/Sources/MacMergeApp/Support/Theme.swift` L60: `static let lineNumberFont = NSFont.monospacedDigitSystemFont(ofSize: 10, weight: .regular)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L233: `.font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.3, 5)),`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L296: `.font:                    NSFont.monospacedSystemFont(ofSize: theme.codeFont.pointSize * 0.75, weight: .regular),`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L312: `.font:                    NSFont.monospacedSystemFont(ofSize: theme.codeFont.pointSize * 0.75, weight: .regular),`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L557: `let cellFont: NSFont = isHeader`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L558: `? (NSFont(descriptor: theme.bodyFont.fontDescriptor.withSymbolicTraits(.bold),`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L560: `: (NSFont(descriptor: theme.bodyFont.fontDescriptor,`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L585: `.font:                    NSFont.systemFont(ofSize: max(theme.bodyFont.pointSize * 0.4, 6)),`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L603: `let mono = NSFont.monospacedSystemFont(ofSize: theme.bodyFont.pointSize * 0.85, weight: .regular)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L605: `.font:                    NSFont(descriptor: mono.fontDescriptor.withSymbolicTraits(.bold), size: mono.pointSize) ?? mono,`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L626: `let f    = (val as? NSFont) ?? theme.bodyFont`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L627: `let bold = NSFont(descriptor: f.fontDescriptor.withSymbolicTraits(.bold), size: f.pointSize) ?? f`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L635: `let f      = (val as? NSFont) ?? theme.bodyFont`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L638: `let italic = NSFont(descriptor: f.fontDescriptor.withSymbolicTraits(traits), size: f.pointSize) ?? f`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L14: `static func baseFont(size: Double = 13, family: String = "") -> NSFont {`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L15: `if !family.isEmpty, let f = NSFont(name: family, size: size) { return f }`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L16: `return NSFont.monospacedSystemFont(ofSize: size, weight: .regular)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L19: `private static func boldFont(size: Double = 13, family: String = "") -> NSFont {`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L21: `let base = NSFont(name: family, size: size) ?? NSFont.monospacedSystemFont(ofSize: size, weight: .regular)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L22: `return NSFontManager.shared.convert(base, toHaveTrait: .boldFontMask)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L24: `return NSFont.monospacedSystemFont(ofSize: size, weight: .bold)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L27: `private static func italicFont(size: Double = 13, family: String = "") -> NSFont {`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L29: `return NSFontManager.shared.convert(base, toHaveTrait: .italicFontMask)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L67: `// and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L25: `var bodyFont: NSFont`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L26: `var codeFont: NSFont`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L34: `func headingFont(level: Int) -> NSFont {`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L38: `return NSFont(descriptor: bodyFont.fontDescriptor.withSymbolicTraits(.bold), size: sz)`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L39: `?? NSFont.boldSystemFont(ofSize: sz)`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L65: `codeFont:              NSFont.monospacedSystemFont(ofSize: codeSize, weight: .regular),`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L92: `codeFont:              NSFont.monospacedSystemFont(ofSize: codeSize, weight: .regular),`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L131: `private static func makeBodyFont(size: CGFloat, family: String) -> NSFont {`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L132: `guard !family.isEmpty else { return NSFont.systemFont(ofSize: size) }`
- `MackDown/Sources/MackDownApp/MarkdownTheme.swift` L133: `return NSFont(name: family, size: size) ?? NSFont.systemFont(ofSize: size)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSHostingView`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L247: `contentView        = NSHostingView(rootView: SelectionToolbarView())`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L611: `win.contentView = NSHostingView(rootView: content)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSLayoutConstraint`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2179: `NSLayoutConstraint.activate([`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2238: `NSLayoutConstraint.activate([`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L181: `NSLayoutConstraint.activate([`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L149: `NSLayoutConstraint.activate([`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L150: `NSLayoutConstraint.activate([`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSLayoutManager`

TextKit object that computes glyphs/line fragments and exposes drawing hooks. In this code, subclass it for semantic markdown backgrounds and query it for scroll/selection geometry.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L41: `final class MarkdownLayoutManager: NSLayoutManager {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L40: `// Pre-size so NSLayoutManager gets a real container width before the first string`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L100: `// after NSLayoutManager finishes laying out the new content.`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L119: `func layoutManager(_ layoutManager: NSLayoutManager,`

### Agent rules
- Confirm layout exists and coordinate space is known before using this API.
- Convert character ranges to glyph ranges only after clamping UTF-16 offsets.

## `NSLayoutManagerDelegate`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSMenu`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L643: `extension FileDiffViewController: NSMenuItemValidation {`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L644: `func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L185: `private func buildContextMenu() -> NSMenu {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L186: `let menu = NSMenu()`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L568: `extension FolderCompareViewController: NSMenuItemValidation {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L569: `func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L395: `extension MergeViewController: NSMenuItemValidation {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L396: `func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L10: `let main = NSMenu()`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L21: `private static func submenu(_ title: String) -> (NSMenuItem, NSMenu) {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L22: `let item = NSMenuItem()`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L23: `let menu = NSMenu(title: title)`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L32: `private static func makeAppMenu() -> NSMenuItem {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L47: `private static func makeFileMenu() -> NSMenuItem {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L64: `private static func makeEditMenu() -> NSMenuItem {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L78: `private static func makeViewMenu() -> NSMenuItem {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L96: `private static func makeNavigateMenu() -> NSMenuItem {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L132: `private static func makeWindowMenu() -> NSMenuItem {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L146: `private static func makeHelpMenu() -> NSMenuItem {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSMenuItemValidation`

Controller mechanism for enabling/disabling menu commands based on state.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L643: `extension FileDiffViewController: NSMenuItemValidation {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L568: `extension FolderCompareViewController: NSMenuItemValidation {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L395: `extension MergeViewController: NSMenuItemValidation {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSMutableAttributedString`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L129: `var text = NSMutableAttributedString()`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L163: `let attr = NSMutableAttributedString(string: (line ?? "") + "\n", attributes: baseAttributes)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L168: `let out    = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L190: `let out = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L198: `private func renderInlines(_ markup: any Markup) -> NSMutableAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L199: `let out = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L217: `let out = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L254: `let result = NSMutableAttributedString(attributedString: inner)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L267: `let result = NSMutableAttributedString(attributedString: inner)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L287: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L295: `let ls = NSMutableAttributedString(string: lang + "\n", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L311: `let hs = NSMutableAttributedString(string: "⎘\n", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L328: `let cs = NSMutableAttributedString(string: code + "\n", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L341: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L384: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L395: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L405: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L413: `let str = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L433: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L441: `let str = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L476: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L521: `let output  = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L556: `let content = cell.map { renderInlines($0) } ?? NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L597: `let result = NSMutableAttributedString()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L604: `let line = NSMutableAttributedString(string: key + ":  ", attributes: [`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L624: `private func applyBold(_ str: NSMutableAttributedString) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L633: `private func applyItalic(_ str: NSMutableAttributedString) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L644: `private func applyStrikethrough(_ str: NSMutableAttributedString) -> NSAttributedString {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L660: `let result = NSMutableAttributedString(attributedString: inner)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSMutableParagraphStyle`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L226: `let para = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L244: `let para   = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L290: `let lp = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L306: `let hp = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L322: `let cp = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L355: `let para = ((val as? NSParagraphStyle)?.mutableCopy() as? NSMutableParagraphStyle)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L356: `?? NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L551: `let cellPara = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L578: `let para = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L599: `let para = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L699: `private func bodyParagraphStyle() -> NSMutableParagraphStyle {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L700: `let para = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L706: `private func listParagraphStyle(depth: Int, bulletWidth: CGFloat) -> NSMutableParagraphStyle {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L708: `let para   = NSMutableParagraphStyle()`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L443: `let style = NSMutableParagraphStyle()`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSOpenPanel`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2926: `let panel = NSOpenPanel()`
- `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L30: `let panel = NSOpenPanel()`
- `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L195: `let panel = NSOpenPanel()`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L248: `let panel = NSOpenPanel()`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSOutlineView`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L50: `private let outline = NSOutlineView()`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L469: `extension FolderCompareViewController: NSOutlineViewDataSource, NSOutlineViewDelegate {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L471: `func outlineView(_ outlineView: NSOutlineView, numberOfChildrenOfItem item: Any?) -> Int {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L479: `func outlineView(_ outlineView: NSOutlineView, child index: Int, ofItem item: Any?) -> Any {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L487: `func outlineView(_ outlineView: NSOutlineView, isItemExpandable item: Any) -> Bool {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L492: `func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSPasteboard`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L818: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L819: `NSPasteboard.general.setString(path, forType: .string)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L824: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L825: `NSPasteboard.general.setString(remote, forType: .string)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2615: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2616: `NSPasteboard.general.setString(`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2623: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2624: `NSPasteboard.general.setString(fileURL.path, forType: .string)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3225: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3226: `NSPasteboard.general.setString(change.path, forType: .string)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3231: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3232: `NSPasteboard.general.setString(repositoryURL.appendingPathComponent(change.path).path, forType: .string)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4481: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4482: `NSPasteboard.general.setString(stat.path, forType: .string)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4628: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4629: `NSPasteboard.general.setString(sha, forType: .string)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4632: `NSPasteboard.general.clearContents()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4633: `NSPasteboard.general.setString(sha, forType: .string)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L142: `NSPasteboard.general.clearContents()`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L143: `NSPasteboard.general.setString(code, forType: .string)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSRange`

UTF-16 range type expected by TextKit APIs. Must be clamped and derived from NSString lengths.

### Source locations
- `MacMerge/Sources/DiffCore/IntraLine.swift` L2: `/// ranges as UTF-16 offsets (directly convertible to NSRange by UI layers).`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L179: `private func clamp(_ range: Range<Int>, to length: Int) -> NSRange? {`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L183: `return NSRange(location: lower, length: upper - lower)`
- `MacMerge/Sources/SyntaxKit/SyntaxKit.swift` L21: `/// UTF-16 offsets within the line (convertible directly to NSRange).`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L56: `at range: NSRange, tv: NSTextView) {`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L74: `let preStr = text.substring(with: NSRange(location: preStart, length: preLen))`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L75: `let sufStr = text.substring(with: NSRange(location: sufStart, length: sufLen))`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L77: `let outerRange = NSRange(location: preStart, length: preLen + selLen + sufLen)`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L92: `private func toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange) {`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L95: `let lineRange = text.lineRange(for: NSRange(location: sel.location, length: 0))`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L100: `guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: pLen), replacementString: "") else { return }`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L101: `tv.replaceCharacters(in: NSRange(location: lineRange.location, length: pLen), with: "")`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L105: `tv.setSelectedRange(NSRange(location: newLoc, length: newLen))`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L108: `guard tv.shouldChangeText(in: NSRange(location: lineRange.location, length: 0), replacementString: prefix) else { return }`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L109: `tv.replaceCharacters(in: NSRange(location: lineRange.location, length: 0), with: prefix)`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L113: `tv.setSelectedRange(NSRange(location: newLoc, length: newLen))`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L117: `private func replaceAndSelect(_ rep: String, at range: NSRange, tv: NSTextView,`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L122: `tv.setSelectedRange(NSRange(location: range.location + offset, length: len))`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L412: `let range = NSRange(location: 0, length: (ln as NSString).length)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L42: `override func drawBackground(forGlyphRange glyphsToShow: NSRange, at origin: NSPoint) {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L48: `var prev: (MarkdownBlockBackground, NSRange)? = nil`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L50: `func flush(_ range: NSRange, _ bg: MarkdownBlockBackground) {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L117: `forGlyphRange: NSRange(location: iStart, length: iEnd - iStart),`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L256: `let all = NSRange(location: 0, length: result.length)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L269: `let all  = NSRange(location: 0, length: result.length)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L351: `let all    = NSRange(location: 0, length: result.length)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L369: `var borderUpdates: [(NSRange, MarkdownBlockLeftBorders)] = []`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L421: `str.addAttributes(baseAttrs, range: NSRange(location: 0, length: str.length))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L449: `str.addAttributes(baseAttrs, range: NSRange(location: 0, length: str.length))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L484: `range: NSRange(location: 0, length: inline.length))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L486: `range: NSRange(location: 0, length: inline.length))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L492: `result.addAttributes(baseAttrs, range: NSRange(location: 0, length: result.length))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L494: `result.addAttributes(cbAttrs, range: NSRange(location: 0, length: min(2, result.length)))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L566: `], range: NSRange(location: 0, length: content.length))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L625: `str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L634: `str.enumerateAttribute(.font, in: NSRange(location: 0, length: str.length)) { val, range, _ in`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L646: `range: NSRange(location: 0, length: str.length))`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L661: `let all    = NSRange(location: 0, length: result.length)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L158: `var savedSelectedRange: NSRange = NSRange(location: 0, length: 0)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L195: `tv.setSelectedRange(NSRange(location: loc, length: rLen))`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L258: `tv.setSelectedRange(NSRange(location: lineStart, length: 0))`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L276: `range editedRange: NSRange,`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L301: `var evalRange = str.paragraphRange(for: NSRange(location: loc, length: 0))`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L311: `evalRange = NSRange(location: start, length: end - start)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L415: `private func showFloatingPanel(for tv: NSTextView, selectionRange: NSRange) {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L167: `var target: NSRange?`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L168: `let fullRange = NSRange(location: 0, length: storage.length)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L6: `let range: NSRange`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L79: `let fullRange = NSRange(location: 0, length: fullLen)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L136: `paragraphRange: NSRange,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L148: `let safe = NSRange(location: loc, length: len)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L225: `paragraphRange: NSRange`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L260: `_ range: NSRange,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L274: `_ range: NSRange,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L284: `tokens.append(SyntaxToken(range: NSRange(location: r.location, length: delimLen), attributes: dim))`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L285: `tokens.append(SyntaxToken(range: NSRange(location: NSMaxRange(r) - delimLen, length: delimLen), attributes: dim))`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L293: `_ range: NSRange,`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSRulerView`

Line-number gutter implementation for diff panes.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L126: `final class LineNumberRuler: NSRulerView {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSSavePanel`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L609: `let panel = NSSavePanel()`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L310: `let panel = NSSavePanel()`
- `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L48: `let panel = NSSavePanel()`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSScrollView`

Container for text views and table views; clip view origin is the scroll state.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2075: `func makeNSView(context: Context) -> NSScrollView {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2091: `let sv = NSScrollView()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2100: `func updateNSView(_ sv: NSScrollView, context: Context) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L93: `static func makePane(editable: Bool) -> (scrollView: NSScrollView, textView: DiffTextView) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L94: `let scrollView = NSScrollView()`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L133: `init(scrollView: NSScrollView, textView: DiffTextView) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L46: `private var leftScroll: NSScrollView!`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L47: `private var rightScroll: NSScrollView!`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L538: `let other: NSScrollView = (clipView === leftScroll.contentView) ? rightScroll : leftScroll`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L51: `private let scroll = NSScrollView()`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L14: `func makeNSView(context: Context) -> NSScrollView {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L80: `func updateNSView(_ scrollView: NSScrollView, context: Context) {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L26: `func makeNSView(context: Context) -> NSScrollView {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L74: `let scrollView = NSScrollView()`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L84: `func updateNSView(_ scrollView: NSScrollView, context: Context) {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L109: `weak var scrollViewRef:       NSScrollView?`

### Agent rules
- Scroll the clip view, clamp to document bounds, and reflect scrolled clip view after programmatic scrolls.

## `NSStackView`

Programmatic AppKit layout container for controller UI bars and pane rows.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L146: `let controlBar = NSStackView(views: [`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L155: `let contentRow = NSStackView(views: [leftScroll, rightScroll, overview])`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L170: `let statusBar = NSStackView(views: [leftStatus, statusSpacer, rightStatus])`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L174: `let main = NSStackView(views: [controlBar, contentRow, statusBar])`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L124: `let controlBar = NSStackView(views: [backButton, filterPopup, flattenCheckbox, refreshButton, spinner, spacer, summaryLabel])`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L138: `let statusBar = NSStackView(views: [pathLabel])`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L142: `let main = NSStackView(views: [controlBar, scroll, statusBar])`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L84: `let stack = NSStackView(views: [label, scroll])`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L98: `let sourcesRow = NSStackView(views: [leftPane, basePane, rightPane])`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L114: `let outputPane = NSStackView(views: [outputLabel, outputScroll])`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L137: `let controlBar = NSStackView(views: [prevButton, nextButton, counterLabel, spinner, spacer, saveButton])`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L143: `let main = NSStackView(views: [controlBar, split])`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSString`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/SocketBridge.swift` L64: `let path = (NSTemporaryDirectory() as NSString).appendingPathComponent("macgit-\(ProcessInfo.processInfo.processIdentifier).sock")`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L167: `let label = labels[row] as NSString`
- `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift` L101: `(path.trimmingCharacters(in: .whitespacesAndNewlines) as NSString).expandingTildeInPath`
- `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L132: `let left = (item.leftPath as NSString).lastPathComponent`
- `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift` L133: `let right = (item.rightPath as NSString).lastPathComponent`
- `MacMerge/Sources/TextEngine/EncodingDetector.swift` L20: `rawValue: CFStringConvertEncodingToNSStringEncoding(`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L21: `let text  = tv.string as NSString`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L57: `let text   = tv.string as NSString`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L58: `let preLen = (pre as NSString).length`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L59: `let sufLen = (suf as NSString).length`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L60: `let selLen = (sel as NSString).length`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L65: `replaceAndSelect(inner, at: range, tv: tv, offset: 0, len: (inner as NSString).length)`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L93: `let text      = tv.string as NSString`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L97: `let pLen      = (prefix as NSString).length`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L412: `let range = NSRange(location: 0, length: (ln as NSString).length)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L135: `let ns = string as NSString`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L137: `return (ns.substring(to: clamped) as NSString).components(separatedBy: "\n").count - 1`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L141: `let lines = (string as NSString).components(separatedBy: "\n")`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L144: `for i in 0..<line { pos += (lines[i] as NSString).length + 1 }`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L145: `return min(pos, (string as NSString).length)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L191: `let len  = (tv.string as NSString).length`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L236: `let nsOld     = tv.string as NSString`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L238: `? (nsOld.substring(to: min(caretPos, nsOld.length)) as NSString)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L250: `let nsNew = text as NSString`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L255: `for i in 0..<line { pos += (lines[i] as NSString).length + 1 }`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L288: `let str     = textStorage.string as NSString`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L77: `let ns       = text as NSString`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L142: `let ns      = text as NSString`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L254: `// MARK: - Private collect helpers (thread-safe; operate on a pre-bridged NSString)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L259: `_ ns: NSString,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L273: `_ ns: NSString,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L292: `_ ns: NSString,`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSTableColumn`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2078: `let col = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("col"))`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2139: `func tableView(_ tv: NSTableView, viewFor col: NSTableColumn?, row: Int) -> NSView? {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L159: `func column(_ id: NSUserInterfaceItemIdentifier, _ title: String, width: CGFloat) -> NSTableColumn {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L160: `let column = NSTableColumn(identifier: id)`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L492: `func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSTableView`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L1699: `// Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2067: `// MARK: - Phase 6: Virtualized diff renderer (AppKit NSTableView for large visual diffs)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2076: `let tv = NSTableView()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2101: `guard let tv = sv.documentView as? NSTableView else { return }`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2110: `final class Coordinator: NSObject, NSTableViewDataSource, NSTableViewDelegate {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2114: `private weak var tableView: NSTableView?`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2117: `func attachAppearanceObserver(to tv: NSTableView) {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2128: `func numberOfRows(in tv: NSTableView) -> Int { rowCount }`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2130: `func tableView(_ tv: NSTableView, heightOfRow row: Int) -> CGFloat {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2139: `func tableView(_ tv: NSTableView, viewFor col: NSTableColumn?, row: Int) -> NSView? {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2148: `private func capView(_ tv: NSTableView) -> NSView {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2165: `private func sectionView(_ tv: NSTableView, id: String, text: String, isFile: Bool) -> NSView {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2201: `private func lineView(_ tv: NSTableView, line: DiffLine) -> NSView {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSTextAttachment`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L679: `let attachment = NSTextAttachment()`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSTextContainer`

Text layout geometry. Width tracking and container size determine wrapping/no-wrap behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L30: `let container   = NSTextContainer(size: NSSize(width: 0, height: CGFloat.greatestFiniteMagnitude))`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L120: `didCompleteLayoutFor textContainer: NSTextContainer?,`

### Agent rules
- Decide editor/preview/diff role first, then set wrapping, editability, richness, insets, and automation flags.

## `NSTextField`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2150: `if let v = tv.makeView(withIdentifier: nsId, owner: nil) as? NSTextField {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2154: `let f = NSTextField(labelWithString: capText())`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2174: `let label = NSTextField(labelWithString: "")`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2192: `if let label = v.subviews.first(where: { $0.identifier?.rawValue == "lbl" }) as? NSTextField {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2213: `func numField(id: String) -> NSTextField {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2214: `let f = NSTextField(labelWithString: "")`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2225: `let marker = NSTextField(labelWithString: "")`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2230: `let text = NSTextField(labelWithString: "")`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2279: `case "oldNum": (sub as? NSTextField)?.stringValue = line.oldNumber.map { "\($0)" } ?? ""`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2280: `case "newNum": (sub as? NSTextField)?.stringValue = line.newNumber.map { "\($0)" } ?? ""`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2282: `if let f = sub as? NSTextField { f.stringValue = markerStr; f.textColor = markerColor }`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2283: `case "text": (sub as? NSTextField)?.stringValue = line.text`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L53: `private let counterLabel = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L54: `private let leftStatus = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L55: `private let rightStatus = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L56: `private let fileNavLabel = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L52: `private let summaryLabel = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L53: `private let pathLabel = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L494: `let field: NSTextField`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L495: `if let reused = outlineView.makeView(withIdentifier: column.identifier, owner: self) as? NSTextField {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L498: `field = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L507: `private func configure(_ field: NSTextField, column: NSUserInterfaceItemIdentifier, entry: FolderEntry) {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L32: `private let counterLabel = NSTextField(labelWithString: "")`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L80: `let label = NSTextField(labelWithString: header)`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L110: `let outputLabel = NSTextField(labelWithString: "Output")`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSTextStorage`

Mutable attributed backing store. Delegate drives incremental syntax highlighting; live mutations must be main-thread.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L47: `// isInitialLoad suppresses the synchronous NSTextStorageDelegate highlight callback`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150: `final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L161: `/// Location and delta captured from NSTextStorageDelegate during undo/redo.`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L177: `// tv.string to avoid a potential NSTextStorage read off the main thread (R-0050-03).`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L219: `// Use lastText rather than tv.string — the NSTextStorage may be on a layout pass`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L241: `// isInitialLoad suppresses the NSTextStorageDelegate sync highlight so`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L271: `// MARK: NSTextStorageDelegate`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L274: `_ textStorage: NSTextStorage,`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L275: `didProcessEditing editedMask: NSTextStorageEditActions,`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L319: `// String(…) forces an independent copy of the NSTextStorage backing buffer so the`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L28: `let textStorage = NSTextStorage()`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L197: `static func applyTokens(_ tokens: [SyntaxToken], to storage: NSTextStorage) {`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L206: `_ storage: NSTextStorage,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L220: `_ storage: NSTextStorage,`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L236: `static func highlight(_ storage: NSTextStorage, fontSize: Double = 13, family: String = "", enabled: Bool = true) {`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L243: `_ storage: NSTextStorage,`

### Agent rules
- Mutate live storage on main; batch large changes; suppress delegate echo when replacement is programmatic.

## `NSTextStorageDelegate`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L47: `// isInitialLoad suppresses the synchronous NSTextStorageDelegate highlight callback`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150: `final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L161: `/// Location and delta captured from NSTextStorageDelegate during undo/redo.`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L241: `// isInitialLoad suppresses the NSTextStorageDelegate sync highlight so`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L271: `// MARK: NSTextStorageDelegate`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSTextView`

AppKit text view for editing, preview, and diff panes. Configure behavior according to role; do not use one universal settings block.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L3: `/// NSTextView (TextKit 1) with full-width row background painting and a`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L7: `final class DiffTextView: NSTextView {`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L81: `/// Esc in read-only comparison panes navigates Back (NSTextView would`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L372: `extension MergeViewController: NSTextViewDelegate {`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L17: `// MARK: - Apply format to NSTextView (free function; called from coordinator)`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L19: `func applyMarkdownFormat(_ format: MarkdownFormat, to tv: NSTextView) {`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L56: `at range: NSRange, tv: NSTextView) {`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L92: `private func toggleLinePrefix(_ prefix: String, at sel: NSRange, tv: NSTextView, originalSel: NSRange) {`
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L117: `private func replaceAndSelect(_ rep: String, at range: NSRange, tv: NSTextView,`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L354: `// Pull live text from NSTextView; fall back to liveText (set by debounce/deinit).`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L383: `let tv = NSTextView(frame: NSRect(x: 0, y: 0, width: pageWidth, height: 100))`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L6: `// Editor owns its live text in NSTextView; AppState never receives the full string on`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L15: `let scrollView = NSTextView.scrollableTextView()`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L16: `guard let textView = scrollView.documentView as? NSTextView else { return scrollView }`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L62: `// from NSTextView without a SwiftUI binding round-trip (R-0048-02).`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L81: `guard let textView = scrollView.documentView as? NSTextView else { return }`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150: `final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L164: `weak var textViewRef: NSTextView?`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L227: `// (load/reload/toggle/clear) and applies it to NSTextView.`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L326: `// MARK: NSTextViewDelegate`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L329: `guard let tv = notification.object as? NSTextView else { return }`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L355: `guard let tv = notification.object as? NSTextView,`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L415: `private func showFloatingPanel(for tv: NSTextView, selectionRange: NSRange) {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L439: `private func applyTabStops(to textView: NSTextView, tabSize: Int, fontSize: Double, family: String = "") {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L4: `// MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L38: `let textView = NSTextView(frame: .zero, textContainer: container)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L89: `let textView = scrollView.documentView as? NSTextView {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L95: `let textView = scrollView.documentView as? NSTextView else { return }`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L108: `weak var textViewRef:         NSTextView?`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L134: `func textView(_ textView: NSTextView, clickedOnLink link: Any, at charIndex: Int) -> Bool {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L153: `// Web/scheme URLs — let NSTextView handle via NSWorkspace`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L161: `func scrollToHeading(_ entry: MarkdownOutlineEntry, in textView: NSTextView) {`

### Agent rules
- Decide editor/preview/diff role first, then set wrapping, editability, richness, insets, and automation flags.

## `NSTextViewDelegate`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L372: `extension MergeViewController: NSTextViewDelegate {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L150: `final class Coordinator: NSObject, NSTextViewDelegate, NSTextStorageDelegate {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L326: `// MARK: NSTextViewDelegate`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L105: `final class Coordinator: NSObject, NSTextViewDelegate, NSLayoutManagerDelegate {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSView`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2069: `private struct VirtualizedDiffView: NSViewRepresentable {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2075: `func makeNSView(context: Context) -> NSScrollView {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2100: `func updateNSView(_ sv: NSScrollView, context: Context) {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2139: `func tableView(_ tv: NSTableView, viewFor col: NSTableColumn?, row: Int) -> NSView? {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2148: `private func capView(_ tv: NSTableView) -> NSView {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2165: `private func sectionView(_ tv: NSTableView, id: String, text: String, isFile: Bool) -> NSView {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2171: `let box = NSView()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2188: `private func configureSection(_ v: NSView, text: String, isFile: Bool) {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2201: `private func lineView(_ tv: NSTableView, line: DiffLine) -> NSView {`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2207: `let box = NSView()`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2259: `private func configureLine(_ v: NSView, line: DiffLine) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L18: `final class FileDiffViewController: NSViewController {`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L144: `let spacer = NSView()`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L168: `let statusSpacer = NSView()`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L179: `let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L204: `name: NSView.boundsDidChangeNotification, object: scroll.contentView`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L5: `final class OverviewStripView: NSView {`
- `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift` L20: `override var intrinsicContentSize: NSSize { NSSize(width: 14, height: NSView.noIntrinsicMetric) }`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L8: `final class FolderCompareViewController: NSViewController {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L122: `let spacer = NSView()`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L147: `let container = NSView(frame: NSRect(x: 0, y: 0, width: 1100, height: 700))`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L492: `func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L12: `final class MergeViewController: NSViewController {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L78: `func sourcePane(_ header: String) -> (NSView, DiffTextView) {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L135: `let spacer = NSView()`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L148: `let container = NSView(frame: NSRect(x: 0, y: 0, width: 1280, height: 800))`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L202: `private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L178: `// Coordinator subscribes in makeNSView; fires on load/reload/toggle/clear.`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L665: `// Always set theme link color; makeNSView clears the foreground override in linkTextAttributes.`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L5: `struct MarkdownEditorView: NSViewRepresentable {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L14: `func makeNSView(context: Context) -> NSScrollView {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L45: `benchLog("[BENCH] makeNSView frameW=\(Int(scrollView.frame.width)) containerW=\(initCW)")`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L58: `benchLog("[BENCH] makeNSView string-set done")`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L80: `func updateNSView(_ scrollView: NSScrollView, context: Context) {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L83: `benchLog("[BENCH] updateNSView \(benchT()) textLen=\(textView.string.count) cW=\(cW)")`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L103: `// updateNSView is now called only for appearance changes, not for every keystroke.`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L4: `// MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L6: `struct MarkdownPreviewTextView: NSViewRepresentable {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L26: `func makeNSView(context: Context) -> NSScrollView {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L84: `func updateNSView(_ scrollView: NSScrollView, context: Context) {`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L6: `private struct EscapeKeyInterceptor: NSViewRepresentable {`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L7: `func makeNSView(context: Context) -> NSView {`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L11: `func updateNSView(_ nsView: NSView, context: Context) {}`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L13: `private class EscView: NSView {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSViewController`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L18: `final class FileDiffViewController: NSViewController {`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L8: `final class FolderCompareViewController: NSViewController {`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L12: `final class MergeViewController: NSViewController {`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L202: `private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSViewRepresentable`

SwiftUI bridge used to host AppKit text/table views while keeping AppKit state durable.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2069: `private struct VirtualizedDiffView: NSViewRepresentable {`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L5: `struct MarkdownEditorView: NSViewRepresentable {`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L4: `// MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L6: `struct MarkdownPreviewTextView: NSViewRepresentable {`
- `MackDown/Sources/MackDownApp/SettingsView.swift` L6: `private struct EscapeKeyInterceptor: NSViewRepresentable {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSWindow`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/Support/AppActions.swift` L47: `static func save(_ session: ComparisonSession, suggestedName: String, in window: NSWindow?) {`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L60: `menu.addItem(withTitle: "Close", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L91: `action: #selector(NSWindow.toggleFullScreen(_:)), keyEquivalent: "f")`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L134: `menu.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")`
- `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift` L135: `menu.addItem(withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L21: `private var controllers: [NSWindowController] = []`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L22: `private var welcomeController: NSWindowController?`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L23: `private var newComparisonController: NSWindowController?`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L31: `let window = NSWindow(contentViewController: hosting)`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L39: `welcomeController = NSWindowController(window: window)`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L68: `let window = NSWindow(contentViewController: hosting)`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L75: `newComparisonController = NSWindowController(window: window)`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L118: `func openFileDiff(left: URL, right: URL, tabIn host: NSWindow? = nil,`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L126: `func returnToFolderCompare(left: URL, right: URL, near window: NSWindow?) {`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L137: `func openFolderCompare(left: URL, right: URL, tabIn host: NSWindow? = nil) {`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L142: `func openMerge(base: URL, left: URL, right: URL, output: URL? = nil, tabIn host: NSWindow? = nil) {`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L202: `private func present(_ viewController: NSViewController, tabIn host: NSWindow?) {`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L203: `let window = NSWindow(contentViewController: viewController)`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L210: `let controller = NSWindowController(window: window)`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L237: `extension WindowManager: NSWindowDelegate {`
- `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift` L239: `guard let window = notification.object as? NSWindow else { return }`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L605: `let win = NSWindow(`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L613: `win.delegate   = NSApp.delegate as? NSWindowDelegate`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L621: `final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L623: `var extraWindows: [NSWindow: AppState] = [:]`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L625: `func register(_ window: NSWindow, state: AppState) {`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L645: `func windowShouldClose(_ sender: NSWindow) -> Bool {`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L667: `guard let window = notification.object as? NSWindow else { return }`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `NSWorkspace`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L260: `NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: wt.path)])`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2595: `NSWorkspace.shared.open(fileURL)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2601: `NSWorkspace.shared.activateFileViewerSelecting([fileURL])`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3208: `NSWorkspace.shared.activateFileViewerSelecting([repositoryURL])`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3216: `NSWorkspace.shared.activateFileViewerSelecting([fileURL])`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3221: `NSWorkspace.shared.open(repositoryURL.appendingPathComponent(change.path))`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3266: `NSWorkspace.shared.open(url)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L3568: `NSWorkspace.shared.open(url)`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4260: `_ = await MainActor.run { NSWorkspace.shared.open(tempURL) }`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4461: `NSWorkspace.shared.open(repositoryURL.appendingPathComponent(stat.path))`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L4466: `NSWorkspace.shared.activateFileViewerSelecting([repositoryURL.appendingPathComponent(stat.path)])`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L453: `NSWorkspace.shared.activateFileViewerSelecting([leftRoot.appendingPathComponent(entry.relativePath)])`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L458: `NSWorkspace.shared.activateFileViewerSelecting([rightRoot.appendingPathComponent(entry.relativePath)])`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L153: `// Web/scheme URLs — let NSTextView handle via NSWorkspace`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `allowsNonContiguousLayout`

Large-document performance setting that lets layout manager typeset visible regions first.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L29: `textView.layoutManager?.allowsNonContiguousLayout = true`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `beginEditing`

Batch mutation boundary for NSTextStorage attributes.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L401: `storage.beginEditing()`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L196: `// Must be called on the main thread; caller wraps in beginEditing/endEditing.`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L229: `storage.beginEditing()`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L249: `storage.beginEditing()`

### Agent rules
- Mutate live storage on main; batch large changes; suppress delegate echo when replacement is programmatic.

## `boundingRect`

Glyph bounds for selections/headings/inline backgrounds.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L116: `let codeRect = self.boundingRect(`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L418: `var rect = lm.boundingRect(forGlyphRange: glyphRange, in: tc)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L181: `let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)`

### Agent rules
- Confirm layout exists and coordinate space is known before using this API.
- Convert character ranges to glyph ranges only after clamping UTF-16 offsets.

## `characterRange`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L38: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L151: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L552: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L47: `let charRange = characterRange(forGlyphRange: glyphsToShow, actualGlyphRange: nil)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `clickedOnLink`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L134: `func textView(_ textView: NSTextView, clickedOnLink link: Any, at charIndex: Int) -> Bool {`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `containerSize`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L116: `container.containerSize = NSSize(width: CGFloat.greatestFiniteMagnitude,`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L385: `tv.textContainer?.containerSize = NSSize(width: pageWidth, height: .greatestFiniteMagnitude)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L58: `bounding.size.width  = container.containerSize.width - pad * 2`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L44: `let initCW = Int(textView.textContainer?.containerSize.width ?? -1)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L82: `let cW = Int(textView.textContainer?.containerSize.width ?? -1)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `contentView.scroll`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L530: `leftScroll.contentView.scroll(to: origin)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L539: `other.contentView.scroll(to: clipView.bounds.origin)`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L300: `scroll.contentView.scroll(to: NSPoint(x: scroll.contentView.bounds.origin.x, y: targetY))`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L130: `sv.contentView.scroll(to: clamped)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L184: `scrollView.contentView.scroll(to: NSPoint(x: 0, y: y))`

### Agent rules
- Scroll the clip view, clamp to document bounds, and reflect scrolled clip view after programmatic scrolls.

## `didCompleteLayoutFor`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L35: `// didCompleteLayoutFor fires and we restore the scroll position.`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L99: `// Scroll position is restored in layoutManager(_:didCompleteLayoutFor:atEnd:)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L120: `didCompleteLayoutFor textContainer: NSTextContainer?,`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `didProcessEditing`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L275: `didProcessEditing editedMask: NSTextStorageEditActions,`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `documentRect`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L34: `// Single-pass layout required so documentRect.height is accurate when`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L126: `let docH    = sv.contentView.documentRect.height`

### Agent rules
- Scroll the clip view, clamp to document bounds, and reflect scrolled clip view after programmatic scrolls.

## `drawBackground`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L6: `/// in `drawBackground(in:)` from the display-row table. (SPEC §11.4)`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L30: `override func drawBackground(in rect: NSRect) {`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L31: `super.drawBackground(in: rect)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L42: `override func drawBackground(forGlyphRange glyphsToShow: NSRange, at origin: NSPoint) {`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L44: `super.drawBackground(forGlyphRange: glyphsToShow, at: origin)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L134: `super.drawBackground(forGlyphRange: glyphsToShow, at: origin)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `endEditing`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L403: `storage.endEditing()`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L196: `// Must be called on the main thread; caller wraps in beginEditing/endEditing.`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L231: `storage.endEditing()`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L234: `// MARK: - Public highlight wrappers (with begin/endEditing — for external callers)`
- `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift` L251: `storage.endEditing()`

### Agent rules
- Mutate live storage on main; batch large changes; suppress delegate echo when replacement is programmatic.

## `ensureLayout`

Forces layout before geometry-dependent scrolling or rect calculation.

### Source locations
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L391: `lm.ensureLayout(for: tc)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L179: `layoutManager.ensureLayout(for: container)`

### Agent rules
- Confirm layout exists and coordinate space is known before using this API.
- Convert character ranges to glyph ranges only after clamping UTF-16 offsets.

## `glyphRange`

Bridge between character ranges and drawn glyph ranges; required for layout-manager geometry.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L37: `let glyphRange = lm.glyphRange(forBoundingRect: rect, in: tc)`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L38: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L150: `let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L151: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L551: `let glyphRange = lm.glyphRange(forBoundingRect: leftText.visibleRect, in: tc)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L552: `let charRange = lm.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L51: `let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L90: `let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)`
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L111: `let gr = glyphRange(forCharacterRange: range, actualCharacterRange: nil)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L417: `let glyphRange = lm.glyphRange(forCharacterRange: selectionRange, actualCharacterRange: nil)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L418: `var rect = lm.boundingRect(forGlyphRange: glyphRange, in: tc)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L180: `let glyphRange = layoutManager.glyphRange(forCharacterRange: target, actualCharacterRange: nil)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L181: `let rect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: container)`

### Agent rules
- Confirm layout exists and coordinate space is known before using this API.
- Convert character ranges to glyph ranges only after clamping UTF-16 offsets.

## `lineFragmentRect`

Geometry of a laid-out line; used for row background/ruler/jump alignment.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L76: `var frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L165: `let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L527: `let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L298: `let frag = lm.lineFragmentRect(forGlyphAt: glyphIdx, effectiveRange: nil)`

### Agent rules
- Confirm layout exists and coordinate space is known before using this API.
- Convert character ranges to glyph ranges only after clamping UTF-16 offsets.

## `linkTextAttributes`

Text view setting for link visual/cursor behavior in preview.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift` L665: `// Always set theme link color; makeNSView clears the foreground override in linkTextAttributes.`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L63: `textView.linkTextAttributes = [`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `reflectScrolledClipView`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L531: `leftScroll.reflectScrolledClipView(leftScroll.contentView)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L540: `other.reflectScrolledClipView(other.contentView)`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L301: `scroll.reflectScrolledClipView(scroll.contentView)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L131: `sv.reflectScrolledClipView(sv.contentView)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L185: `scrollView.reflectScrolledClipView(scrollView.contentView)`

### Agent rules
- Scroll the clip view, clamp to document bounds, and reflect scrolled clip view after programmatic scrolls.

## `selectedRange`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/EditorToolbar.swift` L20: `let sel   = tv.selectedRange()`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L201: `let newRange = tv.selectedRange()`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L235: `let caretPos  = tv.selectedRanges.first?.rangeValue.location ?? 0`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L366: `let range = tv.selectedRange()`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `setAttributedString`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L358: `leftText.textStorage?.setAttributedString(payload.leftPane.attributed)`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L363: `rightText.textStorage?.setAttributedString(payload.rightPane.attributed)`
- `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift` L7: `/// only `textStorage.setAttributedString` happens on main. (SPEC §9)`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L256: `textView.textStorage?.setAttributedString(pane.attributed)`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L389: `tv.textStorage?.setAttributedString(attr)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L71: `textStorage.setAttributedString(attributedString)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L98: `textView.textStorage?.setAttributedString(attributedString)`

### Agent rules
- Mutate live storage on main; batch large changes; suppress delegate echo when replacement is programmatic.

## `textContainerInset`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L106: `textView.textContainerInset = NSSize(width: 4, height: 4)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L33: `textView.textContainerInset = NSSize(width: 16, height: 16)`
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L419: `let inset = tv.textContainerInset`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L48: `textView.textContainerInset    = NSSize(width: 32, height: 32)`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L182: `.offsetBy(dx: textView.textContainerInset.width, dy: textView.textContainerInset.height)`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `textContainerOrigin`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L77: `frag.origin.y += textContainerOrigin.y`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L166: `let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `translatesAutoresizingMaskIntoConstraints`

Must be disabled for views constrained manually with anchors.

### Source locations
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2177: `label.translatesAutoresizingMaskIntoConstraints = false`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2220: `f.translatesAutoresizingMaskIntoConstraints = false`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2229: `marker.translatesAutoresizingMaskIntoConstraints = false`
- `MacGit/Sources/MacGitApp/MacGitApp.swift` L2235: `text.translatesAutoresizingMaskIntoConstraints = false`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L177: `main.translatesAutoresizingMaskIntoConstraints = false`
- `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift` L145: `main.translatesAutoresizingMaskIntoConstraints = false`
- `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift` L146: `main.translatesAutoresizingMaskIntoConstraints = false`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `typingAttributes`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MackDown/Sources/MackDownApp/MarkdownEditorView.swift` L447: `textView.typingAttributes[.paragraphStyle] = style`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.

## `visibleRect`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L149: `let visibleRect = tv.visibleRect`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L150: `let glyphRange = lm.glyphRange(forBoundingRect: visibleRect, in: tc)`
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L166: `let y = frag.minY + tv.textContainerOrigin.y - visibleRect.minY`
- `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift` L551: `let glyphRange = lm.glyphRange(forBoundingRect: leftText.visibleRect, in: tc)`

### Agent rules
- Scroll the clip view, clamp to document bounds, and reflect scrolled clip view after programmatic scrolls.

## `widthTracksTextView`

Source-relevant AppKit/TextKit symbol. Inspect callsites before modifying behavior.

### Source locations
- `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift` L115: `container.widthTracksTextView = false`
- `MackDown/Sources/MackDownApp/MackDownApp.swift` L384: `tv.textContainer?.widthTracksTextView = true`
- `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift` L31: `container.widthTracksTextView = true`

### Agent rules
- Preserve source-local invariants and reconfigure reused views completely.
