# Source Map (Generated)

Total Swift files: 72. Total source bytes: 734619.

## Top AppKit/TextKit terms

- `Task`: 160
- `NSColor`: 105
- `NSAttributedString`: 75
- `NSRange`: 59
- `NSView`: 46
- `NSFont`: 39
- `MainActor`: 33
- `NSTextView`: 33
- `NSString`: 32
- `AppKit`: 30
- `NSMutableAttributedString`: 29
- `NSWindow`: 28
- `NSTextField`: 25
- `nonisolated`: 22
- `SwiftUI`: 20
- `NSPasteboard`: 20
- `NSMenu`: 20
- `DispatchQueue`: 19
- `NSAttributedString.Key`: 18
- `glyphRange`: 18
- `NSScrollView`: 16
- `NSTextStorage`: 16
- `NSMutableParagraphStyle`: 15
- `NSTableView`: 14
- `NSWorkspace`: 14
- `NSAlert`: 14
- `leadingAnchor`: 13
- `trailingAnchor`: 13
- `orientation`: 13
- `NSButton`: 13
- `NSStackView`: 12
- `ObservableObject`: 10
- `centerYAnchor`: 10
- `darkAqua`: 10
- `bestMatch`: 9
- `vibrantDark`: 8
- `translatesAutoresizingMaskIntoConstraints`: 7
- `NotificationCenter`: 7
- `NSEvent`: 7
- `setAttributedString`: 7
- `NSOutlineView`: 7
- `scrollTo`: 6
- `widthAnchor`: 6
- `effectiveAppearance`: 6
- `drawBackground`: 6
- `textContainerInset`: 6
- `topAnchor`: 6
- `bottomAnchor`: 6
- `NSViewRepresentable`: 5
- `NSTableColumn`: 5
- `NSLayoutConstraint`: 5
- `containerSize`: 5
- `visibleRect`: 5
- `NSBezierPath`: 5
- `contentView.scroll`: 5
- `reflectScrolledClipView`: 5
- `edgeInsets`: 5
- `setSelectedRange`: 5
- `NSLayoutManager`: 5
- `endEditing`: 5
- `NSTextStorageDelegate`: 5
- `NSOpenPanel`: 4
- `wantsLayer`: 4
- `characterRange`: 4
- `lineFragmentRect`: 4
- `NSViewController`: 4
- `NSTextViewDelegate`: 4
- `selectedRange`: 4
- `drawsBackground`: 4
- `beginEditing`: 4
- `NSCursor`: 3
- `widthTracksTextView`: 3
- `isHorizontallyResizable`: 3
- `isVerticallyResizable`: 3
- `NSMenuItemValidation`: 3
- `NSSavePanel`: 3
- `PassthroughSubject`: 3
- `lineFragmentPadding`: 3
- `boundingRect`: 3
- `didCompleteLayoutFor`: 3
- `textContainerOrigin`: 2
- `autoresizingMask`: 2
- `distribution`: 2
- `NSHostingView`: 2
- `ensureLayout`: 2
- `AnyCancellable`: 2
- `linkTextAttributes`: 2
- `NSTextContainer`: 2
- `documentRect`: 2
- `NSRulerView`: 1
- `drawHashMarksAndLabels`: 1
- `boundsDidChangeNotification`: 1
- `postsBoundsChangedNotifications`: 1
- `draw(_`: 1
- `NSTextAttachment`: 1
- `allowsNonContiguousLayout`: 1
- `didProcessEditing`: 1
- `typingAttributes`: 1
- `defaultParagraphStyle`: 1
- `KVO`: 1

## Files


### `MacGit/Sources/MacGitApp/ConsoleView.swift`

- Roles: Support code
- Lines: 447
- Bytes: 16002
- Imports: AppKit, SwiftUI, MacGitCore
- Declarations:
  - struct `ConsoleLine` : Identifiable, Sendable
  - class `ConsoleStore` : ObservableObject
  - struct `ConsoleDrawer` : View
  - extension `View`
- Functions/methods: `configure`, `updateSocketPath`, `updateBranch`, `rebuildPrompt`, `submit`, `interrupt`, `historyUp`, `historyDown`, `echo`, `runCommand`, `appendLine`, `run`, `interrupt`, `shellSplit`, `shellQuote`, `containsCursorMovement`, `parseSGR`, `sgrColor`, `lineColor`, `cursor`
- Stored/visible properties: `id`, `text`, `kind`, `color`, `inputText`, `history`, `historyIndex`, `runner`, `repositoryURL`, `branchName`, `socketPath`, `maxLines`, `repoName`, `branch`, `raw`, `command`, `firstToken`, `r`, `next`, `r`, `repositoryURL`, `socketPath`, `pid`, `parts`, `master`, `slave`, `process`, `extra`, `exeDir`, `cliPath`, `quotedCLI`, `hasCursorSeqs`, `bufSize`, `buf`, `accumulated`, `n`, `chunk`, `line`, `tokens`, `current`, `inSingle`, `inDouble`, `cursorPattern`, `result`, `color`, `i`, `j`, `params`, `cmd`, `codes`, `drawerHeight`, `isDragging`, `body`
- Relevant term counts: `nonisolated`=6, `Task`=3, `MainActor`=2, `NSCursor`=2, `AppKit`=1, `ObservableObject`=1, `SwiftUI`=1, `scrollTo`=1
- Source comments carrying design intent:
  - L5: // MARK: - Console model
  - L21: /// Manages the console state: lines buffer, history, running process (SPEC §3.1).
  - L71: // Git-scope fence: bare first token → prepend "git ".
  - L107: /// Appends a GUI-action echo line (SPEC §3.2 GUI→Console).
  - L112: // MARK: - Private
  - L142: // MARK: - PTY Runner (SPEC §3.1)
  - L144: /// Runs a git command on a pseudo-TTY. Parses SGR color sequences; flags cursor movement.
  - L161: // Build the argv: ["git", "subcommand", ...]
  - L168: // Open PTY via POSIX (openpty is deprecated in macOS 14).
  - L199: // Find macgit-cli next to the running executable (works for both .app bundle and
  - L200: // plain-executable dev builds produced by make build).
  - L204: // Shell-quote the path so spaces in the bundle location don't split the command.
  - L230: // Move blocking Foundation.read off the actor executor so interrupt() can
  - L231: // preempt the loop and deliver SIGINT without waiting for a read to return.
  - L244: // Check for cursor-movement sequences (non-SGR).
  - L250: // Emit lines as they become available.
  - L261: // Flush remaining.
  - L277: // MARK: - Helpers (nonisolated: pure computation, safe to call from detached tasks)
  - L280: // Handles single- and double-quoted tokens so paths with spaces work correctly.
  - L309: // Cursor movement: ESC [ <n> A/B/C/D/H/f or ESC [ 2J etc. Exclude SGR (m).
  - L315: /// Strips SGR escape sequences and returns (clean text, color if any).
  - L322: // Skip to end of escape sequence (terminated by a letter).
  - L329: // SGR: parse color.
  - L363: // MARK: - Console Drawer View
  - L372: // Drag handle.
  - L387: // Scrollable output area.
  - L408: // Input bar.

### `MacGit/Sources/MacGitApp/MacGitApp.swift`

- Roles: MacGit NSTableView virtualized diff preview
- Lines: 4810
- Bytes: 189974
- Imports: AppKit, SwiftUI, UniformTypeIdentifiers, MacGitCore
- Declarations:
  - class `MacGitAppDelegate` : NSObject, NSApplicationDelegate
  - struct `MacGitApplication` : App
  - struct `WelcomeView` : View
  - struct `OperationErrorBanner` : View
  - struct `BranchRowView` : View
  - struct `UnbornBranchRowView` : View
  - struct `SidebarIconButton` : View
  - struct `RecentRowView` : View
  - struct `BranchSwitchSheet` : View
  - struct `NewBranchSheet` : View
  - struct `RenameBranchSheet` : View
  - struct `RepoHeaderView` : View
  - struct `BranchPreviewPopover` : View
  - struct `SnapshotDetectedBanner` : View
  - struct `ConflictBannerV0` : View
  - struct `ConflictBannerV1` : View
  - struct `CreateTagSheet` : View
  - struct `SquashSheet` : View
  - struct `ResetSheet` : View
  - struct `DetachedHeadBanner` : View
  - struct `RepositoryPresentations` : ViewModifier
  - struct `InitializeRepositorySheet` : View
  - struct `IgnorePatternSheet` : View
  - enum `PatternType` : String, CaseIterable, Identifiable
  - struct `ChangeRowView` : View, Equatable
  - struct `ChangesView` : View
  - struct `QuickLookDiffPopover` : View
  - class `DiffPreviewModel` : ObservableObject
  - struct `DiffContentView` : View
  - struct `CappedMonospacedTextView` : View
  - struct `VisualDiffView` : View
  - struct `SplitDiffView` : View
  - struct `VirtualizedDiffView` : NSViewRepresentable
  - class `Coordinator` : NSObject, NSTableViewDataSource, NSTableViewDelegate
  - struct `CommitDiffContentView` : View
  - struct `FileNode` : Identifiable
  - class `FolderViewModel` : ObservableObject
  - struct `FolderRowView` : View
  - struct `FolderView` : View
  - struct `DiffInspector` : View
  - enum `PreviewContent`
  - struct `CommitBar` : View
  - struct `UndoEntry`
  - struct `UndoLog`
  - enum `SwitchOption` : String
  - struct `BranchSwitchRequest` : Identifiable
  - class `RepositoryStore` : ObservableObject
  - struct `SelectedChangeDigest` : Equatable
  - struct `DiffCacheKey` : Equatable
  - struct `RecentRepositoryStore`
  - struct `MacGitCommands` : Commands
  - struct `OpenRepositoryActionKey` : FocusedValueKey
  - struct `RefreshRepositoryActionKey` : FocusedValueKey
  - struct `UndoRepositoryActionKey` : FocusedValueKey
  - struct `UndoRepositoryLabelKey` : FocusedValueKey
  - extension `FocusedValues`
  - class `HistoryViewModel` : ObservableObject
  - struct `CommitActions`
  - struct `HistoryView` : View
  - struct `CommitRowView` : View
  - struct `CommitHoverPopover` : View
  - struct `GraphLaneCanvas` : View
  - struct `RefChip` : View
- Functions/methods: `applicationShouldTerminateAfterLastWindowClosed`, `filesDetailContent`, `optionRow`, `loadCommits`, `loadDiffStats`, `loadFileDiff`, `modeRow`, `body`, `fileChangeIconName`, `fileChangeIconColor`, `statusText`, `isStaged`, `update`, `buildVisual`, `buildSplit`, `visualFileHeader`, `visualHunkHeader`, `visualLine`, `lineMarker`, `markerColor`, `rowBackground`, `splitRow`, `splitCell`, `makeCoordinator`, `makeNSView`, `updateNSView`, `attachAppearanceObserver`, `numberOfRows`, `tableView`, `tableView`, `capView`, `capText`, `sectionView`, `configureSection`, `lineView`, `numField`, `configureLine`, `load`, `selectFile`, `buildNodes`, `rebadge`, `collectPaths`, `walk`, `nodeContextMenu`, `push`, `pop`, `stopBridge`, `stopWatching`, `openRepositoryPanel`, `openRepository`, `activateRepository`, `cancelInitialization`, `openRecentRepository`, `openDroppedItems`, `initializePendingFolder`, `refresh`, `scheduleRefresh`, `runRefresh`, `setAmend`, `commitChanges`, `setStaged`, `clearOperationError`, `revealRepositoryInFinder`, `revealInFinder`, `openFile`, `copyRelativePath`, `copyFullPath`, `requestIgnore`, `confirmIgnore`, `cancelIgnore`, `editGitIgnore`, `requestDiscard`, `cancelDiscard`, `confirmDiscard`, `switchBranch`, `performBranchSwitch`, `cancelBranchSwitch`, `createBranch`, `renameBranch`, `requestDeleteBranch`
- Stored/visible properties: `body`, `selectedView`, `showConsole`, `historyActions`, `body`, `navigationContent`, `sidebarView`, `branchSidebarSection`, `tagSidebarSection`, `worktreeSidebarSection`, `linkedWorktrees`, `recentSidebarSection`, `detailView`, `message`, `dismissAction`, `body`, `branch`, `hasSnapshot`, `client`, `repositoryURL`, `switchAction`, `newBranchAction`, `renameAction`, `deleteAction`, `selectHistoryAction`, `showPreview`, `isHovered`, `body`, `branchName`, `newBranchAction`, `isHovered`, `body`, `icon`, `help`, `action`, `isHovered`, `body`, `recent`, `openAction`, `removeAction`, `isHovered`, `body`, `targetBranch`, `changeCount`, `isUnborn`, `savedOption`, `switchAction`, `cancelAction`, `selectedOption`, `rememberChoice`, `body`, `pref`, `createAction`, `cancelAction`, `name`, `body`, `isValid`, `currentName`, `renameAction`, `cancelAction`
- Relevant term counts: `Task`=99, `NSPasteboard`=18, `NSTableView`=14, `NSTextField`=12, `NSView`=11, `NSWorkspace`=11, `centerYAnchor`=10, `MainActor`=8, `leadingAnchor`=7, `nonisolated`=7, `trailingAnchor`=7, `AppKit`=5, `NSColor`=5, `ObservableObject`=4, `SwiftUI`=4, `translatesAutoresizingMaskIntoConstraints`=4, `wantsLayer`=4, `NSScrollView`=3, `widthAnchor`=3, `NSFont`=2, `NSLayoutConstraint`=2, `NSTableColumn`=2, `DispatchQueue`=1, `NSOpenPanel`=1, `NSViewRepresentable`=1, `NotificationCenter`=1, `effectiveAppearance`=1
- Source comments carrying design intent:
  - L7: // R-0038-12: terminate when all windows are closed.
  - L25: // Prevent SwiftUI from opening a new window for every file-open URL event;
  - L26: // MacGit manages its own single-window repository routing.
  - L133: // Proxy icon and Spotlight/dock title when a repo is open.
  - L602: // R-0038-11/13: Recent row with hover feedback and context menu.
  - L852: // Header
  - L870: // Tab bar
  - L880: // Content
  - L889: // R-0038-09: use .task(id: tab) so loading fires whenever the tab changes,
  - L890: // including when the popover re-opens with tab already == 1.
  - L943: // R-0038-10: surface error instead of silently showing empty state.
  - L992: // R-0038-09/10: proper error capture; isLoadingStats already set by caller.
  - L1405: // "By folder" only makes sense for directories or files with a parent subfolder.
  - L1450: // R-0039-02: pre-select .byFolder for files inside a subdirectory, not only directories.
  - L1456: // MARK: - Shared icon helpers (M11-D)
  - L1476: // R-0038-14: Equatable row to avoid re-rendering unchanged rows.
  - L1504: // R-0038-02: truncate long paths to single line
  - L1593: // R-0038-03: Stage All / Unstage All header
  - L1614: // R-0038-01: minWidth prevents the list from collapsing when HSplitView is narrow
  - L1632: // Keep the current primary stable when the selection grows (multi-select).
  - L1633: // Only move the primary when it's no longer in the new selection.
  - L1691: // MARK: - Visual Diff (M11-C)
  - L1695: // R-0038-04 / R-0039-01: cap for SwiftUI path; AppKit path uses visualMaxLines.
  - L1697: // Phase 6: visual mode stores up to this many lines for the AppKit virtualized renderer.
  - L1699: // Phase 6: items above this count use the AppKit NSTableView renderer instead of SwiftUI.
  - L2067: // MARK: - Phase 6: Virtualized diff renderer (AppKit NSTableView for large visual diffs)
  - L2291: /// Diff panel for commit history — visual/split/patch toggle, no external tool button.
  - L2317: // MARK: - Folder View (M10)
  - L2355: // Badge-only update when tree shape is unchanged (no new file paths detected).
  - L2361: // Full rebuild off-main.
  - L2737: // Check file size before reading to avoid allocating large buffers.
  - L2743: // Load raw bytes on background thread; NSImage (non-Sendable) created on main actor.
  - L3093: // Always release the in-flight lock regardless of how the Task exits (return, throw,
  - L3094: // or normal completion), then start a trailing refresh if one was requested.
  - L3109: // Discard stale results if repo switched or a newer refresh superseded this one.
  - L3148: // Capture HEAD before commit so it can be restored by undo.
  - L3299: // MARK: - Branch operations
  - L3341: // Stash fallback: SPEC §5.2.
  - L3380: // On unborn repos HEAD doesn't resolve; skip undo capture and use switch -c without start-point.
  - L3447: // MARK: - Undo
  - L3464: // MARK: - Snapshot
  - L3500: // MARK: - Conflict resolution (SPEC §2.6)
  - L3574: // Fire-and-forget: if no merge tool is configured the external process exits
  - L3575: // non-zero but the error is not actionable from the UI (user can see the tool
  - L3576: // did not open). hasMergeTool guards the button so this path is only reached
  - L3577: // when merge.tool is configured.
  - L3582: // MARK: - Cherry-pick (SPEC §2.4)
  - L3598: // Conflict: detection will show ConflictBannerV1 via inProgressOperation.
  - L3606: // MARK: - Revert (SPEC §2.4)
  - L3629: // MARK: - Reset current branch (SPEC §2.4)
  - L3657: // MARK: - Tag CRUD (SPEC §2.4)
  - L3689: // MARK: - Squash (SPEC §2.4)
  - L3724: // MARK: - Preferences
  - L3732: // MARK: - Private helpers
  - L3767: // Batch: one git log call for all branch OIDs instead of one process per branch.
  - L3819: // Use single-flight coordinator; operationErrorMessage is not cleared for watcher events.
  - L3832: // Diff cache: skip git if the same path+status was just loaded.
  - L3870: // Skip full re-render when git status is identical — prevents flicker from
  - L3871: // FSEvents that fire on .git internal writes with no actual worktree change.
  - L3877: // Primary path still present — only reload diff when its own status changed.
  - L3884: // Primary path gone — fall back to first available.
  - L3899: // R-0038-11: remove a single entry and clear all.
  - L3908: // R-0038-03: stage or unstage all changes at once.
  - L3937: // MARK: - Phase 2 dirty-detection helpers
  - L3964: // R-0038-11: remove one entry by id.
  - L3971: // R-0038-11: clear all entries.
  - L3997: // Try to resolve with security scope first (sandboxed build); fall back for non-sandboxed.
  - L4018: // Prefer security-scoped bookmarks (required for sandboxed Mac App Store builds);
  - L4019: // fall back to plain bookmarks in non-sandboxed builds where the entitlement is absent.
  - L4113: // MARK: - History View
  - L4175: // Non-fatal: show empty state
  - L4215: // R-0038-24: reset loading flag on nil path.
  - L4239: // R-0038-08: opens the external diff tool for a single file at a given commit.
  - L4249: // R-0038-07: extracts a file at a commit to a temp path and opens it.
  - L4277: // Filter snapshot WIP commits from the visible history (SPEC §5.1).
  - L4370: // Squash: only when multiple contiguous-from-HEAD commits selected, all unpushed.
  - L4396: // Must start from HEAD (index 0 in visible rows).
  - L4398: // Check contiguous block.
  - L4454: // R-0038-08: double-click opens external diff tool for this file at this commit.
  - L4458: // R-0038-07: context menu with file actions.

### `MacGit/Sources/MacGitApp/SocketBridge.swift`

- Roles: Support code
- Lines: 273
- Bytes: 9175
- Imports: Foundation, SwiftUI
- Declarations:
  - struct `BridgeRequest` : Codable
  - struct `BridgeResponse` : Codable
  - class `SocketBridge` : ObservableObject
  - struct `CommitMessageEditorSheet` : View
  - struct `AskpassSheet` : View
  - struct `SocketBridgePresentations` : ViewModifier
- Functions/methods: `start`, `stop`, `handleClient`, `sendFrameIO`, `recvAllBytes`, `sendAllBytes`, `body`
- Stored/visible properties: `type`, `path`, `prompt`, `ok`, `value`, `id`, `pendingRequest`, `id`, `path`, `prompt`, `reply`, `id`, `prompt`, `reply`, `serverFD`, `acceptTask`, `sunPathMax`, `path`, `fd`, `addr`, `addrLen`, `bindResult`, `clientFD`, `maybeRequest`, `response`, `lenBuf`, `len`, `body`, `len`, `received`, `r`, `sent`, `s`, `path`, `onDone`, `text`, `body`, `prompt`, `onDone`, `password`, `body`
- Relevant term counts: `Task`=9, `nonisolated`=5, `MainActor`=1, `NSString`=1, `ObservableObject`=1, `SwiftUI`=1
- Source comments carrying design intent:
  - L4: // MARK: - Wire protocol
  - L6: /// Simple length-prefixed framing over a UNIX domain socket.
  - L7: /// Frame: 4-byte big-endian uint32 length + UTF-8 JSON payload.
  - L8: /// Request JSON: {"type": "edit"|"askpass", "path": "...", "prompt": "..."}
  - L9: /// Response JSON: {"ok": true|false, "value": "..."}
  - L22: // MARK: - SocketBridge actor (app side)
  - L24: /// Listens on a UNIX domain socket in TMPDIR and dispatches edit/askpass sheets.
  - L25: /// The socket path is written to the environment so child processes can find it.
  - L28: /// Single-item enum so only one bridge sheet is presented at a time.
  - L59: // Maximum length of sun_path on Darwin is 104 bytes (including NUL terminator).
  - L66: // Validate path length before bind() to avoid silent truncation.
  - L117: // MARK: - Client handling
  - L122: // Receive request off main actor — blocking recv must not block the UI thread.
  - L128: // Present UI on main actor (we're already here).
  - L144: // Send response off main actor.
  - L151: // MARK: - Frame I/O (nonisolated static — safe to call from any executor)
  - L189: // MARK: - Editor sheet
  - L209: // Write the edited text back to disk; cli reads it.
  - L224: // MARK: - Askpass sheet
  - L251: // MARK: - SocketBridgePresentations ViewModifier

### `MacGit/Sources/MacGitCore/DiffStatParser.swift`

- Roles: Core diff/text/git/model logic
- Lines: 60
- Bytes: 2206
- Imports: Foundation
- Declarations:
  - enum `DiffStatParser`
- Functions/methods: `parse`, `count`
- Stored/visible properties: `tokens`, `stats`, `index`, `token`, `parts`, `added`, `deleted`, `pathPart`
- Source comments carrying design intent:
  - L3: /// Pure `String -> [DiffStat]` parser for `git diff --numstat -z` (SPEC §6.2).
  - L4: ///
  - L5: /// Record shape (R-0005-02): `added<TAB>deleted<TAB>` then either `path` (normal) or an empty slot
  - L6: /// followed by two NUL tokens `oldpath` `newpath` (rename/copy). Binary files report `-` for both
  - L7: /// counts. Splitting the whole stream on NUL yields, per normal file, one token
  - L8: /// `added\tdeleted\tpath`; per rename, the token `added\tdeleted\t` plus two path tokens.
  - L36: // Rename/copy: next two tokens are original then new path.
  - L56: /// `-` marks a binary file (no line counts).

### `MacGit/Sources/MacGitCore/ForEachRefParser.swift`

- Roles: Core diff/text/git/model logic
- Lines: 71
- Bytes: 2923
- Imports: Foundation
- Declarations:
  - enum `ForEachRefParser`
- Functions/methods: `parse`, `suffix`, `parseTrack`, `leadingInt`
- Stored/visible properties: `format`, `fieldCount`, `branches`, `tags`, `fields`, `refname`, `objectName`, `headMark`, `upstreamShort`, `track`, `derefObjectName`
- Source comments carrying design intent:
  - L3: /// Pure `String -> RefList` parser for `git for-each-ref` (SPEC §6.2).
  - L4: ///
  - L5: /// Ref names cannot contain newline or NUL, so records are newline-separated and fields are
  - L6: /// `%00`-separated — unambiguous without `-z`. ahead/behind come from `%(upstream:track)` rather
  - L7: /// than `%(ahead-behind:)`, which is git 2.41+ and above the 2.39 floor (R-0003-02).
  - L9: /// `refname \0 objectname \0 HEAD \0 upstreamShort \0 upstreamTrack \0 derefObjectname`
  - L60: /// `%(upstream:track)` is `[ahead N, behind M]`, `[ahead N]`, `[behind M]`, `[gone]`, or empty.

### `MacGit/Sources/MacGitCore/GitClient.swift`

- Roles: Core diff/text/git/model logic
- Lines: 323
- Bytes: 12370
- Imports: Foundation
- Declarations:
  - extension `GitClient`
  - enum `OpKind` : Sendable
  - struct `GitResult` : Equatable, Sendable
  - enum `GitError` : Error, Equatable, CustomStringConvertible, Sendable
  - class `PipeDrain` : @unchecked Sendable
  - class `ResumeOnceBox` : @unchecked Sendable
- Functions/methods: `run`, `requireSuccess`, `validateInstallation`, `execute`, `ensureSupportedGit`, `acquireMutationLock`, `releaseMutationLock`, `read`, `markTimedOut`, `resume`
- Stored/visible properties: `executableURL`, `baseEnvironment`, `resolvedVersion`, `isMutating`, `mutationWaiters`, `emptyDirCache`, `minimumGitVersion`, `result`, `process`, `gitArguments`, `stdout`, `stderr`, `outReader`, `errReader`, `drainGroup`, `drainQueue`, `timedOut`, `pid`, `timeoutTask`, `box`, `result`, `version`, `defaultEnvironment`, `arguments`, `exitCode`, `stdoutData`, `stderr`, `stdout`, `succeeded`, `description`, `handle`, `maxBytes`, `chunkSize`, `chunk`, `remaining`, `lock`, `resumed`, `continuation`
- Relevant term counts: `Task`=5, `DispatchQueue`=1
- Source comments carrying design intent:
  - L9: /// Incremented on every mutation; callers can snapshot before and compare after
  - L10: /// to detect whether a concurrent mutation has occurred and discard stale results.
  - L12: /// Cache of empty-untracked-directory scan results: repoPath → (dirs, systemUptime at cache time).
  - L57: /// Resolves and validates the git installation (≥ ``minimumGitVersion``), returning the
  - L58: /// discovered version. Cached after the first success; throws a friendly install-guidance
  - L59: /// error when git is missing or too old (SPEC §6.2 / A1).
  - L66: // MARK: - Internal execution
  - L68: /// Spawns git once, draining both pipes concurrently. Bypasses the version gate and the
  - L69: /// mutation queue — callers go through ``run(_:in:kind:timeout:)``.
  - L77: // Stateless w.r.t. CWD: explicit `-C <path>` on every call (SPEC §6.2), never the
  - L78: // per-process working directory.
  - L94: // Drain both pipes concurrently. Caps: stdout 32 MB, stderr 256 KB.
  - L109: // Grace period: if still running after 3 s, SIGKILL.
  - L114: // Non-blocking wait via termination handler so the actor executor is not blocked.
  - L115: // Use a lock-protected flag to prevent double-resume if the process already exited.
  - L193: /// Reads run concurrently (status, log, diff…).
  - L195: /// Mutations are serialized so two GUI actions can never interleave (SPEC §6.2).
  - L202: /// Raw stdout bytes — preserves binary fidelity for image diffs, `cat-file`, and
  - L203: /// NUL-delimited output (SPEC §6.2 `GitOutput.stdout: Data`).
  - L207: /// UTF-8 decoded stdout for text commands.
  - L226: /// Switching would overwrite local changes that can't be carried forward cleanly.
  - L228: /// Target branch is already checked out in another worktree.
  - L230: /// Attempted a branch-level op while a merge/rebase/cherry-pick is in progress.
  - L232: /// Git command output exceeded the hard byte cap and was truncated.
  - L265: /// Concurrent pipe reader with a hard byte cap. `@unchecked Sendable` because the wrapped
  - L266: /// `FileHandle` is confined to a single drain queue and results are read only after the
  - L267: /// `DispatchGroup` completes.
  - L290: // Drain remaining bytes to prevent pipe-buffer deadlock.
  - L306: /// Thread-safe wrapper that resumes a `CheckedContinuation` at most once.

### `MacGit/Sources/MacGitCore/GitCommit.swift`

- Roles: Core diff/text/git/model logic
- Lines: 62
- Bytes: 2443
- Imports: Foundation
- Declarations:
  - extension `GitClient`
- Functions/methods: `stageAll`, `stage`, `unstage`, `commit`, `commitAll`, `commitAmend`, `hasHead`
- Stored/visible properties: `trimmedMessage`, `result`, `trimmedMessage`, `result`, `result`

### `MacGit/Sources/MacGitCore/GitDiff.swift`

- Roles: Core diff/text/git/model logic
- Lines: 44
- Bytes: 2157
- Imports: Foundation
- Declarations:
  - extension `GitClient`
- Functions/methods: `diff`, `diff`, `diff`, `openDiffTool`, `showFileText`
- Stored/visible properties: `unstaged`, `staged`, `result`, `result`, `result`, `text`
- Source comments carrying design intent:
  - L14: /// Returns the diff for a specific file as introduced by `sha` (SPEC §2.4 inspector).
  - L15: /// Uses `git show <sha> -- <path>` which includes the commit header and the unified diff.
  - L21: /// Returns the diff of `path` between two revisions (e.g. `HEAD...branchName` for branch preview).
  - L30: /// Opens the configured external diff tool (`git difftool`) for a working-tree file.
  - L31: /// Respects the user's `git config diff.tool`; falls back to `opendiff` (FileMerge) on macOS.
  - L36: /// Returns the text content of a file at a given commit (using `git show SHA:path`).
  - L37: /// Returns nil for binary files, files larger than 512 KB, or errors.

### `MacGit/Sources/MacGitCore/GitDiffStat.swift`

- Roles: Core diff/text/git/model logic
- Lines: 53
- Bytes: 2216
- Imports: Foundation
- Declarations:
  - struct `DiffStat` : Equatable, Sendable, Identifiable
  - extension `GitClient`
- Functions/methods: `diffStat`, `diffStat`, `diffStat`
- Stored/visible properties: `path`, `originalPath`, `added`, `deleted`, `id`, `isBinary`, `isRename`, `arguments`, `result`, `result`, `result`
- Source comments carrying design intent:
  - L3: /// Per-file line-change summary for the inspector file list (SPEC §2.4). `added`/`deleted` are
  - L4: /// `nil` for binary files (git reports `-`). `originalPath` is set for renames/copies.
  - L24: /// Working-tree numstat: unstaged by default, staged when `staged` is true (SPEC §6.2).
  - L34: /// Numstat for the change introduced by a single commit. `<sha>^!` diffs the commit against its
  - L35: /// parents (the empty tree for a root commit, i.e. everything added). Reused by M3 history.
  - L44: /// Numstat between two revisions — used by branch preview to show files that differ.
  - L45: /// Typical usage: `diffStat(from: "HEAD", to: branchName, in: url)`.

### `MacGit/Sources/MacGitCore/GitLog.swift`

- Roles: Core diff/text/git/model logic
- Lines: 66
- Bytes: 2126
- Imports: Foundation
- Declarations:
  - struct `Commit` : Equatable, Sendable, Identifiable
  - extension `GitClient`
- Functions/methods: `log`
- Stored/visible properties: `sha`, `parents`, `authorName`, `authorEmail`, `authorDate`, `subject`, `id`, `isMerge`, `isRoot`, `arguments`, `result`
- Source comments carrying design intent:
  - L3: /// A single commit as needed by the History view (SPEC §2.4) and GraphLayout (M1.4).
  - L4: /// `parents` carries the full parent list so lane assignment and merge detection work without
  - L5: /// a second query.
  - L36: /// Reads a page of history as `[Commit]` (SPEC §2.4, §7: 500/page, infinite scroll).
  - L37: /// A repository with no commits yet returns `[]` rather than erroring — that is a normal,
  - L38: /// expected state for a freshly initialized repo, not a failure.
  - L58: // Unborn branch / empty repo: `git log` exits non-zero with this message.

### `MacGit/Sources/MacGitCore/GitLogParser.swift`

- Roles: Core diff/text/git/model logic
- Lines: 68
- Bytes: 2500
- Imports: Foundation
- Declarations:
  - enum `GitLogParser`
- Functions/methods: `parse`
- Stored/visible properties: `format`, `fieldCount`, `fields`, `dateParser`, `commits`, `index`, `sha`, `parentField`, `authorName`, `authorEmail`, `dateField`, `subject`, `parents`
- Source comments carrying design intent:
  - L3: /// Pure `String -> [Commit]` parser for `git log` output (SPEC §6.2: machine-readable format only).
  - L4: ///
  - L5: /// Format (R-0001-02): each field is `%x00`-separated and `-z` terminates each commit record with a
  - L6: /// trailing NUL, so the whole stream is NUL-separated tokens grouped `fieldCount` at a time. The
  - L7: /// scheme is unambiguous because none of the fields can contain a NUL: `%s` is the single-line
  - L8: /// subject, `%P` is a space-separated SHA list, and `%aI` is strict ISO-8601.
  - L10: /// `sha \0 parents \0 authorName \0 authorEmail \0 authorDateISO \0 subject`
  - L21: // `-z` terminates the final record too, leaving a trailing empty token.

### `MacGit/Sources/MacGitCore/GitRefs.swift`

- Roles: Core diff/text/git/model logic
- Lines: 389
- Bytes: 17687
- Imports: Foundation
- Declarations:
  - struct `Branch` : Equatable, Sendable, Identifiable
  - struct `Tag` : Equatable, Sendable, Identifiable
  - struct `RefList` : Equatable, Sendable
  - struct `WorktreeInfo` : Equatable, Sendable, Identifiable
  - extension `GitClient`
- Functions/methods: `refs`, `isHeadPushed`, `switchBranch`, `createBranch`, `renameBranch`, `deleteBranch`, `isBranchMerged`, `resetHard`, `resetMixed`, `resetSoft`, `updateRef`, `revParse`, `isOperationInProgress`, `stashPushIncludingUntracked`, `stashPop`, `stashDrop`, `addWorktree`, `removeWorktree`, `listWorktrees`, `parseWorktreePorcelain`, `cherryPick`, `cherryPickContinue`, `cherryPickAbort`, `revert`, `revertContinue`, `revertAbort`, `rebaseContinue`, `rebaseAbort`, `mergeContinue`, `mergeAbort`, `takeOurs`, `takeTheirs`, `createTag`, `deleteTag`, `detectOperationInProgress`, `mergeTool`, `launchMergeTool`, `remoteURL`
- Stored/visible properties: `name`, `targetOID`, `isCurrent`, `upstream`, `ahead`, `behind`, `id`, `name`, `targetOID`, `id`, `branches`, `tags`, `path`, `branch`, `isMain`, `id`, `result`, `result`, `result`, `stderr`, `args`, `result`, `flag`, `result`, `result`, `result`, `gitDir`, `fm`, `base`, `result`, `statusResult`, `conflicts`, `args`, `result`, `args`, `result`, `worktrees`, `path`, `branch`, `isFirst`, `ref`, `result`, `result`, `args`, `gitDir`, `fm`, `base`, `result`, `result`, `url`
- Source comments carrying design intent:
  - L3: /// A local branch (SPEC §2.4 chips, §M3.2 sidebar). `ahead`/`behind` are relative to the configured
  - L4: /// upstream; both are 0 when there is no upstream.
  - L32: /// A tag. `targetOID` is the *commit* it points at — annotated tags are dereferenced so chips land
  - L33: /// on the right history row (R-0003-03).
  - L56: /// A git worktree listing entry.
  - L65: /// Lists local branches and tags via `for-each-ref` (SPEC §6.2). A repository with no refs
  - L66: /// (freshly initialized) returns empty lists, not an error.
  - L77: /// Returns `true` when HEAD is reachable from any remote-tracking ref — i.e., the current
  - L78: /// commit has been pushed. Returns `false` for unborn branches, repos with no remotes, or when
  - L79: /// HEAD is not reachable from any remote ref.
  - L86: /// Switches to `branch`. Throws `GitError.wouldOverwrite` when the tree is dirty and git
  - L87: /// refuses, `GitError.operationInProgress` when a merge/rebase is active.
  - L105: /// Creates a new branch at `startPoint` (default: HEAD), then switches to it.
  - L106: /// On an unborn repo (no commits) pass `startPoint: nil` — `git switch -c` works without HEAD.
  - L116: /// Renames `oldName` to `newName`.
  - L121: /// Deletes `name`. Pass `force: true` to delete unmerged branches (`-D`).
  - L130: /// Returns `true` if `branchName` is merged into the current HEAD (safe to delete).
  - L139: /// Hard-resets the current branch to `sha` (dangerous — callers must snapshot first).
  - L144: /// Mixed-reset HEAD to `sha` (drops commit; index ← tree at sha; worktree unchanged).
  - L149: /// Soft-reset HEAD to `sha` (drops commit; index keeps staged changes; worktree unchanged).
  - L154: /// Updates a ref to point at `sha` (used by UndoLog to restore branch tips).
  - L159: /// Returns the SHA of `ref` (or HEAD when `ref` is nil). Returns `nil` for unborn branches.
  - L166: /// Returns true when a merge/rebase/cherry-pick is currently in progress.
  - L178: // MARK: - Stash (used only as silent fallback for Option B bring-along; SPEC §5.2)
  - L180: /// Stashes all changes including untracked (`-u`). Returns the stash ref (e.g. `stash@{0}`).
  - L190: /// Applies and removes the top stash. Returns conflicted file paths if the pop conflicted.
  - L194: // Pop failed: collect conflicted files from the index.
  - L200: /// Drops the stash entry at `ref` (e.g. `stash@{0}`).
  - L205: // MARK: - Worktrees
  - L207: /// Adds a linked worktree for `branch` at `path`. If `createBranch` is true, creates the
  - L208: /// branch first (equivalent to `git worktree add -b <branch> <path>`).
  - L222: /// Removes a linked worktree. Pass `force: true` if the worktree has uncommitted changes.
  - L229: /// Lists all linked worktrees (including the main one).
  - L265: // MARK: - Cherry-pick (SPEC §2.4)
  - L285: // MARK: - Revert (SPEC §2.4)
  - L305: // MARK: - Rebase continue / abort (interactive rebase via console; SPEC §6.4)
  - L315: // MARK: - Merge continue / abort
  - L325: // MARK: - Conflict resolution helpers (SPEC §2.6)
  - L327: /// Checks out our version of a conflicted file and stages it.
  - L333: /// Checks out their version of a conflicted file and stages it.
  - L339: // MARK: - Tags (SPEC §2.4)
  - L341: /// Creates a lightweight tag (when message is nil) or an annotated tag.
  - L356: // MARK: - Operation detection (replaces Bool isOperationInProgress)
  - L358: /// Returns the specific in-progress operation, if any.
  - L372: /// Returns the merge.tool config value (empty string when unconfigured).
  - L378: /// Launches mergetool for a specific file (fire-and-forget; opens external tool).
  - L383: /// Returns the fetch URL for the named remote, or nil when no such remote exists.

### `MacGit/Sources/MacGitCore/GitRepository.swift`

- Roles: Core diff/text/git/model logic
- Lines: 55
- Bytes: 1938
- Imports: Foundation
- Declarations:
  - struct `RepositoryLocation` : Equatable, Sendable
  - extension `GitClient`
- Functions/methods: `repositoryRoot`, `initializeRepository`, `writeDefaultGitIgnore`
- Stored/visible properties: `rootURL`, `result`, `path`, `gitIgnoreURL`, `template`, `handle`

### `MacGit/Sources/MacGitCore/GitStatus.swift`

- Roles: Core diff/text/git/model logic
- Lines: 205
- Bytes: 6747
- Imports: Foundation
- Declarations:
  - enum `RepositoryHeadState` : Equatable, Sendable
  - enum `InProgressOperation` : Equatable, Sendable
  - struct `RepositoryStatus` : Equatable, Sendable
  - extension `RepositoryStatus`
  - struct `BranchStatus` : Equatable, Sendable
  - struct `FileChange` : Equatable, Sendable
  - extension `FileChange`
  - enum `GitFileStatus` : Character, Equatable, Sendable
  - extension `GitClient`
- Functions/methods: `status`, `cachedEmptyUntrackedDirectories`, `emptyUntrackedDirectoriesScan`, `scan`
- Stored/visible properties: `branchName`, `isUnborn`, `isDetached`, `oid`, `branch`, `changes`, `hasStagedChanges`, `headState`, `head`, `oid`, `upstream`, `ahead`, `behind`, `path`, `originalPath`, `stagedStatus`, `worktreeStatus`, `isStaged`, `result`, `parsed`, `emptyDirs`, `allChanges`, `key`, `now`, `fresh`, `fm`, `repoPath`, `gitPath`, `result`, `deadline`, `timedOut`, `nonGit`, `rel`, `isDir`
- Source comments carrying design intent:
  - L3: /// Explicit model of the HEAD state derived from porcelain v2 branch fields.
  - L5: /// Freshly initialized repo with no commits; `branchName` is the configured initial branch.
  - L7: /// Normal branch with at least one commit.
  - L9: /// Detached HEAD (no branch name).
  - L51: /// The specific git operation currently in progress (merge/cherry-pick/rebase/revert).
  - L157: // Returns cached empty-dir results if within the 10s TTL; otherwise re-scans with a 50ms budget.
  - L169: // Scans the working tree (up to 5 levels deep) for directories that are completely
  - L170: // empty (no files, no non-empty subdirectories). Git ignores such directories entirely,
  - L171: // so they would otherwise be invisible in the changes list. Stops early if the 50ms
  - L172: // budget is exceeded, returning whatever was found so far.

### `MacGit/Sources/MacGitCore/GitVersion.swift`

- Roles: Core diff/text/git/model logic
- Lines: 46
- Bytes: 1684
- Imports: (none)
- Declarations:
  - struct `GitVersion` : Comparable, Equatable, Sendable
  - extension `GitClient`
- Functions/methods: `parse`, `version`
- Stored/visible properties: `major`, `minor`, `patch`, `parts`, `major`, `minor`, `patch`, `result`
- Source comments carrying design intent:
  - L38: // Probes the binary directly so it doubles as the version-gate primitive without recursing
  - L39: // through ``run(_:in:kind:timeout:)``.

### `MacGit/Sources/MacGitCore/GitWorkingTree.swift`

- Roles: Core diff/text/git/model logic
- Lines: 70
- Bytes: 2679
- Imports: Foundation
- Declarations:
  - struct `BackupRef` : Equatable, Sendable
  - extension `GitClient`
- Functions/methods: `createBackupRef`, `discard`, `appendToGitIgnore`, `isTracked`, `backupRefTimestamp`
- Stored/visible properties: `name`, `timestamp`, `name`, `backupRef`, `gitIgnoreURL`, `line`, `existing`, `handle`, `result`, `formatter`

### `MacGit/Sources/MacGitCore/GraphLayout.swift`

- Roles: Core diff/text/git/model logic
- Lines: 89
- Bytes: 3723
- Imports: Foundation
- Declarations:
  - enum `GraphLayout`
  - struct `Row` : Equatable, Sendable, Identifiable
- Functions/methods: `compute`, `firstFreeLane`
- Stored/visible properties: `sha`, `lane`, `parentLanes`, `outgoing`, `id`, `active`, `rows`, `matches`, `lane`, `parentLanes`, `free`, `outgoing`
- Source comments carrying design intent:
  - L3: /// Incremental commit-graph lane assignment (SPEC §2.4, plan M1.4).
  - L4: ///
  - L5: /// Pure function `[Commit] -> [Row]`. Commits arrive newest-first (as `git log` emits them) and are
  - L6: /// processed strictly top-to-bottom; each row's result depends only on the rows above it, never
  - L7: /// below. That is the stability contract (R-0007-02): pages extend history *downward* (older commits
  - L8: /// appended), so `compute(prefix + suffix)`'s first `prefix.count` rows are identical to
  - L9: /// `compute(prefix)`. A commit that is a tip in an earlier page stays a tip.
  - L10: ///
  - L11: /// Lane assignment tracks, for each column, the SHA that column is "waiting to draw" (a child's
  - L12: /// parent pointer). A commit takes the column waiting for it (the leftmost, if several children
  - L13: /// converge), its first parent inherits that column, and additional parents fan out into free
  - L14: /// columns — reusing an existing column when another commit already tracks that parent (merge
  - L15: /// convergence). Color is a render concern (`lane % 8`, M3) and is intentionally absent here.
  - L19: /// Column of the commit dot.
  - L21: /// Column each parent occupies going down; drives merge fan-out lines.
  - L23: /// Lane occupancy at the bottom edge of this row (index = column, nil = free). With the next
  - L24: /// row's `lane`, this fully determines the edge segments crossing the gap.
  - L46: // Converging children: free the other columns waiting for this commit.

### `MacGit/Sources/MacGitCore/MacGitBuild.swift`

- Roles: Core diff/text/git/model logic
- Lines: 6
- Bytes: 227
- Imports: (none)
- Declarations:
  - enum `MacGitBuild`
- Stored/visible properties: `productName`, `bundleIdentifier`, `version`, `minimumMacOSVersion`

### `MacGit/Sources/MacGitCore/ParsedDiff.swift`

- Roles: Core diff/text/git/model logic
- Lines: 108
- Bytes: 3989
- Imports: Foundation
- Declarations:
  - struct `DiffFile` : Sendable
  - struct `DiffHunk` : Sendable
  - enum `DiffLineKind` : Sendable
  - struct `DiffLine` : Sendable
- Functions/methods: `parseDiff`, `hunkLineNumbers`, `leadingInt`
- Stored/visible properties: `oldPath`, `newPath`, `hunks`, `isBinary`, `header`, `oldStart`, `newStart`, `lines`, `kind`, `oldNumber`, `newNumber`, `text`, `lines`, `files`, `i`, `oldPath`, `newPath`, `hunks`, `l`, `p`, `p`, `header`, `dLines`, `oldN`, `newN`, `l`, `old`, `new`
- Source comments carrying design intent:
  - L3: /// A single file section within a unified diff.
  - L11: /// A `@@` hunk within a diff file section.
  - L30: /// Parses a unified diff string (output of `git diff` / `git show`) into structured `DiffFile` values.
  - L43: // Consume file header lines (---, +++, index, mode, similarity, etc.)
  - L56: // Consume hunks
  - L75: // "No newline at end of file" — skip
  - L80: // empty or inter-hunk meta lines are skipped
  - L95: /// Extracts (oldStart, newStart) from a hunk header like `@@ -1,5 +1,6 @@ ctx`.

### `MacGit/Sources/MacGitCore/PorcelainV2StatusParser.swift`

- Roles: Core diff/text/git/model logic
- Lines: 124
- Bytes: 4901
- Imports: (none)
- Declarations:
  - enum `PorcelainV2StatusParser`
- Functions/methods: `parse`, `parseOrdinary`, `parseRename`, `parseUnmerged`, `parseXY`
- Stored/visible properties: `records`, `branchHead`, `branchOID`, `upstream`, `ahead`, `behind`, `changes`, `index`, `record`, `value`, `value`, `fields`, `originalPath`, `fields`, `status`, `fields`, `status`, `fields`, `staged`, `worktree`
- Source comments carrying design intent:
  - L98: // Porcelain v2 unmerged record: "u <xy> <sub> <m1> <m2> <m3> <mW> <h1> <h2> <h3> <path>"

### `MacGit/Sources/MacGitCore/RenameGrouper.swift`

- Roles: Core diff/text/git/model logic
- Lines: 123
- Bytes: 5616
- Imports: Foundation
- Declarations:
  - enum `RenameGrouper`
- Functions/methods: `group`, `parentDir`, `basename`
- Stored/visible properties: `deletedWorktree`, `untrackedFiles`, `result`, `usedDeleted`, `usedUntracked`, `deletedByDir`, `untrackedByDir`, `sortedDirs`, `dPaths`, `dBasenames`, `uPaths`, `uBasenames`, `oldPath`, `newPath`, `remainingDeleted`, `remainingUntracked`, `untrackedByBasename`, `usedDeletedFile`, `usedUntrackedFile`, `base`, `u`
- Source comments carrying design intent:
  - L3: /// Detects OS-level renames (not staged via `git mv`) by pairing worktree-deleted
  - L4: /// tracked entries with untracked entries. Two strategies:
  - L5: ///
  - L6: /// 1. **Directory rename**: If all deleted entries inside an old directory correspond
  - L7: ///    (same basenames) to untracked entries in a different directory, with ≥2 matching
  - L8: ///    files, emit one synthetic directory-rename entry and suppress the individual pairs.
  - L9: ///
  - L10: /// 2. **File rename**: For any remaining deleted/untracked pair sharing an identical
  - L11: ///    basename with exactly one match on each side, emit a synthetic file-rename entry.
  - L12: ///
  - L13: /// Staged rename entries (produced by `git mv`) already arrive as a single `FileChange`
  - L14: /// with `stagedStatus == .renamed` from `PorcelainV2StatusParser` and are untouched.
  - L17: // Only worktree-deleted tracked files are candidates for OS-level rename source.
  - L21: // Only plain untracked files (not directory entries with trailing /).
  - L29: // Preserve all other changes; pairs will be added back below.
  - L38: // MARK: Step 1 — Directory rename detection
  - L45: // Compare every (oldDir, newDir) pair for matching basename sets.
  - L46: // Process larger groups first so a bigger rename wins over subsets.
  - L59: // All basenames must match exactly, with at least 2 files.
  - L64: // Emit one directory-rename entry (trailing / on both sides).
  - L77: // MARK: Step 2 — File rename detection (1:1 basename match)
  - L82: // Build basename → [untracked] lookup.
  - L106: // Add back unmatched entries unchanged.
  - L113: // MARK: - Helpers

### `MacGit/Sources/MacGitCore/RepoWatcher.swift`

- Roles: Core diff/text/git/model logic
- Lines: 119
- Bytes: 4422
- Imports: Foundation, CoreServices
- Functions/methods: `events`, `stop`, `startFSEvents`, `fire`, `events`, `stop`
- Stored/visible properties: `stream`, `continuation`, `debounceTask`, `selfRef`, `ctx`, `paths`, `flags`, `watcher`, `pathArray`, `paths`, `noisySuffixes`, `relevant`
- Relevant term counts: `Task`=10, `DispatchQueue`=2
- Source comments carrying design intent:
  - L6: /// Watches a repository directory for file-system changes using FSEvents (SPEC §6.3).
  - L7: /// Fires an `AsyncStream<Void>` event on change, debounced (trailing-edge, 300 ms).
  - L8: /// Ignores changes inside `.git/objects` (pack operations) and `.git/refs` writes
  - L9: /// that MacGit itself just made (not filtered — cheap refresh is fine).
  - L17: /// Returns an `AsyncStream` that fires once per debounce window when the repo changes.
  - L39: // MARK: - Private
  - L62: // eventPaths is CFArray of CFString when kFSEventStreamCreateFlagUseCFTypes is set.
  - L65: // Ignore git-internal write noise that does not reflect worktree changes:
  - L66: // .git/objects/ (pack ops), transient lock files, reflog entries (always
  - L67: // accompany a .git/HEAD or .git/refs/ write that will also be in the batch).
  - L107: // FSEventStream cleanup is handled by stop() — call it before releasing the watcher.
  - L108: // deinit cannot access actor-isolated state; release is managed via stop().
  - L111: // Non-macOS stub (for compilation on Linux CI if ever needed).

### `MacGit/Sources/MacGitCore/SnapshotEngine.swift`

- Roles: Core diff/text/git/model logic
- Lines: 150
- Bytes: 7198
- Imports: Foundation
- Declarations:
  - enum `SnapshotEngine`
  - struct `FileTimestamp` : Codable
- Functions/methods: `isSnapshotCommit`, `detectSnapshot`, `realTip`, `createSnapshot`, `restoreSnapshot`, `timestampsURL`, `saveTimestamps`, `restoreTimestamps`, `loadAllTimestamps`, `subject`
- Stored/visible properties: `sentinelPrefix`, `result`, `current`, `subj`, `currentStatus`, `modified`, `created`, `fm`, `all`, `branchMap`, `filePath`, `all`, `fm`, `filePath`, `attrs`, `decoded`, `result`
- Source comments carrying design intent:
  - L3: /// Implements the stashless WIP snapshot protocol from SPEC §5.1.
  - L4: ///
  - L5: /// Snapshot shape: two WIP commits on the branch tip —
  - L6: ///   parent~1  «macgit-wip» index    (staged state, --allow-empty)
  - L7: ///   parent    «macgit-wip» worktree (everything else incl. untracked)
  - L8: ///
  - L9: /// Restore: two-reset dance —
  - L10: ///   git reset --mixed HEAD~1   (drop worktree commit; index ← index-commit tree)
  - L11: ///   git reset --soft  HEAD~1   (drop index commit;    HEAD ← real parent)
  - L12: ///
  - L13: /// The sentinel prefix is checked by exact prefix match; do NOT change it (reflog stores it).
  - L21: /// Returns true when the current HEAD is the worktree-layer of a snapshot.
  - L32: /// Returns the real (pre-snapshot) tip SHA for the given branch, walking back past any
  - L33: /// snapshot commits. Used for push guard, History filtering, and branch-from-here.
  - L49: /// Creates a snapshot of the current dirty state on `branch`.
  - L50: /// Saves file modification/creation timestamps beforehand so `restoreSnapshot`
  - L51: /// can reapply them after git rewrites the files.
  - L52: /// Precondition: not in a merge/rebase/cherry-pick in-progress state.
  - L54: // Require at least one commit on the branch (unborn HEAD cannot be snapshot-committed).
  - L61: // 1. Commit whatever is staged (--allow-empty for clean index case).
  - L67: // 2. Stage everything remaining (untracked, unstaged).
  - L69: // 3. Commit the worktree state.
  - L77: /// Restores a snapshot on `branch`. The branch tip must be a `«macgit-wip» worktree`
  - L78: /// commit (i.e., `detectSnapshot` returns true).
  - L80: // Drop worktree commit; index ← index-commit tree.
  - L82: // Drop index commit; HEAD ← real parent; index retains staged set.
  - L84: // Reapply saved file timestamps so Finder shows the original modification times.
  - L88: // MARK: - Timestamp persistence
  - L144: // MARK: - Private helpers

### `MacGit/Sources/macgit-cli/main.swift`

- Roles: Core diff/text/git/model logic
- Lines: 498
- Bytes: 18161
- Imports: Foundation, MacGitCore
- Declarations:
  - struct `BridgeCLIRequest` : Codable
  - struct `BridgeCLIResponse` : Codable
- Functions/methods: `writeStderr`, `bridgeRoundtrip`, `recvAllBytes`, `sendAllBytes`
- Stored/visible properties: `data`, `type`, `path`, `prompt`, `ok`, `value`, `fd`, `addr`, `connected`, `len`, `lenBuf`, `respLen`, `body`, `received`, `r`, `sent`, `s`, `arguments`, `client`, `version`, `repositoryURL`, `client`, `status`, `branchName`, `path`, `client`, `location`, `client`, `location`, `commandArguments`, `repositoryURL`, `message`, `client`, `output`, `commandArguments`, `repositoryURL`, `message`, `client`, `output`, `commandArguments`, `repositoryURL`, `message`, `client`, `output`, `commandArguments`, `client`, `pushed`, `commandArguments`, `client`, `commandArguments`, `client`, `commandArguments`, `client`, `output`, `commandArguments`, `client`, `commandArguments`, `client`, `commandArguments`, `maxCount`
- Source comments carrying design intent:
  - L10: // MARK: - Bridge IPC helpers (used by _edit and _askpass)
  - L23: /// Synchronous round-trip: send request frame, receive response frame.
  - L48: // Read response.
  - L77: // MARK: - Commands
  - L434: // Called by git as GIT_EDITOR: open a native editor sheet in MacGitApp.
  - L435: // Usage: macgit-cli _edit <file>
  - L449: // Called by git as GIT_ASKPASS: prompt for a credential.
  - L450: // Usage: macgit-cli _askpass <prompt>

### `MacMerge/Sources/DiffCore/Diff3.swift`

- Roles: Core diff/text/git/model logic
- Lines: 111
- Bytes: 4339
- Imports: (none)
- Declarations:
  - struct `Merge3Segment` : Sendable, Equatable
  - enum `Kind` : Sendable, Equatable
  - enum `Diff3`
- Functions/methods: `emitUnchanged`
- Stored/visible properties: `kind`, `base`, `left`, `right`, `dl`, `dr`, `segments`, `i`, `pos`, `lpos`, `len`, `nextStart`, `hi`, `li`, `grew`, `lo`, `sumBaseL`, `sumBaseR`, `leftLen`, `rightLen`, `leftRange`, `rightRange`, `hasL`, `kind`
- Source comments carrying design intent:
  - L1: /// Three-way merge segmentation (SPEC §3.3). Segments cover base, left, and
  - L2: /// right completely and in order. Adjacent change regions (no unchanged line
  - L3: /// between them) merge into one region — same behavior as git's diff3.
  - L33: // Change records against base: (base range, replacement range on that side).
  - L64: // Expand the region while changes from either side touch or overlap it.
  - L81: // Side lengths: unchanged-in-side portions stay 1:1; changed portions
  - L82: // contribute their replacement lengths.

### `MacMerge/Sources/DiffCore/DiffTypes.swift`

- Roles: Core diff/text/git/model logic
- Lines: 84
- Bytes: 3309
- Imports: (none)
- Declarations:
  - enum `DiffAlgorithm` : String, Sendable, Codable, CaseIterable
  - struct `DiffOptions` : Sendable
  - enum `HunkKind` : Sendable, Equatable
  - struct `Hunk` : Sendable, Equatable
  - struct `DiffResult` : Sendable, Equatable
- Functions/methods: `change`
- Stored/visible properties: `algorithm`, `histogramOccurrenceCap`, `myersMaxD`, `myersFallbackLimit`, `kind`, `left`, `right`, `isWhitespaceOnly`, `kind`, `hunks`, `isApproximate`, `changeCount`, `hasChanges`, `whitespaceOnlyChangeCount`
- Relevant term counts: `AppKit`=1
- Source comments carrying design intent:
  - L1: /// DiffCore — pure diff engine. No AppKit, no I/O. (SPEC §11.1)
  - L4: /// JGit-style histogram diff: anchor on low-occurrence common elements. Default.
  - L6: /// Patience diff: anchor on unique common elements only.
  - L8: /// Classic Myers O(ND). Exact, but capped by `myersMaxD`.
  - L14: /// Histogram: max occurrences of an element before it is rejected as an anchor.
  - L16: /// Myers: max edit distance explored before falling back to an approximate result.
  - L18: /// Regions up to this combined size may fall back from histogram to Myers.
  - L41: /// One contiguous region of the comparison. Hunks cover both inputs completely
  - L42: /// and in order: concatenating all `left` ranges yields `0..<a.count`, and all
  - L43: /// `right` ranges yields `0..<b.count`.
  - L48: /// Replace hunks whose paired lines differ only in whitespace (e.g. a
  - L49: /// re-indented block after extracting a function). Real but minor:
  - L50: /// display layers demote these so content changes stand out.
  - L61: /// Kind derived from range emptiness (insert/delete/replace) for non-equal hunks.
  - L70: /// True when an algorithm cap was hit and part of the result is a coarse block replace.
  - L80: /// How many of the changes are whitespace-only (subset of `changeCount`).

### `MacMerge/Sources/DiffCore/Differ.swift`

- Roles: Core diff/text/git/model logic
- Lines: 287
- Bytes: 11963
- Imports: (none)
- Declarations:
  - enum `Differ`
- Functions/methods: `longestIncreasingChain`, `normalized`, `hunks`
- Stored/visible properties: `hunks`, `approximate`, `aLo`, `bLo`, `pa`, `suffix`, `aIndex`, `bIndex`, `pairs`, `bEntry`, `anyCommon`, `anchors`, `prevA`, `best`, `score`, `exact`, `i`, `tailsJ`, `tailsIdx`, `parent`, `lo`, `mid`, `chain`, `aLo`, `suffix`, `out`, `h`, `merged`, `left`, `right`, `out`, `ai`, `idx`, `start`, `len`
- Source comments carrying design intent:
  - L1: /// Entry point for sequence diffs. Operates on any Hashable element type
  - L2: /// (lines, words, tokens, bytes). Ignore rules are applied by the caller via
  - L3: /// normalization — pass pre-normalized keys and display the raw content.
  - L30: // MARK: - Histogram (default; patience = occurrence cap 1)
  - L41: // Common prefix.
  - L48: // Common suffix (emitted after the middle).
  - L72: // Occurrence counts on BOTH sides. A single greedy anchor chosen
  - L73: // from one side's counts can pair an element with an unrelated
  - L74: // occurrence far away on the other side; one such crossing match
  - L75: // folds everything between into one-sided blocks (seen in practice:
  - L76: // a field unique in A anchored to an early duplicate in B, hiding
  - L77: // 500+ surviving lines).
  - L97: // Patience skeleton: elements unique on both sides, restricted to
  - L98: // a longest non-crossing chain — moved lines drop out of the
  - L99: // skeleton instead of forcing a crossing alignment.
  - L111: // Free the indexes before recursing: gap regions rebuild
  - L112: // their own, and holding these across recursion makes peak
  - L113: // memory quadratic in pathological inputs.
  - L128: // No unique-unique element: histogram fallback — anchor on the
  - L129: // element rarest across both sides (a one-sided count invites the
  - L130: // crossing failure above).
  - L143: // No shared element at all: a block replace is exact, not approximate.
  - L155: // Extend the anchor to its maximal equal run.
  - L172: /// Longest chain of pairs ascending in both coordinates. Input is
  - L173: /// ascending in `.i` with distinct `.j` values, so this is the classic
  - L174: /// O(n log n) LIS over `.j` with parent links.
  - L203: // MARK: - Myers (top level)
  - L229: // MARK: - Normalization
  - L231: /// Merges adjacent mergeable hunks, recomputes canonical kinds, drops empties.
  - L258: /// Builds covering hunks from an ascending list of matched index pairs.

### `MacMerge/Sources/DiffCore/DisplayModel.swift`

- Roles: Core diff/text/git/model logic
- Lines: 90
- Bytes: 4094
- Imports: (none)
- Declarations:
  - struct `DiffDisplayModel` : Sendable
  - struct `Row` : Sendable
- Functions/methods: `build`, `emitEqualRows`
- Stored/visible properties: `leftLine`, `rightLine`, `kind`, `changeIndex`, `collapsedCount`, `isWhitespaceOnly`, `rows`, `changeRowRanges`, `hiddenLineCount`, `model`, `count`, `leading`, `trailing`, `hidden`, `start`, `changeIndex`, `l`
- Source comments carrying design intent:
  - L1: /// Maps hunks to aligned display rows: matched lines stay level, one-sided
  - L2: /// regions render as phantom rows on the other side (SPEC §5.3).
  - L3: ///
  - L4: /// With a `context` limit, long identical runs collapse into a single marker
  - L5: /// row (`collapsedCount > 0`) so the view shows only the lines around each
  - L6: /// change — callers must label the view as partial when `hiddenLineCount > 0`.
  - L14: /// > 0 → marker row standing in for this many hidden identical lines.
  - L16: /// Mirrors `Hunk.isWhitespaceOnly` for the row's hunk.
  - L32: /// Display-row range of each non-equal hunk, in order (navigation targets).
  - L34: /// Total identical lines hidden behind marker rows (0 = full view).
  - L39: /// - Parameter context: identical lines to keep around each change;
  - L40: ///   nil shows the full file.
  - L60: // No context needed before the first change or after the last.

### `MacMerge/Sources/DiffCore/IntraLine.swift`

- Roles: Core diff/text/git/model logic
- Lines: 134
- Bytes: 5472
- Imports: (none)
- Declarations:
  - struct `IntraLineDiff` : Sendable, Equatable
  - enum `IntraLine`
- Functions/methods: `refine`, `appendCoalescing`, `tokenize`, `flushWord`
- Stored/visible properties: `leftChanged`, `rightChanged`, `similarity`, `rewriteThreshold`, `isRewrite`, `refinementLimit`, `lt`, `rt`, `leftTotal`, `rightTotal`, `result`, `leftRanges`, `rightRanges`, `sharedLength`, `lo`, `hi`, `lo`, `hi`, `visibleTotal`, `similarity`, `text`, `range`, `tokens`, `u16`, `wordStartU16`, `wordStartIdx`, `idx`, `ch`, `chU16`, `isWord`, `next`
- Relevant term counts: `NSRange`=1
- Source comments carrying design intent:
  - L1: /// Word-level refinement of a changed line pair. Returns changed character
  - L2: /// ranges as UTF-16 offsets (directly convertible to NSRange by UI layers).
  - L7: /// How much non-whitespace text the pair shares, length-weighted, 0…1.
  - L8: /// Low values mean the two lines are not versions of each other — the
  - L9: /// pairing is positional, and emphasis ranges would be confetti.
  - L12: /// Below this the pair reads as removed+added code, not an edited line.
  - L13: /// Calibrated on the scriptcat 1.3.2→1.4.0 corpus: genuine edits
  - L14: /// (renames, argument changes) score ≥ 0.5; positionally-paired
  - L15: /// unrelated lines cluster under 0.25.
  - L18: /// True when the pair should render as a rewrite (delete + insert),
  - L19: /// suppressing intra-line emphasis.
  - L32: /// Lines longer than this (UTF-16 units) are not refined — whole line marked changed.
  - L42: // Refinement skipped: similarity stays 1 so the pair keeps the
  - L43: // edited treatment rather than being misreported as a rewrite.
  - L55: // Whitespace tokens carry no identity (deep indents would make any
  - L56: // two lines look related), so similarity weighs only visible text.
  - L94: // MARK: - Tokenization
  - L101: /// Words (alphanumerics + underscore) as single tokens; everything else char-by-char.

### `MacMerge/Sources/DiffCore/Myers.swift`

- Roles: Core diff/text/git/model logic
- Lines: 73
- Bytes: 2436
- Imports: (none)
- Declarations:
  - enum `Myers`
- Stored/visible properties: `n`, `a0`, `aRange`, `cap`, `offset`, `v`, `trace`, `dFound`, `k`, `x0`, `x`, `y`, `matches`, `x`, `d`, `vd`, `k`, `prevK`, `prevX`, `prevY`
- Source comments carrying design intent:
  - L1: /// Classic Myers O(ND) greedy diff with full trace backtracking.
  - L2: /// Used for small regions (histogram fallback) and when explicitly selected.
  - L3: /// Memory is O(D²), so callers cap `maxD`; exceeding the cap returns nil.
  - L7: /// Returns covering hunks in absolute (slice) indices, or nil if `maxD` was exceeded.
  - L47: // Backtrack, collecting matched pairs (absolute indices).

### `MacMerge/Sources/DiffCore/TextDiff.swift`

- Roles: Core diff/text/git/model logic
- Lines: 560
- Bytes: 26585
- Imports: (none)
- Declarations:
  - enum `TextDiff`
  - struct `PairLine`
- Functions/methods: `diff`, `mergeSameKind`, `trimmed`, `alignKey`, `reanchor`, `resplit`, `pair`, `pairRegion`, `emitGap`, `score`, `markWhitespaceOnlyReplaces`, `slide`, `shifted`, `boundaryScore`, `indentWidth`
- Stored/visible properties: `leftContent`, `rightContent`, `alignLeft`, `alignRight`, `aligned`, `approximate`, `hunks`, `out`, `sub`, `t`, `reanchorMaxRun`, `reanchorMaxWindow`, `result`, `i`, `run`, `winL`, `winR`, `oldMass`, `flankCap`, `sub`, `newMass`, `rebased`, `out`, `n`, `k`, `start`, `runEqual`, `left`, `right`, `whitespaceOnly`, `pairingCellLimit`, `pairingThreshold`, `out`, `i`, `h`, `j`, `left`, `right`, `l`, `leftInfo`, `rightInfo`, `stride`, `dp`, `skip`, `s`, `take`, `pairs`, `li`, `here`, `s`, `allPairs`, `nextL`, `lo`, `hi`, `bottom`, `out`, `prevL`, `k`, `start`, `trimEqual`
- Source comments carrying design intent:
  - L1: /// Text-aware line diff (SPEC §3.2). Improves on raw line equality for the
  - L2: /// patterns that dominate real source trees:
  - L3: ///
  - L4: /// 1. **Alignment on whitespace-trimmed keys** — lint/indent churn pairs up
  - L5: ///    as changed lines instead of disjoint delete/insert blocks. Lines that
  - L6: ///    are *only* structural delimiters (`}`, `});`, …) additionally carry
  - L7: ///    their indent width in the key: trimmed equality would let a closing
  - L8: ///    bracket anchor to a same-shaped bracket at a different nesting depth,
  - L9: ///    crossing the pairing a human reads from the brackets.
  - L10: /// 2. **Local re-anchoring** — the differ's patience skeleton picks anchors
  - L11: ///    by uniqueness over the whole region, so a small moved block that is
  - L12: ///    unique file-wide can out-anchor a bigger surviving block that occurs
  - L13: ///    twice (the duplicate disqualifies it). Small equal runs flanked by
  - L14: ///    changes are re-diffed together with their flanks; within that window
  - L15: ///    uniqueness is local, and the bigger match wins. Accepted only when
  - L16: ///    strictly more non-blank lines end up matched.
  - L17: /// 3. **Hunk-boundary sliding** — insert/delete hunks with ambiguous
  - L18: ///    placement shift to structurally better boundaries (after blank
  - L19: ///    lines; never starting at a closing bracket, which would steal it
  - L20: ///    from its block). Compact version of git's indent heuristic.
  - L21: /// 4. **Re-splitting** — key-equal runs whose content still differs (e.g.
  - L22: ///    indent-only changes) come back as replace hunks so they remain
  - L23: ///    visible and navigable, unless the caller's content keys say to
  - L24: ///    ignore them.
  - L25: /// 5. **Similarity pairing** — inside a changed region the display pairs
  - L26: ///    rows positionally, so one inserted blank line shifts every following
  - L27: ///    pair off by one. A monotonic max-similarity matching re-segments the
  - L28: ///    region: edited lines pair up as replaces, the rest become inserts/
  - L29: ///    deletes. Delimiter-only lines pair only on exact depth-qualified key
  - L30: ///    equality — an added `{` keeps its added `}` instead of the `}`
  - L31: ///    pairing with an unrelated bracket.
  - L34: /// - Parameters:
  - L35: ///   - leftContentKeys/rightContentKeys: per-line comparison keys after
  - L36: ///     the user's ignore options (nil = compare raw content). Lines
  - L37: ///     whose content keys match are reported equal.
  - L58: // Merge same-kind neighbors only. Differ.normalized would fold a
  - L59: // one-sided insert/delete into an adjacent replace, which shifts
  - L60: // the replace's row pairing off by one — exactly the misalignment
  - L61: // this type exists to prevent.
  - L70: // Whitespace-only and content replaces never merge: a real edit
  - L71: // inside a re-indented block must stay its own navigation stop.
  - L72: // Replaces merge only when both are 1:1 — folding an uneven
  - L73: // block into a paired run would shift its row pairing.
  - L100: /// Alignment key for one content key. Normally the trimmed content;
  - L101: /// delimiter-only lines append their indent width. Such lines carry no
  - L102: /// content of their own — their identity is their nesting position, and
  - L103: /// indentation is the depth signal available without parsing. Often this
  - L104: /// makes the matching delimiter unique in its region, so the patience
  - L105: /// skeleton anchors it instead of the rare-line fallback guessing among
  - L106: /// look-alikes. Derived from the *content key* (not the raw line) so
  - L107: /// ignore-whitespace options neutralize the qualifier along with the
  - L108: /// indentation itself.
  - L112: // U+0001 cannot occur in `t` (delimiter characters only).
  - L116: // MARK: - Local re-anchoring
  - L118: /// Equal runs longer than this are trusted as anchors. Spurious anchors
  - L119: /// are small moved blocks; the cap also bounds how many windows get a
  - L120: /// second diff.
  - L122: /// Window (both sides combined) above which re-diffing is skipped.
  - L125: /// A patience anchor is unique over the whole region, so a small moved
  - L126: /// block that is unique file-wide (a relocated 4-line `setTimeout`) can
  - L127: /// out-anchor a bigger surviving block that occurs twice in the file —
  - L128: /// the duplicate disqualifies the bigger block from the skeleton, and
  - L129: /// the gaps around the small anchor then bury it as delete + insert
  - L130: /// walls. Re-diff each small equal run together with its flanking
  - L131: /// change hunks: within the window, occurrence counts are local, so the
  - L132: /// bigger block anchors and the moved one drops out. Accept only when
  - L133: /// strictly more non-blank lines match — a legitimate anchor re-matches
  - L134: /// itself and the result is discarded.
  - L151: // The flanks are single change hunks (zero internal matches), so
  - L152: // the run is the window's whole matched mass. A run bigger than
  - L153: // either flank can't be a buried move — skip the re-diff.
  - L177: // Rescan from before the splice: the new alignment can expose a
  - L178: // further buried anchor. Terminates — every acceptance strictly
  - L179: // increases total matched mass.
  - L185: // MARK: - Re-splitting key-equal runs
  - L187: /// Splits equal hunks at lines whose content keys differ (alignment was
  - L188: /// on trimmed keys, so e.g. indent-only changes land here) into 1:1
  - L189: /// replace hunks. Each replace run is classified `isWhitespaceOnly`
  - L190: /// when its *raw* line pairs all match after trimming — the flag
  - L191: /// describes what the user will see, not the comparison keys.

### `MacMerge/Sources/FolderCompareKit/FolderFileOps.swift`

- Roles: Core diff/text/git/model logic
- Lines: 46
- Bytes: 2036
- Imports: Foundation
- Declarations:
  - enum `FolderFileOps`
  - enum `Side` : Sendable
  - enum `Direction` : Sendable
- Functions/methods: `copy`, `trash`
- Stored/visible properties: `source`, `fm`, `destDir`, `tmp`, `root`, `url`
- Source comments carrying design intent:
  - L3: /// File operations on comparison entries (SPEC §3.4). Deletes go to the
  - L4: /// Trash. Queued/progress-reported bulk operations come with sync execution
  - L5: /// in a later release; v0.1 operations are single-entry and synchronous.
  - L12: /// Copies the entry (file or whole subtree) across, replacing any
  - L13: /// existing destination.
  - L31: // Stage into a temp sibling so the destination is never removed before
  - L32: // the replacement is ready.
  - L40: /// Moves the entry on the given side to the Trash.

### `MacMerge/Sources/FolderCompareKit/FolderModel.swift`

- Roles: Core diff/text/git/model logic
- Lines: 107
- Bytes: 3374
- Imports: Foundation
- Declarations:
  - struct `FileMeta` : Sendable, Equatable
  - enum `EntryStatus` : Sendable, Equatable
  - class `FolderEntry` : @unchecked Sendable
  - struct `ScanSummary` : Sendable, Equatable
  - struct `ScanOptions` : Sendable
  - enum `Criteria` : String, Sendable
- Functions/methods: `count`
- Stored/visible properties: `size`, `modified`, `isSymlink`, `name`, `relativePath`, `isDirectory`, `left`, `right`, `identical`, `equivalent`, `different`, `leftOnly`, `rightOnly`, `errors`, `criteria`, `ignoreGlobs`, `followSymlinks`, `ignoreLineEndings`, `defaultIgnores`
- Source comments carrying design intent:
  - L3: /// Folder comparison model (SPEC §11.3).
  - L19: /// Equal only under active comparison options (e.g. ignoring line
  - L20: /// endings) — the raw bytes differ. (SPEC §3.4 "equivalent")
  - L28: /// One aligned row of the comparison tree. Built once on a background task,
  - L29: /// then treated as immutable by the UI (hence @unchecked Sendable).
  - L79: /// Equal size + equal modification date ⇒ identical.
  - L81: /// Equal size + streamed byte-by-byte content comparison.
  - L86: /// Glob patterns matched against entry *names* (fnmatch).
  - L89: /// Treat CRLF/CR as LF when comparing content. Files equal only after
  - L90: /// normalization are classified `.equivalent`. Forces content
  - L91: /// comparison even under `.quick` criteria.

### `MacMerge/Sources/FolderCompareKit/FolderScanner.swift`

- Roles: Core diff/text/git/model logic
- Lines: 324
- Bytes: 13102
- Imports: Foundation
- Declarations:
  - enum `FolderScanner`
  - struct `Listing`
  - class `NormalizedByteReader`
- Functions/methods: `scan`, `fileResourceID`, `summary`, `walk`, `scanDirectory`, `directoryStatus`, `list`, `globMatches`, `fileStatus`, `byteCompare`, `normalizedCompare`, `nextRaw`, `next`
- Stored/visible properties: `visited`, `root`, `id`, `summary`, `directories`, `files`, `maxScanDepth`, `listError`, `leftListing`, `rightListing`, `children`, `dirNames`, `fileNames`, `typeConflicts`, `childRel`, `lMeta`, `rMeta`, `childRel`, `cycleError`, `child`, `status`, `lMeta`, `rMeta`, `childRel`, `status`, `message`, `status`, `keys`, `contents`, `listing`, `itemName`, `values`, `isSymlink`, `isDirectory`, `meta`, `lt`, `rt`, `fa`, `fb`, `chunkSize`, `ca`, `cb`, `ra`, `rb`, `iterations`, `ba`, `bb`, `handle`, `buffer`, `position`, `pushedBack`, `exhausted`, `chunk`
- Relevant term counts: `Task`=5
- Source comments carrying design intent:
  - L3: /// Recursive two-root scanner. Synchronous; run it inside a Task and it
  - L4: /// honors cooperative cancellation. v0.1 returns the complete tree;
  - L5: /// streaming row delivery (SPEC §3.4) comes with the virtualized UI.
  - L36: // MARK: - Directory recursion
  - L76: // Names that are a dir on one side and a file on the other are type
  - L77: // conflicts — emit one error entry and exclude from both loops.
  - L94: // Symlink cycle detection: track visited file-resource IDs.
  - L119: // Patch in this directory's own meta/one-sidedness.
  - L215: // MARK: - File comparison
  - L222: // Symlinks compare by target path; EOL normalization doesn't apply.
  - L232: // Normalized-equal: only byte equality distinguishes identical
  - L233: // from equivalent, and only same-size pairs can be byte-equal.
  - L263: /// Streamed comparison with CRLF/CR → LF normalization on both sides.
  - L279: /// Buffered byte stream that yields CRLF and lone CR as a single LF.

### `MacMerge/Sources/GitSupport/Git.swift`

- Roles: Core diff/text/git/model logic
- Lines: 99
- Bytes: 3918
- Imports: Foundation
- Declarations:
  - enum `GitError` : Error, LocalizedError
  - enum `Git`
- Functions/methods: `repositoryRoot`, `status`, `run`
- Stored/visible properties: `errorDescription`, `dir`, `path`, `result`, `statuses`, `entries`, `skipNext`, `xy`, `path`, `status`, `stdout`, `stderr`, `stderrText`, `process`, `out`, `stdout`, `group`
- Relevant term counts: `DispatchQueue`=2
- Source comments carrying design intent:
  - L3: /// Git integration by shelling out to the user's git binary (SPEC §3.8,
  - L4: /// decision log §17.3). Plumbing commands only, parsed defensively.
  - L5: /// v0.1 surface: repository detection + porcelain status. Compare-against-
  - L6: /// commit and mergetool installation build on this in later releases.
  - L24: /// Returns the work-tree root containing `url`, or nil if not in a repo
  - L25: /// (or git is unavailable).
  - L38: /// `git status --porcelain -z` parsed into relativePath → XY status code.
  - L53: // Rename/copy entries are followed by the original path as a separate record.
  - L59: // MARK: - Subprocess plumbing
  - L81: // Drain stdout and stderr concurrently to prevent pipe-buffer deadlock
  - L82: // when either stream writes more than the kernel pipe buffer (~64 KB).

### `MacMerge/Sources/MacMergeApp/AppDelegate.swift`

- Roles: Window/menu/AppKit shell
- Lines: 50
- Bytes: 1378
- Imports: AppKit, SessionKit
- Declarations:
  - class `AppDelegate` : NSObject, NSApplicationDelegate
- Functions/methods: `applicationDidFinishLaunching`, `applicationSupportsSecureRestorableState`, `applicationShouldTerminateAfterLastWindowClosed`, `applicationShouldHandleReopen`, `application`, `newComparison`, `threeWayMergeAction`, `openSessionAction`, `showWelcomeWindow`
- Relevant term counts: `AppKit`=1, `MainActor`=1
- Source comments carrying design intent:
  - L28: /// Finder "Open With", Dock drops, and `open -a MacMerge a b`.
  - L33: // MARK: - Menu actions (File menu, explicit target via responder chain)

### `MacMerge/Sources/MacMergeApp/FileDiff/DiffTextView.swift`

- Roles: Diff NSTextView and ruler
- Lines: 175
- Bytes: 7519
- Imports: AppKit
- Declarations:
  - class `DiffTextView` : NSTextView
  - class `LineNumberRuler` : NSRulerView
- Functions/methods: `rowIndex`, `drawBackground`, `fragmentRect`, `keyDown`, `makePane`, `drawHashMarksAndLabels`
- Stored/visible properties: `rowBackgrounds`, `lineStartOffsets`, `highlightedRows`, `lo`, `result`, `mid`, `lm`, `storage`, `glyphRange`, `charRange`, `row`, `drawRect`, `first`, `last`, `outline`, `path`, `charIdx`, `glyphIdx`, `frag`, `scrollView`, `textView`, `diffTextView`, `labels`, `storage`, `visibleRect`, `glyphRange`, `charRange`, `starts`, `attrs`, `row`, `charIdx`, `glyphIdx`, `frag`, `y`, `label`, `size`
- Relevant term counts: `glyphRange`=6, `visibleRect`=4, `NSColor`=3, `NSScrollView`=3, `NSTextView`=3, `drawBackground`=3, `characterRange`=2, `lineFragmentRect`=2, `textContainerOrigin`=2, `AppKit`=1, `NSAttributedString`=1, `NSAttributedString.Key`=1, `NSBezierPath`=1, `NSEvent`=1, `NSRulerView`=1, `NSString`=1, `autoresizingMask`=1, `containerSize`=1, `drawHashMarksAndLabels`=1, `isHorizontallyResizable`=1, `isVerticallyResizable`=1, `orientation`=1, `textContainerInset`=1, `widthTracksTextView`=1
- Source comments carrying design intent:
  - L3: /// NSTextView (TextKit 1) with full-width row background painting and a
  - L4: /// row-aware line number ruler. Attribute-based backgrounds only cover
  - L5: /// glyphs; diff row tints must span the full line width, so they are drawn
  - L6: /// in `drawBackground(in:)` from the display-row table. (SPEC §11.4)
  - L9: /// Display row index → row background color.
  - L11: /// UTF-16 character offset of each display row's start, ascending.
  - L13: /// Rows of the *current* difference (⌘↑/⌘↓ target) — drawn with an
  - L14: /// accent outline so the user can see where navigation is pointing.
  - L51: // Current-difference indicator: accent outline around its rows.
  - L70: /// View-coordinate rect of one display row's line fragment.
  - L81: /// Esc in read-only comparison panes navigates Back (NSTextView would
  - L82: /// otherwise swallow it for completion). The editable merge-output
  - L83: /// pane keeps Esc for normal text editing.
  - L92: /// Standard no-wrap diff editor configuration.
  - L109: // Disable wrapping: one display row per line fragment.
  - L125: /// Line numbers per display row; phantom rows show no number.

### `MacMerge/Sources/MacMergeApp/FileDiff/FileDiffViewController.swift`

- Roles: File diff AppKit controller
- Lines: 663
- Bytes: 27999
- Imports: AppKit, DiffCore, TextEngine, PatchKit, SessionKit
- Declarations:
  - struct `FolderNavContext`
  - class `FileDiffViewController` : NSViewController
  - enum `PendingTarget`
  - struct `ReloadPayload`
  - extension `FileDiffViewController` : NSMenuItemValidation
- Functions/methods: `updateTitle`, `loadView`, `symbolButton`, `viewDidLoad`, `armWatcher`, `updateFileNavUI`, `updateBackButton`, `reload`, `isBinaryFile`, `textPayload`, `status`, `hexPayload`, `hexDocument`, `apply`, `updateCounter`, `nextDifference`, `previousDifference`, `goToChange`, `nextFile`, `previousFile`, `goToFile`, `scrollToRow`, `boundsChanged`, `updateOverviewViewport`, `contextChanged`, `swapSides`, `refresh`, `toggleIgnoreWhitespace`, `generatePatch`, `sanitize`, `saveSession`, `goBack`, `cancelOperation`, `validateMenuItem`
- Stored/visible properties: `pairs`, `index`, `navContext`, `folderOrigin`, `leftDoc`, `rightDoc`, `model`, `changeCount`, `currentChange`, `ignoreWhitespace`, `isHexMode`, `contextLines`, `generation`, `reloadTask`, `watcher`, `pendingTarget`, `leftScroll`, `rightScroll`, `leftText`, `rightText`, `leftRuler`, `rightRuler`, `overview`, `counterLabel`, `leftStatus`, `rightStatus`, `fileNavLabel`, `backButton`, `prevFileButton`, `nextFileButton`, `contextPopup`, `spinner`, `syncing`, `leftDoc`, `rightDoc`, `result`, `model`, `leftPane`, `rightPane`, `isHex`, `leftStatusText`, `rightStatusText`, `base`, `leftPane`, `rightPane`, `prevButton`, `nextButton`, `swapButton`, `patchButton`, `spacer`, `controlBar`, `contentRow`, `statusSpacer`, `statusBar`, `main`, `container`, `image`, `button`, `hasNav`, `gen`
- Relevant term counts: `Task`=7, `NSButton`=5, `NSView`=5, `NSStackView`=4, `NSTextField`=4, `nonisolated`=4, `orientation`=4, `NSAlert`=3, `NSScrollView`=3, `glyphRange`=3, `scrollTo`=3, `widthAnchor`=3, `NSMenu`=2, `NotificationCenter`=2, `bottomAnchor`=2, `contentView.scroll`=2, `edgeInsets`=2, `leadingAnchor`=2, `reflectScrolledClipView`=2, `setAttributedString`=2, `topAnchor`=2, `trailingAnchor`=2, `AppKit`=1, `MainActor`=1, `NSColor`=1, `NSLayoutConstraint`=1, `NSMenuItemValidation`=1, `NSSavePanel`=1, `NSViewController`=1, `boundsDidChangeNotification`=1, `characterRange`=1, `distribution`=1, `lineFragmentRect`=1, `postsBoundsChangedNotifications`=1, `translatesAutoresizingMaskIntoConstraints`=1, `visibleRect`=1
- Source comments carrying design intent:
  - L7: /// Cross-file navigation context: the changed files of the folder
  - L8: /// comparison this diff was opened from (SPEC §3.4 drill-down).
  - L14: /// Side-by-side comparison (SPEC §5.3). Text files diff line-by-line;
  - L15: /// binary files automatically render as aligned hex dumps (SPEC §3.5).
  - L16: /// Panes are read-only in 0.1.x; in-place editing and per-hunk merge
  - L17: /// gestures follow in M2.
  - L23: /// Folder comparison this diff was opened from; Back returns to it
  - L24: /// (recreating its tab if the user closed it).
  - L34: /// Identical lines to keep around changes; nil = full file (SPEC item:
  - L35: /// context-collapsed view). Driven by the "Show" popup.
  - L99: // MARK: - View construction
  - L214: /// (Re)points the external-change watcher at the current pair. Panes are
  - L215: /// read-only in 0.1.x, so an external change is always safe to reload
  - L216: /// without losing user edits.
  - L250: // MARK: - Loading
  - L318: // Read only up to the render cap (+1 to detect truncation) instead
  - L319: // of mapping the whole binary into memory.
  - L324: // True file size for the status line (the read above is capped).
  - L375: // Dimmed so the strip's "where are the real edits" answer
  - L376: // isn't drowned by a re-indented block.
  - L426: // MARK: - Difference navigation
  - L431: // No diffs in this file — flow to the next changed file if any.
  - L440: // Past the last difference: continue into the next changed file.
  - L489: // MARK: - File navigation (folder drill-down context)
  - L517: // MARK: - Scrolling
  - L559: // MARK: - Commands
  - L569: // The folder-nav file list is direction-specific; swapping leaves it.
  - L594: // Sanitize path labels: tabs or newlines in filenames corrupt diff headers.
  - L627: /// Back: return to the folder comparison this diff came from,
  - L628: /// recreating its tab if it was closed; otherwise to the Welcome
  - L629: /// window. Bound to Esc, ⌘[, and the back button. (⌘W still closes.)

### `MacMerge/Sources/MacMergeApp/FileDiff/OverviewStripView.swift`

- Roles: Overview strip custom NSView
- Lines: 60
- Bytes: 2088
- Imports: AppKit
- Declarations:
  - class `OverviewStripView` : NSView
- Functions/methods: `draw`, `mouseDown`, `mouseDragged`, `jump`
- Stored/visible properties: `rowRange`, `color`, `marks`, `totalRows`, `visibleRows`, `onJump`, `scale`, `y`, `height`, `y`, `height`, `point`, `fraction`
- Relevant term counts: `NSColor`=3, `NSEvent`=3, `NSView`=2, `AppKit`=1, `draw(_`=1
- Source comments carrying design intent:
  - L3: /// Whole-document map of change positions on the trailing edge (SPEC §5.3).
  - L4: /// Click or drag to jump.
  - L14: /// Currently visible display-row span (viewport indicator).
  - L29: // Mark colors arrive with their final alpha (demoted marks are
  - L30: // pre-dimmed by the caller).

### `MacMerge/Sources/MacMergeApp/FileDiff/PaneBuilder.swift`

- Roles: Diff pane attributed-string builder
- Lines: 186
- Bytes: 7846
- Imports: AppKit, DiffCore, TextEngine, SyntaxKit
- Declarations:
  - struct `PaneContent`
  - enum `PaneBuilder`
  - enum `Side`
  - struct `Accumulator`
- Functions/methods: `buildPanes`, `buildPlain`, `background`, `appendMarkerRow`, `appendRow`, `clamp`
- Stored/visible properties: `attributed`, `lineStartOffsets`, `rowBackgrounds`, `labels`, `leftLang`, `rightLang`, `leftAcc`, `rightAcc`, `marker`, `leftLine`, `rightLine`, `leftEmphasis`, `rightEmphasis`, `isRewrite`, `intra`, `language`, `acc`, `isUnpairedTail`, `language`, `baseAttributes`, `text`, `starts`, `backgrounds`, `labels`, `offset`, `content`, `attr`, `rowIndex`, `attr`, `contentLength`, `lower`, `upper`
- Relevant term counts: `NSColor`=8, `NSAttributedString`=3, `NSMutableAttributedString`=2, `NSRange`=2, `AppKit`=1, `NSAttributedString.Key`=1, `setAttributedString`=1
- Source comments carrying design intent:
  - L6: /// Pre-rendered content for one editor pane. Built off the main thread;
  - L7: /// only `textStorage.setAttributedString` happens on main. (SPEC §9)
  - L17: /// Builds both panes of a 2-way diff together so intra-line refinement
  - L18: /// runs once per changed line pair. `languageOverride` forces a language
  - L19: /// (e.g. `.plain` for hex rows) instead of detecting from the extension.
  - L44: // Replace rows pairing lines that aren't versions of each other
  - L45: // (the pairing is positional) render as removed+added code:
  - L46: // emphasis on shared confetti would mislead.
  - L58: // Whitespace-only rows whisper: faint row tint, soft emphasis on
  - L59: // the whitespace delta itself — content edits keep the strong
  - L60: // red/green treatment so they stand out inside re-indented blocks.
  - L79: /// One-pane builder for merge views: rows map 1:1 to lines.
  - L111: // Rewritten pairs and the unpaired tail of an uneven replace
  - L112: // are removed/added code, not edits of a surviving line.
  - L121: // MARK: - Accumulator
  - L140: /// Collapsed-context marker: dimmed text, phantom background, no number.

### `MacMerge/Sources/MacMergeApp/FolderCompare/FolderCompareViewController.swift`

- Roles: Folder compare outline controller
- Lines: 596
- Bytes: 24833
- Imports: AppKit, FolderCompareKit, SessionKit
- Declarations:
  - class `FolderCompareViewController` : NSViewController
  - enum `ViewFilter` : Int, CaseIterable
  - enum `ColumnID`
  - extension `FolderCompareViewController` : NSOutlineViewDataSource, NSOutlineViewDelegate
  - extension `FolderCompareViewController` : NSMenuItemValidation
- Functions/methods: `passes`, `loadView`, `configureOutline`, `column`, `buildContextMenu`, `viewDidLoad`, `rescan`, `applyViewOptions`, `expandChangedDirectories`, `format`, `visibleChildren`, `subtreePasses`, `flatFiles`, `walk`, `changedFilePairs`, `walk`, `filterPopupChanged`, `flattenChanged`, `toggleDifferencesOnly`, `toggleFlatten`, `goBack`, `cancelOperation`, `toggleIgnoreLineEndings`, `refresh`, `didDoubleClick`, `targetEntry`, `perform`, `copyLeftToRight`, `copyRightToLeft`, `trashLeft`, `trashRight`, `revealLeft`, `revealRight`, `saveSession`, `outlineView`, `outlineView`, `outlineView`, `outlineView`, `configure`, `validateMenuItem`
- Stored/visible properties: `leftRoot`, `rightRoot`, `rootEntry`, `scanOptions`, `scanTask`, `fileOpInProgress`, `title`, `filter`, `flattened`, `subtreePassCache`, `flatCache`, `outline`, `scroll`, `summaryLabel`, `pathLabel`, `spinner`, `filterPopup`, `flattenCheckbox`, `sizeFormatter`, `dateFormatter`, `f`, `left`, `status`, `right`, `sizeL`, `sizeR`, `modL`, `modR`, `backImage`, `backButton`, `refreshImage`, `refreshButton`, `spacer`, `controlBar`, `statusBar`, `main`, `container`, `column`, `leftColumn`, `menu`, `l`, `options`, `root`, `parts`, `result`, `files`, `pairs`, `pairs`, `nav`, `row`, `result`, `rel`, `rel`, `rel`, `rel`, `session`, `entry`, `entry`, `field`, `leftPresent`
- Relevant term counts: `Task`=10, `NSOutlineView`=7, `NSTextField`=6, `NSButton`=5, `NSMenu`=4, `NSView`=4, `NSStackView`=3, `NSTableColumn`=3, `orientation`=3, `MainActor`=2, `NSAlert`=2, `NSWorkspace`=2, `bottomAnchor`=2, `edgeInsets`=2, `leadingAnchor`=2, `topAnchor`=2, `trailingAnchor`=2, `AppKit`=1, `DispatchQueue`=1, `NSColor`=1, `NSLayoutConstraint`=1, `NSMenuItemValidation`=1, `NSScrollView`=1, `NSViewController`=1, `translatesAutoresizingMaskIntoConstraints`=1
- Source comments carrying design intent:
  - L5: /// Recursive folder comparison (SPEC §5.4). v0.1.1 adds view filters,
  - L6: /// a flattened file list, the ignore-line-endings comparison option, and
  - L7: /// the cross-file navigation context handed to drill-down diffs.
  - L18: /// File-level row filter (SPEC §3.4 "view filters").
  - L91: // MARK: - View construction
  - L204: // MARK: - Scanning
  - L236: /// Single path for every view-option change. Reload is deferred to the
  - L237: /// next runloop turn so it never lands inside popup/menu tracking, and
  - L238: /// matching directories re-expand so filter results are actually
  - L239: /// visible instead of sitting inside collapsed folders.
  - L252: /// First-level directories with relevant content start expanded:
  - L253: /// changed ones by default, filter-matching ones under a narrowing filter.
  - L275: // MARK: - Filtering / flattening
  - L308: /// All changed file pairs, in tree order — the cross-file navigation
  - L309: /// list handed to drill-down diff views.
  - L329: // MARK: - Actions
  - L353: /// Back from the list view goes to the Welcome window. Bound to Esc,
  - L354: /// ⌘[, and the back button. (⌘W still closes the tab.)
  - L467: // MARK: - Outline data source / delegate

### `MacMerge/Sources/MacMergeApp/MacMergeApp.swift`

- Roles: Window/menu/AppKit shell
- Lines: 16
- Bytes: 447
- Imports: AppKit
- Declarations:
  - struct `MacMergeApp`
- Functions/methods: `main`
- Stored/visible properties: `app`, `delegate`
- Relevant term counts: `AppKit`=1, `MainActor`=1
- Source comments carrying design intent:
  - L3: // SwiftPM executable entry point — no nib, no storyboard, no Xcode project.
  - L4: // `build-app.sh` wraps this executable into MacMerge.app; running the bare
  - L5: // binary also works for development.

### `MacMerge/Sources/MacMergeApp/Merge/MergeViewController.swift`

- Roles: Merge AppKit controller
- Lines: 404
- Bytes: 16558
- Imports: AppKit, DiffCore, TextEngine, MergeKit, SessionKit
- Declarations:
  - class `MergeViewController` : NSViewController
  - struct `MergePayload`
  - extension `MergeViewController` : NSTextViewDelegate
  - extension `MergeViewController` : NSMenuItemValidation
- Functions/methods: `armWatcher`, `loadView`, `sourcePane`, `symbolButton`, `viewDidLoad`, `reload`, `apply`, `nextConflict`, `previousConflict`, `goToConflict`, `scrollOutputToRow`, `saveOutput`, `write`, `refresh`, `saveSession`, `goBack`, `cancelOperation`, `textDidChange`, `validateMenuItem`
- Stored/visible properties: `baseURL`, `leftURL`, `rightURL`, `outputURL`, `baseDoc`, `conflictRowRanges`, `currentConflict`, `generation`, `reloadTask`, `isOutputDirty`, `watcher`, `leftText`, `baseText`, `rightText`, `outputText`, `outputRuler`, `counterLabel`, `spinner`, `baseDoc`, `leftPane`, `basePane`, `rightPane`, `outputPane`, `conflictRowRanges`, `label`, `stack`, `sourcesRow`, `outputLabel`, `outputPane`, `split`, `prevButton`, `nextButton`, `saveButton`, `spacer`, `controlBar`, `main`, `container`, `image`, `button`, `gen`, `b`, `bg`, `baseDoc`, `leftDoc`, `rightDoc`, `segments`, `merged`, `leftBG`, `baseBG`, `rightBG`, `outputBG`, `ext`, `payload`, `count`, `clamped`, `starts`, `scroll`, `length`, `clampedRow`, `charIdx`
- Relevant term counts: `Task`=7, `NSStackView`=5, `orientation`=5, `NSColor`=4, `NSView`=4, `NSAlert`=3, `NSButton`=3, `NSTextField`=3, `NSMenu`=2, `bottomAnchor`=2, `leadingAnchor`=2, `topAnchor`=2, `trailingAnchor`=2, `AppKit`=1, `MainActor`=1, `NSLayoutConstraint`=1, `NSMenuItemValidation`=1, `NSSavePanel`=1, `NSTextView`=1, `NSTextViewDelegate`=1, `NSViewController`=1, `contentView.scroll`=1, `distribution`=1, `edgeInsets`=1, `lineFragmentRect`=1, `reflectScrolledClipView`=1, `setAttributedString`=1, `translatesAutoresizingMaskIntoConstraints`=1
- Source comments carrying design intent:
  - L7: /// Three-way merge (SPEC §3.3). Layout: left / base / right source panes
  - L8: /// over an editable output pane. Auto-resolvable segments are pre-applied;
  - L9: /// true conflicts appear in the output with diff3 markers and a tinted
  - L10: /// background. v0.1 resolves conflicts by editing the output directly;
  - L11: /// per-hunk take-left/take-right gestures land in M4.
  - L61: /// Watches the three merge inputs. Auto-reloads only when the output has
  - L62: /// no unsaved edits; otherwise surfaces a non-destructive notice so the
  - L63: /// user's in-progress merge is never discarded silently.
  - L75: // MARK: - View construction
  - L173: // MARK: - Loading
  - L271: // MARK: - Navigation
  - L304: // MARK: - Saving
  - L361: /// Back from a merge goes to the Welcome window (Esc outside the
  - L362: /// editable output pane, ⌘[). ⌘W still closes.
  - L374: // After a manual edit, recompute row offsets so backgrounds and line
  - L375: // numbers stay truthful. Conflict tints are cleared lazily: ranges no
  - L376: // longer match reality once lines shift, so drop them.

### `MacMerge/Sources/MacMergeApp/Support/AppActions.swift`

- Roles: Support code
- Lines: 67
- Bytes: 2187
- Imports: AppKit, SessionKit, UniformTypeIdentifiers
- Declarations:
  - enum `AppActions`
  - enum `Pickers`
  - enum `SessionWriter`
- Functions/methods: `newComparison`, `threeWayMerge`, `openSession`, `pickOne`, `save`
- Stored/visible properties: `panel`, `panel`, `completion`
- Relevant term counts: `MainActor`=3, `AppKit`=1, `NSAlert`=1, `NSOpenPanel`=1, `NSSavePanel`=1, `NSWindow`=1
- Source comments carrying design intent:
  - L5: /// Shared entry points used by both the menu bar and the Welcome window.
  - L44: /// Save-panel helper for `.mmsession` documents.

### `MacMerge/Sources/MacMergeApp/Support/FileWatcher.swift`

- Roles: Support code
- Lines: 60
- Bytes: 2099
- Imports: Foundation
- Declarations:
  - class `FileWatcher`
- Functions/methods: `arm`, `handleEvent`
- Stored/visible properties: `urls`, `onChange`, `sources`, `debounce`, `fd`, `source`, `work`
- Relevant term counts: `MainActor`=3, `DispatchQueue`=1
- Source comments carrying design intent:
  - L3: /// Watches a set of files for on-disk changes and invokes a handler on the
  - L4: /// main actor. Used to detect external edits to open comparison/merge inputs
  - L5: /// (SPEC §3.6 external-change handling).
  - L6: ///
  - L7: /// Each watched path gets a DispatchSource file-system-object source on an
  - L8: /// open descriptor. On a `.write`/`.extend`/`.delete`/`.rename`, the handler
  - L9: /// fires. Editors that replace files (write-to-temp + rename) invalidate the
  - L10: /// descriptor; we re-arm by re-opening the path after a short debounce.
  - L49: // Debounce bursts (editors emit several events per save) and re-arm
  - L50: // afterward so atomic-rename saves keep being watched.

### `MacMerge/Sources/MacMergeApp/Support/MainMenu.swift`

- Roles: Window/menu/AppKit shell
- Lines: 152
- Bytes: 8722
- Imports: AppKit
- Declarations:
  - enum `MainMenu`
- Functions/methods: `install`, `submenu`, `functionKey`, `makeAppMenu`, `makeFileMenu`, `makeEditMenu`, `makeViewMenu`, `makeNavigateMenu`, `makeWindowMenu`, `makeHelpMenu`
- Stored/visible properties: `main`, `item`, `menu`, `hideOthers`, `saveSession`, `redo`, `diffOnly`, `flatten`, `fullScreen`, `next`, `prev`, `nextConflict`, `prevConflict`, `nextFile`, `prevFile`, `swap`
- Relevant term counts: `NSMenu`=12, `NSWindow`=4, `AppKit`=1, `MainActor`=1
- Source comments carrying design intent:
  - L3: /// Programmatic menu bar (SPEC §6). Every command lives here; comparison
  - L4: /// commands use nil-target actions resolved through the responder chain to
  - L5: /// the front tab's view controller.

### `MacMerge/Sources/MacMergeApp/Support/Theme.swift`

- Roles: Support code
- Lines: 61
- Bytes: 3149
- Imports: AppKit, SyntaxKit
- Declarations:
  - enum `Theme`
- Functions/methods: `dynamic`, `rgb`, `color`
- Stored/visible properties: `addedBackground`, `removedBackground`, `changedBackground`, `whitespaceOnlyBackground`, `conflictBackground`, `phantomBackground`, `addedStrong`, `removedStrong`, `changedStrong`, `whitespaceOnlyStrong`, `addedAccent`, `removedAccent`, `changedAccent`, `conflictAccent`, `syntaxKeyword`, `syntaxString`, `syntaxComment`, `syntaxNumber`, `editorFont`, `lineNumberFont`
- Relevant term counts: `NSColor`=11, `NSFont`=2, `darkAqua`=2, `AppKit`=1, `bestMatch`=1
- Source comments carrying design intent:
  - L4: /// Semantic, dark-mode-aware colors (SPEC §5.3). Backgrounds carry diff
  - L5: /// state; text color stays free for syntax highlighting. User-overridable
  - L6: /// palettes arrive with the Settings window in a later release.
  - L20: // Row backgrounds
  - L24: /// Whitespace-only changed rows (re-indented blocks): a whisper of the
  - L25: /// changed tint so a 100-line extraction doesn't read as 100 edits.
  - L30: // Intra-line emphasis
  - L34: /// Marks the whitespace delta itself on whitespace-only rows — softer
  - L35: /// than the red/green emphasis used for content edits.
  - L38: // Overview strip / status glyph accents
  - L44: // Syntax (placeholder palette for SyntaxKit's keyword tokenizer)

### `MacMerge/Sources/MacMergeApp/Support/WindowManager.swift`

- Roles: Window/menu/AppKit shell
- Lines: 253
- Bytes: 10226
- Imports: AppKit, SwiftUI, SessionKit
- Declarations:
  - class `PanelHostingController`
  - class `WindowManager` : NSObject
  - extension `WindowManager` : NSWindowDelegate
- Functions/methods: `cancelOperation`, `showWelcome`, `dropPath`, `showNewComparison`, `closeNewComparison`, `openComparison`, `openFileDiff`, `returnToFolderCompare`, `openFolderCompare`, `openMerge`, `openSession`, `openRecent`, `present`, `isDirectory`, `presentMessage`, `windowWillClose`
- Stored/visible properties: `shared`, `controllers`, `welcomeController`, `newComparisonController`, `newComparisonModel`, `hosting`, `window`, `hasVisibleComparisonWindows`, `model`, `hosting`, `window`, `dirs`, `dirs`, `session`, `base`, `fm`, `required`, `missing`, `output`, `fm`, `required`, `missing`, `left`, `right`, `window`, `controller`, `isDir`, `alert`
- Relevant term counts: `NSWindow`=16, `NSAlert`=2, `AppKit`=1, `MainActor`=1, `NSView`=1, `NSViewController`=1, `SwiftUI`=1
- Source comments carrying design intent:
  - L5: /// Owns all windows and routes comparisons to the right view controller.
  - L6: /// Windows use native tabbing (SPEC §5.5); folder drill-down opens file
  - L7: /// diffs as tabs of the same window.
  - L8: /// Hosting controller for panel-style windows (Welcome, New Comparison):
  - L9: /// Esc closes them, like native dialogs.
  - L26: // MARK: - Welcome
  - L49: // MARK: - New Comparison chooser
  - L51: /// Fills the next empty slot (L→R→Base) in an open NewComparison window,
  - L52: /// or opens a new one with the path pre-filled in the left slot.
  - L62: /// Recreated each show so the threeWay preset and stale paths reset.
  - L86: // MARK: - Routing
  - L88: /// Routes dropped/opened URLs: one session file, two items for diff/folder, or three files for merge.
  - L124: /// Back-navigation target: activates an existing folder-comparison tab
  - L125: /// for these roots, or recreates one if the user closed it.
  - L200: // MARK: - Presentation

### `MacMerge/Sources/MacMergeApp/Welcome/NewComparisonView.swift`

- Roles: Support code
- Lines: 204
- Bytes: 7326
- Imports: SwiftUI, UniformTypeIdentifiers
- Declarations:
  - class `NewComparisonModel` : ObservableObject
  - struct `NewComparisonView` : View
  - struct `PathWell` : View
- Functions/methods: `fillNextPath`, `expanded`, `loadURL`, `start`, `validated`, `browse`
- Stored/visible properties: `leftPath`, `rightPath`, `basePath`, `threeWay`, `errorMessage`, `dropTargeted`, `body`, `fieldsFilled`, `fm`, `expandedPath`, `isDir`, `right`, `label`, `targeted`, `body`, `panel`
- Relevant term counts: `MainActor`=5, `Task`=2, `NSOpenPanel`=1, `NSString`=1, `ObservableObject`=1, `SwiftUI`=1
- Source comments carrying design intent:
  - L4: /// Shared state for the "New Comparison" chooser.
  - L5: /// WindowManager holds a reference so drops on any screen fill slots sequentially (L→R→Base).
  - L20: /// Fills the next empty slot: left → right → base (auto-enables threeWay on base fill).
  - L33: /// "New Comparison" window (SPEC §5.1 chooser): independent Left/Right
  - L34: /// path wells — each accepts drag & drop, Browse…, or a typed path — plus
  - L35: /// an optional Base well for three-way merges. The comparison mode
  - L36: /// (file/folder) is inferred from what was chosen, WinMerge-style.
  - L155: /// One side's path input: editable text field + Browse… + drop target.

### `MacMerge/Sources/MacMergeApp/Welcome/WelcomeView.swift`

- Roles: Support code
- Lines: 158
- Bytes: 5260
- Imports: SwiftUI, SessionKit, UniformTypeIdentifiers
- Declarations:
  - struct `WelcomeView` : View
  - struct `RecentRow` : View
- Functions/methods: `actionButton`, `handleDrop`, `loadURL`
- Stored/visible properties: `dropTargeted`, `body`, `actionsColumn`, `recentsColumn`, `item`, `symbol`, `name`, `left`, `right`, `body`
- Relevant term counts: `MainActor`=2, `NSString`=2, `SwiftUI`=1, `Task`=1
- Source comments carrying design intent:
  - L5: /// Welcome window (SPEC §5.1): actions, recents, and whole-window drop target.
  - L6: /// Single drops fill slot A then B; two or three drops open immediately.

### `MacMerge/Sources/MergeKit/MergeBuilder.swift`

- Roles: Core diff/text/git/model logic
- Lines: 46
- Bytes: 1803
- Imports: DiffCore
- Declarations:
  - enum `MergeBuilder`
  - struct `Output` : Sendable
- Functions/methods: `autoMerge`
- Stored/visible properties: `lines`, `conflictLineRanges`, `conflictCount`, `lines`, `conflicts`, `start`
- Source comments carrying design intent:
  - L3: /// Builds the auto-merged output for a 3-way merge (SPEC §3.3): non-conflict
  - L4: /// segments are pre-applied; true conflicts are emitted with diff3-style
  - L5: /// markers for manual resolution in the output pane.
  - L11: /// Ranges in `lines` spanning each conflict block, markers included.

### `MacMerge/Sources/PatchKit/UnifiedDiff.swift`

- Roles: Core diff/text/git/model logic
- Lines: 95
- Bytes: 3722
- Imports: DiffCore
- Declarations:
  - enum `UnifiedDiff`
- Functions/methods: `generate`, `render`, `emitContext`
- Stored/visible properties: `hunks`, `changes`, `groups`, `current`, `out`, `lStart`, `lEnd`, `rStart`, `rEnd`, `lCount`, `rCount`, `lDisplay`, `rDisplay`, `lPos`
- Source comments carrying design intent:
  - L3: /// Unified diff generation (SPEC §3.7). Patch parsing/application is a
  - L4: /// later-release feature; generation covers the patch-export commands.
  - L36: // Group changes whose equal-line gap is ≤ 2 × context.
  - L59: // Unified convention: with count 0, the displayed number is the line *before*.

### `MacMerge/Sources/SessionKit/SessionKit.swift`

- Roles: Core diff/text/git/model logic
- Lines: 136
- Bytes: 4175
- Imports: Foundation, Combine
- Declarations:
  - struct `ComparisonSession` : Codable, Sendable, Equatable
  - enum `Mode` : String, Codable, Sendable
  - struct `RecentComparison` : Codable, Sendable, Equatable, Identifiable
  - class `RecentsStore` : ObservableObject
- Functions/methods: `load`, `write`, `add`, `clear`, `load`, `save`
- Stored/visible properties: `schemaVersion`, `mode`, `leftPath`, `rightPath`, `basePath`, `outputPath`, `name`, `fileExtension`, `data`, `encoder`, `id`, `mode`, `leftPath`, `rightPath`, `basePath`, `date`, `shared`, `capacity`, `storageURL`, `appSupport`, `decoded`, `data`
- Relevant term counts: `MainActor`=1, `ObservableObject`=1
- Source comments carrying design intent:
  - L4: /// Sessions & recents (SPEC §11.6).
  - L5: ///
  - L6: /// v0.1: sessions are plain Codable JSON documents with absolute paths;
  - L7: /// NSDocument integration and security-scoped bookmarks (for the sandboxed
  - L8: /// SKU) are layered on in later releases — the schema already reserves the
  - L9: /// fields via `schemaVersion`.
  - L85: /// Designated initializer is injectable for tests.
  - L132: // Recents are best-effort; losing them must never break the app.

### `MacMerge/Sources/SyntaxKit/SyntaxKit.swift`

- Roles: Core diff/text/git/model logic
- Lines: 290
- Bytes: 13230
- Imports: Foundation
- Declarations:
  - enum `Language` : String, CaseIterable, Sendable
  - enum `TokenKind` : Sendable, Equatable
  - struct `Token` : Sendable, Equatable
  - enum `LanguageDetector`
  - struct `LanguageProfile`
  - enum `Profiles`
  - enum `LineTokenizer`
- Functions/methods: `language`, `profile`, `tokenize`, `u16len`, `matches`
- Stored/visible properties: `kind`, `utf16Range`, `map`, `keywords`, `lineCommentPrefixes`, `stringDelimiters`, `cFamilyKeywords`, `kw`, `kw`, `kw`, `profile`, `chars`, `tokens`, `i`, `u16`, `c`, `rest`, `start`, `j`, `width`, `start`, `j`, `width`, `start`, `j`, `width`, `word`, `p`
- Relevant term counts: `NSRange`=1
- Source comments carrying design intent:
  - L3: /// SyntaxKit — v0.1 placeholder implementation (SPEC §11.5).
  - L4: ///
  - L5: /// This is a per-line keyword/string/comment/number tokenizer, deliberately
  - L6: /// stateless across lines (no block comments, no multi-line strings). The
  - L7: /// module boundary is the contract: it will be replaced by tree-sitter
  - L8: /// incremental parsing without touching callers.
  - L21: /// UTF-16 offsets within the line (convertible directly to NSRange).
  - L212: // Line comment → rest of line.
  - L220: // String literal (single line; unterminated runs to end of line).
  - L241: // Number.
  - L259: // Identifier / keyword.

### `MacMerge/Sources/TextEngine/EncodingDetector.swift`

- Roles: Core diff/text/git/model logic
- Lines: 57
- Bytes: 2081
- Imports: Foundation
- Declarations:
  - enum `EncodingDetector`
  - enum `BinarySniffer`
- Functions/methods: `detect`, `detectBOM`, `isBinary`
- Stored/visible properties: `isASCII`, `gb18030`, `bytes`
- Relevant term counts: `NSString`=1
- Source comments carrying design intent:
  - L3: /// Encoding detection per SPEC §3.2: BOM → UTF-8 validation → legacy
  - L4: /// candidates → Latin-1 last resort. Statistical charset sniffing (full
  - L5: /// ICU-style) is a later-release refinement; candidate order is fixed here.
  - L52: /// Binary detection: NUL byte in the first 64 KB. (SPEC §3.2)

### `MacMerge/Sources/TextEngine/HexDump.swift`

- Roles: Core diff/text/git/model logic
- Lines: 53
- Bytes: 1892
- Imports: Foundation
- Declarations:
  - enum `HexDump`
- Functions/methods: `lines`
- Stored/visible properties: `bytesPerRow`, `bytes`, `rows`, `hexDigits`, `offset`, `rowEnd`, `row`, `b`, `b`
- Source comments carrying design intent:
  - L3: /// Hex-dump row rendering for the binary comparison view (SPEC §3.5).
  - L4: /// Rows are plain strings so the standard line-diff pipeline aligns and
  - L5: /// highlights them; byte-insertion re-alignment (rolling-hash anchors) is a
  - L6: /// later-release refinement.
  - L11: /// `00000010  48 65 6C 6C 6F 20 57 6F  72 6C 64 21 0A 00 00 00  |Hello World!....|`

### `MacMerge/Sources/TextEngine/IgnoreOptions.swift`

- Roles: Core diff/text/git/model logic
- Lines: 42
- Bytes: 1367
- Imports: Foundation
- Declarations:
  - struct `IgnoreOptions` : Sendable, Codable, Equatable
  - enum `Whitespace` : String, Sendable, Codable
- Functions/methods: `key`, `keys`
- Stored/visible properties: `whitespace`, `ignoreCase`, `isNoop`, `s`
- Source comments carrying design intent:
  - L3: /// Comparison-time normalization (SPEC §3.2 "ignore options"). Diffing runs
  - L4: /// on normalized keys; display always shows raw content. Blank-line ignoring
  - L5: /// and regex line rules are later-release additions.
  - L24: /// Normalized comparison key for one line.

### `MacMerge/Sources/TextEngine/TextDocument.swift`

- Roles: Core diff/text/git/model logic
- Lines: 171
- Bytes: 6128
- Imports: Foundation
- Declarations:
  - enum `LineEnding` : String, Sendable
  - enum `TextLoadError` : Error, LocalizedError
  - struct `TextDocument` : Sendable
  - extension `LineEnding`
- Functions/methods: `load`, `make`, `analyze`
- Stored/visible properties: `errorDescription`, `formatted`, `url`, `encoding`, `encodingConfidence`, `lineEnding`, `endsWithNewline`, `lines`, `maxLoadBytes`, `data`, `detected`, `analysis`, `displayName`, `encodingDisplayName`, `lines`, `current`, `lfCount`, `endedWithTerminator`, `iter`, `pending`, `scalar`, `kinds`, `lineEnding`, `terminator`
- Source comments carrying design intent:
  - L3: /// TextEngine — file loading, encoding/EOL detection, line model. (SPEC §11.2)
  - L4: ///
  - L5: /// v0.1 loads via `Data(mappedIfSafe:)` and materializes decoded lines.
  - L6: /// The piece-table / chunked-line-index design from SPEC §10 lands when
  - L7: /// editing and >100 MB virtualization are implemented.
  - L42: /// Logical lines without terminators.
  - L57: /// Hard ceiling for full in-memory text load. Above this, `load` throws
  - L58: /// `.fileTooLarge` rather than risk exhausting memory. Chunked streaming
  - L59: /// for larger files is tracked in SPEC §10.
  - L109: // MARK: - Line / EOL analysis

### `MacMerge/Sources/macmerge-cli/main.swift`

- Roles: Core diff/text/git/model logic
- Lines: 93
- Bytes: 2856
- Imports: Foundation, DiffCore, TextEngine, PatchKit
- Functions/methods: `fail`
- Stored/visible properties: `usage`, `paths`, `context`, `algorithm`, `ignoreWhitespace`, `arguments`, `argument`, `leftURL`, `rightURL`, `left`, `right`, `ignore`, `options`, `result`, `patch`
- Source comments carrying design intent:
  - L6: // macmerge — headless CLI (SPEC §3.10).
  - L7: // v0.1 prints a unified diff; GUI hand-off (`--wait`, opening the app)
  - L8: // arrives with the app-bundle install flow.
  - L9: //
  - L10: // Exit codes follow diff(1): 0 = identical, 1 = different, 2 = error.

### `MackDown/Sources/MackDownApp/AppearanceSettings.swift`

- Roles: Support code
- Lines: 262
- Bytes: 10158
- Imports: AppKit, SwiftUI
- Declarations:
  - struct `SyntaxHighlightColors`
  - extension `NSColor`
  - extension `Color`
  - class `AppearanceSettings` : ObservableObject
- Functions/methods: `resetSyntaxColors`, `syntaxColors`, `c`
- Stored/visible properties: `h`, `hexString`, `hexString`, `shared`, `appThemeIndex`, `contentWidth`, `paperColorIndex`, `baseFontSize`, `renderingFontFamily`, `lineSpacingMultiplier`, `showWordCount`, `outlineDisplayIndex`, `editorFontSize`, `editorFontFamily`, `editorTabSize`, `syntaxHighlighting`, `synLHeading`, `synLCode`, `synLItalic`, `synLLink`, `synLQuote`, `synLList`, `synLStrike`, `synLMatter`, `synLImage`, `synDHeading`, `synDCode`, `synDItalic`, `synDLink`, `synDQuote`, `synDList`, `synDStrike`, `synDMatter`, `synDImage`, `monospacedFonts`, `proportionalFonts`, `defaultLightHex`, `defaultDarkHex`, `d`, `l`, `label`, `colorScheme`, `appTheme`, `label`, `backgroundColor`, `foregroundColor`, `secondaryForegroundColor`, `isDark`, `paperColor`, `label`, `outlineDisplay`
- Relevant term counts: `NSColor`=7, `bestMatch`=2, `darkAqua`=2, `vibrantDark`=2, `AppKit`=1, `ObservableObject`=1, `SwiftUI`=1, `effectiveAppearance`=1
- Source comments carrying design intent:
  - L4: // MARK: - Syntax highlight color set
  - L10: // MARK: - Color hex helpers
  - L41: // MARK: - Appearance settings
  - L46: // MARK: General
  - L49: // MARK: Paper / Preview
  - L58: // MARK: Editor
  - L64: // MARK: Syntax highlight colors — light mode (muted, eye-friendly for light backgrounds)
  - L75: // MARK: Syntax highlight colors — dark mode (VS Code One Dark inspired)
  - L86: // MARK: Curated font lists for pickers
  - L105: // MARK: Default hex values (for "Reset to defaults")
  - L149: // MARK: - App theme
  - L177: // MARK: - Paper color
  - L198: // White in light mode; system window background (dark-gray) in dark mode.
  - L243: // MARK: - Outline display

### `MackDown/Sources/MackDownApp/ContentView.swift`

- Roles: Support code
- Lines: 396
- Bytes: 13531
- Imports: SwiftUI, UniformTypeIdentifiers
- Declarations:
  - struct `ContentView` : View
  - struct `WelcomeRecentRow` : View
  - struct `NavigationDocumentModifier` : ViewModifier
  - struct `GearSettingsButton` : View
  - struct `GearSettingsButtonMacOS14` : View
  - extension `View`
- Functions/methods: `loadRecentURLs`, `outlineFontSize`, `isMarkdownURL`, `body`, `hideScrollBackground`
- Stored/visible properties: `appState`, `appearance`, `isTargeted`, `recentURLs`, `outlineJump`, `markdownExts`, `body`, `mainContent`, `welcomeView`, `welcomeLeftColumn`, `welcomeRecentColumn`, `editorPane`, `shouldShowOutline`, `previewWithOutline`, `outlinePane`, `previewPane`, `ext`, `relPath`, `resolved`, `toolbarItems`, `externalChangeBar`, `dropOverlay`, `statusBar`, `wordCountLabel`, `count`, `url`, `body`, `url`, `body`, `body`
- Relevant term counts: `DispatchQueue`=1, `SwiftUI`=1
- Source comments carrying design intent:
  - L42: // MARK: - Main content
  - L63: // MARK: - Welcome view (no file open)
  - L138: // MARK: - Editor pane
  - L219: // Re-render when appearance properties that affect the theme change.
  - L226: // MARK: - Toolbar
  - L248: // MARK: - Sub-views
  - L306: // MARK: - Helpers
  - L322: // MARK: - Recent file row for welcome screen
  - L346: // MARK: - navigationDocument shim (macOS 13+ proxy icon popup)
  - L359: // MARK: - Gear / Settings button (uses openSettings env action on macOS 14+)
  - L385: // MARK: - macOS 12-compatible List background shim

### `MackDown/Sources/MackDownApp/EditorToolbar.swift`

- Roles: Support code
- Lines: 249
- Bytes: 10424
- Imports: AppKit, SwiftUI
- Declarations:
  - enum `MarkdownFormat` : Hashable
  - extension `Notification.Name`
  - struct `EditorToolbarView` : View
  - struct `SelectionToolbarView` : View
  - class `FloatingSelectionPanel` : NSPanel
- Functions/methods: `applyMarkdownFormat`, `wrapInline`, `toggleLinePrefix`, `replaceAndSelect`, `fmtBtn`, `help`, `selBtn`
- Stored/visible properties: `applyMarkdownFormat`, `sel`, `text`, `inner`, `label`, `rep`, `body`, `rep`, `rep`, `text`, `preLen`, `sufLen`, `selLen`, `inner`, `preStart`, `sufStart`, `preStr`, `sufStr`, `outerRange`, `inner`, `rep`, `offset`, `len`, `text`, `fullLen`, `lineRange`, `lineStr`, `pLen`, `newLoc`, `newLen`, `newLoc`, `newLen`, `body`, `tbDivider`, `body`
- Relevant term counts: `NSRange`=15, `NSString`=8, `NSTextView`=5, `setSelectedRange`=3, `NotificationCenter`=2, `SwiftUI`=2, `AppKit`=1, `NSHostingView`=1, `selectedRange`=1
- Source comments carrying design intent:
  - L4: // MARK: - Format actions
  - L17: // MARK: - Apply format to NSTextView (free function; called from coordinator)
  - L62: // Case A: selection itself includes the markers (e.g. user selected "**text**").
  - L69: // Case B: selection is the inner text with markers immediately outside in the document.
  - L84: // Default: wrap.
  - L99: // Remove prefix: cursor shifts left by pLen, clamped to line start.
  - L107: // Add prefix: cursor shifts right by pLen.
  - L125: // MARK: - Fixed editor toolbar strip
  - L199: // MARK: - Floating selection toolbar (SwiftUI content embedded in NSPanel)
  - L230: // MARK: - Borderless floating NSPanel hosting SelectionToolbarView

### `MackDown/Sources/MackDownApp/FrontMatterParser.swift`

- Roles: Support code
- Lines: 43
- Bytes: 1610
- Imports: Foundation
- Declarations:
  - struct `FrontMatter`
  - struct `ParsedMarkdownInput`
- Functions/methods: `parseFrontMatter`
- Stored/visible properties: `fields`, `frontMatter`, `markdownBody`, `lines`, `closingLine`, `t`, `fields`, `line`, `key`, `value`, `body`

### `MackDown/Sources/MackDownApp/MackDownApp.swift`

- Roles: Support code
- Lines: 688
- Bytes: 26814
- Imports: AppKit, Combine, SwiftUI
- Declarations:
  - enum `ViewMode` : Int, CaseIterable
  - struct `MarkdownOutlineEntry` : Identifiable, Equatable
  - struct `MarkdownOutlineJump` : Equatable
  - struct `MackDownApplication` : App
  - class `AppState` : ObservableObject
  - class `FileWatcher`
  - class `AppDelegate` : NSObject, NSApplicationDelegate, NSWindowDelegate
- Functions/methods: `benchLog`, `benchT`, `normalized`, `markDirtyImmediately`, `editorTextChanged`, `batchUpdate`, `confirmDiscardIfDirty`, `openFile`, `load`, `reloadCurrentFile`, `closeCurrentFile`, `clearDocument`, `saveCurrentFile`, `printDocument`, `invalidateRendering`, `toggleCheckbox`, `updateBlocksAsync`, `extractOutline`, `add`, `startWatching`, `restartWatcherAfterWrite`, `start`, `stop`, `openInNewWindow`, `register`, `application`, `application`, `applicationShouldTerminateAfterLastWindowClosed`, `windowShouldClose`, `windowWillClose`, `applicationDidFinishLaunching`
- Stored/visible properties: `isBenchMode`, `gBenchStart`, `line`, `id`, `level`, `title`, `line`, `occurrence`, `normalizedTitle`, `id`, `entry`, `body`, `shared`, `_isBatching`, `source`, `sourceByteCount`, `liveText`, `filename`, `filePath`, `externallyModified`, `viewMode`, `fileWatcher`, `willChangeSink`, `externalTextPublisher`, `editorCoordinator`, `checkboxRegex`, `mode`, `dirty`, `alert`, `panel`, `tLoad0`, `text`, `tRead`, `tNorm`, `tState`, `msg`, `text`, `text`, `alert`, `text`, `pi`, `pageWidth`, `attr`, `tv`, `op`, `currentText`, `lines`, `i`, `ln`, `range`, `stateRange`, `newState`, `newLn`, `newContent`, `alert`, `lastParsedSource`, `parseGeneration`, `appearance`, `baseURL`, `gen`
- Relevant term counts: `NSWindow`=7, `DispatchQueue`=6, `NSAttributedString`=5, `NSAlert`=3, `NSTextView`=2, `SwiftUI`=2, `AnyCancellable`=1, `AppKit`=1, `NSHostingView`=1, `NSOpenPanel`=1, `NSRange`=1, `NSString`=1, `NSView`=1, `ObservableObject`=1, `PassthroughSubject`=1, `containerSize`=1, `ensureLayout`=1, `isHorizontallyResizable`=1, `isVerticallyResizable`=1, `setAttributedString`=1, `widthTracksTextView`=1
- Source comments carrying design intent:
  - L5: // MARK: - Bench logging (writes to /tmp/mackdown-bench.log when --bench is active)
  - L16: // MARK: - View mode
  - L51: // MARK: - App
  - L61: // Disable press-and-hold accent picker so character keys repeat while held.
  - L62: // register(defaults:) only applies when the user hasn't set this preference themselves.
  - L123: // MARK: - App state
  - L128: // During load/reload/clear, _isBatching suppresses per-property objectWillChange signals
  - L129: // so the whole bulk update fires ONE signal instead of 8+. batchUpdate() manages the flag.
  - L132: // Disk content — the reference for dirty checks and saves.
  - L137: // Cached UTF-8 byte count of source for O(1) fast-path in editorTextChanged (R-0048-05).
  - L140: // Most-recently known live text: updated by the coordinator's debounce callback and
  - L141: // by deinit when the editor view disappears (e.g. switching to preview-only mode).
  - L142: // Used as fallback by save/print/toggle when the coordinator is not alive.
  - L145: // Attributed string derived from source. Updated on background queue, published on main.
  - L149: // Word count computed on the background parse thread (Substring-based, no String allocs).
  - L177: // Pushes text into the editor view without a SwiftUI round-trip (R-0048-02).
  - L178: // Coordinator subscribes in makeNSView; fires on load/reload/toggle/clear.
  - L180: // Weak back-reference set by the editor coordinator; used for save/print/toggle (R-0048-02).
  - L198: // Called immediately on every keystroke to keep the title dot responsive (R-0051-03).
  - L199: // The debounced editorTextChanged() still computes the correct isDirty = false if the
  - L200: // user restores the original content.
  - L205: // Called by the editor coordinator's 200 ms debounce — at most once per 200 ms (R-0048-02).
  - L206: // No full-text copy flows into AppState on every keystroke.
  - L210: // O(1) fast path: if byte counts differ, definitely dirty (R-0048-05).
  - L216: // MARK: File operations
  - L225: /// If there are unsaved edits, shows Save/Discard/Cancel. Calls `proceed` only when
  - L226: /// safe to replace the current document (no edits, user chose Discard, or save succeeded).
  - L324: // File deleted/moved — leave current content visible
  - L354: // Pull live text from NSTextView; fall back to liveText (set by debounce/deinit).
  - L400: // Clears the parse-dedup guard and re-renders with current appearance (called on theme changes).
  - L444: // MARK: Private
  - L541: // Show banner: user has unsaved edits; don't auto-reload.
  - L544: // Auto-reload silently per SPEC §3.5.
  - L560: // MARK: - File watcher (kqueue via DispatchSource)
  - L598: // MARK: - Open URL in new window
  - L619: // MARK: - App delegate
  - L622: /// Tracks extra document windows opened via link navigation.
  - L646: // Extra document windows opened via link navigation.
  - L659: // Original main document window — stays open to show welcome screen after close.
  - L675: // Heartbeat: log when main thread is blocked > 30ms between ticks

### `MackDown/Sources/MackDownApp/MarkdownAttributedRenderer.swift`

- Roles: Markdown attributed renderer/custom layout manager
- Lines: 716
- Bytes: 33304
- Imports: AppKit, Markdown
- Declarations:
  - extension `NSAttributedString.Key`
  - struct `MarkdownBlockBackground`
  - struct `MarkdownBlockLeftBorderEntry`
  - class `MarkdownBlockLeftBorders` : NSObject
  - class `MarkdownLayoutManager` : NSLayoutManager
  - class `MarkdownAttributedRenderer`
- Functions/methods: `drawBackground`, `flush`, `parseAttributed`, `countWords`, `render`, `renderBlock`, `renderInlines`, `renderInline`, `renderHeadingRule`, `renderHeading`, `renderParagraph`, `renderCodeBlock`, `renderCodeBlock`, `renderBlockQuote`, `renderUnorderedList`, `renderOrderedList`, `renderBulletItem`, `renderOrderedItem`, `renderTaskItem`, `renderTable`, `renderThematicBreak`, `renderFrontMatter`, `applyBold`, `applyItalic`, `applyStrikethrough`, `renderInlineCode`, `renderLink`, `renderImage`, `bodyParagraphStyle`, `listParagraphStyle`
- Stored/visible properties: `markdownBlockBackground`, `markdownBlockLeftBorders`, `markdownCopyCode`, `markdownInlineCode`, `markdownHeadingTitle`, `color`, `borderColor`, `topInset`, `bottomInset`, `color`, `xOffset`, `width`, `list`, `charRange`, `prev`, `gr`, `rects`, `bounding`, `pad`, `rect`, `path`, `bp`, `pad2`, `gr`, `rects`, `bounding`, `barRect`, `gr`, `iStart`, `iEnd`, `codeRect`, `vMargin`, `r`, `path`, `theme`, `renderer`, `theme`, `baseURL`, `parsed`, `doc`, `out`, `out`, `out`, `out`, `para`, `bg`, `level`, `font`, `color`, `para`, `inner`, `result`, `all`, `inner`, `result`, `all`, `para`, `code`, `bg`, `copyURL`
- Relevant term counts: `NSAttributedString`=57, `NSMutableAttributedString`=27, `NSRange`=19, `NSMutableParagraphStyle`=14, `NSFont`=13, `NSAttributedString.Key`=10, `NSColor`=6, `NSBezierPath`=4, `drawBackground`=3, `glyphRange`=3, `lineFragmentPadding`=3, `AppKit`=2, `Task`=2, `NSLayoutManager`=1, `NSTextAttachment`=1, `NSView`=1, `boundingRect`=1, `characterRange`=1, `containerSize`=1, `linkTextAttributes`=1
- Source comments carrying design intent:
  - L4: // Resolve name conflicts with AppKit
  - L10: // MARK: - Custom block-background attribute
  - L33: // NSObject wrapper so NSAttributedString can store/copy the array safely.
  - L39: // MARK: - Layout manager that draws full-width paragraph backgrounds
  - L71: // 1. Draw full-width block backgrounds (code blocks, blockquotes, front matter, heading rules).
  - L86: // 2. Draw blockquote left-border bars.
  - L96: // Extend 1pt top/bottom to close hairline gaps between adjacent paragraphs.
  - L108: // 3. Draw inline code rounded backgrounds (drawn before super so selection renders on top).
  - L133: // 4. Super draws selection highlights and NSTextTable cell backgrounds on top.
  - L138: // MARK: - Top-level parse function (replaces parseBlocks)
  - L148: // MARK: - Word count helper
  - L154: // MARK: - Renderer
  - L174: // MARK: - Block dispatch
  - L196: // MARK: - Inline dispatch
  - L223: // MARK: - Heading
  - L229: // topInset:0 — flush with heading text bottom; bottomInset:18 — strips paragraphSpacing(16)+2
  - L230: // so the colored band covers only the ~font-height, not the post-rule gap.
  - L263: // MARK: - Paragraph
  - L276: // MARK: - Code block
  - L305: // No language label: add a minimal right-aligned copy hint.
  - L338: // MARK: - Block quote
  - L353: // Indent paragraph styles for this depth level.
  - L363: // Accumulate a left-border entry for this depth without overwriting inner depth entries.
  - L380: // MARK: - Lists
  - L493: // Re-apply checkbox link attributes (overrides baseAttrs on first two chars)
  - L498: // MARK: - Table
  - L575: // MARK: - Thematic break
  - L581: // topInset:12 — strips paragraphSpacingBefore(12); bottomInset:12 — strips paragraphSpacing(12).
  - L582: // Colored band covers only the font line height between the two spacing regions.
  - L592: // MARK: - Front matter
  - L622: // MARK: - Inline formatting
  - L665: // Always set theme link color; makeNSView clears the foreground override in linkTextAttributes.
  - L697: // MARK: - Paragraph style helpers

### `MackDown/Sources/MackDownApp/MarkdownEditorView.swift`

- Roles: Markdown editor bridge
- Lines: 449
- Bytes: 23556
- Imports: AppKit, Combine, SwiftUI
- Declarations:
  - struct `MarkdownEditorView` : NSViewRepresentable
  - class `Coordinator` : NSObject, NSTextViewDelegate, NSTextStorageDelegate
- Functions/methods: `makeNSView`, `updateNSView`, `makeCoordinator`, `lineIndex`, `startOffset`, `subscribeToExternalText`, `textStorage`, `textDidChange`, `textViewDidChangeSelection`, `scheduleBackgroundHighlight`, `showFloatingPanel`, `applyTabStops`
- Stored/visible properties: `initialText`, `onTextChanged`, `onViewDisappear`, `externalTextPublisher`, `appearance`, `scrollView`, `bg`, `initCW`, `cW`, `targetFont`, `fontChanged`, `tabChanged`, `syntaxChanged`, `text`, `editorBackground`, `ns`, `clamped`, `lines`, `line`, `pos`, `parent`, `lastSyntaxHighlighting`, `lastTabSize`, `isInitialLoad`, `savedSelectedRange`, `isApplyingFormat`, `undoEditLoc`, `undoDelta`, `textViewRef`, `floatingPanel`, `formatObserver`, `firstResponderObservation`, `debounceTimer`, `externalTextSink`, `highlightGeneration`, `highlightDebounceTimer`, `lastText`, `coordinator`, `tv`, `len`, `loc`, `rLen`, `newRange`, `caretPos`, `nsOld`, `caretLine`, `nsNew`, `lineStart`, `pos`, `lines`, `line`, `str`, `fullLen`, `isDark`, `colors`, `fontSize`, `family`, `enabled`, `loc`, `evalRange`
- Relevant term counts: `NSTextView`=13, `NSString`=11, `NSTextStorage`=10, `NSRange`=8, `NSView`=7, `NSTextStorageDelegate`=5, `DispatchQueue`=4, `NSColor`=3, `SwiftUI`=3, `bestMatch`=3, `darkAqua`=3, `glyphRange`=3, `selectedRange`=3, `vibrantDark`=3, `AppKit`=2, `NSScrollView`=2, `NSTextViewDelegate`=2, `NotificationCenter`=2, `PassthroughSubject`=2, `containerSize`=2, `drawsBackground`=2, `effectiveAppearance`=2, `setSelectedRange`=2, `textContainerInset`=2, `AnyCancellable`=1, `KVO`=1, `NSLayoutManager`=1, `NSMutableParagraphStyle`=1, `NSViewRepresentable`=1, `allowsNonContiguousLayout`=1, `beginEditing`=1, `boundingRect`=1, `defaultParagraphStyle`=1, `didProcessEditing`=1, `endEditing`=1, `typingAttributes`=1
- Source comments carrying design intent:
  - L6: // Editor owns its live text in NSTextView; AppState never receives the full string on
  - L7: // every keystroke. These three params replace the old @Binding var text (R-0048-02).
  - L27: // Non-contiguous layout: layout manager only typesets visible glyphs, making
  - L28: // initial display of large documents near-instant instead of blocking on full layout.
  - L40: // Pre-size so NSLayoutManager gets a real container width before the first string
  - L41: // assignment. A zero-width container forces one line-fragment per character
  - L42: // (258K frags for 258 KB), causing a 400 ms+ display stall.
  - L47: // isInitialLoad suppresses the synchronous NSTextStorageDelegate highlight callback
  - L48: // so the text appears immediately; deferred async applyFull runs on the next pass.
  - L52: // lastText must be set here so that deinit has correct content if the user
  - L53: // switches modes before typing (SwiftUI recreates MarkdownEditorView on every
  - L54: // structural-position change; the new coordinator starts with lastText = "")
  - L55: // (R-0052-01 residual fix for R-0050-03).
  - L61: // Register coordinator with AppState so save/print can pull live text directly
  - L62: // from NSTextView without a SwiftUI binding round-trip (R-0048-02).
  - L65: // Subscribe coordinator to external text pushes (load/reload/toggle/clear).
  - L68: // Defer initial full-document syntax highlight: text appears first, highlight follows.
  - L69: // Runs on background thread so 258KB+ files don't block the main thread (R-0049-01).
  - L86: // Font sync
  - L91: // Tab size sync
  - L98: // Syntax highlighting toggle
  - L102: // External text changes (load/reload/toggle) arrive via externalTextPublisher, not here.
  - L103: // updateNSView is now called only for appearance changes, not for every keystroke.
  - L105: // Settings change: re-highlight the whole document on background thread (R-0049-01).
  - L120: // MARK: - Dynamic background color
  - L132: // MARK: - Cursor position helpers (UTF-16 safe)
  - L148: // MARK: - Coordinator
  - L154: /// True while externalTextPublisher is being applied; suppresses sync highlight and
  - L155: /// textDidChange debounce so the external push doesn't echo back to AppState.
  - L157: /// Persists the last known selection so toolbar buttons can restore it after focus change.
  - L159: /// True while a toolbar format action is being applied; suppresses savedSelectedRange updates.
  - L161: /// Location and delta captured from NSTextStorageDelegate during undo/redo.
  - L168: // Debounce for pushing text to AppState — replaces the old Combine pipeline (R-0048-02).
  - L170: // Subscription to AppState.externalTextPublisher for load/reload/toggle/clear.
  - L172: // Background highlight coordination (R-0049-01/02).
  - L173: // Incremented on each background highlight dispatch; stale completions compare and bail.
  - L176: // Cached text updated on main thread in textDidChange; used in deinit instead of
  - L177: // tv.string to avoid a potential NSTextStorage read off the main thread (R-0050-03).
  - L198: // Persist the post-format selection; without this, a second toolbar click
  - L199: // reads the stale pre-format savedSelectedRange and wraps again, producing
  - L200: // e.g. ****an app**le** (R-0051-04).
  - L212: // Cancel pending async work before any further teardown (R-0049-03).
  - L217: // Push the live text to AppState so save works when the editor pane disappears
  - L218: // (e.g. user switches to preview-only mode).
  - L219: // Use lastText rather than tv.string — the NSTextStorage may be on a layout pass
  - L220: // and tv.string is unsafe to read off the main thread (R-0050-03).
  - L226: // Sets up the Combine subscription that receives text pushed by AppState
  - L227: // (load/reload/toggle/clear) and applies it to NSTextView.
  - L234: // Preserve caret line so the view doesn't jump to top on reload.
  - L241: // isInitialLoad suppresses the NSTextStorageDelegate sync highlight so
  - L242: // text appears immediately; deferred async applyFull handles coloring.
  - L246: // Cache the loaded text so deinit has a non-empty lastText even when the
  - L247: // user switches away before typing (R-0051-01 regression fix for R-0050-03).
  - L249: // Restore caret position (clamped to new length).
  - L259: // Background highlight: text is visible first, coloring follows on background
  - L260: // thread so large files don't block the main thread (R-0049-01).
  - L271: // MARK: NSTextStorageDelegate
  - L280: // Skip during external text assignments; scheduleBackgroundHighlight handles those.
  - L298: // Immediate feedback: paragraph-level inline highlight on main thread (fast path).
  - L299: // No isLargeFile gate — syntax highlighting is never disabled for any file size (R-0049-02).
  - L303: // Expand scan window when the paragraph contains backticks or the document has
  - L304: // code fences: the paragraph alone doesn't include the opening/closing delimiters,
  - L305: // so the inline reset would strip code-block foreground color for up to 300 ms
  - L306: // until the debounced full-document pass corrects it (R-0050-02).
  - L318: // Debounced background full-document highlight: fires 300 ms after typing settles.
  - L319: // String(…) forces an independent copy of the NSTextStorage backing buffer so the
  - L320: // background thread never aliases live storage memory (R-0049-01).
  - L326: // MARK: NSTextViewDelegate
  - L330: // Cache current text on main thread for safe use in deinit (R-0050-03).
  - L332: // For undo/redo, rely on AppKit's native cursor placement via the undo stack
  - L333: // (shouldChangeText registers cursor state). Custom offset math conflicts with
  - L334: // programmatic format replacements and causes incorrect shifts (R-0050-01).
  - L335: // Skip dirty marking only: undoing back to original must not re-set isDirty = true
  - L336: // (R-0051-03). Still debounce onTextChanged so the preview updates after undo/redo.
  - L339: // Update the title dot immediately so it responds during fast typing without
  - L340: // waiting for the 200 ms debounce (R-0051-03).
  - L343: // Debounce: push text to AppState at most once per 200 ms (R-0048-02).
  - L344: // No full-text copy flows to AppState on every keystroke.
  - L357: // Lazily set up first-responder KVO once the text view has a window.
  - L377: // Dispatches collectTokensFull to a background queue and applies results on main.

### `MackDown/Sources/MackDownApp/MarkdownPreviewTextView.swift`

- Roles: Markdown preview TextKit stack
- Lines: 188
- Bytes: 8985
- Imports: AppKit, SwiftUI
- Declarations:
  - struct `MarkdownPreviewTextView` : NSViewRepresentable
  - class `Coordinator` : NSObject, NSTextViewDelegate, NSLayoutManagerDelegate
- Functions/methods: `makeCoordinator`, `makeNSView`, `updateNSView`, `layoutManager`, `textView`, `scrollToHeading`
- Stored/visible properties: `attributedString`, `onToggleCheckbox`, `onRelativeLink`, `outlineJump`, `textStorage`, `layoutMgr`, `container`, `textView`, `scrollView`, `textView`, `textView`, `onToggle`, `onRelativeLink`, `textViewRef`, `scrollViewRef`, `lastAttributedString`, `pendingScrollOrigin`, `lastOutlineJumpID`, `origin`, `sv`, `docH`, `clipH`, `maxY`, `clamped`, `code`, `layoutManager`, `container`, `scrollView`, `seen`, `target`, `fullRange`, `glyphRange`, `rect`, `y`
- Relevant term counts: `NSTextView`=9, `NSScrollView`=4, `NSView`=4, `NSAttributedString`=3, `NSLayoutManager`=3, `didCompleteLayoutFor`=3, `glyphRange`=3, `textContainerInset`=3, `NSPasteboard`=2, `NSRange`=2, `NSTextContainer`=2, `NSViewRepresentable`=2, `contentView.scroll`=2, `documentRect`=2, `drawsBackground`=2, `reflectScrolledClipView`=2, `scrollTo`=2, `setAttributedString`=2, `AppKit`=1, `NSCursor`=1, `NSLayoutManagerDelegate`=1, `NSTextStorage`=1, `NSTextViewDelegate`=1, `NSWorkspace`=1, `SwiftUI`=1, `autoresizingMask`=1, `boundingRect`=1, `clickedOnLink`=1, `ensureLayout`=1, `isHorizontallyResizable`=1, `isVerticallyResizable`=1, `linkTextAttributes`=1, `widthTracksTextView`=1
- Source comments carrying design intent:
  - L4: // MARK: - NSViewRepresentable wrapping an NSTextView for rich markdown preview
  - L27: // Manual construction so we can inject MarkdownLayoutManager.
  - L34: // Single-pass layout required so documentRect.height is accurate when
  - L35: // didCompleteLayoutFor fires and we restore the scroll position.
  - L50: // Read-only preview — disable all text-editing assistance.
  - L62: // Theme-consistent link appearance; foreground color is set by the renderer.
  - L93: // Skip if the attributed string object hasn't changed (e.g. isDirty re-renders).
  - L99: // Scroll position is restored in layoutManager(_:didCompleteLayoutFor:atEnd:)
  - L100: // after NSLayoutManager finishes laying out the new content.
  - L103: // MARK: - Coordinator
  - L137: // Copy-code links on language labels / copy hint
  - L147: // Checkbox toggle links
  - L153: // Web/scheme URLs — let NSTextView handle via NSWorkspace
  - L156: // Relative (nil-scheme) links — delegate to caller for markdown navigation

### `MackDown/Sources/MackDownApp/MarkdownSyntaxHighlighter.swift`

- Roles: Markdown syntax highlighter
- Lines: 307
- Bytes: 16133
- Imports: AppKit
- Declarations:
  - struct `SyntaxToken`
  - enum `MarkdownSyntaxHighlighter`
- Functions/methods: `baseFont`, `boldFont`, `italicFont`, `collectTokensFull`, `collectTokensInline`, `applyTokens`, `applyFull`, `applyInline`, `highlight`, `highlight`, `collect`, `collectDelimDim`, `collectHeadingWithDim`
- Stored/visible properties: `range`, `attributes`, `base`, `base`, `codeBackground`, `reFrontMatter`, `reCodeFence`, `reCodeFenceLang`, `reSetextH1`, `reSetextH2`, `reHeadingCapture`, `reBoldItalic`, `reBold`, `reItalicStar`, `reItalicUnder`, `reStrike`, `reImage`, `reLink`, `reAutoLink`, `reCodeInline`, `reBlockquote`, `reOrderedList`, `reUnorderedList`, `reTable`, `reHRule`, `reCheckbox`, `ns`, `fullLen`, `fullRange`, `base`, `bold`, `italic`, `tokens`, `ns`, `fullLen`, `loc`, `len`, `safe`, `base`, `bold`, `italic`, `tokens`, `tokens`, `tokens`, `isDark`, `colors`, `dim`, `dim`, `prefixRange`, `textRange`
- Relevant term counts: `NSColor`=11, `NSFont`=11, `NSRange`=10, `NSAttributedString`=6, `NSAttributedString.Key`=6, `NSString`=6, `NSTextStorage`=5, `endEditing`=4, `beginEditing`=3, `bestMatch`=2, `darkAqua`=2, `vibrantDark`=2, `AppKit`=1, `effectiveAppearance`=1
- Source comments carrying design intent:
  - L3: // MARK: - Token type (produced by background thread, consumed on main thread)
  - L12: // MARK: - Fonts
  - L32: // MARK: - Dynamic code background (evaluates appearance at draw time, safe to store in tokens)
  - L40: // MARK: - Pre-compiled patterns
  - L64: // MARK: - Token collection (pure, thread-safe — operates on a String snapshot)
  - L65: //
  - L66: // Call these from any thread. Pre-create font and color objects on the main thread
  - L67: // and pass them in; NSFont / NSColor are safe to *use* (read) from background threads.
  - L85: // Pre-size: 20 patterns × average 10 matches for a medium file → ~200 tokens typical
  - L88: // Reset token covers the full document.
  - L157: // Paragraph-level reset: foreground/font/strike only — do not touch .backgroundColor.
  - L195: // Apply a pre-computed token array to storage.
  - L196: // Must be called on the main thread; caller wraps in beginEditing/endEditing.
  - L203: // MARK: - Full-document apply (convenience — still runs on caller's thread)
  - L217: // MARK: - Paragraph-level apply (convenience — still runs on caller's thread)
  - L234: // MARK: - Public highlight wrappers (with begin/endEditing — for external callers)
  - L254: // MARK: - Private collect helpers (thread-safe; operate on a pre-bridged NSString)

### `MackDown/Sources/MackDownApp/MarkdownTheme.swift`

- Roles: Support code
- Lines: 135
- Bytes: 6851
- Imports: AppKit
- Declarations:
  - struct `MarkdownTheme`
  - extension `MarkdownTheme`
- Functions/methods: `headingFont`, `githubLight`, `githubDark`, `current`, `c`, `makeBodyFont`
- Stored/visible properties: `textColor`, `secondaryTextColor`, `linkColor`, `codeTextColor`, `inlineCodeBackground`, `codeBlockBackground`, `codeBlockBorderColor`, `quoteBorderColor`, `quoteTextColor`, `tableHeaderBackground`, `tableBorderColor`, `tableAltRowBackground`, `hrColor`, `frontMatterBackground`, `frontMatterTextColor`, `frontMatterKeyColor`, `bodyFont`, `codeFont`, `paragraphSpacing`, `blockSpacing`, `lineHeightMultiple`, `contentInset`, `s`, `sizes`, `sz`, `isDark`, `baseSize`, `lineSpacing`, `codeSize`, `family`, `theme`, `bg`, `br`, `bg`, `br`, `bg`, `br`
- Relevant term counts: `NSColor`=42, `NSFont`=11, `AppKit`=1
- Source comments carrying design intent:
  - L3: // MARK: - Theme
  - L6: // Colors
  - L24: // Fonts
  - L28: // Spacing
  - L43: // MARK: - GitHub presets
  - L109: // Paper-adaptive code block and inline-code backgrounds.

### `MackDown/Sources/MackDownApp/SettingsView.swift`

- Roles: Support code
- Lines: 365
- Bytes: 13197
- Imports: AppKit, SwiftUI
- Declarations:
  - struct `EscapeKeyInterceptor` : NSViewRepresentable
  - class `EscView` : NSView
  - struct `SettingsView` : View
- Functions/methods: `makeNSView`, `updateNSView`, `viewDidMoveToWindow`, `settingsSectionHeader`, `colorRow`, `colorBinding`
- Stored/visible properties: `view`, `monitor`, `appearance`, `colorsDark`, `body`, `generalPane`, `editorPane`, `previewPane`, `colorsPane`, `settingsDivider`, `binding`
- Relevant term counts: `NSView`=6, `NSEvent`=3, `AppKit`=1, `NSViewRepresentable`=1, `SwiftUI`=1, `bestMatch`=1, `darkAqua`=1, `effectiveAppearance`=1, `vibrantDark`=1
- Source comments carrying design intent:
  - L4: // MARK: - Esc key interceptor (closes the Settings window)
  - L29: // MARK: - Settings view
  - L56: // MARK: - General
  - L86: // MARK: - Editor
  - L161: // MARK: - Preview
  - L269: // MARK: - Colors
  - L320: // MARK: - Shared row components (matching Colors pane style)

### `MackDown/Sources/MackDownApp/UpdaterController.swift`

- Roles: Support code
- Lines: 15
- Bytes: 467
- Imports: Sparkle
- Declarations:
  - class `UpdaterController`
- Functions/methods: `checkForUpdates`
- Stored/visible properties: `shared`, `spu`
- Source comments carrying design intent:
  - L1: // Sparkle auto-updater controller — compiled only when Sparkle is vendored.
  - L2: // Enable: WITH_SPARKLE=1 ./scripts/vendor.sh && make build

### `MackDown/Sources/mackdown-cli/main.swift`

- Roles: Core diff/text/git/model logic
- Lines: 39
- Bytes: 1006
- Imports: Foundation
- Stored/visible properties: `version`, `args`, `resolvedPaths`, `hasError`, `url`, `proc`
- Source comments carrying design intent:
  - L19: // Resolve and validate each path
  - L33: // Open all files in MackDown.app via /usr/bin/open
